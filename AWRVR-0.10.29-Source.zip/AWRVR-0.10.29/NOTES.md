# AWRVR - technical notes

Reverse-engineering notes for Alan Wake Remastered (`Game_f_x64_EOS.exe`, x64, Northlight, D3D12). Addresses are RVAs
in the analysed build (PE timestamp 0x697455b7, image base 0x140000000, not packed, no relocations); **the mod does
not use them** - they are here so the next person can check a new build quickly. Everything the mod needs is found
at run time (see "How each item is located").

## Executable
- Imports: dbghelp.dll (MiniDumpWriteDump only), dxgi.dll (CreateDXGIFactory only), d3d12.dll (ordinals 101/102 +
  D3D12SerializeRootSignature), XINPUT1_4 (ordinals 2, 3), bink2w64, fmod, EOSSDK. No dinput8 / version / winmm import,
  so the proxy is dbghelp.dll (as the head-tracking mod found).
- RTTI intact. Classes of interest: rend::View, rend::PerspectiveView, rend::CustomView, BaseCamera, PlayerCamera,
  CinematicCamera, FreeCamera, DeathCamera, RenderViewD3D12, Umbra::Camera.
- Settings: `%sresolution.xml` (screen_resolution width/height, window_mode, dlss, display, hdr) under
  Documents (SHGetFolderPathW CSIDL_PERSONAL) + "...AlanWakeRemastered\".
- Tweakables: Camera:FOV default 88 (15..150), Camera:Near default 0.2 (0.1..0.5) -> world units are metres.

## rend::PerspectiveView (vtable exe+751BD8)
- 3 virtuals: 0 destructor, 1 clone (allocates 0xCC8, exe+463270), 2 getProjection(double out[16]) (exe+4637F0).
  BaseCamera (vtable exe+752AD0), PlayerCamera (exe+769280) share slots 1 and 2: cameras ARE views.
- Lens: +0xCB0 horizontal FOV (rad, default pi/2), +0xCB4 zoom (1), +0xCB8 aspect w/h, +0xCBC near, +0xCC0 far (100).
- getProjection: t = tan(fov/2); m00 = 1/(t zoom), m11 = aspect/(t zoom), m22 = f/(f-n), m23 = 1, m32 = -n f/(f-n):
  left-handed, row vectors, camera looks along +z.
- Setters: setAspect exe+463C30, setFar exe+463C50, setFov exe+463C70: `movss [rcx+field], xmm1; mov word [rcx+4A8], 0; ret`.
- getVFov exe+463AA0 = 2 atan(tan(fov/2 zoom)/aspect); other getters read the fields directly (culling, frustum corners at
  exe+475180) - so the mod writes the fields rather than only patching the returned matrix.

## Camera transform
- BaseCamera keeps its transform as floats at +0xCC8: rows right +0xCC8, up +0xCD4, forward +0xCE0 (tight 3x3) and
  position +0xCEC (the head-tracking mod's "rbx + 0x24" struct is this one).
- BaseCamera::applyTransform exe+15E650 converts it to 12 doubles and calls Node::setTransform exe+15E2F0
  (stores +0x1E8 and +0x248..+0x2A0, position doubles at +0x290, clears +0x4A9). Setters that end in applyTransform:
  exe+15E210 (full 3x4), exe+15E280 (position), exe+15E2A0 (rotation).
- View matrices are built lazily (exe+46C500: +0x1E8 -> 4x4 +0x3A8 -> inverse -> +0x2A8/+0x428 -> float buffers),
  per-thread buffered (TLS index * 0x40 at +0xB30...).
- The head-tracking mod's hook (after the lookAt call at exe+15DFD9) is inside a camera controller; the mod uses the
  setTransform funnel instead so every camera type (player, cinematic, free, death) is covered.

## How each item is located (src/engine.cpp, src/scan.cpp)
1. `.?AVPerspectiveView@rend@@` -> TypeDescriptor -> CompleteObjectLocator (signature 1, offset 0, pSelf = its RVA) ->
   vtable; slot 2 = getProjection. Fallback pattern `48 89 5C 24 08 57 48 83 EC ?? F3 0F 10 81 ?? ?? ?? ?? 48 8B DA 0F 5A C0`.
2. Lens offset = disp32 of the first `F3 0F 10 81` in getProjection; confirmed by finding `movss xmm7,[rdi+fov+8]`,
   `subss xmm0,[rdi+fov+C]`, `movss xmm1,[rdi+fov+10]`, `movss xmm0,[rdi+fov+4]` (2 of 4 needed).
3. Setters: `F3 0F 11 89 <field32> 66 C7 81 ?? ?? ?? ?? 00 00 C3` for fov and aspect (dirty offset from the match).
4. applyTransform: `48 8B C4 48 81 EC ?? ?? ?? ?? F3 0F 10 81 ?? ?? ?? ?? 48 8D 50 ?? F3 0F 10 89 ?? ?? ?? ?? 0F 5A C0 0F 5A C9`
   with the second displacement = first + 4; setTransform = the `E8` followed by `48 81 C4` (epilogue). Fallback: the
   setTransform prologue `48 89 5C 24 08 48 89 7C 24 10 55 48 8B EC 48 83 EC ?? 48 8B 02 48 8D 99 ...` (2 hits in this
   build: exe+15E2F0 and exe+4893D0, a sibling node class; both may be hooked, the detour filters by object).
5. Main view: every getProjection call notes `this` (lens sane). At each Present the busiest one whose aspect equals the
   back buffer's (or the VR aspect the mod set) becomes the main view; kept while it is used, dropped after 120 Presents.

## Frame flow
- Camera thread: setTransform(main view) -> base transform -> optional decoupled pitch / offsets -> eye pose (AER: eye =
  parity of the target Present; head: centre pose) -> record {eye, pose, frustum} for Present (count + lag) -> lens
  written (symmetric headset frustum) -> original setTransform with the eye transform.
- Present thread: record for this Present (or the last one for up to 3 Presents; else flat screen) -> D3D12: back buffer
  PRESENT->COPY_SOURCE, shared texture COMMON->COPY_DEST, CopyResource, back; game queue waits for D3D11's "read done"
  fence before writing a shared texture again -> D3D11 waits for D3D12's fence, blits into the eye texture -> atlas slot
  (keyed mutex) -> ClientSubmitSlot with each eye's own pose and the frustum it was rendered with.
- The submitted FOV is exactly the frustum the game rendered with, so the picture is geometrically correct at any render
  size / aspect; the runtime crops it to each eye.

## 0.2.0 research (same build, RVAs)
- **Tweakables**: registered as `lea rdx,[name]; lea rcx,[object]; call exe+461320` (about 1,450 in this build). The
  value is at object+0xB0 (float, or vec4 for positions).
  - Used: `Camera:Near` exe+b1e550, `Camera:FOV` exe+b1e3d0, `TAA:Jitter Scale` exe+dbfe20, `TAA:Resolve` exe+dbf2c0.
  - Also: `Cinematic Effect:Vignette` exe+af5ae0, `Vector Blur:Enable` / `Force Enable` exe+dafbb0 / dafc70.
  - Also: `Camera:High/Mid/Low/Safe Pos` exe+b1f210 / b1f2f0 / b1f3d0 / b1f4b0. Mid defaults to (0.55, -0.0357, -2.2):
    the shoulder camera's offset from its pivot.
- **Renderer debug variables** (~124): bound as
  `lea rdx,[name]; mov rcx,[rdi+0xb0]; call; mov rcx,rax; lea rdx,[var]; call`. The bytes are:
  - `TAA` exe+955636, `Antialiasing` exe+d755d8, `Render Vector Blur` exe+95565b, `Film grain` exe+d755da
  - `Enable Film Grain d3t` exe+955667, `Use Umbra` exe+955639, `Cinematic Mode` exe+d75614, `VSync Enabled` exe+95566c
- **Main loop frame timer**:
  - Pattern `48 8D 0D ?? ?? ?? ?? E8 ?? ?? ?? ?? 8B 15 ?? ?? ?? ?? 0F 57 FF 4C 8B 05 ?? ?? ?? ?? 41 0F 28 F1 F2 0F 5A F8`
    matches at exe+1df9b8. The timer object is exe+b06c18 and `Timer::lap` is exe+3c7bf0.
  - A held lap returns a tiny dt and banks the real time for the next lap: synchronized stereo.
- **Frame limiter**: `F3 44 0F 10 05 ?? ?? ?? ?? 45 0F 57 C9 41 0F 2F C1 76 ?? F3 0F 10 0D` + 17 = `jbe` at exe+1df966.
  `EB` skips the wait.
- **Mode classes** (RTTI, slot 6 = per-frame update): GameMode exe+1d8d60, MenuMode exe+259560, LoadingMode exe+2375a0,
  VideoMode exe+337140, CreditsMode exe+1a3940. They are hooked with tiny asm thunks that only count, so all argument
  registers are kept.
- **Focus**: `ModeSwitch` secondary vtable (complete-object offset 8) is at exe+766f88; slot 15 is exe+2627b0.
  - It does `cmp byte [rdx+4],0` and prints "ModeSwitch: Focus Event - %s Focus\n" with "Gained" (nonzero) or "Lost" (0).
  - The mod drops only the Lost events.
- **Player**: the "Player    %.2fm/s" print loads the global player at exe+b00020 (getPlayer = `48 8B 05 rel; C3`). The
  character is at player+0x50.
- **Bink**: bink2w64 BinkOpen / BinkClose / BinkNextFrame are imported by name. HBINK starts with width and height.
- **D3D12 vtable slots used**:
  - Device: CreateGraphicsPipelineState 10, CreateRTV 20, CreateDSV 21, CopyDescriptorsSimple 24.
  - Command list: Reset 10, DrawInstanced 12, DrawIndexedInstanced 13, RSSetViewports 21, RSSetScissorRects 22,
    SetPipelineState 25, ResourceBarrier 26, OMSetRenderTargets 46, ExecuteIndirect 59.
  - List5: RSSetShadingRate 77, RSSetShadingRateImage 78.
  - Swap chain: Present 8, SetFullscreenState 10, ResizeBuffers 13, Present1 22, ResizeBuffers1 39.
  - Factory: MakeWindowAssociation 8, CreateSwapChain 10, CreateSwapChainForHwnd 15.
- **Not found** (so not offered): depth of field / radial blur switches, a launcher, a head-mesh hide switch.

## 0.3.0 research (1.33 build, timestamp 0x697455b7)
- **The supplied exe is the 1.33 update** (26 Feb 2026). It has the `Camera:Modern ...` tweakables, HDR (`hdr_supported`
  in resolution.xml, Tonemap:HDR ...) and an R10G10B10A2 output path.
- **Tweakable memory layout:**
  - float: value +0xB0, min +0xB4, max +0xB8.
  - vec3: value +0xB0..B8, min +0xBC..C4, max +0xC8..D0.
  - Camera positions range from -4 to 4 m. Mid is (0.55, -0.0357, -2.2): x right, y up, z forward from the pivot.
- **Player camera:**
  - The constructor (exe+2ed330..ed50e) copies the tweakables into per-camera fields: +0x134 Zoom Factor, +0x138
    Switch Side Speed, +0x144 Catch Amount, +0x148 Catch Speed, +0x14C Angle × deg→rad, +0x158 / 164 / 170 / 17C
    High / Mid / Low / Safe Pos.
  - The per-frame update (exe+2ef3a0, the blend at exe+2ef8b1..2efb80) eases each field toward the live tweakable:
    field = field·(1-k) + tweak·k. Writing a tweakable therefore takes effect at once, smoothly.
- **Catch Amount** (0.1, range 0–1) multiplies a velocity term at exe+2ee71c. It is the camera trailing behind the
  moving player.
- **Camera:Angle** (7°, range 0–45) is the toe-in of the shoulder camera. The style switch scales it ×0.3 for the
  modern style (Modern Central Angle Scale) together with x × 0.8 (Modern Central Offset Scale). Its getter exe+2eee70
  is called through exe+29bc50.
- **Camera-style switch** at exe+2f00f0 (`this`, new style dl, old style r8b):
  - When dl ≠ r8b it rewrites the tweakables themselves: x of High / Mid / Low scaled by 1/0.8 or 0.8, Angle by 1/0.3
    or 0.3, y / z moved per camera mode (+0x108 vs +0x118 / +0x120).
  - It is found as the only function reading Modern Central Offset Scale that also reads Mid Pos and Angle.
- **The pivot** comes from the character in the update at exe+2ef3a0. The final transform is built at exe+2ed8d0:
  rotation from r8, position from r9+0x24.
- **Free Camera** tweakables exist (Free Camera:Movement Speed, Teleport X / Y / Z ...): the debug free camera.
- **Mods researched:**
  - Nexus #9 "HUD and invisible character toggler" (ReShade Shader Toggler). Hiding Alan's shaders also hides NPCs,
    vehicles, doors and manuscripts; there is no separate player-mesh switch.
  - The Cheat Engine tables and trainers (alien66, WeMod-style +8) are gameplay only (health, ammo, flashlight).
- **D3D12 in Wine for testing:** Wine 9 + vkd3d + Mesa lavapipe under xvfb runs a D3D12 swap chain. Wine's own HLSL
  compiler lacks Interlocked* functions.

## 0.4.0 research: the 3D path
- **getProjection** (exe+4637f0):
  - It copies a static identity, then writes out[0] = 1/(t·zoom), out[5] = aspect/(t·zoom), out[10] = f/(f-n),
    out[11] = 1, out[14] = -n·f/(f-n). out[8] / out[9] are 0: the off-centre terms (row-major, row vectors,
    left-handed).
  - There is no jitter inside.
- **Lazy matrices:**
  - exe+46c890 (update) does: if byte +0x4A8 == 0, exe+46c120 (projection); if byte +0x4A9 == 0, exe+46c500 (world /
    view).
  - exe+46c120 calls vtable slot 2 (getProjection), multiplies the result by the matrix at +0x8 (TAA jitter, set by
    exe+46c090 from RendererD3D12 slot 10, exe+508970), and stores it at +0x2A8 / +0x328, with floats in per-thread
    slots at +0x730.
  - exe+46c500 builds the world matrix from +0x1E8, then the view matrix (+0x3A8 / +0x428, floats +0x9B0 / +0xAF0) and
    sets +0x4A9 = 1.
  - The per-thread slot is base + (TLS[+0x30060] + 1)·0x40 (exe+15e140).
  - The lens setters clear the 16-bit word at +0x4A8, which covers both flags. Node::setTransform clears only +0x4A9.
- **Clone** (vtable slot 1, exe+463270, the same function for PerspectiveView and every camera class): it allocates
  0xCC8 from the passed allocator, then copies the lens fields, +0x1E8, all matrix slots and both dirty bytes
  (exe+46a4f0).
- **Culling / shadow frusta** come from the lens getters: far exe+463790, near exe+4637e0, fov exe+4637a0, used by
  exe+475180 and others.
- **OrthoView** (vtable exe+7ac138) and **CustomView** (exe+792420) use the same field offsets with other meanings.
- **Frame-time function** exe+1df8d0 (called once per frame from exe+263642):
  - The lap goes to xmm7, i.e. raw.
  - The step is xmm6 = the average of the ring before pushing the new sample. The ring is index exe+92d1d8, count +4,
    size +8 (= 4), array pointer +16. Samples are clamped to 0.1 s.
  - Raw dt is stored at exe+b06bfc and the step at exe+b06bd4. The game clocks exe+b06be8 / b06bf0 accumulate.
  - A fixed-frame-rate override (exe+1ab170, int fps at exe+b027cc) applies only when a demo/recording object exists.
- **Camera pivot:**
  - In the camera update exe+2ef3a0: the character is getPlayer (exe+1873a0 = [exe+b00020]) → +0x50, and its 3×4
    world transform is vtable slot 1.
  - Position.y += character→[+0x1C0]→[+0xD0] (pattern at exe+2effd3).
  - The result is passed as r9 to exe+2ed8d0, which builds the camera transform.
- **Cinematic moments** (CinematicMomentManager):
  - The start is exe+194630: slow motion via exe+1df730 (Slomo 0.1, blend 0.3 s), the camera manager (exe+1d2570) →
    exe+29bdb0 (blend to the moment camera, Melee 1.0 s / Throw 1.2 s), and the FOV multiplier 0.8 via exe+29cf10.
  - exe+29bdb0 is also used by exe+194030 (a scripted camera) and by the camera manager itself; only the call from the
    moment code is skipped.

## 0.5.0 research: tracking and HUD
- **applyTransform** (exe+15e650) converts the camera's floats +0xCC8 … +0xCF4 (right, up, forward, position) into 12
  doubles, then calls **Node::setTransform** (exe+15e2f0).
- **setTransform** copies them to +0x248 and +0x1E8, re-orthonormalises the rotation (exe+15da10), clears +0x4A9, and
  pushes float copies to the per-thread slots at +0x4B0.
- **There is no parent multiply:** +0x1E8 is the world transform the view matrix is built from.
- **Safe area:**
  - getSafeArea (exe+1e0710) returns (Tweak X, Tweak Y) when "Safe Area: Tweak enable" (byte) is set, otherwise the
    platform default (settings +0x38 / +0x40).
  - The tweak defaults are 0.05 / 0.05, with a maximum of 0.8. It has 59 callers (HUD elements, subtitles, menus).
- **HUD element tweakables:** HUD:Flashlight / Health / Weapon&Throwable X / Y, Map Y / Scale, Max X, HUD:FadeTime and
  "HUD: Viewport Offset" (vec2, −1 … 1, read by exe+469370).
- **"Hide HUD"** is a debug-menu command (id 0xB), not a variable.
- **The HUD** is drawn by HUDMode with HUDAtlasSprite / text: blended 2D quads.

## 0.7.0 research
- **Camera classes:** PlayerCamera (gameplay), CinematicCamera (in-engine cutscenes), PathCamera, RailCamera,
  TailCamera, AttachedCamera, RevealCamera, DeathCamera, FreeCamera. They all share clone (slot 1) and getProjection
  (slot 2).
- **Camera shake:**
  - The camera manager (around exe+29dde0) does: matrix on the stack → CameraShakeController::Apply(camera+0xD08,
    &matrix) (exe+172db0) → exe+15e210 (set 3×4) → applyTransform.
  - The controller start function exe+172d40 does: [+0x64] = duration, [+0x60] = intensity, [+0x5C] = 0 (the timer).
    It is used by the script "Shake" (exe+29c8f3) and the cinematic moments (exe+194777).
  - Shake objects ("CameraShake", 0x50 bytes) are created by LightSource, WeaponFeature and others (exe+1728f0).
- **Renderer:**
  - RendererD3D12 vtable exe+7ac158. Slot 10 (exe+508970) takes rcx = renderer, rdx = view, r8 / r9 = frame targets.
  - It sets the jitter (exe+46c090), updates the matrices (exe+46c890) and calls exe+5090b0, which renders that view
    in full (scene, shadows, effects, post). This is the candidate for a second-eye render.

## 0.8.0 research: true stereo
- **Who calls the view render:** the only direct `call [reg+0x50]` site on the renderer is exe+4a661b, in the render
  job exe+4a5d30: `mov rcx,[r12+0x78]` (renderer) / `mov rdx,[rdi+0x10]` (view) / `call [rax+0x50]`. It is skipped when
  [r12+0xC8] (a deferred-context object) is set; the return value is not used.
- **The renderer object** is created by the factory exe+4b0f70 (from exe+2abd19) and kept at +0x20 of its owning system.
  RendererD3D12's constructor is exe+513e70.
- **Slot 10 (exe+508970):** pushes 7 registers, 0x120 locals, reads no stack arguments. rdx → r14. Two paths, both
  doing: build the jitter (exe+4697d0) → store it on the view (exe+46c090) → update the matrices (exe+46c890, `49 8B CE
  E8` = mov rcx,r14 / call) → render (exe+5090b0, only caller exe+508e63).
- **Main loop** exe+263600 (called from exe+1d1971): frame time (exe+1df8d0), then the game systems, then the render
  system through the global at exe+b15f70 (set at exe+298270).
- **Supersampling Mode** ("Cinematic Render", off / 2x2 / 4x4 / 8x8, object exe+dbf1e0): only registration
  references were found, so it is read through the tweakable registry; not used.
- **TAA tweakables present:** TAA:History Blend Weight, Velocity Scale, Enable Camera / Object Velocity, Jitter Scale,
  Resolve. The mod uses the existing switches (TAA, TAA:Resolve, Jitter Scale 0) to turn TAA off for true stereo.
- **Design of the mod's true stereo:** see README "True stereo". Risks that only the running game can settle:
  per-frame GPU buffers sized for one view (ring overflow), occlusion queries, and whether the final picture is written
  inside slot 10 (the capture's three triggers and the fallback cover the last one).

## 0.9.0 research: the first test in the headset
- **True stereo froze / crashed the game.** The renderer's view render (slot 10) was called with the live main view
  (`.?AVBaseCamera@@`, not a render snapshot); drawing it twice per frame is not something the engine survives. Removed,
  together with stereo reconstruction (also froze).
- **The main view** is `.?AVBaseCamera@@` with 6 - 10 getProjection calls per frame; the game's setTransform runs ~7 times
  per frame on it.
- **Screen-space effects read the lens fields.** With fields = wide culling frustum and the picture = patched off-centre
  projection, light shafts, the flashlight glow and volumetric lights showed copies at the sides. Matched view (new
  default): fields = the eye's symmetric frustum, getProjection unpatched - one projection for every consumer.
- **The HUD is not drawn as separate draws into the final image** on this build (UI draws into the final image: 0 in
  every report); it is baked into the picture. HUD = scale now falls back to the game's safe area.
- **Scene depth detection** flipped every frame between the scene depth (3840x2160) and a shadow map (8192x4096,
  more draws), writing a log line each time (2886 lines). Now only back-buffer-shaped depth counts, with hysteresis.
- **Foveated rendering** coarsened every pass with a depth buffer bound - including fog, particles and volumetrics,
  where the zones showed as rings. Now only opaque, depth-writing pipelines are coarsened.
- **Speed hacks** patch QueryPerformanceCounter / GetTickCount: the mod's own timing now reads ntdll's
  NtQueryPerformanceCounter (tests/test_realclock.cpp patches kernel32 like Cheat Engine does).
- **First person** calibrated in the headset: eye height 0.60, Eye Z 0.60 (the pivot read from the character is not
  Alan's feet - the "height above the feet" naming was wrong).

## 0.10.3 - lessons taken from the GOTGVR issue report
- Render growth is never a default: matched view renders at the headset's size; `render_density = sharp` is the
  opt-in. `ResolutionSettingsChanged()` writes the size again whenever it changes, both ways.
- The synchronized held tick steps `real / 32` (max 4 ms), never ~0; the following tick's clamps subtract what the held
  ticks already stepped (speed-hack exact, `tests/test_syncclock.cpp`).
- `ApplyLens` writes fov / zoom / aspect only - never the near plane.
- HUD layer: >= 2 draws and a bind order after the last scene-depth pass (`g_sceneBindOrder`).
- Host: the flat screen uses `g_screenBase` (head yaw + position, lazy follow), not the recentre pose.
- vrkit input: "until release" after the panel closes checks all four XInput slots and the DirectInput nav state.
- `ScanText` / `InText` cover every executable section (this exe: `.text` and `BINK`).

## 0.10.7 - head aim: the game's aim path (1.33 Epic addresses; all found by signature)
- `PlayerInputReader` (RTTI) vtable slot 5 = thunk `mov rcx,[rcx+0x50]; jmp exe+2f53c0` -> **aim update** of the aim
  object (the global current aim: getter exe+2f3d10 = `mov rax,[rip+..]`).
- Aim object: +0x00 aim point (ray hit), +0x0C aim origin, +0x18 direction, +0x24 yaw, +0x28 pitch (radians), +0x2C..2F
  flags (hit enemy / too close ...), +0x3C assist factor.
- In the update: stick axes (exe+3fe450(5/6)), mouse (3fdd00 / 3fdc90), adhesion (*Aim: Adhesion Angle*), yaw / pitch
  wrapped (1e0e60), pitch clamped by *Aim: Min / Max Vertical Angle* (deg x 0.0174533; min default -60),
  direction = row 2 of exe+14c4c0(out, pitch, yaw, 0, 0), origin = exe+2f3bb0(character, &aim+0xC) (a local
  offset (-0.22, 1.16, 0.23) through the character's matrix: the shoulder), ray exe+405920(origin, origin + dir x
  range, mask 0x27, ...), hit -> +0x00.
- setAimDirection exe+2f5390: +0x18 = dir, then exe+29b8a0(dir, &pitch, &yaw).
- Readers of the direction (accessor exe+13e350): the player camera at exe+2edac4 (-> look-at exe+15f4d0) and exe+2efc6f;
  also 29f1b0 (PlayerInputReader: direction in the character's frame), 20a56d, 21d72f, 22f825, 33e032, 33e4f5, 33ebfc,
  341d80. Aim point accessor exe+164db0 (identity), PlayerInputReader slot 8 returns it.
- Head aim = swap the angles around the update, origin hook to the eyes, the camera's two accessor reads get the
  game's direction (return-address filter). See src/headaim.cpp / headaim_core.h.

### 0.10.8 - every reader / writer of the aim object (1.33 Epic)
- Access only through: the getter exe+2f3d10 (global exe+b20980, referenced only by the aim class itself),
  PlayerInputReader+0x50, and the accessors: 13e350 direction (identical-code folded: also used for unrelated
  types, hence the pointer filter), 164db0 point (identity, folded), 2f5390 setAimDirection (also sets the
  angles), 2f3ba0 / 2f42a0..2d0 flags, 2f42e0 reset, 2f3bb0 origin calculation.
- Direction readers (13e350 on the aim): TailCamera slot 3 (exe+2ef3a0, and exe+2ed8d0 called from it) - the
  player camera; ThrowFlashbangAction slots 6 / 7; TakenThrowAction (via 33e9e0); DropFlareAction slots 6 / 7 (via
  21d700); Character slots 78 / 79 (via 21db60: character position + direction x k -> look / turn target);
  PlayerInputReader slot 25 (exe+29f1b0: direction x matrix -> setAimDirection).
- Point readers: PlayerInputReader slot 16 (exe+29f2f0: a locked target from the character if there is one, else
  the aim point), PlayerInputReader input handler (exe+29fa40, slot 3 path: interaction target under the point).
- setAimDirection writers: 15b530, 230f0a, 29b4d0, 29c2f0, 29d380 (PlayerInputReader), 2ef070 / 2ef160 (camera).
  None of them builds its direction from the aim's current direction (only slot 25 does - guarded).
- Yaw / pitch (+0x24 / +0x28) are read only inside the aim class (update, assist exe+2f43e0).

## 0.10.10 - DLSS in the exe (1.33 Epic)
- NGX is statically linked (rel_310_5); the game's NGX_D3D12_EVALUATE_DLSS_EXT helper is exe+4a5800, called from the
  DLSS manager's evaluate (vtable, exe+4a67b0: list = renderer+0x38d0 ->+0x158, handle +0x38a8, params +0x38a0).
- DLSS manager update exe+4a6660: mode global exe+d75620 (0 off .. 5 DLAA), output size exe+d74600 / 604, render size
  exe+d745e8 / 5ec; on a change: release exe+4a73e0, create exe+4a7080 (PerfQualityValue).
- Renderer (slot 10, exe+508970): `TAA switch &= !settings+0x2b` every render; `if (DLSS mode) Halton jitter (phases
  from the scale) else TAA jitter x TAA:Jitter Scale`; resources for history chosen by `DLSS mode || TAA`.
- 3D targets are created at the render size (e.g. exe+461a09: quarter-size buffers from the render width).
- Graphics menu table at exe+2b0cd0: "TAA" -> switch exe+955636, "DLSS Mode" -> Off / Ultra Performance / Performance /
  Balanced / Quality / DLAA.

### Resolution scale (1.33 Epic)
- Graphics option `resolutionscale`: setter exe+1dd470 (`g_fRenderScale = slider / 10 + 0.5`) -> exe+9556b8; saved in the
  settings stream from version 0x9e (DLSS mode from 0x9d, exe+1daf26).
- exe+50d7c0 (renderer resize): `if (DLSS mode == 0) render size = output x g_fRenderScale` (exe+d745e8 / ec from
  exe+d745f8 / fc); scale != 1 -> renderer+0x355 (targets rebuilt). No dynamic resolution heuristic anywhere.
