// Head aim: shots, the flashlight and aim assist go where the head looks; the camera and the view do not turn.
// See headaim_core.h for the game's aim object and the method. Hooks (all found by signature, verified at run time):
//   AimUpdate   the aim object's once-a-frame update (PlayerInputReader vtable slot 5 -> exe+2f53c0 in 1.33)
//   AimOrigin   where the aim ray starts (a point on Alan's shoulder, exe+2f3bb0): moved to the eyes (option)
//   AimDirGet   the direction accessor (exe+13e350): the player camera's two reads get the game's own direction
#include <windows.h>
#include <atomic>
#include <cstring>
#include <cstdio>
#include <string>
#include "headaim.h"
#include "headaim_core.h"
#include "scan.h"
#include "log.h"
#include "settings.h"
#include "MinHook.h"
#include "realclock.h"

namespace {
using AimUpdateFn = void (*)(void* aim, unsigned char flag);
using AimOriginFn = void* (*)(void* chr, float* out);
using AimDirGetFn = float* (*)(void* aim, float* out);
AimUpdateFn o_update = nullptr; AimOriginFn o_origin = nullptr; AimDirGetFn o_dirGet = nullptr;
ha::GameFns g_fns;
float* g_pitchLoA = nullptr; float* g_pitchHiA = nullptr; float* g_degToRad = nullptr;
uint8_t* g_camSite[2] = {};          // return addresses of the player camera's two direction reads
bool g_installed = false;

std::atomic<int> g_mode{0};          // 0 off, 1 always, 2 while aiming
std::atomic<bool> g_aimHeld{false};
std::atomic<bool> g_targetOnly{false};   // fallback: the camera follows the aim direction elsewhere too -> point only

SRWLOCK g_lock = SRWLOCK_INIT;
Xf g_base{}; double g_ws = 1; LONGLONG g_baseT = 0; float g_headQ[4] = { 0, 0, 0, 1 }, g_headP[3] = {};
bool g_haveBase = false;

// written by the aim update (game thread), read by the accessor / the camera check
std::atomic<void*> g_aimObj{nullptr};
std::atomic<bool> g_swapped{false};
float g_gameDir[3] = { 0, 0, 1 }, g_headDir[3] = { 0, 0, 1 };
thread_local bool t_inAim = false; thread_local V3 t_eyes; thread_local double t_blend = 0;

double g_blend = 0; LONGLONG g_lastT = 0; ha::Smoother g_smooth;
thread_local bool t_originMoved = false; thread_local V3 t_shoulder;

// who reads the aim (diagnostics for the log: return addresses into the exe, the busiest first)
struct CallerHist {
    std::atomic<uintptr_t> a[8]; std::atomic<uint32_t> n[8];
    void Note(void* ret) {
        uintptr_t r = (uintptr_t)ret;
        for (int i = 0; i < 8; i++) { uintptr_t c = a[i].load(std::memory_order_relaxed); if (c == r) { n[i]++; return; } if (!c) { uintptr_t z = 0; if (a[i].compare_exchange_strong(z, r) || z == r) { n[i]++; return; } } }
    }
    std::string Text() {
        std::string t; char b[48];
        for (int i = 0; i < 8; i++) { uintptr_t c = a[i].exchange(0); uint32_t k = n[i].exchange(0); if (c && k) { snprintf(b, sizeof b, " exe+%x x%u", Rva((void*)c), k); t += b; } }
        return t.empty() ? " none" : t;
    }
} g_dirReaders, g_pointReaders;
using VGetPointFn = float* (*)(void* pir, float* out);
using VTurnFn = void (*)(void* pir, const float* m);
VGetPointFn o_vPoint = nullptr; VTurnFn o_vTurn = nullptr;
std::atomic<uint32_t> s_turnGuard{0}, s_gameSets{0};
// the game setting the aim direction itself (camera transitions, cutscene ends, PlayerInputReader): from then on the
// object holds the game's own direction again - the camera's reads are no longer replaced until the next aim update
using SetDirFn = void (*)(void* aim, const float* dir);
SetDirFn o_setDir = nullptr;
void H_SetDir(void* aim, const float* dir) { if (aim == g_aimObj.load() && g_swapped.exchange(false)) s_gameSets++; o_setDir(aim, dir); }
float* H_VPoint(void* pir, float* out) { g_pointReaders.Note(__builtin_return_address(0)); return o_vPoint(pir, out); }
// PlayerInputReader slot 25 turns the aim direction by a matrix and sets it again (setAimDirection: dir AND angles).
// While the direction holds the head's, the game's own direction is turned instead - the camera never takes the head's
void H_VTurn(void* pir, const float* m) {
    void* aim = pir && Readable((uint8_t*)pir + 0x50, 8) ? *(void**)((uint8_t*)pir + 0x50) : nullptr;
    if (aim && g_swapped.load() && aim == g_aimObj.load()) { memcpy((uint8_t*)aim + 0x18, g_gameDir, 12); g_swapped = false; s_turnGuard++; }
    o_vTurn(pir, m);
}
bool PatchVt(void** vt, int slot, void* det, void** orig) {
    DWORD old; if (!VirtualProtect(&vt[slot], 8, PAGE_READWRITE, &old)) return false;
    *orig = vt[slot]; vt[slot] = det; VirtualProtect(&vt[slot], 8, old, &old); return true;
}
std::atomic<uint32_t> s_calls{0}, s_noBase{0}, s_notHeld{0}, s_turned{0}, s_camReads{0}, s_origins{0}, s_skipped{0}, s_followVotes{0}, s_okVotes{0};
double s_angSum = 0, s_angMax = 0; uint32_t s_angN = 0;

double Sec(LONGLONG a, LONGLONG b) { LARGE_INTEGER f; rc::Qpf(&f); return double(b - a) / double(f.QuadPart); }
LONGLONG NowQ() { LARGE_INTEGER q; rc::Qpc(&q); return q.QuadPart; }

void H_Update(void* aimP, unsigned char flag) {
    unsigned char* aim = (unsigned char*)aimP;
    LONGLONG now = NowQ();
    double dt = g_lastT ? Sec(g_lastT, now) : 0; g_lastT = now;
    if (!(dt > 0 && dt < 0.25)) dt = 0;
    int mode = g_mode.load();
    Xf b; double ws; float q[4], p[3]; bool have;
    AcquireSRWLockShared(&g_lock); b = g_base; ws = g_ws; memcpy(q, g_headQ, 16); memcpy(p, g_headP, 12);
    have = g_haveBase && Sec(g_baseT, now) < 0.25; ReleaseSRWLockShared(&g_lock);
    bool want = have && (mode == 1 || (mode == 2 && g_aimHeld.load()));
    s_calls++; if (mode && !have) s_noBase++; if (mode == 2 && have && !g_aimHeld.load()) s_notHeld++;
    double a = dt > 0 ? 1.0 - exp(-dt / 0.04) : 0.0;
    g_blend += ((want ? 1.0 : 0.0) - g_blend) * a;
    if (!want && g_blend < 0.01) { g_blend = 0; g_smooth.have = false; }
    if (g_blend <= 0 || !have || !aim || !Readable(aim, 0x30)) { g_swapped = false; o_update(aimP, flag); return; }
    // the game's pitch limits, read live (tweakables: they may change; set by the game's own start-up code)
    { float lo = *g_pitchLoA * *g_degToRad, hi = *g_pitchHiA * *g_degToRad; if (lo != hi && lo == lo && hi == hi) { g_fns.pitchLo = lo; g_fns.pitchHi = hi; } }
    V3 hf = g_smooth.Step(ha::HeadFwdTracking(q), dt, g_set.headAimSmooth);
    V3 headWorld = ha::TrackingToWorld(b, hf);
    t_eyes = ha::EyesWorld(b, p, ws); t_blend = g_set.headAimFromEyes ? g_blend : 0.0;
    ha::Result r = ha::AimWithHead(g_fns, aim, headWorld, g_blend, [&] { t_inAim = true; o_update(aimP, flag); t_inAim = false; });
    g_gameDir[0] = (float)r.gameDir.x; g_gameDir[1] = (float)r.gameDir.y; g_gameDir[2] = (float)r.gameDir.z;
    g_headDir[0] = (float)r.headDir.x; g_headDir[1] = (float)r.headDir.y; g_headDir[2] = (float)r.headDir.z;
    if (t_originMoved) {
        // the ray was cast from the eyes; what stays in the object is the game's own origin (Alan's shoulder) and a
        // direction from it through the aim point - everything that aims from Alan (arms, throws, the look-at)
        // points at what the player looks at
        t_originMoved = false;
        V3 d = ha::ConvergeFromShoulder(aim, t_shoulder, r.headDir, 0.5 * ws);
        g_headDir[0] = (float)d.x; g_headDir[1] = (float)d.y; g_headDir[2] = (float)d.z;
    }
    if (g_targetOnly.load()) memcpy(aim + 0x18, g_gameDir, 12);   // fallback: only the aim point follows the head
    g_aimObj = aimP; g_swapped = true; s_turned++;
    double ang = ha::AngleDeg(r.headDir, r.gameDir); s_angSum += ang; s_angN++; if (ang > s_angMax) s_angMax = ang;
}
void* H_Origin(void* chr, float* out) {
    void* r = o_origin(chr, out);
    if (t_inAim && t_blend > 0 && out) {   // the ray starts where the player's eyes are drawn (first person: the head)
        V3 o{ out[0], out[1], out[2] }, e = o + (t_eyes - o) * t_blend;
        t_shoulder = o; t_originMoved = true;
        out[0] = (float)e.x; out[1] = (float)e.y; out[2] = (float)e.z; s_origins++;
    }
    return r;
}
float* H_DirGet(void* aim, float* out) {
    float* r = o_dirGet(aim, out);
    if (out && aim && g_swapped.load(std::memory_order_relaxed) && aim == g_aimObj.load(std::memory_order_relaxed)) {
        uint8_t* ret = (uint8_t*)__builtin_return_address(0);
        if (ret == g_camSite[0] || ret == g_camSite[1]) { memcpy(out, g_gameDir, 12); s_camReads++; }
        else g_dirReaders.Note(ret);
    }
    return r;
}
template <class T> bool HookAt(void* at, void* det, T* orig) { return at && MH_CreateHook(at, det, (void**)orig) == MH_OK && MH_EnableHook(at) == MH_OK; }
} // namespace

void HeadAimInstall() {
    // the aim update: huge stack frame (0x80b0), PlayerInputReader slot 5
    auto upd = ScanText("48 89 5C 24 10 55 56 57 41 54 41 55 41 56 41 57 48 8D AC 24 50 80 FF FF B8 B0 80 00 00 E8", 2);
    auto org = ScanText("48 8D 56 0C 49 8B CF E8", 2);                       // origin: lea rdx,[rsi+0xc]; mov rcx,r15; call
    auto eul = ScanText("48 8D 4D D0 E8 ?? ?? ?? ?? F2 0F 10 45 E8 F2 0F 11 46 18", 2);   // angles -> matrix, dir = row 2
    auto lim = ScanText("F3 0F 10 0D ?? ?? ?? ?? F3 0F 10 1D ?? ?? ?? ?? F3 0F 59 CB 0F 2F C8 76 07 F3 0F 11 4E 28 EB 1C F3 0F 10 15", 2);
    auto set = ScanText("F2 0F 10 02 4C 8B C9 48 83 C1 18 4D 8D 41 24 F2 0F 11 01 8B 42 08 49 8D 51 28 89 41 08 E9", 2);   // setAimDirection
    auto cam1 = ScanText("E8 ?? ?? ?? ?? 48 8B C8 48 8D 54 24 ?? E8 ?? ?? ?? ?? 48 8B C8 4C 8D 85 ?? ?? ?? ?? 48 8D 55 ?? E8", 2);
    auto cam2 = ScanText("E8 ?? ?? ?? ?? 48 8B C8 48 8D 54 24 ?? E8 ?? ?? ?? ?? F3 44 0F 10 B7", 2);
    if (upd.size() != 1 || org.size() != 1 || eul.size() != 1 || lim.size() != 1 || set.size() != 1) {
        LOGW("headaim: aim update not found (update %zu, origin %zu, angles %zu, limits %zu, set %zu) - head aim unavailable", upd.size(), org.size(), eul.size(), lim.size(), set.size());
        return;
    }
    uint8_t* fn = upd[0];
    auto inside = [&](uint8_t* p) { return p > fn && p < fn + 0x1100; };
    if (!inside(org[0]) || !inside(eul[0]) || !inside(lim[0])) { LOGW("headaim: aim update parts outside the function - head aim unavailable"); return; }
    uint8_t* originFn = Rel32Target(org[0] + 7);
    g_fns.euler = (decltype(g_fns.euler))Rel32Target(eul[0] + 4);
    g_fns.dirToAngles = (decltype(g_fns.dirToAngles))Rel32Target(set[0] + 29);
    g_pitchLoA = (float*)RipTarget(lim[0], 4, 8); g_degToRad = (float*)RipTarget(lim[0] + 8, 4, 8); g_pitchHiA = (float*)RipTarget(lim[0] + 0x20, 4, 8);
    if (!InText(originFn) || !InText((void*)g_fns.euler) || !InText((void*)g_fns.dirToAngles) || !Readable(g_pitchLoA, 4) || !Readable(g_pitchHiA, 4) || !Readable(g_degToRad, 4)) {
        LOGW("headaim: aim helpers not confirmed - head aim unavailable"); return;
    }
    // the camera's reads of the direction: both call the same accessor (verified: same target)
    uint8_t* dirGet = nullptr; int sites = 0;
    for (auto* v : { &cam1, &cam2 }) if (v->size() == 1) {
        uint8_t* t = Rel32Target((*v)[0] + 13);   // the call at +13
        if (!dirGet) dirGet = t;
        if (t == dirGet) g_camSite[sites++] = (*v)[0] + 18;
    }
    if (dirGet && !(dirGet[0] == 0x8B && dirGet[1] == 0x41 && dirGet[2] == 0x20)) dirGet = nullptr;   // mov eax,[rcx+0x20]: reads +0x18..+0x20
    // proof by data flow: PlayerInputReader's slot 5 is `mov rcx,[rcx+0x50]; jmp <aim update>`
    void** pir = RttiVtable(".?AVPlayerInputReader@@");
    bool pirOk = pir && Readable(pir, 26 * 8) && Readable(pir[5], 9) && memcmp(pir[5], "\x48\x8B\x49\x50\xE9", 5) == 0 && Rel32Target((uint8_t*)pir[5] + 4) == fn;
    if (!pirOk) LOGW("headaim: PlayerInputReader slot 5 does not lead to the aim update - checking with the pattern only");
    if (!HookAt(fn, (void*)&H_Update, &o_update)) { LOGE("headaim: aim update hook failed"); return; }
    if (pirOk) {
        // slot 16 = the aim point getter (diagnostics), slot 25 = turn the aim direction by a matrix (guarded)
        uint8_t* s16 = (uint8_t*)pir[16]; uint8_t* s25 = (uint8_t*)pir[25];
        bool ok16 = InText(s16) && PatchVt(pir, 16, (void*)&H_VPoint, (void**)&o_vPoint);
        bool ok25 = InText(s25) && PatchVt(pir, 25, (void*)&H_VTurn, (void**)&o_vTurn);
        LOGI("headaim: PlayerInputReader vtable exe+%x: aim point getter exe+%x %s, aim turn exe+%x %s", Rva(pir), Rva(s16), ok16 ? "counted" : "not hooked", Rva(s25), ok25 ? "guarded" : "NOT guarded");
    }
    if (!HookAt(set[0], (void*)&H_SetDir, &o_setDir)) LOGW("headaim: setAimDirection hook failed");
    if (!HookAt(originFn, (void*)&H_Origin, &o_origin)) LOGW("headaim: aim origin hook failed - shots start at the shoulder");
    if (dirGet && sites == 2 && HookAt(dirGet, (void*)&H_DirGet, &o_dirGet)) {}
    else { g_targetOnly = true; LOGW("headaim: camera reads of the aim direction not found (%d) - only the aim point follows the head", sites); }
    g_installed = true;
    LOGI("sig AimUpdate exe+%x, AimOrigin exe+%x, AimDirGet exe+%x (camera reads exe+%x, exe+%x), angles exe+%x / exe+%x, pitch limits read live - head aim available",
         Rva(fn), Rva(originFn), dirGet ? Rva(dirGet) : 0, g_camSite[0] ? Rva(g_camSite[0]) : 0, g_camSite[1] ? Rva(g_camSite[1]) : 0,
         Rva((void*)g_fns.euler), Rva((void*)g_fns.dirToAngles));
    HeadAimApplySettings();
}

void HeadAimApplySettings() {
    const std::string& m = g_set.headAim;
    g_mode = m == "always" ? 1 : m == "aiming" ? 2 : 0;
}
void HeadAimSetAimHeld(bool held) { g_aimHeld = held; }
bool HeadAimAvailable() { return g_installed; }

// camera thread, every VR camera set of the player camera: the drawn base (level horizon, first person, offsets) and
// the head pose it is drawn with; plus a check that the camera really does not follow the head-aimed direction
void HeadAimNoteBase(const Xf& drawn, double ws, const float headQ[4], const float headP[3], const Xf& gameCam) {
    if (!g_installed) return;
    AcquireSRWLockExclusive(&g_lock);
    g_base = drawn; g_ws = ws; memcpy(g_headQ, headQ, 16); memcpy(g_headP, headP, 12); g_baseT = NowQ(); g_haveBase = true;
    ReleaseSRWLockExclusive(&g_lock);
    if (!g_swapped.load() || g_targetOnly.load()) return;
    V3 gd{ g_gameDir[0], g_gameDir[1], g_gameDir[2] }, hd{ g_headDir[0], g_headDir[1], g_headDir[2] }, cf = Norm(gameCam.r[2]);
    if (ha::AngleDeg(gd, hd) < 8) return;   // only telling when head and game aim differ clearly
    if (ha::AngleDeg(cf, hd) + 2 < ha::AngleDeg(cf, gd)) s_followVotes++; else s_okVotes++;
    if (s_followVotes > 30 && s_followVotes > 2 * s_okVotes) {
        g_targetOnly = true;
        LOGW("headaim: the camera turned with the head-aimed direction (%u of %u checks) - from now on only the aim point follows the head", s_followVotes.load(), s_followVotes.load() + s_okVotes.load());
    }
}

void HeadAimReport() {
    if (!g_installed) return;
    static const char* names[] = { "off", "always", "while aiming" };
    LOGI("headaim: aim updates %u (no VR camera %u, aim button up %u)", s_calls.exchange(0), s_noBase.exchange(0), s_notHeld.exchange(0));
    LOGI("headaim: %s%s, blend %.2f, aim turned %u, camera reads kept %u, origins at the eyes %u, aim turns guarded %u, game sets %u | head vs game aim avg %.1f max %.1f deg | camera check ok %u / follows %u",
         names[g_mode.load() % 3], g_targetOnly.load() ? " (aim point only)" : "", g_blend, s_turned.load(), s_camReads.load(), s_origins.load(), s_turnGuard.load(), s_gameSets.load(),
         s_angN ? s_angSum / s_angN : 0.0, s_angMax, s_okVotes.load(), s_followVotes.load());
    std::string dr = g_dirReaders.Text(), pr = g_pointReaders.Text();
    LOGI("headaim: read the head-aimed direction:%s | read the aim point:%s", dr.c_str(), pr.c_str());
    s_turnGuard = 0; s_gameSets = 0;
    s_turned = 0; s_camReads = 0; s_origins = 0; s_angSum = 0; s_angMax = 0; s_angN = 0;
}
