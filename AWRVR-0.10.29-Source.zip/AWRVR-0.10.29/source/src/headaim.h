#pragma once
#include "vrmath.h"
// Head aim (see headaim_core.h). Installed after the game scan; settings applied from SettingsApply.
void HeadAimInstall();
void HeadAimApplySettings();
void HeadAimSetAimHeld(bool held);                 // the aim button (L2 / LT on any controller, right mouse)
bool HeadAimAvailable();
void HeadAimNoteBase(const Xf& drawn, double ws, const float headQ[4], const float headP[3], const Xf& gameCam);
void HeadAimReport();
