#include "log.h"
#include <windows.h>
#include <io.h>
#include <string>
#include "realclock.h"

static FILE* g_log = nullptr;
static CRITICAL_SECTION g_cs;
static LARGE_INTEGER g_freq, g_t0;

void LogInit(const wchar_t* path) {
    InitializeCriticalSection(&g_cs);
    rc::Qpf(&g_freq);
    rc::Qpc(&g_t0);
    // the previous run's log is kept as *.prev.log (a crash is not lost on restart)
    std::wstring prev = path; size_t dot = prev.rfind(L".log");
    if (dot != std::wstring::npos) { prev = prev.substr(0, dot) + L".prev.log"; MoveFileExW(path, prev.c_str(), MOVEFILE_REPLACE_EXISTING); }
    g_log = _wfopen(path, L"w");
}

void LogWrite(const char* level, const char* fmt, ...) {
    if (!g_log) return;
    LARGE_INTEGER t; rc::Qpc(&t);
    double s = double(t.QuadPart - g_t0.QuadPart) / double(g_freq.QuadPart);
    char buf[2048];
    va_list ap; va_start(ap, fmt);
    vsnprintf(buf, sizeof buf, fmt, ap);
    va_end(ap);
    EnterCriticalSection(&g_cs);
    fprintf(g_log, "%9.3f [%s] [%5lu] %s\n", s, level, GetCurrentThreadId(), buf);
    fflush(g_log);
    LeaveCriticalSection(&g_cs);
}

void LogFlushDisk() {
    if (!g_log) return;
    EnterCriticalSection(&g_cs);
    FlushFileBuffers((HANDLE)_get_osfhandle(_fileno(g_log)));
    LeaveCriticalSection(&g_cs);
}
