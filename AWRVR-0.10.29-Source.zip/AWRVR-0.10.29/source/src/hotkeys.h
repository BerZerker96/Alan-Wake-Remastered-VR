#pragma once
// Hotkeys tab of the VR panel: remappable keyboard / controller bindings for the mod's functions (hotkeys.cpp).
void HotkeysRegister();                 // adds the "Hotkeys" page (after the other pages); reads hotkey_* from the config
void HotkeysPoll(bool* screenshot);     // Present thread, once per frame
