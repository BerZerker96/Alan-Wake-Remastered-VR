#pragma once
// AWRVR log: <game>\AWRVR\awrvr.log, flushed per line (fflush) and committed to disk once a second.
#include <cstdio>
#include <cstdarg>

void LogInit(const wchar_t* path);
void LogWrite(const char* level, const char* fmt, ...);
void LogFlushDisk();

#define LOGI(...) LogWrite("I", __VA_ARGS__)
#define LOGW(...) LogWrite("W", __VA_ARGS__)
#define LOGE(...) LogWrite("E", __VA_ARGS__)
