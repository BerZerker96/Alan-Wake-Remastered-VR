#include "scan.h"
#include "log.h"
#include <cstring>
#include <cstdio>
#include <cctype>
#include <string>
#include <mutex>
#include "realclock.h"

ExeImage g_exe;

bool ScanInit() { return g_exe.base ? true : ScanInitModule(GetModuleHandleW(nullptr)); }

bool ScanInitModule(HMODULE m) {
    g_exe = ExeImage{};
    auto* dos = (IMAGE_DOS_HEADER*)m;
    auto* nt = (IMAGE_NT_HEADERS64*)((uint8_t*)m + dos->e_lfanew);
    g_exe.base = (uint8_t*)m;
    g_exe.size = nt->OptionalHeader.SizeOfImage;
    auto* s = IMAGE_FIRST_SECTION(nt);
    for (int i = 0; i < nt->FileHeader.NumberOfSections; i++, s++) {
        ExeImage::Sec sec{};
        sec.p = g_exe.base + s->VirtualAddress; sec.n = s->Misc.VirtualSize; sec.ch = s->Characteristics;
        memcpy(sec.name, s->Name, 8); sec.name[8] = 0;
        g_exe.secs.push_back(sec);
        if (!g_exe.text && (s->Characteristics & IMAGE_SCN_MEM_EXECUTE)) { g_exe.text = sec.p; g_exe.textSize = sec.n; }
    }
    // code is found by the section flags, never by name (a protected / repacked exe may keep code in ".bss" or a second
    // executable section): every executable section is searched
    std::string code;
    for (auto& c : g_exe.secs) if (c.ch & IMAGE_SCN_MEM_EXECUTE) { char b[64]; snprintf(b, sizeof b, "%s%s %zx", code.empty() ? "" : ", ", c.name, c.n); code += b; }
    LOGI("scan: exe base %p size %zx, code %p size %zx, %zu sections, timestamp %08lx (executable: %s)", g_exe.base, g_exe.size, g_exe.text,
         g_exe.textSize, g_exe.secs.size(), (unsigned long)nt->FileHeader.TimeDateStamp, code.c_str());
    return g_exe.text != nullptr;
}

bool InText(const void* p) {
    const uint8_t* q = (const uint8_t*)p;
    if (q >= g_exe.text && q < g_exe.text + g_exe.textSize) return true;
    for (auto& c : g_exe.secs) if ((c.ch & IMAGE_SCN_MEM_EXECUTE) && q >= c.p && q < c.p + c.n) return true;
    return false;
}
uint32_t Rva(const void* p) { return (uint32_t)((const uint8_t*)p - g_exe.base); }

struct Pat { std::vector<uint8_t> b; std::vector<uint8_t> m; };
static Pat Parse(const char* s) {
    Pat p;
    while (*s) {
        while (*s == ' ') s++;
        if (!*s) break;
        if (*s == '?') { p.b.push_back(0); p.m.push_back(0); s++; if (*s == '?') s++; continue; }
        int v = 0;
        for (int k = 0; k < 2 && isxdigit((unsigned char)*s); k++, s++) v = v * 16 + (isdigit((unsigned char)*s) ? *s - '0' : (tolower(*s) - 'a' + 10));
        p.b.push_back((uint8_t)v); p.m.push_back(0xFF);
    }
    return p;
}

std::vector<uint8_t*> ScanPattern(const char* pattern, uint8_t* start, size_t len, int maxHits) {
    std::vector<uint8_t*> out;
    Pat p = Parse(pattern);
    size_t n = p.b.size();
    if (!n || len < n) return out;
    // first non-wildcard byte as the anchor for memchr
    size_t a = 0; while (a < n && !p.m[a]) a++;
    uint8_t* end = start + len - n;
    for (uint8_t* q = start; q <= end;) {
        if (a < n) {
            uint8_t* f = (uint8_t*)memchr(q + a, p.b[a], (size_t)(end - q) + 1);
            if (!f) break;
            q = f - a;
        }
        size_t i = 0;
        for (; i < n; i++) if (p.m[i] && q[i] != p.b[i]) break;
        if (i == n) { out.push_back(q); if ((int)out.size() >= maxHits) break; }
        q++;
    }
    return out;
}

std::vector<uint8_t*> ScanText(const char* pattern, int maxHits) {
    std::vector<uint8_t*> out;
    for (auto& c : g_exe.secs) {
        if (!(c.ch & IMAGE_SCN_MEM_EXECUTE) || (int)out.size() >= maxHits) continue;
        auto h = ScanPattern(pattern, c.p, c.n, maxHits - (int)out.size());
        out.insert(out.end(), h.begin(), h.end());
    }
    return out;
}

uint8_t* FindBytes(uint8_t* p, size_t len, const uint8_t* bytes, size_t n) {
    for (size_t i = 0; i + n <= len; i++) if (memcmp(p + i, bytes, n) == 0) return p + i;
    return nullptr;
}

uint8_t* Rel32Target(uint8_t* p) { return p + 5 + ReadI32(p + 1); }

// MSVC x64 RTTI: TypeDescriptor { void* vftable; void* spare; char name[]; }
// CompleteObjectLocator { DWORD signature(1); DWORD offset; DWORD cdOffset; DWORD pTypeDescriptor(rva);
//                         DWORD pClassDescriptor(rva); DWORD pSelf(rva); }   vftable[-1] = &COL
void** RttiVtable(const char* name, uint32_t colOffset) {
    size_t nl = strlen(name) + 1;
    for (auto& s : g_exe.secs) {
        if (s.ch & IMAGE_SCN_MEM_EXECUTE) continue;
        for (uint8_t* q = s.p; q + nl <= s.p + s.n; q++) {
            q = (uint8_t*)memchr(q, name[0], (size_t)(s.p + s.n - q));
            if (!q || q + nl > s.p + s.n) break;
            if (memcmp(q, name, nl) != 0) continue;
            uint32_t td = Rva(q - 16);
            // complete object locators referencing this type descriptor
            for (auto& r : g_exe.secs) {
                if (r.ch & IMAGE_SCN_MEM_EXECUTE) continue;
                for (uint8_t* c = r.p; c + 24 <= r.p + r.n; c += 4) {
                    const uint32_t* col = (const uint32_t*)c;
                    if (col[0] != 1 || col[3] != td || col[5] != Rva(c) || col[1] != colOffset) continue;
                    uint64_t colVa = (uint64_t)(uintptr_t)c;
                    for (auto& v : g_exe.secs) {
                        if (v.ch & IMAGE_SCN_MEM_EXECUTE) continue;
                        for (uint8_t* w = v.p; w + 16 <= v.p + v.n; w += 8) {
                            if (*(uint64_t*)w == colVa) {
                                void** vt = (void**)(w + 8);
                                if (InText(vt[0])) return vt;
                            }
                        }
                    }
                }
            }
        }
    }
    return nullptr;
}

void* PatchImport(const char* dll, const char* func, void* replacement) {
    auto* dos = (IMAGE_DOS_HEADER*)g_exe.base;
    auto* nt = (IMAGE_NT_HEADERS64*)(g_exe.base + dos->e_lfanew);
    auto& dir = nt->OptionalHeader.DataDirectory[IMAGE_DIRECTORY_ENTRY_IMPORT];
    if (!dir.VirtualAddress) return nullptr;
    for (auto* d = (IMAGE_IMPORT_DESCRIPTOR*)(g_exe.base + dir.VirtualAddress); d->Name; d++) {
        if (_stricmp((const char*)(g_exe.base + d->Name), dll) != 0) continue;
        auto* thunk = (IMAGE_THUNK_DATA64*)(g_exe.base + d->FirstThunk);
        auto* orig = (IMAGE_THUNK_DATA64*)(g_exe.base + (d->OriginalFirstThunk ? d->OriginalFirstThunk : d->FirstThunk));
        for (; orig->u1.AddressOfData; orig++, thunk++) {
            if (IMAGE_SNAP_BY_ORDINAL64(orig->u1.Ordinal)) continue;
            auto* ibn = (IMAGE_IMPORT_BY_NAME*)(g_exe.base + orig->u1.AddressOfData);
            if (strcmp((const char*)ibn->Name, func) != 0) continue;
            DWORD old;
            if (!VirtualProtect(&thunk->u1.Function, 8, PAGE_READWRITE, &old)) return nullptr;
            void* prev = (void*)thunk->u1.Function;
            thunk->u1.Function = (ULONGLONG)(uintptr_t)replacement;
            VirtualProtect(&thunk->u1.Function, 8, old, &old);
            return prev;
        }
    }
    return nullptr;
}

// ---------------------------------------------------------------- cached readability
namespace {
struct PageEntry { uintptr_t page; DWORD tick; bool ok; };
PageEntry g_pages[256];
std::mutex g_pageMx;
}

static bool PageReadable(uintptr_t page) {
    DWORD now = rc::TickMs();
    PageEntry& e = g_pages[(page >> 12) & 255];
    {
        std::lock_guard<std::mutex> l(g_pageMx);
        if (e.page == page && now - e.tick < 50) return e.ok;
    }
    MEMORY_BASIC_INFORMATION mbi;
    bool ok = VirtualQuery((void*)page, &mbi, sizeof mbi) && mbi.State == MEM_COMMIT &&
              !(mbi.Protect & (PAGE_NOACCESS | PAGE_GUARD)) &&
              (mbi.Protect & (PAGE_READONLY | PAGE_READWRITE | PAGE_EXECUTE_READ | PAGE_EXECUTE_READWRITE | PAGE_WRITECOPY | PAGE_EXECUTE_WRITECOPY));
    std::lock_guard<std::mutex> l(g_pageMx);
    e = { page, now, ok };
    return ok;
}

bool Readable(const void* p, size_t n) {
    uintptr_t a = (uintptr_t)p, b = a + n - 1;
    if (a < 0x10000 || b < a) return false;
    for (uintptr_t pg = a & ~(uintptr_t)0xFFF; pg <= (b & ~(uintptr_t)0xFFF); pg += 0x1000)
        if (!PageReadable(pg)) return false;
    return true;
}

uint8_t* FindString(const char* str) {
    size_t n = strlen(str) + 1;
    for (auto& s : g_exe.secs) {
        if (s.ch & IMAGE_SCN_MEM_EXECUTE) continue;
        for (uint8_t* q = s.p; q + n <= s.p + s.n; q++) {
            q = (uint8_t*)memchr(q, str[0], (size_t)(s.p + s.n - q));
            if (!q || q + n > s.p + s.n) break;
            if (memcmp(q, str, n) == 0 && (q == s.p || q[-1] == 0)) return q;
        }
    }
    return nullptr;
}

const char* RttiName(const void* obj) {
    if (!obj || !Readable(obj, 8)) return "";
    void** vt = *(void***)obj;
    if (!Readable(vt - 1, 8)) return "";
    const uint32_t* col = (const uint32_t*)vt[-1];
    if ((uint8_t*)col < g_exe.base || (uint8_t*)col >= g_exe.base + g_exe.size || col[0] != 1) return "";
    const char* nm = (const char*)(g_exe.base + col[3] + 16);
    if ((uint8_t*)nm >= g_exe.base + g_exe.size) return "";
    return nm;
}
bool RttiIs(const void* obj, const char* n) { return strcmp(RttiName(obj), n) == 0; }
