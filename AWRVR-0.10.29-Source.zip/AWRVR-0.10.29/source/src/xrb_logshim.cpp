// xrbridge logging: the host thread writes AWRVR\xrhost.log (its own file, as the separate host did), every other
// caller (the client inside the mod) goes to awrvr.log.
#include <windows.h>
#include <cstdio>
#include <cstdarg>
#include "log.h"
#include "realclock.h"
namespace xrb {
static int g_level = 2;
static FILE* g_host = nullptr;
static DWORD g_hostTid = 0;
static CRITICAL_SECTION g_cs;
static LARGE_INTEGER g_f, g_t0;
void LogInit(const wchar_t* path, int level) {
    g_level = level;
    InitializeCriticalSection(&g_cs);
    rc::Qpf(&g_f); rc::Qpc(&g_t0);
    g_host = _wfopen(path, L"w");
    g_hostTid = GetCurrentThreadId();
}
void LogSetLevel(int level) { g_level = level; }
int LogGetLevel() { return g_level; }
void LogFlush() { if (g_host) { EnterCriticalSection(&g_cs); fflush(g_host); LeaveCriticalSection(&g_cs); } }
void LogWrite(int level, const char* fmt, ...) {
    if (level > g_level) return;
    char buf[1536]; va_list ap; va_start(ap, fmt); vsnprintf(buf, sizeof buf, fmt, ap); va_end(ap);
    if (g_host && GetCurrentThreadId() == g_hostTid) {
        LARGE_INTEGER t; rc::Qpc(&t);
        EnterCriticalSection(&g_cs);
        fprintf(g_host, "%9.3f [%c] %s\n", double(t.QuadPart - g_t0.QuadPart) / double(g_f.QuadPart), level == 0 ? 'E' : level == 1 ? 'W' : 'I', buf);
        fflush(g_host);
        LeaveCriticalSection(&g_cs);
        return;
    }
    ::LogWrite(level == 0 ? "E" : level == 1 ? "W" : "I", "xrbridge: %s", buf);
}
}
