#pragma once
// Headset refresh logic (guide B.4, performance manual 9.1 / 9.2), no Windows dependency: unit tested.
//   * Never cap below the full rate: remember the highest rate reported; a higher one is accepted after 30 reports
//     within 3 %; reports under 30 Hz or over 250 Hz are noise.
//   * Pimax reports a halved rate while Smart Smoothing is forced: undivide it (only for Pimax).
//   * A slower rate that stays 20 s and is not 1/2, 2/3 or 1/3 of the known one = the player lowered the refresh.
#include <cmath>
#include <cstring>
#include <cctype>
#include <string>

struct RefreshTracker {
    double maxHz = 0, candHz = 0; int candN = 0;
    double lowHz = 0, lowSince = -1;
    bool pimax = false;
    double fixedHz = 0;                        // headset_refresh_hz override
    static bool Near(double a, double b, double tol) { return b > 0 && fabs(a - b) <= tol * b; }
    void SetRuntime(const char* name) {
        std::string s = name ? name : ""; for (auto& c : s) c = (char)tolower((unsigned char)c);
        pimax = s.find("pimax") != std::string::npos;
    }
    static double Undivide(double hz, double known) {
        const double common[] = { 72, 75, 80, 90, 96, 100, 110, 120, 144, 165, 180 };
        if (hz >= 66) return hz;
        for (int k = 2; k <= 4; k++) if (known > 0 && Near(hz * k, known, 0.03)) return known;
        for (int k = 2; k <= 4; k++) for (double c : common) if (Near(hz * k, c, 0.02)) return c;
        double r = hz; while (r < 66) r += hz; return r;
    }
    // cur = rate reported now (Hz), t = seconds (steady clock). Returns the full rate to pace at.
    double Update(double cur, double t) {
        if (cur < 30 || cur > 250) cur = 0;
        if (cur > 0 && pimax) cur = Undivide(cur, maxHz);
        if (cur > maxHz) {
            if (maxHz <= 0) maxHz = cur;
            else if (Near(cur, candHz, 0.03)) { if (++candN >= 30) { maxHz = candHz; candN = 0; } }
            else { candHz = cur; candN = 1; }
        } else if (cur > 0 && !Near(cur, maxHz, 0.03)) {
            bool ratio = Near(cur * 2, maxHz, 0.03) || Near(cur * 1.5, maxHz, 0.03) || Near(cur * 3, maxHz, 0.03);
            if (ratio) lowSince = -1;                            // the runtime's smoothing: keep the full rate
            else if (lowSince < 0 || !Near(cur, lowHz, 0.03)) { lowHz = cur; lowSince = t; }
            else if (t - lowSince >= 20) { maxHz = cur; lowSince = -1; }   // the player set a lower refresh
        } else lowSince = -1;
        if (fixedHz > 0) return fixedHz;
        return maxHz > 0 ? maxHz : 90.0;
    }
};
