#pragma once
// Comfort filters on the game camera (guide deep dive C), header-only so they are unit tested on their own.
//   Stabilize: critically damped follower (camera shake filter), cuts pass at once.
//   Settle:    rope with slack (idle-sway lock) - the output moves only once the input moved further than the slack.
#include "vrmath.h"
#include <cmath>
#ifndef M_PI
#define M_PI 3.14159265358979323846
#endif

// yaw / pitch / roll of a basis around a world up axis (y-up frames; other axes are rotated into it by the caller)
struct Ypr { double yaw, pitch, roll; };
inline Ypr ToYpr(const Xf& x) {
    V3 f = Norm(x.r[2]);
    Ypr o; o.yaw = atan2(f.x, f.z); o.pitch = asin(f.y < -1 ? -1 : f.y > 1 ? 1 : f.y);
    V3 levelRight = { cos(o.yaw), 0, -sin(o.yaw) };
    V3 right = Norm(x.r[0]) * (XfDet(x) >= 0 ? 1.0 : -1.0);   // mirrored frames: compare the unmirrored right
    o.roll = atan2(Dot(Cross(levelRight, right), f), Dot(levelRight, right));
    return o;
}
inline Xf FromYpr(const Ypr& a, V3 pos, bool rightHanded) {
    double cy = cos(a.yaw), sy = sin(a.yaw), cp = cos(a.pitch), sp = sin(a.pitch), cr = cos(a.roll), sr = sin(a.roll);
    V3 f = { sy * cp, sp, cy * cp };
    V3 r0 = { cy, 0, -sy };
    V3 u0 = Cross(f, r0);                          // up without roll (for this handedness of Cross)
    if (Dot(u0, V3{0, 1, 0}) < 0 && cp > 0) u0 = u0 * -1.0;
    V3 r = r0 * cr + u0 * sr, u = u0 * cr - r0 * sr;
    Xf o; o.r[0] = rightHanded ? r : r * -1.0; o.r[1] = u; o.r[2] = f; o.p = pos;
    return o;
}
inline double WrapPi(double a) { while (a > M_PI) a -= 2 * M_PI; while (a < -M_PI) a += 2 * M_PI; return a; }

// Trend-following smoother (Holt double exponential): follows a steady motion with no lag at all and removes only what
// deviates from it (shake, bob). a = level gain, b = trend gain, per step; wrap = angles.
struct Holt1 {
    double l = 0, v = 0;
    double Step(double x, double dt, double a, double b, bool wrap) {
        double pred = l + v * dt, e = x - pred;
        if (wrap) e = WrapPi(e);
        l = pred + a * e; if (wrap) l = WrapPi(l);
        v += b * e / dt;
        return l;
    }
    void Reset(double x) { l = x; v = 0; }
};
inline void HoltGains(double dt, double tau, double* a, double* b) { *a = 1.0 - exp(-dt / tau); *b = *a * *a * 0.5; }

// Camera shake filter: removes the fast part of the game camera's motion (hits, landing, catch-up jitter) while walking,
// running and turning are followed without lag. Cuts and big jumps pass at once.
struct Stabilizer {
    bool have = false; Holt1 p[3], ang[3]; Xf last{};
    Xf Step(const Xf& in, double dt, double k) {
        if (k <= 0.001) { have = false; return in; }
        if (dt <= 1e-4) dt = 1e-4;
        Ypr y = ToYpr(in);
        bool cut = !have || dt > 0.25 || Len(in.p - last.p) > 2.0 || Dot(Norm(in.r[2]), Norm(last.r[2])) < cos(40.0 * M_PI / 180.0);
        last = in;
        if (cut) { p[0].Reset(in.p.x); p[1].Reset(in.p.y); p[2].Reset(in.p.z); ang[0].Reset(y.yaw); ang[1].Reset(y.pitch); ang[2].Reset(y.roll); have = true; return in; }
        double a, b; HoltGains(dt, 0.12 * k, &a, &b);
        V3 o = { p[0].Step(in.p.x, dt, a, b, false), p[1].Step(in.p.y, dt, a, b, false), p[2].Step(in.p.z, dt, a, b, false) };
        Ypr f = { ang[0].Step(y.yaw, dt, a, b, true), ang[1].Step(y.pitch, dt, a, b, true), ang[2].Step(y.roll, dt, a, b, true) };
        Xf r = FromYpr(f, o, XfDet(in) >= 0);
        if (Dot(r.r[1], in.r[1]) < 0) { r.r[1] = r.r[1] * -1.0; r.r[0] = r.r[0] * -1.0; }
        return r;
    }
};

// First-person head bob filter: only the height (along world up) is smoothed - the bob is vertical; stairs, jumps and
// walking speed are followed without lag.
struct BobFilter {
    bool have = false; Holt1 h;
    V3 Step(V3 pos, V3 up, double dt, double k) {
        if (k <= 0.001) { have = false; return pos; }
        if (dt <= 1e-4) dt = 1e-4;
        double y = Dot(pos, up);
        if (!have || dt > 0.25 || fabs(y - h.l) > 0.6) { h.Reset(y); have = true; return pos; }
        double a, b; HoltGains(dt, 0.25 * k, &a, &b);
        return pos + up * (h.Step(y, dt, a, b, false) - y);
    }
};

struct Settler {
    bool have = false; Ypr out{}; V3 pos{};
    Xf Step(const Xf& in, double k) {
        if (k <= 0.001) { have = false; return in; }
        bool hand = XfDet(in) >= 0;
        Ypr a = ToYpr(in);
        double slack = 2.5 * M_PI / 180.0 * k, slackPos = 0.06 * k;
        if (!have) { out = a; pos = in.p; have = true; }
        auto rope = [&](double in_, double& o) {
            double d = WrapPi(in_ - o);
            if (d > slack) o = WrapPi(in_ - slack); else if (d < -slack) o = WrapPi(in_ + slack);
            if (fabs(d) > M_PI * 0.5) o = in_;          // a cut
        };
        rope(a.yaw, out.yaw); rope(a.pitch, out.pitch); rope(a.roll, out.roll);
        V3 d = in.p - pos; double l = Len(d);
        if (l > 2.0) pos = in.p; else if (l > slackPos) pos = in.p - d * (slackPos / l);
        Xf o = FromYpr(out, pos, hand);
        // keep the game's own up sign convention
        if (Dot(o.r[1], in.r[1]) < 0) { o.r[1] = o.r[1] * -1.0; o.r[0] = o.r[0] * -1.0; }
        return o;
    }
};
