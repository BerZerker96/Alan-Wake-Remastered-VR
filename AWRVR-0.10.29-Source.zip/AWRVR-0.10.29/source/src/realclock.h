#pragma once
// The real clock - unchanged by speed hacks (Cheat Engine's speedhack and similar tools patch QueryPerformanceCounter,
// GetTickCount and timeGetTime in the game process). The mod's own timing (head pose filters, frame pacing, the fps
// limiter, the headset host, timeouts, logs) reads the system counter through ntdll's NtQueryPerformanceCounter,
// which those tools leave alone, so the game can run at any speed while the headset keeps real time.
// The game's own clock (its frame timer) is left as it is: a speed hack still changes the game's speed.
#include <windows.h>

namespace rc {
using NtQpcFn = LONG(NTAPI*)(LARGE_INTEGER*, LARGE_INTEGER*);
inline NtQpcFn NtQpc() {
    static NtQpcFn f = (NtQpcFn)(void*)GetProcAddress(GetModuleHandleW(L"ntdll.dll"), "NtQueryPerformanceCounter");
    return f;
}
inline BOOL Qpc(LARGE_INTEGER* c) {
    if (NtQpc()) { LARGE_INTEGER f; if (NtQpc()(c, &f) >= 0) return TRUE; }
    return QueryPerformanceCounter(c);
}
inline BOOL Qpf(LARGE_INTEGER* f) {
    if (NtQpc()) { LARGE_INTEGER c; if (NtQpc()(&c, f) >= 0 && f->QuadPart > 0) return TRUE; }
    return QueryPerformanceFrequency(f);
}
inline LONGLONG Freq() { static LONGLONG f = [] { LARGE_INTEGER x; Qpf(&x); return x.QuadPart > 0 ? x.QuadPart : 10000000LL; }(); return f; }
inline DWORD TickMs() { LARGE_INTEGER c; Qpc(&c); return (DWORD)((c.QuadPart / Freq()) * 1000 + (c.QuadPart % Freq()) * 1000 / Freq()); }
}  // namespace rc
