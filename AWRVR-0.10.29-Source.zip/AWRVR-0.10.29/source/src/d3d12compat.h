// D3D12 variable-rate-shading declarations missing from older mingw-w64 d3d12.h (values from the Windows SDK).
#pragma once
#include <d3d12.h>
#ifndef __ID3D12GraphicsCommandList5_INTERFACE_DEFINED__
#define AWRVR_VRS_COMPAT 1
enum AWRVR_SHADING_RATE : UINT8 { D3D12_SHADING_RATE_1X1 = 0, D3D12_SHADING_RATE_1X2 = 1, D3D12_SHADING_RATE_2X1 = 4, D3D12_SHADING_RATE_2X2 = 5,
    D3D12_SHADING_RATE_2X4 = 6, D3D12_SHADING_RATE_4X2 = 9, D3D12_SHADING_RATE_4X4 = 10 };
typedef enum D3D12_SHADING_RATE_COMBINER { D3D12_SHADING_RATE_COMBINER_PASSTHROUGH = 0, D3D12_SHADING_RATE_COMBINER_OVERRIDE = 1,
    D3D12_SHADING_RATE_COMBINER_MIN = 2, D3D12_SHADING_RATE_COMBINER_MAX = 3, D3D12_SHADING_RATE_COMBINER_SUM = 4 } D3D12_SHADING_RATE_COMBINER;
typedef enum D3D12_VARIABLE_SHADING_RATE_TIER { D3D12_VARIABLE_SHADING_RATE_TIER_NOT_SUPPORTED = 0, D3D12_VARIABLE_SHADING_RATE_TIER_1 = 1,
    D3D12_VARIABLE_SHADING_RATE_TIER_2 = 2 } D3D12_VARIABLE_SHADING_RATE_TIER;
typedef struct D3D12_FEATURE_DATA_D3D12_OPTIONS6 { BOOL AdditionalShadingRatesSupported; BOOL PerPrimitiveShadingRateSupportedWithViewportIndexing;
    D3D12_VARIABLE_SHADING_RATE_TIER VariableShadingRateTier; UINT ShadingRateImageTileSize; BOOL BackgroundProcessingSupported; } D3D12_FEATURE_DATA_D3D12_OPTIONS6;
static const D3D12_RESOURCE_STATES D3D12_RESOURCE_STATE_SHADING_RATE_SOURCE = (D3D12_RESOURCE_STATES)0x1000000;
// ID3D12GraphicsCommandList5: vtable slots 77 RSSetShadingRate, 78 RSSetShadingRateImage (after List4's 68..76)
struct ID3D12GraphicsCommandList5 {
    void** Vt() { return *(void***)this; }
    ULONG Release() { return ((ULONG(STDMETHODCALLTYPE*)(void*))Vt()[2])(this); }
    void RSSetShadingRate(UINT8 r, const D3D12_SHADING_RATE_COMBINER* c) { ((void(STDMETHODCALLTYPE*)(void*, UINT, const D3D12_SHADING_RATE_COMBINER*))Vt()[77])(this, r, c); }
    void RSSetShadingRateImage(ID3D12Resource* img) { ((void(STDMETHODCALLTYPE*)(void*, ID3D12Resource*))Vt()[78])(this, img); }
};
static const GUID IID_AwrvrList5 = { 0x55050859, 0x4024, 0x474c, { 0x87, 0xf5, 0x64, 0x72, 0xea, 0xee, 0x44, 0xea } };
#define AWRVR_IID_LIST5 IID_AwrvrList5
#else
#define AWRVR_IID_LIST5 __uuidof(ID3D12GraphicsCommandList5)
#endif
