#pragma once
// Minimal OpenXR loader for the in-process host (guide: "one DLL, no extra program"): finds the active runtime
// (XR_RUNTIME_JSON, else HKLM\SOFTWARE\Khronos\OpenXR\1\ActiveRuntime), loads its library, negotiates the
// loader-runtime interface and resolves every entry point the host uses. API layers are not loaded (they are listed
// in the log so a report shows them).
#define XR_NO_PROTOTYPES
#include <windows.h>
#include <d3d11.h>
#include <openxr/openxr.h>
#define XR_USE_PLATFORM_WIN32
#define XR_USE_GRAPHICS_API_D3D11
#include <openxr/openxr_platform.h>

#define XRL_FUNCS(X) \
    X(xrGetInstanceProcAddr) X(xrCreateInstance) X(xrDestroyInstance) X(xrGetInstanceProperties) X(xrGetSystem) \
    X(xrGetSystemProperties) X(xrEnumerateViewConfigurationViews) X(xrCreateSession) X(xrDestroySession) X(xrBeginSession) \
    X(xrEndSession) X(xrRequestExitSession) X(xrCreateReferenceSpace) X(xrLocateSpace) X(xrLocateViews) X(xrPollEvent) \
    X(xrEnumerateSwapchainFormats) X(xrCreateSwapchain) X(xrDestroySwapchain) X(xrEnumerateSwapchainImages) \
    X(xrAcquireSwapchainImage) X(xrWaitSwapchainImage) X(xrReleaseSwapchainImage) X(xrWaitFrame) X(xrBeginFrame) X(xrEndFrame) \
    X(xrDestroySpace)

#define XRL_DECL(f) extern PFN_##f f;
XRL_FUNCS(XRL_DECL)
#undef XRL_DECL

bool XrLoaderInit();                       // before xrCreateInstance
bool XrLoaderResolve(XrInstance inst);     // after xrCreateInstance
