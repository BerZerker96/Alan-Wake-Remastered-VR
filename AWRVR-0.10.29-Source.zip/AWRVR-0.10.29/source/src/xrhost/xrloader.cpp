#include "xrloader.h"
#include <openxr/openxr_loader_negotiation.h>
#include <string>
#include <cstdio>
#include "xrblog.h"   // xrb host log (xrhost.log)

#define XRL_DEF(f) PFN_##f f = nullptr;
XRL_FUNCS(XRL_DEF)
#undef XRL_DEF

namespace {
std::wstring ReadRegStr(HKEY root, const wchar_t* key, const wchar_t* value) {
    wchar_t buf[1024]; DWORD sz = sizeof buf;
    if (RegGetValueW(root, key, value, RRF_RT_REG_SZ, nullptr, buf, &sz) == ERROR_SUCCESS) return buf;
    return L"";
}
std::string ReadFileA(const std::wstring& p) {
    FILE* f = _wfopen(p.c_str(), L"rb"); if (!f) return "";
    std::string s; char b[4096]; size_t n; while ((n = fread(b, 1, sizeof b, f)) > 0) s.append(b, n); fclose(f); return s;
}
// "library_path": "..." from the runtime manifest (JSON escapes: \\ and \/)
std::string JsonString(const std::string& j, const char* key) {
    size_t k = j.find(std::string("\"") + key + "\""); if (k == std::string::npos) return "";
    size_t c = j.find(':', k); size_t q = j.find('"', c + 1); if (c == std::string::npos || q == std::string::npos) return "";
    std::string out;
    for (size_t i = q + 1; i < j.size() && j[i] != '"'; i++) { if (j[i] == '\\' && i + 1 < j.size()) { i++; out += j[i]; } else out += j[i]; }
    return out;
}
void LogLayers() {
    HKEY k;
    for (const wchar_t* path : { L"SOFTWARE\\Khronos\\OpenXR\\1\\ApiLayers\\Implicit", L"SOFTWARE\\Khronos\\OpenXR\\1\\ApiLayers\\Explicit" }) {
        for (HKEY root : { HKEY_LOCAL_MACHINE, HKEY_CURRENT_USER }) {
            if (RegOpenKeyExW(root, path, 0, KEY_READ, &k) != ERROR_SUCCESS) continue;
            wchar_t name[1024]; DWORD nl, type, data, dl;
            for (DWORD i = 0;; i++) {
                nl = 1024; dl = sizeof data;
                if (RegEnumValueW(k, i, name, &nl, nullptr, &type, (BYTE*)&data, &dl) != ERROR_SUCCESS) break;
                LOGI("API layer %ls (%s) - not loaded by the in-process host", name, data == 0 ? "enabled" : "disabled");
            }
            RegCloseKey(k);
        }
    }
}
} // namespace

bool XrLoaderInit() {
    if (xrGetInstanceProcAddr) return true;
    wchar_t env[1024]; std::wstring json;
    if (GetEnvironmentVariableW(L"XR_RUNTIME_JSON", env, 1024)) json = env;
    if (json.empty()) json = ReadRegStr(HKEY_LOCAL_MACHINE, L"SOFTWARE\\Khronos\\OpenXR\\1", L"ActiveRuntime");
    if (json.empty()) { LOGE("No active OpenXR runtime (HKLM\\SOFTWARE\\Khronos\\OpenXR\\1\\ActiveRuntime) - set one in SteamVR / your headset's software"); return false; }
    std::string j = ReadFileA(json);
    std::string lib = JsonString(j, "library_path");
    if (lib.empty()) { LOGE("Runtime manifest %ls has no library_path", json.c_str()); return false; }
    std::wstring wl(lib.begin(), lib.end());
    if (!(wl.size() > 1 && (wl[1] == L':' || (wl[0] == L'\\' && wl[1] == L'\\')))) wl = json.substr(0, json.find_last_of(L"\\/") + 1) + wl;
    LOGI("OpenXR runtime manifest %ls -> %ls", json.c_str(), wl.c_str());
    LogLayers();
    HMODULE rt = LoadLibraryExW(wl.c_str(), nullptr, LOAD_WITH_ALTERED_SEARCH_PATH);
    if (!rt) { LOGE("Loading the runtime failed (%lu)", GetLastError()); return false; }
    auto neg = (PFN_xrNegotiateLoaderRuntimeInterface)GetProcAddress(rt, "xrNegotiateLoaderRuntimeInterface");
    if (!neg) { LOGE("Runtime has no xrNegotiateLoaderRuntimeInterface"); return false; }
    XrNegotiateLoaderInfo li{}; li.structType = XR_LOADER_INTERFACE_STRUCT_LOADER_INFO; li.structVersion = XR_LOADER_INFO_STRUCT_VERSION; li.structSize = sizeof li;
    li.minInterfaceVersion = 1; li.maxInterfaceVersion = XR_CURRENT_LOADER_RUNTIME_VERSION;
    li.minApiVersion = XR_MAKE_VERSION(1, 0, 0); li.maxApiVersion = XR_MAKE_VERSION(1, 0x3ff, 0xfff);
    XrNegotiateRuntimeRequest rr{}; rr.structType = XR_LOADER_INTERFACE_STRUCT_RUNTIME_REQUEST; rr.structVersion = XR_RUNTIME_INFO_STRUCT_VERSION; rr.structSize = sizeof rr;
    XrResult r = neg(&li, &rr);
    if (XR_FAILED(r) || !rr.getInstanceProcAddr) { LOGE("Runtime negotiation failed (%d)", (int)r); return false; }
    xrGetInstanceProcAddr = rr.getInstanceProcAddr;
    LOGI("Runtime interface %u, API %u.%u", rr.runtimeInterfaceVersion, XR_VERSION_MAJOR(rr.runtimeApiVersion), XR_VERSION_MINOR(rr.runtimeApiVersion));
    xrGetInstanceProcAddr(XR_NULL_HANDLE, "xrCreateInstance", (PFN_xrVoidFunction*)&xrCreateInstance);
    return xrCreateInstance != nullptr;
}

bool XrLoaderResolve(XrInstance inst) {
    bool ok = true;
#define XRL_GET(f) if (!f) { xrGetInstanceProcAddr(inst, #f, (PFN_xrVoidFunction*)&f); if (!f) { LOGE("OpenXR entry point %s missing", #f); ok = false; } }
    XRL_FUNCS(XRL_GET)
#undef XRL_GET
    return ok;
}
