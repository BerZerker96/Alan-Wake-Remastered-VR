#pragma once
// the game's per-thread scratch pads (scratchpad.cpp)
struct ScratchMark { void* entry = nullptr; void* top = nullptr; void* cur = nullptr; int used = 0; };
bool ScratchPadMark(ScratchMark* m);              // the current thread's pad as it is now
int ScratchPadRelease(const ScratchMark& m);      // back to the mark: blocks taken back, or -1 (left alone)
