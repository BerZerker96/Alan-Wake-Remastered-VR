#include "game.h"
#include "d3d12hooks.h"
#include "scan.h"
#include "log.h"
#include "settings.h"
#include "MinHook.h"
#include "engine.h"
#include "upscaler.h"
#include "syncclock.h"
#include <unordered_map>
#include <vector>
#include <algorithm>
#include <cstring>
#include <string>
#include <atomic>
#include <cmath>
#include "realclock.h"

GameFound g_game;

namespace {
// ---------------------------------------------------------------- one pass over the code: name -> object
std::unordered_map<uintptr_t, uint8_t*> g_tweakObj;    // name string -> tweakable object
std::unordered_map<uintptr_t, uint8_t*> g_tweakReg;    // name string -> registration site
std::unordered_map<uintptr_t, uint8_t*> g_dbgVar;      // name string -> bound variable

void IndexCode() {
    // Semantic, not register-exact (other builds / compilers): a name is loaded into rdx, then within a few
    // instructions either
    //   tweakable: lea rcx,[object] ... call ctor
    //   renderer switch: call addItem ... mov rcx,rax; lea rdx,[variable]; call bind
    uint8_t* t = g_exe.text; size_t n = g_exe.textSize;
    for (size_t i = 0; i + 48 < n; i++) {
        uint8_t* p = t + i;
        if (p[0] != 0x48 || p[1] != 0x8D || p[2] != 0x15) continue;
        uint8_t* str = RipTarget(p, 3, 7);
        if (str < g_exe.base || str >= g_exe.base + g_exe.size) continue;
        bool tweak = false;
        for (uint8_t* q = p + 7; q < p + 22 && !tweak; q++)
            if (q[0] == 0x48 && q[1] == 0x8D && q[2] == 0x0D)
                for (uint8_t* c = q + 7; c < q + 16; c++) if (c[0] == 0xE8) {
                    if (!g_tweakObj.count((uintptr_t)str)) { g_tweakObj[(uintptr_t)str] = RipTarget(q, 3, 7); g_tweakReg[(uintptr_t)str] = c - 14; }
                    tweak = true; break;
                }
        if (tweak) continue;
        for (uint8_t* c = p + 7; c < p + 22; c++) {
            if (c[0] != 0xE8) continue;
            uint8_t* m = c + 5;
            if (m[0] == 0x48 && m[1] == 0x8B && m[2] == 0xC8 && m[3] == 0x48 && m[4] == 0x8D && m[5] == 0x15 && m[10] == 0xE8 && !g_dbgVar.count((uintptr_t)str))
                g_dbgVar[(uintptr_t)str] = RipTarget(m + 3, 3, 7);
            break;
        }
    }
}

// value of a tweakable: the lowest store offset into the object after its registration call
uint8_t* Tweak(const char* name) {
    uint8_t* s = FindString(name);
    if (!s) { LOGW("game: tweakable '%s' not in this exe", name); return nullptr; }
    auto it = g_tweakObj.find((uintptr_t)s);
    if (it == g_tweakObj.end()) { LOGW("game: tweakable '%s' not registered", name); return nullptr; }
    uint8_t* obj = it->second; uint8_t* reg = g_tweakReg[(uintptr_t)s];
    int best = -1;
    for (uint8_t* q = reg + 19; q < reg + 19 + 140; q++) {
        // movss/movaps/mov dword/mov byte [rip+disp] ...
        int dOff = -1, len = 0;
        if (q[0] == 0xF3 && q[1] == 0x0F && q[2] == 0x11 && (q[3] & 0xC7) == 0x05) { dOff = 4; len = 8; }
        else if (q[0] == 0x0F && q[1] == 0x29 && (q[2] & 0xC7) == 0x05) { dOff = 3; len = 7; }
        else if (q[0] == 0xC7 && q[1] == 0x05) { dOff = 2; len = 10; }
        else if (q[0] == 0xC6 && q[1] == 0x05) { dOff = 2; len = 7; }
        else if (q[0] == 0x88 && (q[1] & 0xC7) == 0x05) { dOff = 2; len = 6; }
        else if (q[0] == 0xE9 || q[0] == 0xC3) break;
        if (dOff < 0) continue;
        int64_t off = RipTarget(q, dOff, len) - obj;
        if (off >= 0x20 && off < 0x200 && (best < 0 || off < best)) best = (int)off;
    }
    if (best < 0) { LOGW("game: tweakable '%s': value offset not found", name); return nullptr; }
    LOGI("sig tweak '%s' object exe+%x value +%x", name, Rva(obj), best);
    return obj + best;
}

uint8_t* TweakOptional(const char* name) { return FindString(name) ? Tweak(name) : nullptr; }   // newer builds only

// instructions in the code that address `target` rip-relatively (mod 00 r/m 101, with 0/1/4 bytes of immediate)
std::vector<uint8_t*> RipRefs(uint8_t* target, size_t maxHits) {
    std::vector<uint8_t*> out;
    uint8_t* t = g_exe.text; size_t n = g_exe.textSize;
    for (size_t i = 1; i + 8 < n && out.size() < maxHits; i++) {
        if ((t[i - 1] & 0xC7) != 0x05) continue;
        int32_t disp = ReadI32(t + i);
        for (int extra : { 0, 1, 4 }) if (t + i + 4 + extra + disp == target) { out.push_back(t + i - 1); break; }
    }
    return out;
}
// start of the function containing p: after the int3 / nop padding before it (MSVC aligns functions to 16)
uint8_t* FunctionStart(uint8_t* p, size_t maxBack) {
    for (uint8_t* q = p; q > p - maxBack * 16 && q > g_exe.text + 2; q--)
        if (((uintptr_t)q & 15) == 0 && (q[-1] == 0xCC || q[-1] == 0xC3)) return q;
    return nullptr;
}

uint8_t* DebugVar(const char* name) {
    uint8_t* s = FindString(name);
    auto it = s ? g_dbgVar.find((uintptr_t)s) : g_dbgVar.end();
    if (it == g_dbgVar.end()) { LOGW("game: renderer switch '%s' not found", name); return nullptr; }
    LOGI("sig switch '%s' exe+%x (now %u)", name, Rva(it->second), *it->second);
    return it->second;
}

// ---------------------------------------------------------------- frame timer (synchronized stereo)
using LapFn = double (*)(void*);
LapFn o_lap = nullptr;
std::atomic<bool> g_holdNext{false}, g_lastHeld{false};
std::atomic<uint32_t> g_ticks{0}, s_held{0};
double g_bank = 0;
constexpr double kHeldDt = 1e-4;
// The frame-time function (exe+1df8d0 in 1.33) does not use the lap directly: it steps the game by the AVERAGE of the
// last N laps (a ring of 4: index, count, size, array pointer - globals right after each other), and the raw lap feeds
// other clocks. A held frame must be tiny in both, so while synchronized the ring is one entry long and its entry is
// written together with the lap: held frame tiny, next frame the real time of both frames.
struct DtRing { int* idx = nullptr; int* count = nullptr; int* size = nullptr; float** arr = nullptr; int origSize = 0; bool on = false; } g_ring;
SyncClock g_sync;
double H_Lap(void* t) {
    if (t != g_game.frameTimer) return o_lap(t);
    g_ticks++;
    double real = o_lap(t);
    float* ring = g_ring.on && g_ring.arr && *g_ring.arr ? *g_ring.arr : nullptr;
    bool hold = g_holdNext.exchange(false);
    g_lastHeld = hold; if (hold) s_held++;
    return g_sync.Lap(real, hold, ring);
}

// ---------------------------------------------------------------- game modes
// The per-frame update's arguments are unknown (could be floats in xmm registers), so the detours are asm thunks
// that only count the call and jump on with every register untouched.
enum { M_GAME, M_MENU, M_LOADING, M_VIDEO, M_CREDITS, M_COUNT };
} // namespace
extern "C" { void* g_modeOrig[5] = {}; volatile long g_modeCount[5] = {}; }
#define MODE_THUNK(i) asm(".text\n.globl ModeThunk" #i "\nModeThunk" #i ":\n\tlock incl g_modeCount+" #i "*4(%rip)\n\tjmp *g_modeOrig+" #i "*8(%rip)\n");
MODE_THUNK(0) MODE_THUNK(1) MODE_THUNK(2) MODE_THUNK(3) MODE_THUNK(4)
extern "C" void ModeThunk0(); extern "C" void ModeThunk1(); extern "C" void ModeThunk2(); extern "C" void ModeThunk3(); extern "C" void ModeThunk4();
namespace {
void* kUpd[M_COUNT] = { (void*)&ModeThunk0, (void*)&ModeThunk1, (void*)&ModeThunk2, (void*)&ModeThunk3, (void*)&ModeThunk4 };
long g_modeSeen[M_COUNT] = {}; DWORD g_modeTick[M_COUNT] = {};

// ---------------------------------------------------------------- focus
using FocusFn = char (*)(void*, const uint8_t*);
FocusFn o_focus = nullptr;
std::atomic<uint32_t> s_focusDropped{0};
char H_Focus(void* self, const uint8_t* ev) {
    if (g_set.runInBackground && ev && Readable(ev, 8) && ev[4] == 0) { s_focusDropped++; return 0; }   // focus lost: not passed on
    return o_focus(self, ev);
}

// ---------------------------------------------------------------- Bink
using BinkOpenFn = void* (WINAPI*)(const char*, unsigned);
using BinkVoidFn = void (WINAPI*)(void*);
using BinkIntFn = int (WINAPI*)(void*);
BinkOpenFn o_binkOpen = nullptr; BinkVoidFn o_binkClose = nullptr; BinkVoidFn o_binkNext = nullptr;
std::atomic<void*> g_bink{nullptr};
std::atomic<uint32_t> g_binkW{0}, g_binkH{0};
std::atomic<DWORD> g_binkTick{0};
void* WINAPI H_BinkOpen(const char* name, unsigned fl) {
    void* h = o_binkOpen(name, fl);
    if (h && Readable(h, 8)) {
        uint32_t w = ((uint32_t*)h)[0], hh = ((uint32_t*)h)[1];
        LOGI("video: Bink open '%s' %ux%u", name ? name : "?", w, hh);
        g_bink = h; g_binkW = w; g_binkH = hh;
    }
    return h;
}
void WINAPI H_BinkClose(void* h) { if (h == g_bink.load()) { g_bink = nullptr; g_binkW = 0; LOGI("video: Bink closed"); } o_binkClose(h); }
void WINAPI H_BinkNext(void* h) { if (h == g_bink.load()) g_binkTick = rc::TickMs(); o_binkNext(h); }

// ---------------------------------------------------------------- saved game values (restored when we stop forcing)
// While a value is forced, the game may change it itself (its options menu, the camera-style switch): then the
// game's new value becomes the one restored later, so the player's own choice is never lost.
struct Saved { bool have = false; uint8_t b = 0, wb = 0; float f = 0, wf = 0; float v[3] = {}, wv[3] = {}; const char* name = ""; };
Saved g_sv_taa{.name = "TAA"}, g_sv_vb{.name = "Render Vector Blur"}, g_sv_vbt{.name = "Vector Blur:Enable"}, g_sv_grain{.name = "Film grain"},
      g_sv_grain2{.name = "Film Grain d3t"}, g_sv_vig{.name = "Vignette"}, g_sv_jit{.name = "TAA:Jitter Scale"}, g_sv_near{.name = "Camera:Near"},
      g_sv_umbra{.name = "Use Umbra"}, g_sv_cine{.name = "Cinematic Mode"}, g_sv_taar{.name = "TAA:Resolve"}, g_sv_vbf{.name = "Vector Blur:Force Enable"};
Saved g_sv_safeE{.name = "Safe Area: Tweak enable"}, g_sv_safeX{.name = "Safe Area: Tweak X"}, g_sv_safeY{.name = "Safe Area: Tweak Y"};
Saved g_sv_pos[4], g_sv_catch{.name = "Camera:Catch Amount"}, g_sv_angle{.name = "Camera:Angle"}, g_sv_modvel{.name = "Camera:Modern Velocity Horizontal Offset Scale"};
bool g_fpOn = false;
SRWLOCK g_forceLock = SRWLOCK_INIT;       // Present thread (once a second) vs the game thread (camera-style switch)

void ForceByte(uint8_t* p, Saved& s, bool force, uint8_t v) {
    if (!p) return;
    if (force) {
        if (!s.have) { s.have = true; s.b = *p; }
        else if (*p != s.wb) { LOGI("game: '%s' changed by the game to %u while forced - restored to that later", s.name, *p); s.b = *p; }
        *p = v; s.wb = v;
    } else if (s.have) { if (*p == s.wb) *p = s.b; s.have = false; }
}
void ForceFloat(float* p, Saved& s, bool force, float v) {
    if (!p) return;
    if (force) {
        if (!s.have) { s.have = true; s.f = *p; }
        else if (*p != s.wf) { LOGI("game: '%s' changed by the game to %.3f while forced - restored to that later", s.name, *p); s.f = *p; }
        *p = v; s.wf = v;
    } else if (s.have) { if (*p == s.wf) *p = s.f; s.have = false; }
}
void ForceVec3(float* p, Saved& s, bool force, const float* v) {
    if (!p) return;
    if (force) {
        if (!s.have) { s.have = true; memcpy(s.v, p, 12); }
        else if (memcmp(p, s.wv, 12)) { LOGI("game: '%s' changed by the game to (%.3f %.3f %.3f) while forced", s.name, p[0], p[1], p[2]); memcpy(s.v, p, 12); }
        memcpy(p, v, 12); memcpy(s.wv, v, 12);
    } else if (s.have) { if (!memcmp(p, s.wv, 12)) memcpy(p, s.v, 12); s.have = false; }
}

// ---------------------------------------------------------------- first person (the player camera's own offsets)
// The player camera (exe+2ed8d0 .. 2f0560 in 1.33) blends its per-camera copies toward these tweakables every frame:
//   Camera:High / Mid / Low / Safe Pos  - offset from the camera pivot (x right, y up, z forward; Mid = 0.55, -0.04, -2.2)
//   Camera:Catch Amount                 - how far the camera trails Alan while he moves (a first-person view must not lag)
//   Camera:Angle                        - the toe-in that turns the shoulder camera toward the centre line (7 deg; 0 with no
//                                         sideways offset, else the view is yawed against the aim)
//   Camera:Modern Velocity Horizontal Offset Scale - the 1.33 "modern" style's sideways shift with speed
// The player camera's pivot is Alan's root (feet) + up x a per-character height: character->[+0x1C0]->[+0xD0] (read in the
// camera update, exe+2effd3 in 1.33). First person puts the eye at fp_eye_height above the feet: Y offset = eye - pivot.
float PivotHeight() {
    if (!g_game.playerGlobal || g_game.playerCharOff < 0 || g_game.pivotCompOff < 0 || !Readable(g_game.playerGlobal, 8)) return -1;
    uint8_t* pl = (uint8_t*)*g_game.playerGlobal;
    if (!pl || !Readable(pl + g_game.playerCharOff, 8)) return -1;
    uint8_t* ch = *(uint8_t**)(pl + g_game.playerCharOff);
    if (!ch || !Readable(ch + g_game.pivotCompOff, 8)) return -1;
    uint8_t* comp = *(uint8_t**)(ch + g_game.pivotCompOff);
    if (!comp || !Readable(comp + g_game.pivotHeightOff, 4)) return -1;
    float h = *(float*)(comp + g_game.pivotHeightOff);
    return std::isfinite(h) && h > 0.3f && h < 3.f ? h : -1;
}
float g_lastPivot = -1;
std::atomic<DWORD> g_worldLiftTick{0};
std::atomic<float> g_fpLift{0.f};
// The camera offset tweakables are in the camera's own frame (they tilt with its pitch), so the eye-height difference is
// applied by the mod along world up on the player camera (engine.cpp); only if that is not happening (no PlayerCamera
// RTTI) it goes into the Y offset.
void FpApplyLocked(bool on) {
    float pos[3] = { g_set.fpOffsetX, g_set.fpOffsetY, g_set.fpOffsetZ };
    float lift = 0;
    if (on && g_set.fpEyeHeight > 0) { float h = PivotHeight(); if (h > 0) { lift = g_set.fpEyeHeight - h; g_lastPivot = h; } }
    g_fpLift = lift;
    if (rc::TickMs() - g_worldLiftTick.load() > 2000) pos[1] += lift;
    static const char* names[4] = { "Camera:High Pos", "Camera:Mid Pos", "Camera:Low Pos", "Camera:Safe Pos" };
    for (int i = 0; i < 4; i++) { g_sv_pos[i].name = names[i]; ForceVec3(g_game.camPos[i], g_sv_pos[i], on, pos); }
    ForceFloat(g_game.camCatch, g_sv_catch, on, 0.f);
    ForceFloat(g_game.camAngle, g_sv_angle, on, 0.f);
    ForceFloat(g_game.camModernVel, g_sv_modvel, on, 0.f);
}
// ---------------------------------------------------------------- camera shake
// The camera manager builds the camera matrix, hands it to CameraShakeController::Apply (exe+172db0 in 1.33: advances
// the shake timers / sources, adds the shake), then sets it on the camera. Every shake (script "Shake", weapons, lights,
// cinematic moments) goes through it. The game runs Apply on a copy; the mod blends clean -> shaken by camera_shake.
using ShakeApplyFn = void (*)(void*, float*);
ShakeApplyFn o_shakeApply = nullptr; std::atomic<uint32_t> s_shakeApplied{0}, s_shakeScaled{0};
void H_ShakeApply(void* ctrl, float* m) {
    float k = g_set.vrMode == "screen" ? 1.f : (g_set.cameraShake < 0 ? 0 : g_set.cameraShake > 1 ? 1 : g_set.cameraShake);
    s_shakeApplied++;
    if (k >= 0.999f || !m) { o_shakeApply(ctrl, m); return; }
    float clean[16], shaken[16];
    memcpy(clean, m, sizeof clean); memcpy(shaken, m, sizeof shaken);
    o_shakeApply(ctrl, shaken);                    // timers advance exactly as the game's
    bool moved = memcmp(clean, shaken, 48) != 0;
    for (int i = 0; i < 12; i++) m[i] = clean[i] + (shaken[i] - clean[i]) * k;   // the game re-orthonormalises (exe+15da10)
    if (moved) s_shakeScaled++;
}

// ---------------------------------------------------------------- action cameras (cinematic moments)
// A dodge / melee / throw "cinematic moment" (CinematicMomentManager, exe+194630 in 1.33) slows time and asks the camera
// manager to blend to a moment camera around the action (exe+29bdb0, blend time = Cinematic Moment:Melee / Throw Camera
// In). In VR that swing is skipped when action_cameras = off; the slow motion stays.
using FocusCamFn = void (*)(void*, void*, float, int);
FocusCamFn o_focusCam = nullptr; void* g_momentRet = nullptr; std::atomic<uint32_t> s_momentSkipped{0};
void H_FocusCam(void* mgr, void* target, float blend, int flags) {
    if (g_momentRet && __builtin_return_address(0) == g_momentRet && g_set.actionCameras == "off" && g_set.vrMode != "screen") { s_momentSkipped++; return; }
    o_focusCam(mgr, target, blend, flags);
}

// the camera-style switch rewrites the offsets itself (x scaled, Angle scaled, y / z moved): run it on the player's values
using StyleFn = void (*)(void*, uintptr_t, uintptr_t, uintptr_t);
StyleFn o_style = nullptr;
void H_Style(void* cam, uintptr_t a, uintptr_t b, uintptr_t c) {
    if ((uint8_t)a == (uint8_t)b || !g_fpOn) { o_style(cam, a, b, c); return; }
    AcquireSRWLockExclusive(&g_forceLock);
    FpApplyLocked(false);
    o_style(cam, a, b, c);
    FpApplyLocked(true);
    ReleaseSRWLockExclusive(&g_forceLock);
    LOGI("firstperson: the game switched the camera style - its new offsets are kept for third person");
}
} // namespace

bool GameScan() {
    IndexCode();
    LOGI("game: %zu tweakables, %zu renderer switches indexed", g_tweakObj.size(), g_dbgVar.size());
    g_game.camNear = (float*)Tweak("Camera:Near");
    g_game.camFov = (float*)Tweak("Camera:FOV");
    g_game.taaJitter = (float*)Tweak("TAA:Jitter Scale");
    g_game.taaResolve = Tweak("TAA:Resolve");
    g_game.vignette = (float*)Tweak("Cinematic Effect:Vignette");
    g_game.vbEnable = Tweak("Vector Blur:Enable");
    g_game.vbForce = Tweak("Vector Blur:Force Enable");
    const char* pos[4] = { "Camera:High Pos", "Camera:Mid Pos", "Camera:Low Pos", "Camera:Safe Pos" };
    for (int i = 0; i < 4; i++) g_game.camPos[i] = (float*)Tweak(pos[i]);
    g_game.safeEnable = TweakOptional("Safe Area: Tweak enable");
    g_game.safeX = (float*)TweakOptional("Safe Area: Tweak X");
    g_game.safeY = (float*)TweakOptional("Safe Area: Tweak Y");
    g_game.camCatch = (float*)Tweak("Camera:Catch Amount");
    g_game.camAngle = (float*)Tweak("Camera:Angle");
    g_game.camModernVel = (float*)TweakOptional("Camera:Modern Velocity Horizontal Offset Scale");
    float* modernOff = (float*)TweakOptional("Camera:Modern Central Offset Scale");
    // camera-style switch: the one function that reads Modern Central Offset Scale and also the Mid offset and Angle
    if (modernOff && g_game.camPos[1] && g_game.camAngle) {
        auto refs = RipRefs((uint8_t*)modernOff, 4);
        for (uint8_t* r : refs) {
            uint8_t* fn = FunctionStart(r, 0x200);
            if (!fn) continue;
            bool mid = false, ang = false;
            for (uint8_t* q : RipRefs((uint8_t*)g_game.camPos[1], 32)) if (q > fn && q < fn + 0x600) mid = true;
            for (uint8_t* q : RipRefs((uint8_t*)g_game.camAngle, 32)) if (q > fn && q < fn + 0x600) ang = true;
            if (mid && ang && MH_CreateHook(fn, (void*)&H_Style, (void**)&o_style) == MH_OK && MH_EnableHook(fn) == MH_OK) {
                LOGI("sig CameraStyleSwitch exe+%x hooked", Rva(fn)); break;
            }
        }
        if (!o_style) LOGW("game: camera-style switch not found (switching the camera style while in first person may move the view)");
    } else LOGI("game: no modern camera style in this build");
    g_game.dbgTaa = DebugVar("TAA");
    g_game.dbgAA = DebugVar("Antialiasing");
    g_game.dbgVectorBlur = DebugVar("Render Vector Blur");
    g_game.dbgFilmGrain = DebugVar("Film grain");
    g_game.dbgFilmGrainD3t = DebugVar("Enable Film Grain d3t");
    g_game.dbgUmbra = DebugVar("Use Umbra");
    g_game.dbgCinematicMode = DebugVar("Cinematic Mode");
    g_game.dbgVsync = DebugVar("VSync Enabled");

    // main-loop frame timer: lea rcx,[timer]; call Timer::lap; mov edx,[..]; xorps xmm7,xmm7; mov r8,[..]; movaps xmm6,xmm9; cvtsd2ss xmm7,xmm0
    // main-loop frame timer: lea rcx,[timer]; call Timer::lap; ... mov e?x,[count]; ... mov r?,[array]; ... cvtsd2ss xmmN,xmm0
    // The dt averaging ring is index, count, size, (pad), array pointer: count + 12 = array.
    uint8_t* lapSite = nullptr; int* cnt = nullptr; float** arr = nullptr;
    {
        auto ft = ScanText("48 8D 0D ?? ?? ?? ?? E8 ?? ?? ?? ?? 8B 15 ?? ?? ?? ?? 0F 57 FF 4C 8B 05 ?? ?? ?? ?? 41 0F 28 F1 F2 0F 5A F8", 4);
        if (ft.size() == 1) { lapSite = ft[0]; cnt = (int*)RipTarget(ft[0] + 12, 2, 6); arr = (float**)RipTarget(ft[0] + 21, 3, 7); }
        else {
            // semantic fallback: any lea rcx,[rip]; call - followed within 40 bytes by a 32-bit load of C and a 64-bit load of C+12
            std::vector<uint8_t*> hits;
            uint8_t* t = g_exe.text; size_t n = g_exe.textSize;
            for (size_t i = 0; i + 64 < n && hits.size() < 4; i++) {
                uint8_t* p = t + i;
                if (p[0] != 0x48 || p[1] != 0x8D || p[2] != 0x0D || p[7] != 0xE8) continue;
                int* c = nullptr; float** a = nullptr; bool cvt = false;
                // the count is loaded right after the lap returns (the limiter's own timer calls just convert it)
                for (uint8_t* q = p + 12; q < p + 24 && !c; q++) if (q[0] == 0x8B && (q[1] & 0xC7) == 0x05) c = (int*)RipTarget(q, 2, 6);
                if (!c) continue;
                for (uint8_t* q = p + 12; q < p + 52; q++) {
                    if (!a && (q[0] == 0x48 || q[0] == 0x4C) && q[1] == 0x8B && (q[2] & 0xC7) == 0x05) a = (float**)RipTarget(q, 3, 7);
                    if (q[0] == 0xF2 && ((q[1] == 0x0F && q[2] == 0x5A && (q[3] & 0xC7) == 0xC0) || (q[1] == 0x44 && q[2] == 0x0F && q[3] == 0x5A && (q[4] & 0xC7) == 0xC0))) cvt = true;
                }
                if (c && a && cvt && (uint8_t*)a == (uint8_t*)c + 12) { hits.push_back(p); lapSite = p; cnt = c; arr = a; }
            }
            if (hits.size() != 1) { lapSite = nullptr; cnt = nullptr; arr = nullptr; }
            if (lapSite) LOGI("game: frame timer found by its averaging ring (fallback)");
        }
    }
    if (lapSite) {
        g_game.frameTimer = RipTarget(lapSite, 3, 7);
        g_game.timerLap = Rel32Target(lapSite + 7);
        LOGI("sig FrameTimer exe+%x, Timer::lap exe+%x", Rva(g_game.frameTimer), Rva(g_game.timerLap));
        int* idx = cnt - 1; int* size = cnt + 1;
        if (Readable(idx, 24) && *size >= 1 && *size <= 64 && *idx >= 0 && *idx < *size && !RipRefs((uint8_t*)size, 2).empty()) {
            g_ring.idx = idx; g_ring.count = cnt; g_ring.size = size; g_ring.arr = arr; g_ring.origSize = *size;
            LOGI("sig FrameDtRing exe+%x (averages the last %d frames)", Rva(idx), *size);
        } else LOGW("game: frame time averaging not confirmed - synchronized stereo holds the clock less exactly");
        if (MH_CreateHook(g_game.timerLap, (void*)&H_Lap, (void**)&o_lap) == MH_OK && MH_EnableHook(g_game.timerLap) == MH_OK)
            LOGI("game: frame timer hooked (synchronized stereo available)");
        else { LOGE("game: frame timer hook failed"); g_game.frameTimer = nullptr; }
    } else LOGW("game: frame timer not found - synchronized stereo unavailable (alternate eye is used)");
    // the game's own frame limiter (busy wait before the lap): ... comiss xmm0, xmm9 ; jbe skip
    auto lim = ScanText("F3 44 0F 10 05 ?? ?? ?? ?? 45 0F 57 C9 41 0F 2F C1 76 ?? F3 0F 10 0D", 4);
    if (lim.size() == 1 && (lim[0][17] == 0x76 || lim[0][17] == 0xEB)) { g_game.limiterJump = lim[0] + 17; LOGI("sig GameFrameLimiter exe+%x (%s)", Rva(g_game.limiterJump), lim[0][17] == 0xEB ? "already patched" : "game's own"); }
    else LOGW("game: frame limiter pattern hits %zu", lim.size());

    // game modes: per-frame update = vtable slot 6 (every mode class overrides it)
    const char* modes[M_COUNT] = { ".?AVGameMode@@", ".?AVMenuMode@@", ".?AVLoadingMode@@", ".?AVVideoMode@@", ".?AVCreditsMode@@" };
    int hooked = 0;
    void* seen[M_COUNT] = {};
    for (int i = 0; i < M_COUNT; i++) {
        void** vt = RttiVtable(modes[i]);
        if (!vt || !InText(vt[6])) { LOGW("game: mode class %s not found", modes[i]); continue; }
        bool dup = false; for (int k = 0; k < i; k++) if (seen[k] == vt[6]) dup = true;
        seen[i] = vt[6];
        if (dup) { LOGW("game: %s shares its update with another mode - not used", modes[i]); continue; }
        if (MH_CreateHook(vt[6], kUpd[i], (void**)&g_modeOrig[i]) == MH_OK && MH_EnableHook(vt[6]) == MH_OK) {
            hooked++; LOGI("sig %s update (slot 6) exe+%x", modes[i], Rva(vt[6]));
        }
    }
    g_game.modesHooked = hooked >= 2;

    // focus events: the ModeSwitch listener method that prints "ModeSwitch: Focus Event - %s Focus" (searched in every
    // ModeSwitch vtable and slot, so a moved slot in another build is still found)
    if (uint8_t* fmt = FindString("ModeSwitch: Focus Event - %s Focus\n")) {
        uint8_t* fn = nullptr; int slotFound = -1, offFound = -1;
        for (uint32_t off : { 8u, 0u, 16u }) {
            void** vt = RttiVtable(".?AVModeSwitch@@", off);
            if (!vt) continue;
            for (int slot = 0; slot < 48 && !fn; slot++) {
                if (!Readable(&vt[slot], 8) || !InText(vt[slot])) break;
                uint8_t* f = (uint8_t*)vt[slot];
                for (uint8_t* q = f; q < f + 0x40; q++) if ((q[0] == 0x48 || q[0] == 0x4C) && q[1] == 0x8D && (q[2] & 0xC7) == 0x05 && RipTarget(q, 3, 7) == fmt) { fn = f; slotFound = slot; offFound = (int)off; break; }
            }
            if (fn) break;
        }
        if (fn && MH_CreateHook(fn, (void*)&H_Focus, (void**)&o_focus) == MH_OK && MH_EnableHook(fn) == MH_OK) {
            g_game.focusHooked = true; LOGI("sig FocusEvent exe+%x hooked (ModeSwitch +%x slot %d)", Rva(fn), offFound, slotFound);
        } else LOGW("game: focus handler not confirmed - keep running without focus unavailable");
    }

    // player global (debug display "Player    %.2fm/s": call getPlayer; mov rcx,rax; call getCharacter)
    uint8_t* pfmt = FindString("Player    %.2fm/s");
    if (pfmt) {
        for (uint8_t* q = g_exe.text; q + 7 < g_exe.text + g_exe.textSize && !g_game.playerGlobal; q++) {
            if (q[0] != 0x48 || q[1] != 0x8D || q[2] != 0x0D || RipTarget(q, 3, 7) != pfmt) continue;
            for (uint8_t* c = q; c < q + 0x80; c++) {
                if (c[0] != 0xE8) continue;
                uint8_t* f = Rel32Target(c);
                if (!InText(f) || f[0] != 0x48 || f[1] != 0x8B || f[2] != 0x05 || f[7] != 0xC3) continue;
                g_game.playerGlobal = (void**)RipTarget(f, 3, 7);
                for (uint8_t* d = c + 5; d < c + 0x20; d++) {
                    if (d[0] != 0xE8) continue;
                    uint8_t* g = Rel32Target(d);
                    if (InText(g) && g[0] == 0x48 && g[1] == 0x8B && g[2] == 0x41 && g[4] == 0xC3) { g_game.playerCharOff = g[3]; break; }
                }
                break;
            }
        }
    }
    if (g_game.playerGlobal) LOGI("sig PlayerGlobal exe+%x, character at player+%x", Rva(g_game.playerGlobal), g_game.playerCharOff);
    // camera pivot height: mov rcx,r14; call getComp; mov rcx,rax; call getHeight; movss xmm1,[pivot.y]; lea r9,[pivot]; addss xmm1,xmm0
    {
        auto ph = ScanText("49 8B CE E8 ?? ?? ?? ?? 48 8B C8 E8 ?? ?? ?? ?? F3 0F 10 4D ?? 4C 8D 4C 24 ?? F3 0F 58 C8", 4);
        if (ph.size() != 1 && g_game.camPos[2]) {
            // semantic fallback, near the player camera code (refs to Camera:Low Pos): call A; mov rcx,rax; call B; ... addss xmm?,xmm0
            // with A = mov rax,[rcx+d32]; ret and B = movss xmm0,[rcx+d32]; ret
            ph.clear();
            for (uint8_t* r : RipRefs((uint8_t*)g_game.camPos[2], 32)) {
                uint8_t* lo = r - 0x1800 > g_exe.text ? r - 0x1800 : g_exe.text, *hi = r + 0x1800;
                for (uint8_t* q = lo; q < hi && ph.size() < 2; q++) {
                    if (q[0] != 0xE8 || q[5] != 0x48 || q[6] != 0x8B || q[7] != 0xC8 || q[8] != 0xE8) continue;
                    uint8_t* A = Rel32Target(q), *B = Rel32Target(q + 8);
                    if (!InText(A) || !InText(B) || !(A[0] == 0x48 && A[1] == 0x8B && A[2] == 0x81 && A[7] == 0xC3) || !(B[0] == 0xF3 && B[1] == 0x0F && B[2] == 0x10 && B[3] == 0x81 && B[8] == 0xC3)) continue;
                    bool add = false; for (uint8_t* z = q + 13; z < q + 40; z++) if (z[0] == 0xF3 && z[1] == 0x0F && z[2] == 0x58 && (z[3] & 7) == 0) add = true;
                    if (add && std::find(ph.begin(), ph.end(), q - 3) == ph.end()) ph.push_back(q - 3);
                }
                if (!ph.empty()) break;
            }
            if (ph.size() == 1) LOGI("game: camera pivot height found by its getters (fallback)");
        }
        if (ph.size() == 1) {
            uint8_t* a = Rel32Target(ph[0] + 3); uint8_t* b = Rel32Target(ph[0] + 11);
            if (InText(a) && InText(b) && a[0] == 0x48 && a[1] == 0x8B && a[2] == 0x81 && a[7] == 0xC3 && b[0] == 0xF3 && b[1] == 0x0F && b[2] == 0x10 && b[3] == 0x81 && b[8] == 0xC3) {
                g_game.pivotCompOff = ReadI32(a + 3); g_game.pivotHeightOff = ReadI32(b + 4);
                LOGI("sig CameraPivotHeight exe+%x (character +%x -> +%x)", Rva(ph[0]), g_game.pivotCompOff, g_game.pivotHeightOff);
            }
        }
        if (g_game.pivotCompOff < 0) LOGW("game: camera pivot height not found - first person uses Eye Y as an offset from the pivot");
    }
    if (!g_game.playerGlobal) LOGW("game: player global not found (first person uses the camera offsets only)");

    // camera shake: mov rcx,[rdi+ctrl]; lea rdx,[rsp+m]; call Apply; lea rdx,[rsp+m]; mov rcx,rdi; call setTransform3x4.
    // Confirmed through the shake start (script "Shake" / cinematic moment): movss [rcx+a],xmm2; movss [rcx+b],xmm1;
    // mov dword [rcx+c],0; ret - Apply reads the same timer field c.
    {
        auto sh = ScanText("48 8B 8F ?? ?? ?? ?? 48 8D 54 24 ?? E8 ?? ?? ?? ?? 48 8D 54 24 ?? 48 8B CF E8", 8);
        auto st = ScanText("F3 0F 11 51 ?? F3 0F 11 49 ?? C7 41 ?? 00 00 00 00 C3", 8);
        uint8_t timer = 0; bool startOk = false;
        for (uint8_t* q : st) { if (!startOk) { timer = q[12]; startOk = true; } }
        uint8_t* apply = nullptr; int found = 0;
        for (uint8_t* q : sh) {
            uint8_t* f = Rel32Target(q + 12);
            if (!InText(f)) continue;
            bool reads = false;   // movss xmm?,[rcx+timer] near the start
            for (uint8_t* z = f; z < f + 0x40; z++) if (z[0] == 0xF3 && z[1] == 0x0F && z[2] == 0x10 && (z[3] & 0xC7) == 0x41 && z[4] == timer) reads = true;
            if (startOk && reads) { if (apply != f) found++; apply = f; }
        }
        if (found == 1 && MH_CreateHook(apply, (void*)&H_ShakeApply, (void**)&o_shakeApply) == MH_OK && MH_EnableHook(apply) == MH_OK)
            LOGI("sig CameraShakeApply exe+%x hooked (timer +%x)", Rva(apply), timer);
        else LOGW("game: camera shake controller not found (%zu / %zu candidates) - camera_shake has no effect", sh.size(), st.size());
    }

    // cinematic-moment camera: after the moment's blend time is loaded (Melee Camera In): movaps xmm2,xmm6; mov rdx,rdi; call focus
    if (FindString("Cinematic Moment:Melee Camera In")) {
        float* meleeIn = (float*)Tweak("Cinematic Moment:Melee Camera In");
        if (meleeIn) for (uint8_t* r : RipRefs((uint8_t*)meleeIn, 8)) {
            // the first call after the blend time is loaded whose float argument (xmm2) is set right before it:
            // movaps xmm2,xmmN (0F 28 D0+N or 41 0F 28 D0+N) within 8 bytes of the call
            for (uint8_t* q = r + 8; q < r + 0x60 && !g_momentRet; q++) {
                if (q[0] != 0xE8) continue;
                bool x2 = false;
                for (uint8_t* z = q - 8; z < q; z++) if ((z[0] == 0x0F && z[1] == 0x28 && (z[2] & 0xF8) == 0xD0) || (z[0] == 0x41 && z[1] == 0x0F && z[2] == 0x28 && (z[3] & 0xF8) == 0xD0)) x2 = true;
                if (!x2) continue;
                uint8_t* fn = Rel32Target(q);
                if (InText(fn) && MH_CreateHook(fn, (void*)&H_FocusCam, (void**)&o_focusCam) == MH_OK && MH_EnableHook(fn) == MH_OK) {
                    g_momentRet = q + 5; LOGI("sig ActionCamera exe+%x (called from exe+%x)", Rva(fn), Rva(q));
                }
                break;
            }
            if (g_momentRet) break;
        }
        if (!g_momentRet) LOGW("game: cinematic-moment camera not found - action_cameras has no effect");
    }

    // Bink video (imports by name)
    void* p;
    if ((p = PatchImport("bink2w64.dll", "BinkOpen", (void*)&H_BinkOpen))) o_binkOpen = (BinkOpenFn)p;
    if ((p = PatchImport("bink2w64.dll", "BinkClose", (void*)&H_BinkClose))) o_binkClose = (BinkVoidFn)p;
    if ((p = PatchImport("bink2w64.dll", "BinkNextFrame", (void*)&H_BinkNext))) o_binkNext = (BinkVoidFn)p;
    g_game.binkHooked = o_binkOpen && o_binkClose && o_binkNext;
    LOGI("video: Bink imports %s", g_game.binkHooked ? "hooked" : "not all found");
    return true;
}

void GameApplySettings() {
    AcquireSRWLockExclusive(&g_forceLock);
    // game anti-aliasing: game = untouched, off / on = forced while chosen
    // true stereo: both eyes are drawn in one frame - TAA history and motion-blur velocities would be taken from the
    // other eye (ghost images at every edge), so both are off while it draws 3D (unless game_aa = on), restored after.
    // The game's occlusion culling (Umbra) stays on in true stereo (true_stereo_occlusion, default): with it off the
    // renderer takes its plain frustum-culling path (RenderView core exe+5095dd: Umbra exe+4befa0, else exe+4bf850)
    // and the ground (terrain) was missing in both eyes (0.10.25 report - likely that path; not yet confirmed in game). Umbra reuses the last frame's
    // visibility, so two cameras per frame may make objects pop at the edges - off is still there for that.
    const int eff = EngineEffectiveMode();
    bool native = eff == VRMODE_NATIVE && EngineNative3d();
    bool aaForce = g_set.gameAA != "game" || native; bool aaOn = g_set.gameAA == "on";
    // an upscaler (the game's DLSS / DLAA, or one behind it) needs the game's jitter: never switch TAA / jitter off then
    // (from the exe: with DLSS on the renderer takes its own jitter path - TAA:Jitter Scale and the TAA switch are not used,
    // and the game clears the TAA switch itself - so the mod leaves both alone: forcing them could only fight the game)
    if (UpscalerActive() && aaForce) {
        static bool said = false; if (!said) { said = true; LOGI("game: an upscaler is active - the game's TAA / jitter are left as the game sets them (DLSS has its own jitter)"); }
        aaForce = false;
    }
    ForceByte(g_game.dbgTaa, g_sv_taa, aaForce, aaOn ? 1 : 0);
    ForceByte(g_game.taaResolve, g_sv_taar, aaForce, aaOn ? 1 : 0);
    ForceFloat(g_game.taaJitter, g_sv_jit, aaForce && !aaOn, 0.f);
    bool mbOff = g_set.motionBlurOff || native;
    ForceByte(g_game.dbgVectorBlur, g_sv_vb, mbOff, 0);
    ForceByte(g_game.vbEnable, g_sv_vbt, mbOff, 0);
    ForceByte(g_game.vbForce, g_sv_vbf, mbOff, 0);
    ForceByte(g_game.dbgFilmGrain, g_sv_grain, g_set.filmGrainOff, 0);
    ForceByte(g_game.dbgFilmGrainD3t, g_sv_grain2, g_set.filmGrainOff, 0);
    ForceFloat(g_game.vignette, g_sv_vig, g_set.vignetteOff, 0.f);
    ForceByte(g_game.dbgUmbra, g_sv_umbra, !g_set.occlusionCulling || (native && !g_set.stereoOcclusion), 0);
    ForceByte(g_game.dbgCinematicMode, g_sv_cine, g_set.noBlackBars, 0);
    // near clip: only ever closer than the game's (tweakable range is 0.1 .. 0.5)
    if (g_game.camNear) {
        float nc = EffectiveNearClip();
        bool f = nc > 0.f && nc < (g_sv_near.have ? g_sv_near.f : *g_game.camNear);
        ForceFloat(g_game.camNear, g_sv_near, f, nc < 0.1f ? 0.1f : nc);
    }
    if (g_game.limiterJump) {
        static const uint8_t orig = *g_game.limiterJump;   // the exe's own byte (0x76 jbe, or 0xEB if already patched): restored exactly
        uint8_t want = g_set.gameFrameCap == "off" ? 0xEB : orig;
        if (*g_game.limiterJump != want) {
            DWORD old; VirtualProtect(g_game.limiterJump, 1, PAGE_EXECUTE_READWRITE, &old);
            *g_game.limiterJump = want; VirtualProtect(g_game.limiterJump, 1, old, &old);
            FlushInstructionCache(GetCurrentProcess(), g_game.limiterJump, 1);
            LOGI("game: own frame limiter %s", want == 0xEB ? "skipped" : "restored");
        }
    }
    // HUD in the game's own layout, inset by its safe area (getSafeArea exe+1e0710 feeds the HUD, subtitle and menu
    // layout: 59 callers) - sharp, nothing rescaled; the compositor only moves it to each eye's centre
    {
        // "scale" where the HUD never shows up as separate draws (it is baked into the picture on some builds): the
        // game's own safe area keeps it in the middle, inside both eyes' views (one eye's picture is cut on the inside)
        bool safe = (g_set.hudMode == "safe" || (g_set.hudMode == "scale" && !D3DHooksUiSeen())) && eff != VRMODE_SCREEN && eff != VRMODE_NATIVE;
        float sx = g_set.hudSafeX < 0 ? 0 : g_set.hudSafeX > 0.45f ? 0.45f : g_set.hudSafeX, sy = g_set.hudSafeY < 0 ? 0 : g_set.hudSafeY > 0.45f ? 0.45f : g_set.hudSafeY;
        ForceByte(g_game.safeEnable, g_sv_safeE, safe && g_game.safeX && g_game.safeY, 1);
        ForceFloat(g_game.safeX, g_sv_safeX, safe, sx);
        ForceFloat(g_game.safeY, g_sv_safeY, safe, sy);
    }
    // synchronized stereo: the dt averaging ring is one entry long while chosen (restored otherwise)
    if (g_ring.size) {
        bool want = eff == VRMODE_SYNCED && g_game.frameTimer;   // the method in use (also after a fall back)
        if (want && !g_ring.on) { *g_ring.size = 1; *g_ring.count = 1; *g_ring.idx = 0; g_ring.on = true; LOGI("synchronized: game step averaging %d -> 1 frame (restored when another method is chosen)", g_ring.origSize); }
        else if (!want && g_ring.on) { g_ring.on = false; *g_ring.size = g_ring.origSize; LOGI("synchronized: game step averaging restored to %d frames", g_ring.origSize); }
        else if (want && (*g_ring.size != 1 || *g_ring.idx != 0)) { *g_ring.size = 1; *g_ring.count = 1; *g_ring.idx = 0; }
    }
    FpApplyLocked(g_set.firstPerson);
    if (g_set.firstPerson != g_fpOn) {
        g_fpOn = g_set.firstPerson;
        LOGI("firstperson: %s (camera offsets %s, catch %s, angle %s, style hook %s)", g_fpOn ? "on" : "off", g_game.camPos[1] ? "found" : "NOT found",
             g_game.camCatch ? "ok" : "-", g_game.camAngle ? "ok" : "-", o_style ? "ok" : "-");
    }
    ReleaseSRWLockExclusive(&g_forceLock);
}

void GameFirstPerson(bool, float, float, float) { GameApplySettings(); }
float GameFirstPersonLift() { return g_fpOn ? g_fpLift.load() : 0.f; }
void GameNoteWorldLift() { g_worldLiftTick = rc::TickMs(); }   // the values come from g_set

GameState GameStateNow() {
    if (!g_game.modesHooked) return GS_UNKNOWN;
    DWORD now = rc::TickMs();
    for (int m = 0; m < M_COUNT; m++) { long c = g_modeCount[m]; if (c != g_modeSeen[m]) { g_modeSeen[m] = c; g_modeTick[m] = now; } }
    auto recent = [&](int m) { return g_modeTick[m] && now - g_modeTick[m] < 250; };
    if (recent(M_VIDEO)) return GS_VIDEO;
    if (recent(M_LOADING)) return GS_LOADING;
    if (recent(M_CREDITS)) return GS_CREDITS;
    if (recent(M_MENU)) return GS_MENU;
    if (recent(M_GAME)) return GS_GAMEPLAY;
    return GS_UNKNOWN;
}
const char* GameStateName(GameState s) {
    static const char* n[] = { "unknown", "gameplay", "menu", "loading", "video", "credits" };
    return n[s];
}
bool GameVideoPlaying(int minWidth) {
    return g_bink.load() && (int)g_binkW.load() >= minWidth && rc::TickMs() - g_binkTick.load() < 500;
}
void GameClockHoldNext(bool hold) { g_holdNext = hold; }
bool GameClockLastWasHeld() { return g_lastHeld; }
uint32_t GameTicks() { return g_ticks; }

void GameReport() {
    void* pl = g_game.playerGlobal && Readable(g_game.playerGlobal, 8) ? *g_game.playerGlobal : nullptr;
    void* ch = pl && g_game.playerCharOff >= 0 && Readable((uint8_t*)pl + g_game.playerCharOff, 8) ? *(void**)((uint8_t*)pl + g_game.playerCharOff) : nullptr;
    if (s_shakeScaled.load()) { LOGI("game: camera shake scaled x%.2f on %u of %u frames", g_set.cameraShake, s_shakeScaled.load(), s_shakeApplied.load()); s_shakeScaled = 0; }
    s_shakeApplied = 0;
    if (s_momentSkipped.load()) { LOGI("game: action camera swings skipped %u", s_momentSkipped.load()); s_momentSkipped = 0; }
    LOGI("game: state %s, ticks %u (held %u), focus-loss events dropped %u, video %s %ux%u | player %p %s, character %p %s",
         GameStateName(GameStateNow()), g_ticks.load(), s_held.load(), s_focusDropped.load(), g_bink.load() ? "open" : "none",
         g_binkW.load(), g_binkH.load(), pl, RttiName(pl), ch, RttiName(ch));
    s_held = 0; s_focusDropped = 0;
    if (g_set.firstPerson) {
        float h = PivotHeight();
        if (h > 0) LOGI("firstperson: camera pivot reads %.2f, eye set to %.2f (fp_eye_height %.2f, Eye Y %+.2f)", h,
                        g_set.fpEyeHeight > 0 ? g_set.fpEyeHeight + g_set.fpOffsetY : h + g_set.fpOffsetY, g_set.fpEyeHeight, g_set.fpOffsetY);
        else LOGI("firstperson: pivot height not readable here - Eye Y is the offset from the camera pivot");
    }
}

bool GameTaaOn() { return g_game.dbgTaa && *g_game.dbgTaa != 0; }
