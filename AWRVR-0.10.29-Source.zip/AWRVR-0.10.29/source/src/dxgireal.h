#pragma once
// The real DXGI (System32, or dxgi_chain.dll next to the game to chain another dxgi.dll mod such as ReShade).
// The mod never imports dxgi.dll itself: loaded AS dxgi.dll, an import of its own name would bind to itself.
#include <windows.h>
HMODULE RealDxgi();
FARPROC RealDxgiProc(const char* name);
HRESULT RealCreateDXGIFactory1(REFIID riid, void** out);   // no hooks: the mod's own factories
