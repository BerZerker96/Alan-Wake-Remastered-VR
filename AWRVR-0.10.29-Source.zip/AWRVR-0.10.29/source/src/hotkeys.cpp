// Hotkeys: every important function of the mod can be put on a keyboard key (with Ctrl / Shift / Alt) and / or a
// controller button or button combination. Shown and remapped on the VR panel's "Hotkeys" tab; saved in
// awrvr_config.txt as hotkey_<name> = <keyboard>, <controller>  (e.g. "hotkey_first_person = END, PAD LB+Y").
//  - Keyboards: any (GetAsyncKeyState), only while the game window is in front.
//  - Controllers: every XInput pad (slots 1-4; Xbox and pads mapped to XInput by Steam / DS4Windows / ...) read through
//    the real XInputGetState, and every other game controller through DirectInput ("JOY B3", "JOY POV UP").
//  - A controller binding fires when its last button goes down while the others are held (combos such as LB+Y).
//  - Nothing fires while the VR panel is open (the panel uses the same buttons).
#include "hotkeys.h"
#include "vrkit_options.h"
#include "vrkit_input.h"
#include "vrkit_menu_core.h"
#include "settings.h"
#include "headaim.h"
#include "config.h"
#include "engine.h"
#include "log.h"
#include "realclock.h"
#include <windows.h>
#include <xinput.h>
#define DIRECTINPUT_VERSION 0x0800
#include <dinput.h>
#include <string>
#include <vector>
#include <functional>
#include <atomic>
#include <algorithm>

void SettingsCycleMode();
int PanelMouseTakeExtraButton();
long PanelMouseRightPresses();
void CompositorRecenter();
void FlatToggle();
void FirstPersonToggle();

namespace {
struct Action { const char* id; const char* label; const char* def; const char* help; std::function<void()> run; std::string bind; std::string key; std::string dflt; };
std::vector<Action> g_acts;
bool g_shot = false;

// ---------------------------------------------------------------- names
struct KeyName { int vk; const char* n; };
const KeyName kKeys[] = {
    { VK_F1, "F1" }, { VK_F2, "F2" }, { VK_F3, "F3" }, { VK_F4, "F4" }, { VK_F5, "F5" }, { VK_F6, "F6" }, { VK_F7, "F7" }, { VK_F8, "F8" },
    { VK_F9, "F9" }, { VK_F10, "F10" }, { VK_F11, "F11" }, { VK_F12, "F12" }, { VK_INSERT, "INSERT" }, { VK_DELETE, "DELETE" }, { VK_HOME, "HOME" },
    { VK_END, "END" }, { VK_PRIOR, "PAGEUP" }, { VK_NEXT, "PAGEDOWN" }, { VK_UP, "UP" }, { VK_DOWN, "DOWN" }, { VK_LEFT, "LEFT" }, { VK_RIGHT, "RIGHT" },
    { VK_SPACE, "SPACE" }, { VK_RETURN, "ENTER" }, { VK_BACK, "BACKSPACE" }, { VK_TAB, "TAB" }, { VK_PAUSE, "PAUSE" }, { VK_SCROLL, "SCROLLLOCK" },
    { VK_CAPITAL, "CAPSLOCK" }, { VK_NUMPAD0, "NUM0" }, { VK_NUMPAD1, "NUM1" }, { VK_NUMPAD2, "NUM2" }, { VK_NUMPAD3, "NUM3" }, { VK_NUMPAD4, "NUM4" },
    { VK_NUMPAD5, "NUM5" }, { VK_NUMPAD6, "NUM6" }, { VK_NUMPAD7, "NUM7" }, { VK_NUMPAD8, "NUM8" }, { VK_NUMPAD9, "NUM9" }, { VK_MULTIPLY, "NUMSTAR" },
    { VK_ADD, "NUMPLUS" }, { VK_SUBTRACT, "NUMMINUS" }, { VK_DIVIDE, "NUMSLASH" }, { VK_DECIMAL, "NUMDOT" }, { VK_OEM_PLUS, "EQUALS" }, { VK_OEM_MINUS, "MINUS" },
    { VK_OEM_COMMA, "COMMA" }, { VK_OEM_PERIOD, "PERIOD" }, { VK_OEM_1, "SEMICOLON" }, { VK_OEM_2, "SLASH" }, { VK_OEM_3, "BACKQUOTE" }, { VK_OEM_4, "LBRACKET" }, { VK_OEM_5, "BACKSLASH" },
    { VK_OEM_6, "RBRACKET" }, { VK_OEM_7, "QUOTE" }, { VK_XBUTTON1, "MOUSE4" }, { VK_XBUTTON2, "MOUSE5" }, { VK_MBUTTON, "MOUSE3" } };
std::string VkName(int vk) {
    for (auto& k : kKeys) if (k.vk == vk) return k.n;
    if ((vk >= '0' && vk <= '9') || (vk >= 'A' && vk <= 'Z')) return std::string(1, (char)vk);
    char b[16]; snprintf(b, sizeof b, "VK%02X", vk); return b;
}
int VkFromName(const std::string& n) {
    for (auto& k : kKeys) if (n == k.n) return k.vk;
    if (n.size() == 1 && ((n[0] >= '0' && n[0] <= '9') || (n[0] >= 'A' && n[0] <= 'Z'))) return n[0];
    if (n.size() > 2 && n[0] == 'V' && n[1] == 'K') return (int)strtol(n.c_str() + 2, nullptr, 16);
    return 0;
}
struct PadName { WORD bit; const char* n; };
const PadName kPad[] = { { XINPUT_GAMEPAD_A, "A" }, { XINPUT_GAMEPAD_B, "B" }, { XINPUT_GAMEPAD_X, "X" }, { XINPUT_GAMEPAD_Y, "Y" },
    { XINPUT_GAMEPAD_LEFT_SHOULDER, "LB" }, { XINPUT_GAMEPAD_RIGHT_SHOULDER, "RB" }, { XINPUT_GAMEPAD_BACK, "BACK" }, { XINPUT_GAMEPAD_START, "START" },
    { XINPUT_GAMEPAD_LEFT_THUMB, "L3" }, { XINPUT_GAMEPAD_RIGHT_THUMB, "R3" }, { XINPUT_GAMEPAD_DPAD_UP, "UP" }, { XINPUT_GAMEPAD_DPAD_DOWN, "DOWN" },
    { XINPUT_GAMEPAD_DPAD_LEFT, "LEFT" }, { XINPUT_GAMEPAD_DPAD_RIGHT, "RIGHT" } };
constexpr DWORD kLT = 0x10000, kRT = 0x20000;   // triggers as extra "buttons"

std::string Trim(std::string s) { while (!s.empty() && (s.back() == ' ' || s.back() == '\t')) s.pop_back(); size_t a = s.find_first_not_of(" \t"); return a == std::string::npos ? "" : s.substr(a); }
std::string Upper(std::string s) { for (auto& c : s) c = (char)toupper((unsigned char)c); return s; }
std::vector<std::string> Split(const std::string& s, char sep) { std::vector<std::string> r; size_t a = 0; for (;;) { size_t b = s.find(sep, a); r.push_back(Trim(s.substr(a, b == std::string::npos ? std::string::npos : b - a))); if (b == std::string::npos) break; a = b + 1; } return r; }

// (key names never contain ',' or '+': those separate the parts of a binding)
// a parsed binding
// joy bits: 0-31 buttons B1-B32, 32-35 hat 1 up/right/down/left, 36-51 axes X Y Z RX RY RZ S0 S1 (+ then -), 52-55 hat 2
const char* const kAxis[8] = { "X", "Y", "Z", "RX", "RY", "RZ", "S0", "S1" };
struct Bind { int vk = 0; bool ctrl = false, shift = false, alt = false; DWORD pad = 0; uint64_t joy = 0; };
Bind Parse(const std::string& text) {
    Bind b;
    for (std::string part : Split(Upper(text), ',')) {
        if (part.empty()) continue;
        if (part.rfind("PAD ", 0) == 0) {
            for (std::string t : Split(part.substr(4), '+')) {
                if (t == "LT") b.pad |= kLT; else if (t == "RT") b.pad |= kRT;
                else for (auto& p : kPad) if (t == p.n) b.pad |= p.bit;
            }
        } else if (part.rfind("JOY ", 0) == 0) {
            for (std::string t : Split(part.substr(4), '+')) {
                if (t.size() > 1 && t[0] == 'B' && isdigit((unsigned char)t[1])) { int n = atoi(t.c_str() + 1); if (n >= 1 && n <= 32) b.joy |= 1ull << (n - 1); continue; }
                const char* dirs[4] = { "UP", "RIGHT", "DOWN", "LEFT" };
                for (int h = 0; h < 2; h++) for (int d = 0; d < 4; d++) {
                    std::string nm = std::string(h ? "POV2 " : "POV ") + dirs[d];
                    if (t == nm) b.joy |= 1ull << ((h ? 52 : 32) + d);
                }
                for (int a = 0; a < 8; a++) {
                    if (t == std::string(kAxis[a]) + "UP") b.joy |= 1ull << (36 + a * 2);     // "X+" is written "XUP" ('+' separates)
                    if (t == std::string(kAxis[a]) + "DOWN") b.joy |= 1ull << (37 + a * 2);
                }
            }
        } else {
            for (std::string t : Split(part, '+')) {
                if (t == "CTRL") b.ctrl = true; else if (t == "SHIFT") b.shift = true; else if (t == "ALT") b.alt = true; else b.vk = VkFromName(t);
            }
        }
    }
    return b;
}
std::string PadText(DWORD pad) {
    std::string s;
    for (auto& p : kPad) if (pad & p.bit) s += (s.empty() ? "" : "+") + std::string(p.n);
    if (pad & kLT) s += (s.empty() ? "" : "+") + std::string("LT");
    if (pad & kRT) s += (s.empty() ? "" : "+") + std::string("RT");
    return s;
}
std::string JoyText(uint64_t j) {
    std::string s; char b[16];
    for (int i = 0; i < 32; i++) if (j & (1ull << i)) { snprintf(b, sizeof b, "B%d", i + 1); s += (s.empty() ? "" : "+") + std::string(b); }
    const char* pov[4] = { "POV UP", "POV RIGHT", "POV DOWN", "POV LEFT" }, *pov2[4] = { "POV2 UP", "POV2 RIGHT", "POV2 DOWN", "POV2 LEFT" };
    for (int i = 0; i < 4; i++) if (j & (1ull << (32 + i))) s += (s.empty() ? "" : "+") + std::string(pov[i]);
    for (int a = 0; a < 8; a++) {
        if (j & (1ull << (36 + a * 2))) s += (s.empty() ? "" : "+") + std::string(kAxis[a]) + "UP";
        if (j & (1ull << (37 + a * 2))) s += (s.empty() ? "" : "+") + std::string(kAxis[a]) + "DOWN";
    }
    for (int i = 0; i < 4; i++) if (j & (1ull << (52 + i))) s += (s.empty() ? "" : "+") + std::string(pov2[i]);
    return s;
}
std::string KeyText(const Bind& b) {
    if (!b.vk) return "";
    return std::string(b.ctrl ? "CTRL+" : "") + (b.shift ? "SHIFT+" : "") + (b.alt ? "ALT+" : "") + VkName(b.vk);
}
std::string Compose(const Bind& b) {
    std::string s = KeyText(b);
    if (b.pad) s += (s.empty() ? "" : ", ") + std::string("PAD ") + PadText(b.pad);
    if (b.joy) s += (s.empty() ? "" : ", ") + std::string("JOY ") + JoyText(b.joy);
    return s;
}

// ---------------------------------------------------------------- devices
using XGet = DWORD(WINAPI*)(DWORD, XINPUT_STATE*);
DWORD PadNow() {
    DWORD all = 0;
    for (unsigned u = 0; u < 4; u++) {
        XINPUT_STATE st{};
        if (!vrkit::input::ReadPad(u, &st)) continue;
        all |= st.Gamepad.wButtons;
        if (st.Gamepad.bLeftTrigger > 150) all |= kLT;
        if (st.Gamepad.bRightTrigger > 150) all |= kRT;
    }
    return all;
}
// DirectInput: every attached game controller that is not an XInput pad (those are read above)
IDirectInput8W* g_di = nullptr;
struct Joy { IDirectInputDevice8W* d; LONG rest[8]; bool haveRest; GUID guid; };
std::vector<Joy> g_joys;                            // owned by the enumeration thread, swapped under g_joyLock
SRWLOCK g_joyLock = SRWLOCK_INIT;
std::vector<Joy> g_found; std::vector<GUID> g_seen;
std::atomic<uint32_t> g_joyNav{0};                  // the panel's buttons from these controllers (vrkit extra source)
HWND GameWindow() {
    struct F { static BOOL CALLBACK P(HWND h, LPARAM lp) { DWORD pid = 0; GetWindowThreadProcessId(h, &pid);
        if (pid == GetCurrentProcessId() && IsWindowVisible(h) && !GetWindow(h, GW_OWNER)) { *(HWND*)lp = h; return FALSE; } return TRUE; } };
    HWND h = nullptr; EnumWindows(F::P, (LPARAM)&h); return h;
}
BOOL CALLBACK EnumJoy(const DIDEVICEINSTANCEW* inst, void*) {
    g_seen.push_back(inst->guidInstance);
    for (auto& j : g_joys) if (j.guid == inst->guidInstance) return DIENUM_CONTINUE;   // already open: keep it (and its rest values)
    IDirectInputDevice8W* d = nullptr;
    if (FAILED(g_di->CreateDevice(inst->guidInstance, &d, nullptr)) || !d) return DIENUM_CONTINUE;
    DIPROPGUIDANDPATH gp{}; gp.diph.dwSize = sizeof gp; gp.diph.dwHeaderSize = sizeof(DIPROPHEADER); gp.diph.dwHow = DIPH_DEVICE;
    bool xinput = SUCCEEDED(d->GetProperty(DIPROP_GUIDANDPATH, &gp.diph)) && (wcsstr(gp.wszPath, L"IG_") || wcsstr(gp.wszPath, L"ig_"));
    HWND w = GameWindow();
    if (xinput || FAILED(d->SetDataFormat(&c_dfDIJoystick2)) || !w || FAILED(d->SetCooperativeLevel(w, DISCL_BACKGROUND | DISCL_NONEXCLUSIVE))) { d->Release(); return DIENUM_CONTINUE; }
    // every axis 0..65535 (triggers / pedals / sticks as buttons past 60 % of their travel from where they rest)
    DIPROPRANGE pr{}; pr.diph.dwSize = sizeof pr; pr.diph.dwHeaderSize = sizeof(DIPROPHEADER); pr.diph.dwHow = DIPH_DEVICE; pr.lMin = 0; pr.lMax = 65535;
    d->SetProperty(DIPROP_RANGE, &pr.diph);
    d->Acquire();
    g_found.push_back({ d, {}, false, inst->guidInstance });
    LOGI("hotkeys: controller '%ls' (DirectInput)", inst->tszProductName);
    return DIENUM_CONTINUE;
}
// enumeration thread: controllers plugged in / out are picked up within 5 s, the frame never waits for it
DWORD WINAPI JoyThread(LPVOID) {
    SetThreadPriority(GetCurrentThread(), THREAD_PRIORITY_BELOW_NORMAL);
    size_t lastCount = (size_t)-1;
    for (;;) {
        if (!g_di && FAILED(DirectInput8Create(GetModuleHandleW(nullptr), DIRECTINPUT_VERSION, IID_IDirectInput8W, (void**)&g_di, nullptr))) g_di = nullptr;
        if (g_di && GameWindow()) {
            // only new controllers are opened and unplugged ones closed - the others keep running untouched
            g_found.clear(); g_seen.clear();
            g_di->EnumDevices(DI8DEVCLASS_GAMECTRL, EnumJoy, nullptr, DIEDFL_ATTACHEDONLY);
            std::vector<Joy> gone;
            AcquireSRWLockExclusive(&g_joyLock);
            for (size_t i = 0; i < g_joys.size();) {
                bool still = false; for (auto& g : g_seen) if (g == g_joys[i].guid) still = true;
                if (still) i++; else { gone.push_back(g_joys[i]); g_joys.erase(g_joys.begin() + i); }
            }
            for (auto& j : g_found) g_joys.push_back(j);
            ReleaseSRWLockExclusive(&g_joyLock);
            for (auto& j : gone) { j.d->Unacquire(); j.d->Release(); }
            if (g_joys.size() != lastCount) { lastCount = g_joys.size(); LOGI("hotkeys: %zu DirectInput controller(s) besides the XInput pads", lastCount); }
        }
        Sleep(5000);
    }
}
uint64_t JoyNow() {
    static bool started = false;
    if (!started) { started = true; CreateThread(nullptr, 0, JoyThread, nullptr, 0, nullptr); }
    uint64_t all = 0;
    uint32_t nav = 0;
    AcquireSRWLockExclusive(&g_joyLock);   // (rest values are written)
    for (auto& j : g_joys) {
        IDirectInputDevice8W* d = j.d;
        if (FAILED(d->Poll())) { d->Acquire(); d->Poll(); }
        DIJOYSTATE2 js{};
        if (FAILED(d->GetDeviceState(sizeof js, &js))) continue;
        for (int i = 0; i < 32; i++) if (js.rgbButtons[i] & 0x80) all |= 1ull << i;
        for (int h = 0; h < 2; h++) {
            DWORD p = js.rgdwPOV[h]; int base = h ? 52 : 32;
            if (LOWORD(p) == 0xFFFF) continue;
            if (p >= 31500 || p <= 4500) all |= 1ull << base;
            if (p >= 4500 && p <= 13500) all |= 1ull << (base + 1);
            if (p >= 13500 && p <= 22500) all |= 1ull << (base + 2);
            if (p >= 22500 && p <= 31500) all |= 1ull << (base + 3);
        }
        LONG ax[8] = { js.lX, js.lY, js.lZ, js.lRx, js.lRy, js.lRz, js.rglSlider[0], js.rglSlider[1] };
        if (!j.haveRest) { for (int a = 0; a < 8; a++) j.rest[a] = ax[a]; j.haveRest = true; }   // where the axes rest when first seen
        for (int a = 0; a < 8; a++) {
            LONG dlt = ax[a] - j.rest[a];
            if (dlt > 19660) all |= 1ull << (36 + a * 2);
            if (dlt < -19660) all |= 1ull << (37 + a * 2);
        }
        // the panel with these controllers: hat or left stick = directions, PlayStation layout for the buttons
        // (B2 Cross = accept, B3 Circle = back, B4 Triangle = default, B5 / B6 L1 / R1 = tabs, B11 + B12 L3 + R3 = open / close)
        DWORD p = js.rgdwPOV[0];
        if (LOWORD(p) != 0xFFFF) { if (p >= 31500 || p <= 4500) nav |= vrkit::input::Up; if (p >= 13500 && p <= 22500) nav |= vrkit::input::Down;
                                   if (p >= 4500 && p <= 13500) nav |= vrkit::input::Right; if (p >= 22500 && p <= 31500) nav |= vrkit::input::Left; }
        // (relative to where the stick rests: a controller without X / Y axes reports 0 there and must not "press" them)
        if (ax[1] - j.rest[1] < -16000) nav |= vrkit::input::Up; if (ax[1] - j.rest[1] > 16000) nav |= vrkit::input::Down;
        if (ax[0] - j.rest[0] < -16000) nav |= vrkit::input::Left; if (ax[0] - j.rest[0] > 16000) nav |= vrkit::input::Right;
        if (js.rgbButtons[1] & 0x80) nav |= vrkit::input::Accept;
        if (js.rgbButtons[2] & 0x80) nav |= vrkit::input::Back;
        if (js.rgbButtons[3] & 0x80) nav |= vrkit::input::Reset;
        if (js.rgbButtons[4] & 0x80) nav |= vrkit::input::PagePrev;
        if (js.rgbButtons[5] & 0x80) nav |= vrkit::input::PageNext;
        if ((js.rgbButtons[10] & 0x80) && (js.rgbButtons[11] & 0x80)) nav |= vrkit::input::Toggle;
    }
    g_joyNav = nav;
    ReleaseSRWLockExclusive(&g_joyLock);
    return all;
}
bool Down(int vk) { return (GetAsyncKeyState(vk) & 0x8000) != 0; }
bool GameInFront() { HWND fg = GetForegroundWindow(); DWORD pid = 0; if (fg) GetWindowThreadProcessId(fg, &pid); return pid == GetCurrentProcessId(); }

// ---------------------------------------------------------------- capture (the panel is modal while it listens)
int g_capturing = -1; DWORD g_capStart = 0; bool g_capReleased = false; DWORD g_capPadUnion = 0; uint64_t g_capJoyUnion = 0; long g_capRight = 0;
void UpdateHiddenChords();
bool AnyInputDown() {
    for (int vk = 8; vk < 256; vk++) if (vk != VK_LBUTTON && vk != VK_RBUTTON && Down(vk)) return true;
    return PadNow() != 0 || JoyNow() != 0;
}
void Store(int a, const Bind& nb) {
    g_acts[a].bind = Compose(nb);
    LOGI("hotkeys: %s = %s", g_acts[a].id, g_acts[a].bind.empty() ? "(none)" : g_acts[a].bind.c_str());
    SettingsSave();   // written to awrvr_config.txt at once
    UpdateHiddenChords();
}
int Bits(DWORD v) { int n = 0; while (v) { n += v & 1; v >>= 1; } return n; }
// controller combos (2+ buttons) are hidden from the game while held, so e.g. LB+Y does not also fire the game's Y
void UpdateHiddenChords() {
    unsigned c[64]; int n = 0;
    for (auto& a : g_acts) { Bind b = Parse(a.bind); if (b.pad && Bits(b.pad) >= 2 && n < 64) c[n++] = b.pad; }
    vrkit::input::SetHiddenChords(c, n);
}
bool CapturePoll() {
    if (g_capturing < 0) return false;
    DWORD now = rc::TickMs();
    if (now - g_capStart > 10000) { g_capturing = -1; return false; }               // nothing pressed: unchanged
    if (!g_capReleased) { if (!AnyInputDown()) g_capReleased = true; return true; }  // the A / Enter / click that started it
    if (Down(VK_ESCAPE) || PanelMouseRightPresses() != g_capRight) { g_capturing = -1; return false; }   // Esc / right click: cancel
    Bind b = Parse(g_acts[g_capturing].bind);
    // mouse: middle and side buttons (the panel's mouse hook sees them; left / right stay the panel's own)
    if (int mvk = PanelMouseTakeExtraButton()) {
        b.vk = mvk; b.ctrl = Down(VK_CONTROL); b.shift = Down(VK_SHIFT); b.alt = Down(VK_MENU);
        Store(g_capturing, b); g_capturing = -1;
        return false;
    }
    // keyboard: the first non-modifier key, with the modifiers held at that moment
    for (int vk = 8; vk < 256; vk++) {
        if (vk == VK_LBUTTON || vk == VK_RBUTTON || vk == VK_ESCAPE || vk == VK_SHIFT || vk == VK_CONTROL || vk == VK_MENU || (vk >= VK_LSHIFT && vk <= VK_RMENU) || vk == VK_LWIN || vk == VK_RWIN) continue;
        if (!Down(vk)) continue;
        b.vk = vk; b.ctrl = Down(VK_CONTROL); b.shift = Down(VK_SHIFT); b.alt = Down(VK_MENU);
        Store(g_capturing, b); g_capturing = -1;
        return false;
    }
    // controller: every button held together, taken when they are all released (combos)
    DWORD pad = PadNow(); uint64_t joy = JoyNow();
    g_capPadUnion |= pad; g_capJoyUnion |= joy;
    if (!pad && !joy && (g_capPadUnion || g_capJoyUnion)) {
        if (g_capPadUnion) { b.pad = g_capPadUnion; b.joy = 0; } else { b.joy = g_capJoyUnion; b.pad = 0; }
        Store(g_capturing, b); g_capturing = -1;
        return false;
    }
    return true;
}
void StartCapture(int a) {
    g_capturing = a; g_capStart = rc::TickMs(); g_capReleased = false; g_capPadUnion = 0; g_capJoyUnion = 0;
    PanelMouseTakeExtraButton(); g_capRight = PanelMouseRightPresses();
    vrkit::menu::core::SetModal([] { return CapturePoll(); });
}

// ---------------------------------------------------------------- actions
void Apply() { SettingsApply(); SettingsSave(); }
template <class T> void Cycle(std::string& v, std::initializer_list<T> list) {
    std::vector<std::string> l(list.begin(), list.end());
    auto it = std::find(l.begin(), l.end(), v); size_t k = it == l.end() ? 0 : (it - l.begin() + 1) % l.size(); v = l[k];
}
float Clampf(float v, float a, float b) { return v < a ? a : v > b ? b : v; }
std::string g_beforeNative = "synced";

void Define() {
    auto add = [](const char* id, const char* label, const char* def, const char* help, std::function<void()> run) { g_acts.push_back({ id, label, def, help, run, "", std::string("hotkey_") + id }); };
    add("menu", "Open / close this panel", "", "Besides Insert and holding L3 + R3 (those always work).", [] { vrkit::menu::core::SetOpen(!vrkit::menu::core::IsOpen()); });
    add("recenter", "Recenter view", "F9", "Look straight ahead and press it.", [] { CompositorRecenter(); LOGI("keys: recentre"); });
    add("first_person", "First person on / off", "END", "Switches between first person (Alan's eyes) and the third-person camera.", [] { FirstPersonToggle(); });
    add("cycle_method", "Next stereo method", "F8", "Synchronized -> True stereo -> Alternate eye -> Head -> Flat screen.", [] { SettingsCycleMode(); });
    add("true_stereo", "True stereo on / off", "", "Switches between True stereo and the method you used before it.", [] {
        if (g_set.vrMode == "native") g_set.vrMode = g_beforeNative == "native" ? "synced" : g_beforeNative; else { g_beforeNative = g_set.vrMode; g_set.vrMode = "native"; }
        LOGI("keys: stereo method %s", g_set.vrMode.c_str()); Apply(); });
    add("hide_hud", "Hide / show the game HUD", "F7", "", [] { g_set.hideHud = !g_set.hideHud; LOGI("keys: hide HUD %d", (int)g_set.hideHud); Apply(); });
    add("flat_screen", "Flat screen on / off", "F6", "The game on a big virtual screen (and back).", [] { FlatToggle(); });
    add("screenshot", "Screenshot", "DELETE", "A PNG of the left eye next to the game's exe.", [] { g_shot = true; });
    add("cycle_hud", "Next HUD placement", "", "Scaled -> game safe area -> own panel -> game layout.", [] { Cycle(g_set.hudMode, { "scale", "safe", "panel", "off" }); LOGI("keys: HUD %s", g_set.hudMode.c_str()); Apply(); });
    add("cutscenes", "Cutscenes: theater / 3D", "", "", [] { g_set.cutsceneMode = g_set.cutsceneMode == "theater" ? "3d" : "theater"; LOGI("keys: cutscenes %s", g_set.cutsceneMode.c_str()); Apply(); });
    add("theater_bigger", "Theater screen bigger", "", "+10 degrees.", [] { g_set.theaterSize = Clampf(g_set.theaterSize + 10, 40, 170); Apply(); });
    add("theater_smaller", "Theater screen smaller", "", "-10 degrees.", [] { g_set.theaterSize = Clampf(g_set.theaterSize - 10, 40, 170); Apply(); });
    add("swap_eyes", "Swap eyes", "", "", [] { g_set.swapEyes = !g_set.swapEyes; Apply(); });
    add("world_bigger", "World bigger", "", "World scale -0.05 (you feel smaller).", [] { g_set.worldScale = Clampf(g_set.worldScale - 0.05f, 0.3f, 3.f); Apply(); });
    add("world_smaller", "World smaller", "", "World scale +0.05.", [] { g_set.worldScale = Clampf(g_set.worldScale + 0.05f, 0.3f, 3.f); Apply(); });
    add("eye_up", "First person: eye up", "", "+2 cm.", [] { g_set.fpEyeHeight = Clampf(g_set.fpEyeHeight + 0.02f, 0.f, 2.2f); Apply(); });
    add("eye_down", "First person: eye down", "", "-2 cm.", [] { g_set.fpEyeHeight = Clampf(g_set.fpEyeHeight - 0.02f, 0.f, 2.2f); Apply(); });
    add("eye_forward", "First person: eye forward", "", "+2 cm.", [] { g_set.fpOffsetZ = Clampf(g_set.fpOffsetZ + 0.02f, -1.5f, 1.5f); Apply(); });
    add("eye_back", "First person: eye back", "", "-2 cm.", [] { g_set.fpOffsetZ = Clampf(g_set.fpOffsetZ - 0.02f, -1.5f, 1.5f); Apply(); });
    add("head_aim", "Head aim: off / always / while aiming", "", "Cycles the head aim mode (Camera tab).", [] {
        g_set.headAim = g_set.headAim == "off" ? "always" : g_set.headAim == "always" ? "aiming" : "off";
        LOGI("keys: head aim %s", g_set.headAim.c_str()); Apply(); });
    add("level_horizon", "Level horizon on / off", "", "Decoupled pitch.", [] { g_set.decoupledPitch = !g_set.decoupledPitch; Apply(); });
    add("camera_shake", "Camera shake on / off", "", "Between none and the game's own.", [] { g_set.cameraShake = g_set.cameraShake > 0.5f ? 0.f : 1.f; Apply(); });
    add("foveated", "Next foveated rendering level", "", "Off -> unseen only -> quality -> balanced -> performance.", [] { Cycle(g_set.fovMode, { "off", "unseen", "quality", "balanced", "performance" }); LOGI("keys: foveated %s", g_set.fovMode.c_str()); Apply(); });
    add("matched_view", "Matched view on / off", "", "", [] { g_set.matchedView = !g_set.matchedView; Apply(); });
    add("game_aa", "Next game anti-aliasing setting", "", "Game -> off -> on.", [] { Cycle(g_set.gameAA, { "game", "off", "on" }); Apply(); });
    add("motion_blur", "Motion blur on / off", "", "", [] { g_set.motionBlurOff = !g_set.motionBlurOff; Apply(); });
    add("fps_unlocked", "Frame rate cap on / off", "", "", [] { g_set.fpsUnlocked = !g_set.fpsUnlocked; Apply(); });
}
}  // namespace

// ---------------------------------------------------------------- public
void HotkeysRegister() {
    if (g_acts.empty()) Define();
    auto& o = vrkit::Options::Get();
    // the 0.x key settings are the defaults of their hotkeys (so a key you changed there stays)
    for (auto& a : g_acts) {
        std::string def = a.def;
        if (!strcmp(a.id, "recenter") && !g_set.recenterKey.empty()) def = Upper(g_set.recenterKey);
        if (!strcmp(a.id, "first_person") && !g_set.fpKey.empty()) def = Upper(g_set.fpKey);
        if (!strcmp(a.id, "screenshot") && !g_set.screenshotKey.empty()) def = Upper(g_set.screenshotKey);
        a.dflt = def;
        a.bind = ConfigStr(a.key.c_str(), def.c_str());
    }
    for (size_t i = 0; i < g_acts.size(); i++) {
        Action& a = g_acts[i];
        std::string help = std::string(a.help) + (a.help[0] ? " " : "") +
            "A / Enter / click: set it (then press a key, a button or a button combination; Esc cancels). The x in front of the keys unbinds it (keyboard and controller): click it, or Left then A. Y: back to default.";
        int idx = (int)i;
        bool panel = !strcmp(a.id, "menu");
        if (panel) help = "Insert and holding L3 + R3 always open and close this panel - they can never be unbound. A / Enter / click: add one more key or button "
                          "(press it; Esc cancels). Y: remove that extra one.";
        auto& opt = o.AddHotkey("Hotkeys", a.key.c_str(), a.label, &a.bind, [idx] { StartCapture(idx); },
            [idx, panel] {
                if (g_capturing == idx) return std::string("press a key / button ...");
                const std::string& b = g_acts[idx].bind;
                if (panel) return std::string("INSERT, PAD L3+R3") + (b.empty() ? "" : ", " + b);   // the built-in ones, always
                return b.empty() ? std::string("-") : b; }, "");
        opt.noUnbind = panel;
        opt.help = help;
        opt.defaultText = a.dflt;   // Y: back to this
        opt.group = i == 0 ? "Panel and view" : !strcmp(a.id, "cycle_hud") ? "HUD and screen" : !strcmp(a.id, "swap_eyes") ? "Stereo and first person"
                  : !strcmp(a.id, "level_horizon") ? "Camera and graphics" : "";
        if (opt.group.empty()) {   // keep the previous group
            for (int k = (int)o.All().size() - 2; k >= 0; k--) if (o.All()[k].page == "Hotkeys") { opt.group = o.All()[k].group; break; }
        }
        // a cleared / reset binding through the panel also refreshes the hidden combos
        opt.onChange = [] { UpdateHiddenChords(); };
    }
    UpdateHiddenChords();
    vrkit::input::SetExtraSource([]() -> uint32_t { JoyNow(); return g_joyNav.load(); });
}

// Present thread, once per frame (also while the panel is open: then only to keep the edge state)
void HotkeysPoll(bool* screenshot) {
    static bool keyWas[64] = {}; static DWORD padWas = 0; static uint64_t joyWas = 0;
    bool open = vrkit::menu::core::IsOpen();
    if (g_capturing >= 0 && !vrkit::menu::core::ModalActive()) g_capturing = -1;   // the panel was closed while listening
    bool front = GameInFront();
    DWORD pad = PadNow(); uint64_t joy = JoyNow();
    DWORD padNew = pad & ~padWas; uint64_t joyNew = joy & ~joyWas;
    bool ctrl = Down(VK_CONTROL), shift = Down(VK_SHIFT), alt = Down(VK_MENU);
    size_t n = g_acts.size() < 64 ? g_acts.size() : 64;
    std::vector<Bind> binds(n); for (size_t i = 0; i < n; i++) binds[i] = Parse(g_acts[i].bind);
    std::vector<char> fire(n, 0);
    for (size_t i = 0; i < n; i++) {
        const Bind& b = binds[i];
        if (b.vk) {
            // modifiers: an exact match always fires; a binding without modifiers also fires while Shift / Ctrl / Alt are
            // held (sprinting, crouching), unless another binding uses that key with exactly the held modifiers
            bool exact = ctrl == b.ctrl && shift == b.shift && alt == b.alt;
            bool loose = !b.ctrl && !b.shift && !b.alt;
            if (loose && !exact)
                for (size_t k = 0; k < n; k++) if (k != i && binds[k].vk == b.vk && binds[k].ctrl == ctrl && binds[k].shift == shift && binds[k].alt == alt) loose = false;
            bool d = front && Down(b.vk) && ((!b.ctrl || ctrl) && (!b.shift || shift) && (!b.alt || alt)) && (exact || loose);
            if (d && !keyWas[i]) fire[i] = 1;
            keyWas[i] = d;
        }
        if (b.pad && (pad & b.pad) == b.pad && (padNew & b.pad)) fire[i] = 2;
        if (b.joy && (joy & b.joy) == b.joy && (joyNew & b.joy)) fire[i] = 3;
    }
    // a controller combo wins over its own parts (LB+Y fires, Y alone does not)
    for (size_t i = 0; i < n; i++) if (fire[i] == 2 || fire[i] == 3)
        for (size_t k = 0; k < n; k++) if (k != i && fire[k] == fire[i]) {
            uint64_t a = fire[i] == 2 ? binds[i].pad : binds[i].joy, c = fire[k] == 2 ? binds[k].pad : binds[k].joy;
            if ((a & c) == a && c != a) fire[i] = 0;
        }
    // a binding that is part of a larger one (LB, with LB+Y also bound) fires when it is released, and only if the larger
    // one did not fire meanwhile - pressing LB+Y never fires LB as well (LB is down first)
    static bool pend[64] = {};
    for (size_t i = 0; i < n; i++) for (int dev = 2; dev <= 3; dev++) {
        uint64_t a = dev == 2 ? binds[i].pad : binds[i].joy; if (!a) continue;
        bool part = false, biggerHeld = false;
        for (size_t k = 0; k < n; k++) {
            uint64_t c = dev == 2 ? binds[k].pad : binds[k].joy;
            if (k == i || !c || c == a || (a & c) != a) continue;
            part = true;
            if (dev == 2 ? (pad & c) == c : (joy & c) == c) biggerHeld = true;
        }
        if (!part) continue;
        bool held = dev == 2 ? (pad & a) == a : (joy & a) == a;
        if (fire[i] == dev) { fire[i] = 0; pend[i] = true; }
        if (biggerHeld || (open && strcmp(g_acts[i].id, "menu"))) pend[i] = false;
        if (pend[i] && !held) { fire[i] = (char)dev; pend[i] = false; }
    }
    for (size_t i = 0; i < n; i++) {
        bool allowed = !open || !strcmp(g_acts[i].id, "menu");
        if (fire[i] && allowed && g_capturing < 0) { LOGI("hotkeys: %s", g_acts[i].id); g_acts[i].run(); }
    }
    // head aim "while aiming": L2 / LT on any XInput pad, L2 (button 7) on DirectInput pads, the right mouse button
    // (the physical one: swapped buttons respected) - only with the game in front and the panel closed
    {
        bool rmb = front && Down(GetSystemMetrics(SM_SWAPBUTTON) ? VK_LBUTTON : VK_RBUTTON);
        HeadAimSetAimHeld(!open && ((pad & kLT) || (joy & (1ull << 6)) || rmb));
    }
    padWas = pad; joyWas = joy;
    if (g_shot) { *screenshot = true; g_shot = false; }
}
