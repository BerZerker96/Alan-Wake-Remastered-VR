// Render size (guide 5): the game renders at the size in its resolution.xml (Documents\...\AlanWakeRemastered\).
// render_resolution = auto: exactly the headset's recommended per-eye size x render_scale, clamped to the runtime's
// largest image and render_max_side, even sizes. The size comes from AWRVR\headset.txt: written by
// the mod as soon as the VR runtime reports it - on the first start before the game reads its settings (see the end). force_windowed sets
// the window mode.
// Only width / height (and window_mode) are rewritten; the original file is kept as resolution.xml.awrvr_backup.
#include <windows.h>
#include <shlobj.h>
#include <knownfolders.h>
#include <string>
#include <vector>
#include <algorithm>
#include <atomic>
#include <cstdio>
#include <cmath>
#include <cstring>
#include <cstdint>
#include "log.h"
#include "resparse.h"
#include "config.h"
#include "settings.h"
#include "realclock.h"
#include "MinHook.h"
#include "scan.h"
#include "xrhost/xrloader.h"

extern std::wstring g_modDir;

namespace {
struct HeadsetCache { unsigned w = 0, h = 0; double hz = 0; std::string system; };
HeadsetCache Read() {
    HeadsetCache c; FILE* f = _wfopen((g_modDir + L"\\headset.txt").c_str(), L"r");
    if (!f) return c;
    char sys[128] = "";
    if (fscanf(f, "%u %u %lf %127[^\n]", &c.w, &c.h, &c.hz, sys) >= 2) c.system = sys;
    fclose(f); return c;
}
}

void ResolutionSaveHeadset(unsigned w, unsigned h, const char* system, double hz) {
    if (!w || !h) return;
    HeadsetCache old = Read();
    if (hz <= 0 && old.system == (system ? system : "")) hz = old.hz;
    FILE* f = _wfopen((g_modDir + L"\\headset.txt").c_str(), L"w");
    if (f) { fprintf(f, "%u %u %.2f %s\n", w, h, hz, system ? system : ""); fclose(f); }
    if (old.w != w || old.h != h) LOGI("resolution: headset recommends %ux%u per eye (%s) - saved for render_resolution = auto", w, h, system ? system : "?");
}
bool ResolutionHeadsetRefresh(const char* system, double* hz) {
    HeadsetCache c = Read();
    if (c.hz > 0 && c.system == (system ? system : "")) { *hz = c.hz; return true; }
    return false;
}

static void FindXml(const std::wstring& dir, int depth, std::vector<std::wstring>& out) {
    if (depth < 0 || out.size() > 8) return;
    std::wstring f = dir + L"\\resolution.xml", low = dir;
    for (auto& c : low) c = (wchar_t)towlower(c);
    if (low.find(L"alanwake") != std::wstring::npos && GetFileAttributesW(f.c_str()) != INVALID_FILE_ATTRIBUTES) out.push_back(f);
    WIN32_FIND_DATAW fd; HANDLE h = FindFirstFileW((dir + L"\\*").c_str(), &fd);
    if (h == INVALID_HANDLE_VALUE) return;
    do {
        if (!(fd.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY) || fd.cFileName[0] == L'.' || (fd.dwFileAttributes & FILE_ATTRIBUTE_REPARSE_POINT)) continue;
        std::wstring n = fd.cFileName; for (auto& c : n) c = (wchar_t)towlower(c);
        if (depth >= 2 || n.find(L"remedy") != std::wstring::npos || n.find(L"alan") != std::wstring::npos || n.find(L"wake") != std::wstring::npos)
            FindXml(dir + L"\\" + fd.cFileName, depth - 1, out);
    } while (FindNextFileW(h, &fd));
    FindClose(h);
}

// value of `key` (attribute key="v" or element <key>v</key>) in s[from, from+span): position and length
static unsigned s_appliedW = 0, s_appliedH = 0; static bool s_appliedWin = false, s_applied = false;
static void ResolutionApply(bool startup);
void ResolutionApplyAtStartup() { ResolutionApply(true); }
// a setting that changes the render size (VR method head, symmetric view, render scale / resolution): the size is
// computed again at once and written, both ways - growing back to 1 x writes the headset's own size again (GOTGVR
// Q.2: the size never came back). The game reads resolution.xml at its start, so it takes effect at the next start.
// (applied once the settings have been still for 1.5 s: dragging a slider does not rewrite the file on every step)
static DWORD s_pendingAt = 0;
void ResolutionSettingsChanged() { if (s_applied) s_pendingAt = rc::TickMs() | 1; }
void ResolutionPoll() {
    { void ResolutionWindowPoll(); ResolutionWindowPoll(); } if (s_pendingAt && rc::TickMs() - s_pendingAt > 1500) { s_pendingAt = 0; ResolutionApply(false); } }

// The game's own clamp (exe+1ce7d8, after resolution.xml is read): window_mode 2 (Borderless) replaces width / height
// with the monitor's size, and any other mode clamps them to it:
//   mov r8d,[r14+d4] (width)  mov edx,[r14+d8] (height)  mov ecx,[r14+e8] (monitor w)  mov eax,[r14+ec] (monitor h)
//   cmp [r14+dc],2 (window_mode)  je store  ;  cmp r8d,ecx / cmovl ecx,r8d  ;  cmp edx,eax / cmovl eax,edx  ; store
// so a headset size taller than the monitor (3420x2668 on a 3840x2160 desktop) never reached the renderer: it drew
// 3840x2160 in Borderless, 3420x2160 in Windowed, and the eye images were stretched from that. With the size from
// resolution.xml set by the mod, the two monitor loads read the file's width / height instead: the clamp keeps them.
// Patched at load (before the game reads its settings); the game's own size (render_resolution = game) is left alone.
static bool s_clampPatched = false, s_modeClampPatched = false;
// the one place in the exe's executable sections that matches sig (nullptr when none or several)
static uint8_t* FindUnique(const uint8_t* sig, size_t len, int* hitsOut) {
    uint8_t* base = (uint8_t*)GetModuleHandleW(nullptr);
    auto* dos = (IMAGE_DOS_HEADER*)base; if (dos->e_magic != IMAGE_DOS_SIGNATURE) return nullptr;
    auto* nt = (IMAGE_NT_HEADERS*)(base + dos->e_lfanew);
    auto* sec = IMAGE_FIRST_SECTION(nt);
    uint8_t* hit = nullptr; int hits = 0;
    for (unsigned i = 0; i < nt->FileHeader.NumberOfSections; i++) {
        if (!(sec[i].Characteristics & IMAGE_SCN_MEM_EXECUTE)) continue;
        uint8_t* p = base + sec[i].VirtualAddress; size_t n = sec[i].Misc.VirtualSize;
        for (size_t k = 0; k + len <= n; k++)
            if (p[k] == sig[0] && !memcmp(p + k, sig, len)) { if (!hit) hit = p + k; hits++; }
    }
    *hitsOut = hits; return hits == 1 ? hit : nullptr;
}
static bool PatchBytes(uint8_t* at, const uint8_t* bytes, size_t n) {
    DWORD op; if (!VirtualProtect(at, n, PAGE_EXECUTE_READWRITE, &op)) return false;
    memcpy(at, bytes, n); VirtualProtect(at, n, op, &op); FlushInstructionCache(GetCurrentProcess(), at, n); return true;
}
static void PatchMonitorClamp() {
    static bool once = false; if (once) return; once = true;
    uint8_t* base = (uint8_t*)GetModuleHandleW(nullptr); int hits = 0;
    // 1) settings load (exe+1ce7d8): Borderless takes the monitor's size, other modes are cut to it
    static const uint8_t sig[] = { 0x45,0x8b,0x86,0xd4,0,0,0, 0x41,0x8b,0x96,0xd8,0,0,0, 0x41,0x8b,0x8e,0xe8,0,0,0,
                                   0x41,0x8b,0x86,0xec,0,0,0, 0x41,0x83,0xbe,0xdc,0,0,0,0x02, 0x74 };
    if (uint8_t* hit = FindUnique(sig, sizeof sig, &hits)) {
        static const uint8_t a[] = { 0xd4 }, b[] = { 0xd8 };   // mov ecx,[r14+d4] / mov eax,[r14+d8]: "monitor" = the file's own size
        if (PatchBytes(hit + 17, a, 1) && PatchBytes(hit + 24, b, 1)) s_clampPatched = true;
        LOGI("resolution: the game's monitor-size clamp at load (exe+%llx) lifted", (unsigned long long)(hit - base));
    } else LOGW("resolution: the game's monitor-size clamp at load not found (%d matches)", hits);
    // 2) display setup (exe+1e0170, the display object's constructor, when no -width / -height is on the command line):
    //    a size below the monitor's smallest mode is raised to it, a size above its largest mode (either side) is
    //    replaced by that mode - 3420x2668 on a 3840x2160 monitor became 3840x2160 here, after the load clamp was lifted
    //    (0.10.16). The "above" branch keeps its refresh rate but no longer replaces the size:
    //      mov [rdi+24],eax (height = mode's)  ->  mov edx,r8d (the width stored after it = the asked width)
    static const uint8_t sig2[] = { 0x44,0x8b,0x47,0x20, 0x8b,0x44,0x24,0x54, 0x8b,0x54,0x24,0x50, 0x44,0x3b,0xc2, 0x72,0x21,
                                    0x8b,0x4f,0x24, 0x3b,0xc8, 0x72,0x1a, 0x8b,0x44,0x24,0x44, 0x8b,0x54,0x24,0x40, 0x44,0x3b,0xc2,
                                    0x77,0x04, 0x3b,0xc8, 0x76,0x20, 0x89,0x47,0x24, 0x8b,0x44,0x24,0x48, 0xeb,0x07 };
    if (uint8_t* hit = FindUnique(sig2, sizeof sig2, &hits)) {
        static const uint8_t c[] = { 0x44, 0x89, 0xc2 };
        if (PatchBytes(hit + 41, c, 3)) s_modeClampPatched = true;
        LOGI("resolution: the game's largest-display-mode clamp (exe+%llx) lifted", (unsigned long long)(hit - base));
    } else LOGW("resolution: the game's largest-display-mode clamp not found (%d matches) - a size above the monitor is cut to it", hits);
    if (s_clampPatched && s_modeClampPatched) LOGI("resolution: the game renders the size in resolution.xml even when it is larger than the monitor");
}
unsigned ResolutionWantedW() { return s_appliedW; }
unsigned ResolutionWantedH() { return s_appliedH; }
bool ResolutionClampLifted() { return s_clampPatched && s_modeClampPatched; }


// ---------------------------------------------------------------- pixel perfect
// Matched view draws each eye symmetric around its lens axis (the game's effects are right only with a symmetric
// view), but an eye shows only part of that: the Dream Air shows tangents -1.61..0.92 of -1.61..1.61. With
// pixel_perfect (default) the render grows by exactly drawn / shown per side, from the eyes' fields saved in
// AWRVR\headset_fov.txt, so the part an eye shows IS the headset's own pixel grid: the engine widens the frustum to
// that exact scale and the compositor copies the pixels 1:1 (no resampling). The extra strip the eye never shows is
// drawn at a 16th of the cost by foveated rendering's "unseen" level.
struct EyeFov { float t[2][4]; bool ok = false; };   // tangents l r u d per eye
static EyeFov ReadFov() {
    EyeFov e; FILE* f = _wfopen((g_modDir + L"\\headset_fov.txt").c_str(), L"r"); if (!f) return e;
    e.ok = fscanf(f, "%f %f %f %f %f %f %f %f", &e.t[0][0], &e.t[0][1], &e.t[0][2], &e.t[0][3], &e.t[1][0], &e.t[1][1], &e.t[1][2], &e.t[1][3]) == 8;
    fclose(f); return e;
}
static bool PixelPerfectOn() { return g_set.pixelPerfect && g_set.matchedView && !g_set.cantedView && !g_set.symmetricView && g_set.vrMode != "head" && g_set.vrMode != "screen"; }
// drawn / shown per side for the saved fields (the larger of the two eyes)
static bool PixelGrow(double* gx, double* gy) {
    EyeFov e = ReadFov(); if (!e.ok) return false;
    *gx = *gy = 1;
    for (int k = 0; k < 2; k++) {
        float l = e.t[k][0], r = e.t[k][1], u = e.t[k][2], d = e.t[k][3];
        if (r - l < 0.1f || u - d < 0.1f) return false;
        *gx = fmax(*gx, 2.0 * fmax(-l, r) / (r - l)); *gy = fmax(*gy, 2.0 * fmax(u, -d) / (u - d));
    }
    return *gx < 3 && *gy < 3;
}
// engine: the eyes' fields (tangents) whenever poses arrive - saved when they change (the size follows next start)
void ResolutionNoteFov(const float t[2][4]) {
    static bool done = false; if (done) return; done = true;
    EyeFov o = ReadFov(); bool same = o.ok;
    for (int k = 0; k < 2 && same; k++) for (int i = 0; i < 4; i++) if (fabsf(o.t[k][i] - t[k][i]) > 0.002f) same = false;
    if (same) return;
    FILE* f = _wfopen((g_modDir + L"\\headset_fov.txt").c_str(), L"w"); if (!f) return;
    fprintf(f, "%.4f %.4f %.4f %.4f %.4f %.4f %.4f %.4f\n", t[0][0], t[0][1], t[0][2], t[0][3], t[1][0], t[1][1], t[1][2], t[1][3]); fclose(f);
    LOGI("resolution: the headset's eye fields saved (tangents L %.2f..%.2f x %.2f..%.2f) - %s", t[0][0], t[0][1], t[0][3], t[0][2],
         PixelPerfectOn() ? "pixel perfect render size from the next start" : "kept for pixel_perfect");
    if (PixelPerfectOn()) ResolutionSettingsChanged();
}
// engine: render size / eye image size per side when pixel perfect is in use this run (0 = not)
static double s_ppX = 0, s_ppY = 0;
bool ResolutionPixelScale(double* sx, double* sy) { if (s_ppX <= 0) return false; *sx = s_ppX; *sy = s_ppY; return true; }
static void ResolutionApply(bool startup) {
    std::string mode = g_set.renderResolution;
    unsigned w = 0, h = 0;
    if (mode == "auto") {
        HeadsetCache c = Read();
        if (!c.w) LOGI("resolution: auto - headset size not known yet (start once with the VR runtime running, then again)");
        else {
            float sc = g_set.renderScale < 0.3f ? 0.3f : g_set.renderScale > 1.5f ? 1.5f : g_set.renderScale;
            // exactly the headset's recommended per-eye size (x render_scale): known from headset.txt, so it applies at
            // this start. (0.10.19 grew it by the drawn / shown ratio and needed a second start - removed on request.)
            w = (unsigned)(c.w * sc); h = (unsigned)(c.h * sc);
            double gx = 1, gy = 1;
            if (PixelPerfectOn() && PixelGrow(&gx, &gy) && (gx > 1.001 || gy > 1.001)) {
                unsigned ew = (unsigned)(c.w * sc + 0.5), eh = (unsigned)(c.h * sc + 0.5);
                w = (unsigned)ceil(ew * gx); h = (unsigned)ceil(eh * gy); w = (w + 1) & ~1u; h = (h + 1) & ~1u;
                if (startup) { s_ppX = double(w) / ew; s_ppY = double(h) / eh; }
                LOGI("resolution: pixel perfect - each eye shows %ux%u of a %ux%u picture 1:1 (drawn / shown %.3f x %.3f)", ew, eh, w, h, gx, gy);
            } else if (PixelPerfectOn() && !ReadFov().ok) LOGI("resolution: pixel perfect - the eyes' fields are not known yet: the headset's size this start, the exact size from the next");
        }
    } else if (mode != "game" && sscanf(mode.c_str(), "%ux%u", &w, &h) != 2) { LOGW("resolution: render_resolution '%s' not understood", mode.c_str()); w = h = 0; }
    if (w && h) {
        unsigned mx = (unsigned)(g_set.renderMaxSide > 512 ? g_set.renderMaxSide : 512);
        if (w > mx) { h = h * mx / w; w = mx; } if (h > mx) { w = w * mx / h; h = mx; }
        w &= ~1u; h &= ~1u;
    }
    if (!startup && w == s_appliedW && h == s_appliedH && g_set.forceWindowed == s_appliedWin) return;
    s_applied = true; bool grew = w > s_appliedW; s_appliedW = w; s_appliedH = h; s_appliedWin = g_set.forceWindowed;
    if (startup && w && h) PatchMonitorClamp();
    if (!startup) LOGI("resolution: settings changed - render size %s %ux%u (the game applies it at its next start)", grew ? "grown to" : "back to", w, h);
    if (!w && !g_set.forceWindowed) { LOGI("resolution: the game's own render size and window mode"); return; }
    // Epic: Documents\Remedy\AlanWakeRemastered\resolution.xml (also when Documents is redirected, e.g. to OneDrive).
    // Other stores / builds may keep it in Saved Games, LocalAppData or the game folder: all are searched.
    std::vector<std::wstring> files; wchar_t base[MAX_PATH];
    if (SUCCEEDED(SHGetFolderPathW(nullptr, CSIDL_PERSONAL, nullptr, 0, base))) FindXml(base, 3, files);
    if (files.empty()) { PWSTR sg = nullptr; if (SUCCEEDED(SHGetKnownFolderPath(FOLDERID_SavedGames, 0, nullptr, &sg)) && sg) { FindXml(sg, 3, files); CoTaskMemFree(sg); } }
    if (files.empty() && SUCCEEDED(SHGetFolderPathW(nullptr, CSIDL_LOCAL_APPDATA, nullptr, 0, base))) FindXml(base, 3, files);
    if (files.empty() && SUCCEEDED(SHGetFolderPathW(nullptr, CSIDL_APPDATA, nullptr, 0, base))) FindXml(base, 3, files);
    extern std::wstring g_gameDir;
    if (files.empty()) { std::wstring f = g_gameDir + L"\\resolution.xml"; if (GetFileAttributesW(f.c_str()) != INVALID_FILE_ATTRIBUTES) files.push_back(f); }
    if (files.empty()) { LOGW("resolution: resolution.xml not found (start the game once, then again)"); return; }
    for (auto& path : files) {
        FILE* f = _wfopen(path.c_str(), L"rb"); if (!f) continue;
        std::string s; char buf[4096]; size_t n; while ((n = fread(buf, 1, sizeof buf, f)) > 0) s.append(buf, n); fclose(f);
        std::string t = s; bool changed = false; size_t p, l;
        size_t at = t.find("screen_resolution");
        if (w && at != std::string::npos) {
            unsigned ow = 0, oh = 0;
            // the screen_resolution entry: up to its end ("/>", its closing tag, or 300 characters)
            // (an element with children - <screen_resolution> <width value="3840"/> <height value="2160"/> - ends at its
            //  closing tag, never at the first child's "/>")
            size_t e1 = t.find("/>", at), e2 = t.find("</screen_resolution", at), gt = t.find('>', at);
            bool parent = gt != std::string::npos && (e1 == std::string::npos || gt < e1) && t[gt - 1] != '/';
            size_t end = (std::min)({ parent ? t.size() : (e1 == std::string::npos ? t.size() : e1 + 2), e2 == std::string::npos ? t.size() : e2, at + 400, t.size() });
            std::string entry = t.substr(at, end - at);
            bool named = FindValue(t, at, end - at, "width", &p, &l);
            if (named) {
                ow = atoi(t.substr(p, l).c_str()); if (ow != w) { t.replace(p, l, std::to_string(w)); changed = true; }
                at = t.find("screen_resolution");
                if (FindValue(t, at, end - at + 8, "height", &p, &l)) { oh = atoi(t.substr(p, l).c_str()); if (oh != h) { t.replace(p, l, std::to_string(h)); changed = true; } }
            } else {
                // any other layout ("3840x2160", w= / h=, x= / y=, child elements): see resparse.h
                size_t np[2] = {}, nl[2] = {}; int found = ResFindPair(entry, &np[0], &nl[0], &np[1], &nl[1]) ? 2 : 0;
                if (found == 2) {
                    ow = (unsigned)atoi(entry.substr(np[0], nl[0]).c_str()); oh = (unsigned)atoi(entry.substr(np[1], nl[1]).c_str());
                    if (ow != w || oh != h) { t.replace(at + np[1], nl[1], std::to_string(h)); t.replace(at + np[0], nl[0], std::to_string(w)); changed = true; }
                } else LOGW("resolution: screen_resolution entry not understood: %s", entry.substr(0, 160).c_str());
            }
            LOGI("resolution: the game will render at %ux%u (was %ux%u) - %s", w, h, ow, oh, entry.substr(0, 120).c_str());
        } else if (w) LOGW("resolution: %ls has no screen_resolution entry", path.c_str());
        if (g_set.forceWindowed && FindValue(t, 0, t.size(), "window_mode", &p, &l)) {
            std::string v = t.substr(p, l), lv = v; for (auto& c : lv) c = (char)tolower((unsigned char)c);
            if (!lv.empty() && isalpha((unsigned char)lv[0])) { if (lv != "windowed") { t.replace(p, l, "windowed"); changed = true; LOGI("resolution: window_mode %s -> windowed", v.c_str()); } }
            else if (v != "1") {   // 0 Fullscreen, 1 Windowed, 2 Borderless (exe+2627b0, the focus-event log names them)
                LOGI("resolution: window_mode %s (%s) -> 1 (Windowed)", v.c_str(), v == "2" ? "Borderless" : v == "0" ? "Fullscreen" : "?");
                t.replace(p, l, "1"); changed = true;
            }
        }
        if (!changed) continue;
        std::wstring bak = path + L".awrvr_backup";
        if (GetFileAttributesW(bak.c_str()) == INVALID_FILE_ATTRIBUTES) CopyFileW(path.c_str(), bak.c_str(), TRUE);
        if ((f = _wfopen(path.c_str(), L"wb"))) { fwrite(t.data(), 1, t.size(), f); fclose(f); LOGI("resolution: %ls written (backup %ls)", path.c_str(), bak.c_str()); }
    }
}

// ---------------------------------------------------------------- the headset's size on the very first start
// The game reads resolution.xml in its LoadResolution (exe+1d0120, settings object: +d4 width, +d8 height, +dc
// window_mode), on its main thread soon after start. With no AWRVR\headset.txt yet (first start), the hook holds
// that read (at most 14 s) for a short OpenXR query of its own - instance, system, recommended view size, destroyed
// again, no graphics, no session - saves the size and writes resolution.xml. After the game's read the size and the
// window mode are set in its settings too (also when resolution.xml did not exist yet and the game made a default).
// 0.10.21 started the whole VR host here instead: its D3D11 device creation stalls while the game's main thread
// waits, and the game crashed when the two then ran together - the VR host starts at its usual place again.
// With a saved size nothing is asked here (a different headset is picked up by the VR host, from the next start).
namespace {
struct ProbeResult { unsigned w = 0, h = 0; char system[128] = ""; bool ok = false; };
DWORD WINAPI ProbeThread(LPVOID p) {
    ProbeResult* r = (ProbeResult*)p;
    if (!XrLoaderInit()) return 0;
    PFN_xrCreateInstance create = nullptr; PFN_xrDestroyInstance destroy = nullptr; PFN_xrGetSystem getSystem = nullptr;
    PFN_xrGetSystemProperties props = nullptr; PFN_xrEnumerateViewConfigurationViews views = nullptr;
    ::xrGetInstanceProcAddr(XR_NULL_HANDLE, "xrCreateInstance", (PFN_xrVoidFunction*)&create);
    if (!create) return 0;
    XrInstanceCreateInfo ci{ XR_TYPE_INSTANCE_CREATE_INFO };
    strcpy_s(ci.applicationInfo.applicationName, "Alan Wake Remastered VR");
    strcpy_s(ci.applicationInfo.engineName, "XrBridge");
    ci.applicationInfo.apiVersion = XR_MAKE_VERSION(1, 0, 0);
    XrInstance inst = XR_NULL_HANDLE;
    XrResult res = create(&ci, &inst);
    if (XR_FAILED(res)) { LOGI("resolution: headset query - xrCreateInstance %d", (int)res); return 0; }
    ::xrGetInstanceProcAddr(inst, "xrDestroyInstance", (PFN_xrVoidFunction*)&destroy);
    ::xrGetInstanceProcAddr(inst, "xrGetSystem", (PFN_xrVoidFunction*)&getSystem);
    ::xrGetInstanceProcAddr(inst, "xrGetSystemProperties", (PFN_xrVoidFunction*)&props);
    ::xrGetInstanceProcAddr(inst, "xrEnumerateViewConfigurationViews", (PFN_xrVoidFunction*)&views);
    if (getSystem && views) {
        XrSystemGetInfo sg{ XR_TYPE_SYSTEM_GET_INFO }; sg.formFactor = XR_FORM_FACTOR_HEAD_MOUNTED_DISPLAY;
        XrSystemId sys = XR_NULL_SYSTEM_ID;
        res = getSystem(inst, &sg, &sys);
        if (XR_SUCCEEDED(res)) {
            if (props) { XrSystemProperties sp{ XR_TYPE_SYSTEM_PROPERTIES }; if (XR_SUCCEEDED(props(inst, sys, &sp))) strncpy_s(r->system, sp.systemName, _TRUNCATE); }
            XrViewConfigurationView v[2] = { { XR_TYPE_VIEW_CONFIGURATION_VIEW }, { XR_TYPE_VIEW_CONFIGURATION_VIEW } }; uint32_t n = 0;
            if (XR_SUCCEEDED(views(inst, sys, XR_VIEW_CONFIGURATION_TYPE_PRIMARY_STEREO, 2, &n, v)) && n >= 1 && v[0].recommendedImageRectWidth) {
                r->w = v[0].recommendedImageRectWidth; r->h = v[0].recommendedImageRectHeight; r->ok = true;
            }
        } else LOGI("resolution: headset query - no headset (xrGetSystem %d)", (int)res);
    }
    if (destroy) destroy(inst);
    return 0;
}
using LoadResFn = void(__fastcall*)(void* settings);
LoadResFn o_loadRes = nullptr;
void __fastcall H_LoadRes(void* settings) {
    static bool asked = false;
    if (!asked && g_set.renderResolution == "auto" && g_set.xrOutput && !Read().w) {
        asked = true;
        static ProbeResult r; DWORD t0 = rc::TickMs();
        HANDLE th = CreateThread(nullptr, 0, ProbeThread, &r, 0, nullptr);
        DWORD wr = th ? WaitForSingleObject(th, 14000) : WAIT_FAILED;
        if (th) CloseHandle(th);
        if (wr == WAIT_OBJECT_0 && r.ok) {
            LOGI("resolution: first start - %s recommends %ux%u per eye (%lu ms), applied before the game reads its settings", r.system, r.w, r.h, rc::TickMs() - t0);
            ResolutionSaveHeadset(r.w, r.h, r.system, 0);
            ResolutionApply(true);
        } else LOGI("resolution: first start - %s: the game's own size this time, the headset's from the next start",
                    wr == WAIT_TIMEOUT ? "the VR runtime did not answer in 14 s" : "no VR runtime / headset");
    }
    o_loadRes(settings);
    // the game's settings: the size it just read (or the default it made when resolution.xml did not exist yet)
    unsigned w = s_appliedW, h = s_appliedH;
    if (w && h && settings) {
        unsigned* sw = (unsigned*)((uint8_t*)settings + 0xd4); unsigned* sh = sw + 1; int* wm = (int*)(sw + 2);
        if (Readable(sw, 12)) {
            if (*sw >= 320 && *sw <= 16384 && *sh >= 200 && *sh <= 16384 && (*sw != w || *sh != h)) {
                LOGI("resolution: the game read %ux%u - set to %ux%u in its settings", *sw, *sh, w, h); *sw = w; *sh = h;
            }
            if (g_set.forceWindowed && (*wm == 0 || *wm == 2)) { LOGI("resolution: the game read window mode %d - set to 1 (Windowed)", *wm); *wm = 1; }
        }
    }
}
}

void ResolutionInstallLoadHook() {
    // LoadResolution prologue (exe+1d0120), then `lea rdx,"%sresolution.xml"` 0x2e bytes in confirms it
    static const uint8_t sig[] = { 0x48,0x89,0x5c,0x24,0x08, 0x48,0x89,0x74,0x24,0x10, 0x48,0x89,0x7c,0x24,0x18, 0x55, 0x41,0x56, 0x41,0x57,
                                   0x48,0x8d,0xac,0x24,0x10,0xfd,0xff,0xff, 0x48,0x81,0xec,0xf0,0x03,0x00,0x00, 0x48,0x8b,0xf9, 0xe8 };
    int hits = 0; uint8_t* fn = FindUnique(sig, sizeof sig, &hits);
    uint8_t* base = (uint8_t*)GetModuleHandleW(nullptr);
    bool ok = false;
    if (fn && fn[0x2e] == 0x48 && fn[0x2f] == 0x8d && fn[0x30] == 0x15) {
        const char* str = (const char*)(fn + 0x35 + *(int32_t*)(fn + 0x31));
        ok = !memcmp(str, "%sresolution.xml", 16);
    }
    if (!ok) { LOGW("resolution: the game's LoadResolution not found (%d matches) - without a resolution.xml the first start uses the game's default size", hits); return; }
    if (MH_CreateHook(fn, (void*)&H_LoadRes, (void**)&o_loadRes) == MH_OK && MH_EnableHook(fn) == MH_OK)
        LOGI("resolution: LoadResolution exe+%llx hooked (the headset's size in the game's settings)", (unsigned long long)(fn - base));
}

// ---------------------------------------------------------------- the window: never cut to the screen
// Windowed at the headset's size, the window is taller than the desktop (3420x2668 on a 2160-line monitor). Windows
// cuts a window to the screen when it is moved or sized (DefWindowProc's WM_GETMINMAXINFO limit), and the game then
// resizes its swap chain to the cut client area: 0.10.26 rendered 3420x2135 after 7 s. The game window gets a
// larger limit, and its client area is set back to the render size when it was cut.
namespace {
WNDPROC s_origProc = nullptr; HWND s_hwnd = nullptr; unsigned s_winW = 0, s_winH = 0; std::atomic<int> s_fixes{0};
LRESULT CALLBACK WinProc(HWND h, UINT m, WPARAM wp, LPARAM lp) {
    LRESULT r = CallWindowProcW(s_origProc, h, m, wp, lp);
    if (m == WM_GETMINMAXINFO && lp) {
        MINMAXINFO* mi = (MINMAXINFO*)lp;
        mi->ptMaxTrackSize.x = (std::max)(mi->ptMaxTrackSize.x, (LONG)32000); mi->ptMaxTrackSize.y = (std::max)(mi->ptMaxTrackSize.y, (LONG)32000);
        mi->ptMaxSize.x = (std::max)(mi->ptMaxSize.x, (LONG)32000); mi->ptMaxSize.y = (std::max)(mi->ptMaxSize.y, (LONG)32000);
    }
    return r;
}
void FitClient(const char* why) {
    if (!s_hwnd || !s_winW || IsIconic(s_hwnd)) return;
    RECT c; if (!GetClientRect(s_hwnd, &c)) return;
    if ((unsigned)(c.right - c.left) == s_winW && (unsigned)(c.bottom - c.top) == s_winH) return;
    RECT w{ 0, 0, (LONG)s_winW, (LONG)s_winH };
    AdjustWindowRectEx(&w, (DWORD)GetWindowLongPtrW(s_hwnd, GWL_STYLE), FALSE, (DWORD)GetWindowLongPtrW(s_hwnd, GWL_EXSTYLE));
    LOGI("resolution: the game window's client area %ldx%ld - set back to %ux%u (%s)", c.right - c.left, c.bottom - c.top, s_winW, s_winH, why);
    SetWindowPos(s_hwnd, nullptr, 0, 0, w.right - w.left, w.bottom - w.top, SWP_NOMOVE | SWP_NOZORDER | SWP_NOACTIVATE);
    s_fixes++;
}
}
// dxgi_hooks: the game's swap chain window, when the mod sets the render size
void ResolutionKeepWindow(HWND w, unsigned bufW, unsigned bufH) {
    if (!w || !s_appliedW || bufW != s_appliedW || bufH != s_appliedH) return;
    if (s_hwnd == w) return;
    s_hwnd = w; s_winW = bufW; s_winH = bufH;
    if (GetWindowThreadProcessId(w, nullptr) == GetCurrentThreadId() && !s_origProc) {
        s_origProc = (WNDPROC)SetWindowLongPtrW(w, GWLP_WNDPROC, (LONG_PTR)&WinProc);
        LOGI("resolution: game window kept at %ux%u (not cut to the screen)", bufW, bufH);
    }
    FitClient("at start");
}
// compositor, every report: the client area again (the game resizes its swap chain to it)
void ResolutionWindowPoll() { if (s_hwnd && GetWindowThreadProcessId(s_hwnd, nullptr) == GetCurrentThreadId()) FitClient("cut by Windows"); }
