#pragma once
// HLSL for the compositor (compiled at run time with d3dcompiler_47; checked offline with tools/shadercheck).
//   Crop    : eye window cut out of the rendered picture (guide A.6) + edge fill (D.1) + sharpen + HDR input -> SDR.
//   UiSplit : UI = final - picture without UI (guide 8.5), premultiplied, for the HUD panel.

static const char* kShaderGfx = R"HLSL(
cbuffer C : register(b0) {
    float4 pic;      // drawn picture tangents l r u d
    float4 win;      // eye window tangents l r u d (what this output shows)
    float4 opt;      // x edge fill, y sharpen, z input (0 sdr, 1 scRGB, 2 PQ), w paper white nits
    float4 opt2;     // x: 1 = straight copy (uv as is), y: alpha from texture, z: ui threshold, w: fade to black (0..1)
    float4 cant;     // canted picture: x yaw, y pitch (radians, against the eye), z / w view width / height (1 = none)
};
Texture2D T0 : register(t0);
Texture2D T1 : register(t1);
SamplerState S : register(s0);
void VS(uint id : SV_VertexID, out float4 pos : SV_Position, out float2 uv : TEXCOORD0) {
    uv = float2((id << 1) & 2, id & 2);
    pos = float4(uv * float2(2, -2) + float2(-1, 1), 0, 1);
}
float3 ToSdr(float3 c) {
    if (opt.z > 1.5) {          // PQ (ST 2084) -> nits -> paper white
        float3 e = pow(saturate(c), 1.0 / 78.84375);
        float3 l = pow(max(e - 0.8359375, 0) / (18.8515625 - 18.6875 * e), 1.0 / 0.1593017578) * 10000.0;
        return pow(saturate(l / opt.w), 1.0 / 2.2);
    }
    if (opt.z > 0.5) return pow(saturate(c * 80.0 / opt.w), 1.0 / 2.2);   // scRGB (1.0 = 80 nits)
    return c;
}
float4 Fetch(float2 u) {
    if (opt.x < 0.5 || (u.x >= 0 && u.x <= 1 && u.y >= 0 && u.y <= 1)) return T0.SampleLevel(S, saturate(u), 0);
    float2 c = saturate(u); float d = length(u - c); float r = d * 0.7 + 0.003;       // edge fill (D.1)
    float4 acc = T0.SampleLevel(S, c, 0) * 2.0;
    [unroll] for (int k = 0; k < 10; k++) acc += T0.SampleLevel(S, saturate(c + float2(cos(k * 0.628), sin(k * 0.628)) * r), 0);
    acc /= 12.0; acc.rgb *= 1.0 / (1.0 + d * 1.5);
    return float4(acc.rgb, 1);
}
float4 PSCrop(float4 pos : SV_Position, float2 uv : TEXCOORD0) : SV_Target {
    float2 u = uv;
    if (opt2.x < 0.5) {
        float tx = win.x + uv.x * (win.y - win.x), ty = win.z - uv.y * (win.z - win.w);
        if (cant.x != 0 || cant.y != 0) {      // canted picture: the eye's direction turned into the picture's frame
            float x = tx / cant.z, y = ty / cant.w;
            float ct = cos(cant.x), st = sin(cant.x), ca = cos(cant.y), sa = sin(cant.y);
            float x1 = ct * x + st, z1 = st * x - ct;
            float y2 = ca * y + sa * z1, z2 = -sa * y + ca * z1;
            float w = max(-z2, 1e-4);
            tx = x1 / w * cant.z; ty = y2 / w * cant.w;
        }
        u = float2((tx - pic.x) / (pic.y - pic.x), (pic.z - ty) / (pic.z - pic.w));
        if (opt2.z > 0.5) {                     // pixel perfect: the eye's pixels are the picture's - copy them 1:1
            float tw, th; T0.GetDimensions(tw, th);
            u = (floor(u * float2(tw, th)) + 0.5) / float2(tw, th);
        }
    }
    float4 c = Fetch(u);
    if (opt.y > 0.001) {        // LumaSharpen-style cross, luma only, clamped
        float w, h; T0.GetDimensions(w, h); float2 px = float2(1.0 / w, 1.0 / h);
        float3 b = (T0.SampleLevel(S, u + float2(px.x, 0), 0).rgb + T0.SampleLevel(S, u - float2(px.x, 0), 0).rgb +
                    T0.SampleLevel(S, u + float2(0, px.y), 0).rgb + T0.SampleLevel(S, u - float2(0, px.y), 0).rgb) * 0.25;
        float l = dot(c.rgb - b, float3(0.2126, 0.7152, 0.0722));
        c.rgb += clamp(l * opt.y, -0.035, 0.035);
    }
    c.rgb = ToSdr(c.rgb) * (1.0 - saturate(opt2.w));
    if (opt2.y < 0.5) c.a = 1;
    return c;
}
float4 PSUiSplit(float4 pos : SV_Position, float2 uv : TEXCOORD0) : SV_Target {
    float4 f = T0.SampleLevel(S, uv, 0), n = T1.SampleLevel(S, uv, 0);
    float3 d = abs(f.rgb - n.rgb);
    float a = saturate((max(d.r, max(d.g, d.b)) - opt2.z) * 8.0);
    return float4(ToSdr(f.rgb) * a, a);
}
)HLSL";


