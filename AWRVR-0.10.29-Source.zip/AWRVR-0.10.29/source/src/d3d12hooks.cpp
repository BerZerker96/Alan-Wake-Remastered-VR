#include "d3d12hooks.h"
#include "d3d12compat.h"
#include "log.h"
#include "settings.h"
#include "engine.h"
#include "MinHook.h"
#include <atomic>
#include <cmath>
#include <algorithm>
#include <cstring>
#include <unordered_map>
#include <vector>
#include "realclock.h"

namespace {
template <class T> void SafeRelease(T*& p) { if (p) { p->Release(); p = nullptr; } }

// ---------------------------------------------------------------- vtable slots (D3D12 ABI)
enum { DEV_CreateGraphicsPipelineState = 10, DEV_CreateRenderTargetView = 20, DEV_CreateDepthStencilView = 21, DEV_CopyDescriptorsSimple = 24 };
enum { CL_Reset = 10, CL_DrawInstanced = 12, CL_DrawIndexedInstanced = 13, CL_CopyTextureRegion = 16, CL_CopyResource = 17, CL_RSSetViewports = 21, CL_RSSetScissorRects = 22,
       CL_SetPipelineState = 25, CL_ResourceBarrier = 26, CL_OMSetRenderTargets = 46, CL_ClearRenderTargetView = 48, CL_ExecuteIndirect = 59 };

using CreateRtvFn = void (STDMETHODCALLTYPE*)(ID3D12Device*, ID3D12Resource*, const D3D12_RENDER_TARGET_VIEW_DESC*, D3D12_CPU_DESCRIPTOR_HANDLE);
using CreateDsvFn = void (STDMETHODCALLTYPE*)(ID3D12Device*, ID3D12Resource*, const D3D12_DEPTH_STENCIL_VIEW_DESC*, D3D12_CPU_DESCRIPTOR_HANDLE);
using CopySimpleFn = void (STDMETHODCALLTYPE*)(ID3D12Device*, UINT, D3D12_CPU_DESCRIPTOR_HANDLE, D3D12_CPU_DESCRIPTOR_HANDLE, D3D12_DESCRIPTOR_HEAP_TYPE);
using CreatePsoFn = HRESULT (STDMETHODCALLTYPE*)(ID3D12Device*, const D3D12_GRAPHICS_PIPELINE_STATE_DESC*, REFIID, void**);
using ResetFn = HRESULT (STDMETHODCALLTYPE*)(ID3D12GraphicsCommandList*, ID3D12CommandAllocator*, ID3D12PipelineState*);
using DrawFn = void (STDMETHODCALLTYPE*)(ID3D12GraphicsCommandList*, UINT, UINT, UINT, UINT);
using DrawIdxFn = void (STDMETHODCALLTYPE*)(ID3D12GraphicsCommandList*, UINT, UINT, UINT, INT, UINT);
using VpFn = void (STDMETHODCALLTYPE*)(ID3D12GraphicsCommandList*, UINT, const D3D12_VIEWPORT*);
using ScFn = void (STDMETHODCALLTYPE*)(ID3D12GraphicsCommandList*, UINT, const D3D12_RECT*);
using PsoFn = void (STDMETHODCALLTYPE*)(ID3D12GraphicsCommandList*, ID3D12PipelineState*);
using BarrierFn = void (STDMETHODCALLTYPE*)(ID3D12GraphicsCommandList*, UINT, const D3D12_RESOURCE_BARRIER*);
using OmFn = void (STDMETHODCALLTYPE*)(ID3D12GraphicsCommandList*, UINT, const D3D12_CPU_DESCRIPTOR_HANDLE*, BOOL, const D3D12_CPU_DESCRIPTOR_HANDLE*);
using ClearRtFn = void (STDMETHODCALLTYPE*)(ID3D12GraphicsCommandList*, D3D12_CPU_DESCRIPTOR_HANDLE, const FLOAT*, UINT, const D3D12_RECT*);
ClearRtFn o_clearRt;
using CopyResFn = void (STDMETHODCALLTYPE*)(ID3D12GraphicsCommandList*, ID3D12Resource*, ID3D12Resource*);
using CopyTexFn = void (STDMETHODCALLTYPE*)(ID3D12GraphicsCommandList*, const D3D12_TEXTURE_COPY_LOCATION*, UINT, UINT, UINT, const D3D12_TEXTURE_COPY_LOCATION*, const D3D12_BOX*);
CopyResFn o_copyRes; CopyTexFn o_copyTex;
using ExecIndFn = void (STDMETHODCALLTYPE*)(ID3D12GraphicsCommandList*, ID3D12CommandSignature*, UINT, ID3D12Resource*, UINT64, ID3D12Resource*, UINT64);
CreateRtvFn o_createRtv; CreateDsvFn o_createDsv; CopySimpleFn o_copySimple; CreatePsoFn o_createPso;
ResetFn o_reset; DrawFn o_draw; DrawIdxFn o_drawIdx; VpFn o_vp; ScFn o_sc; PsoFn o_pso; BarrierFn o_barrier; OmFn o_om; ExecIndFn o_execInd;
bool g_installed = false;
ID3D12Device* g_dev = nullptr;   // the game's (set at Present)

// ---------------------------------------------------------------- descriptor handle -> resource
struct DescInfo { ID3D12Resource* res; };
SRWLOCK g_descLock = SRWLOCK_INIT;
std::unordered_map<SIZE_T, ID3D12Resource*> g_rtv, g_dsv;
ID3D12Resource* Lookup(std::unordered_map<SIZE_T, ID3D12Resource*>& m, SIZE_T h) {
    AcquireSRWLockShared(&g_descLock); auto it = m.find(h); ID3D12Resource* r = it == m.end() ? nullptr : it->second; ReleaseSRWLockShared(&g_descLock); return r;
}

// ---------------------------------------------------------------- PSO flags (lock-free sets)
// 2D: blended, no depth test, one UI-format target (HUD / sprites). Opaque: depth test + depth write, no blending (the
// scene's solid geometry - the only draws foveated rendering may coarsen; fog, particles, volumetrics, light shafts and
// full-screen passes stay at full rate, so the zones never show as rings).
constexpr int kPsoSlots = 1 << 16;
std::atomic<void*> g_pso2d[kPsoSlots], g_psoOpaque[kPsoSlots];
std::atomic<uint32_t> s_psoTotal{0}, s_pso2d{0}, s_psoOpaque{0};
void PsoInsert(std::atomic<void*>* set, void* p) {
    uint32_t h = (uint32_t)(((uintptr_t)p >> 4) * 2654435761u) & (kPsoSlots - 1);
    for (int i = 0; i < 64; i++) { void* e = nullptr; if (set[(h + i) & (kPsoSlots - 1)].compare_exchange_strong(e, p)) return; if (e == p) return; }
}
bool PsoIn(std::atomic<void*>* set, void* p) {
    if (!p) return false;
    uint32_t h = (uint32_t)(((uintptr_t)p >> 4) * 2654435761u) & (kPsoSlots - 1);
    for (int i = 0; i < 64; i++) { void* e = set[(h + i) & (kPsoSlots - 1)].load(std::memory_order_relaxed); if (e == p) return true; if (!e) return false; }
    return false;
}
inline void Pso2dInsert(void* p) { PsoInsert(g_pso2d, p); }
inline bool Pso2d(void* p) { return PsoIn(g_pso2d, p); }

// ---------------------------------------------------------------- frame bookkeeping
struct DepthCand { std::atomic<ID3D12Resource*> res{nullptr}; UINT w = 0, h = 0; DXGI_FORMAT fmt = DXGI_FORMAT_UNKNOWN; std::atomic<uint32_t> draws{0}; uint32_t last = 0; };
constexpr int kDepth = 16;
DepthCand g_depth[kDepth];
struct RtCand { std::atomic<ID3D12Resource*> res{nullptr}; UINT w = 0, h = 0; DXGI_FORMAT fmt = DXGI_FORMAT_UNKNOWN; std::atomic<uint32_t> draws{0}, draws2d{0}, withScene{0}, order{0}; uint32_t last = 0, unseen = 0; };
constexpr int kRt = 16;
RtCand g_rt[kRt];
std::atomic<uint32_t> g_bindOrder{0};
SRWLOCK g_candLock = SRWLOCK_INIT;

ID3D12Resource* g_bb[4] = {}; UINT g_bbW = 0, g_bbH = 0; DXGI_FORMAT g_bbFmt = DXGI_FORMAT_UNKNOWN;
std::atomic<ID3D12Resource*> g_sceneDepth{nullptr}; UINT g_sdW = 0, g_sdH = 0; DXGI_FORMAT g_sdFmt = DXGI_FORMAT_UNKNOWN;
std::atomic<ID3D12Resource*> g_uiLayer{nullptr};
CaptureTargets g_tgt; SRWLOCK g_tgtLock = SRWLOCK_INIT;
std::atomic<LONG> g_frame{0};                      // Present count (frame being recorded)
std::atomic<LONG> g_noUiFrame{-1}, g_depthFrame{-1}, g_eye0Frame{-1};
std::atomic<uint32_t> s_eye0Copies{0}, s_bbBinds0{0}, s_bbBinds1{0}, s_bbCopies0{0}, s_bbCopies1{0}, s_eye0Skipped{0};
std::atomic<LONG> g_bbTouch0Frame{-1};   // true stereo: the back buffer was written while the first eye rendered (this frame)
// true stereo diagnostics: back-buffer work recorded on another thread than the one drawing the eyes (the phase flag
// is global, so such work may be counted for the wrong eye), and command lists submitted while each eye renders
std::atomic<uint32_t> s_bbOtherThread{0}, s_exec0{0}, s_exec1{0};
std::atomic<bool> g_uiSeen{false};
std::atomic<uint32_t> g_sceneBindOrder{0};   // bind order of the last pass with the scene depth (this frame)
std::atomic<uint32_t> g_finalDraws{0}, g_uiDraws{0}, g_uiScaled{0}, g_uiHidden{0}, s_depthAtBarrier{0}, s_depthAtUi{0}, s_noUiCopies{0}, s_vrsBinds{0};
ID3D12Resource* g_depthBuf = nullptr; UINT64 g_depthBufSize = 0; D3D12_PLACED_SUBRESOURCE_FOOTPRINT g_depthFp{};

// ---------------------------------------------------------------- foveated rendering
// foveated rendering: one shading-rate image per size the 3D is drawn at - the back buffer's, and the scene's own
// render size when an upscaler (DLSS / DLAA through OptiScaler, FSR, XeSS ...) draws the 3D smaller and scales it up
// per size: three images - [0] the left eye's picture, [1] the right eye's, [2] a picture for both / unknown eye
// (true stereo, head mode, before the eyes are known). The eye images are coarse (4x4) where that eye never looks:
// matched view draws each eye symmetric around its lens axis, so ~20 % of every picture is never shown.
constexpr int kVrsVar = 3;
std::atomic<ID3D12Resource*> g_vrsImg[2][kVrsVar] = {};
std::atomic<uint32_t> g_vrsW[2] = {}, g_vrsH[2] = {};
bool g_vrsTier2 = false; UINT g_vrsTile = 16; bool g_vrsChecked = false;
struct VrsRect { int x0 = 0, x1 = 1000, y0 = 0, y1 = 1000, cx = 500, cy = 500; bool operator==(const VrsRect& o) const { return x0 == o.x0 && x1 == o.x1 && y0 == o.y0 && y1 == o.y1 && cx == o.cx && cy == o.cy; } };
struct VrsKey { std::string mode; float in, out, wide; bool dbg; UINT w, h; VrsRect r; } g_vrsKey[2][kVrsVar];
DWORD g_vrsBuilt[2][kVrsVar] = {};
std::vector<ID3D12Resource*> g_vrsRetire; std::vector<LONG> g_vrsRetireAt;
ID3D12Resource* g_vrsUpload[2][kVrsVar] = {};
// each eye's shown part of its picture (permille), noted by the render threads from the frame they record
std::atomic<uint64_t> g_vrsEyeRect[2] = {};
uint64_t PackRect(const VrsRect& r) { return (uint64_t)r.x0 | (uint64_t)r.x1 << 10 | (uint64_t)r.y0 << 20 | (uint64_t)r.y1 << 30 | (uint64_t)r.cx << 40 | (uint64_t)r.cy << 50 | 1ull << 63; }
VrsRect UnpackRect(uint64_t v) { VrsRect r; r.x0 = v & 1023; r.x1 = v >> 10 & 1023; r.y0 = v >> 20 & 1023; r.y1 = v >> 30 & 1023; r.cx = v >> 40 & 1023; r.cy = v >> 50 & 1023; return r; }
ID3D12Resource* VrsFor(int slot, int var) { ID3D12Resource* r = g_vrsImg[slot][var].load(std::memory_order_relaxed); return r ? r : g_vrsImg[slot][2].load(std::memory_order_relaxed); }

// ---------------------------------------------------------------- per command list state (thread-local)
struct ListState {
    ID3D12GraphicsCommandList* list = nullptr;
    ID3D12Resource* rt = nullptr; UINT rtW = 0, rtH = 0; DXGI_FORMAT rtFmt = DXGI_FORMAT_UNKNOWN;
    ID3D12Resource* ds = nullptr; int dsIdx = -1; int rtIdx = -1;
    ID3D12Resource* vrsImgBound = nullptr; bool isFinal = false, isUi = false, pso2d = false, psoOpaque = false, vrsTarget = false, vrsBound = false, direct = true;
    D3D12_VIEWPORT vp{}; bool vpSet = false; D3D12_RECT sc{}; bool scSet = false;
    ID3D12GraphicsCommandList5* l5 = nullptr; bool l5Checked = false;
    UINT finalDrawsHere = 0;
};
constexpr int kTls = 8;
thread_local ListState t_ls[kTls];
thread_local int t_lsNext = 0;
ListState& LS(ID3D12GraphicsCommandList* l) {
    for (auto& s : t_ls) if (s.list == l) return s;
    ListState& s = t_ls[t_lsNext]; t_lsNext = (t_lsNext + 1) % kTls;
    if (s.l5) s.l5->Release();
    s = ListState{}; s.list = l; s.direct = l->GetType() == D3D12_COMMAND_LIST_TYPE_DIRECT;
    return s;
}

bool IsBackBuffer(ID3D12Resource* r) { for (auto* b : g_bb) if (b && b == r) return true; return false; }
bool UiFormat(DXGI_FORMAT f) {
    return f == DXGI_FORMAT_R8G8B8A8_UNORM || f == DXGI_FORMAT_R8G8B8A8_UNORM_SRGB || f == DXGI_FORMAT_B8G8R8A8_UNORM ||
           f == DXGI_FORMAT_B8G8R8A8_UNORM_SRGB || f == DXGI_FORMAT_R10G10B10A2_UNORM || f == DXGI_FORMAT_R8G8B8A8_TYPELESS || f == DXGI_FORMAT_B8G8R8A8_TYPELESS;
}

int DepthIndex(ID3D12Resource* r) {
    for (int i = 0; i < kDepth; i++) if (g_depth[i].res.load(std::memory_order_relaxed) == r) return i;
    AcquireSRWLockExclusive(&g_candLock);
    int idx = -1;
    for (int i = 0; i < kDepth && idx < 0; i++) if (g_depth[i].res.load() == r) idx = i;
    for (int i = 0; i < kDepth && idx < 0; i++) if (!g_depth[i].res.load()) idx = i;
    if (idx < 0) { idx = 0; for (int i = 1; i < kDepth; i++) if (g_depth[i].last < g_depth[idx].last) idx = i; }
    if (g_depth[idx].res.load() != r) {
        D3D12_RESOURCE_DESC d = r->GetDesc();
        g_depth[idx].w = (UINT)d.Width; g_depth[idx].h = d.Height; g_depth[idx].fmt = d.Format; g_depth[idx].draws = 0; g_depth[idx].last = 0;
        g_depth[idx].res = r;
    }
    ReleaseSRWLockExclusive(&g_candLock);
    return idx;
}
int RtIndex(ID3D12Resource* r, UINT w, UINT h, DXGI_FORMAT f) {
    for (int i = 0; i < kRt; i++) if (g_rt[i].res.load(std::memory_order_relaxed) == r) return i;
    AcquireSRWLockExclusive(&g_candLock);
    int idx = -1;
    for (int i = 0; i < kRt && idx < 0; i++) if (g_rt[i].res.load() == r) idx = i;
    for (int i = 0; i < kRt && idx < 0; i++) if (!g_rt[i].res.load()) idx = i;
    if (idx < 0) { idx = 0; for (int i = 1; i < kRt; i++) if (g_rt[i].unseen > g_rt[idx].unseen) idx = i; }
    if (g_rt[idx].res.load() != r) { g_rt[idx].w = w; g_rt[idx].h = h; g_rt[idx].fmt = f; g_rt[idx].draws = g_rt[idx].draws2d = g_rt[idx].withScene = 0; g_rt[idx].unseen = 0; g_rt[idx].res = r; }
    ReleaseSRWLockExclusive(&g_candLock);
    return idx;
}

void Transition(ID3D12GraphicsCommandList* l, ID3D12Resource* r, D3D12_RESOURCE_STATES a, D3D12_RESOURCE_STATES b, UINT sub = D3D12_RESOURCE_BARRIER_ALL_SUBRESOURCES) {
    if (a == b) return;
    D3D12_RESOURCE_BARRIER x{}; x.Type = D3D12_RESOURCE_BARRIER_TYPE_TRANSITION; x.Transition.pResource = r;
    x.Transition.Subresource = sub; x.Transition.StateBefore = a; x.Transition.StateAfter = b;
    o_barrier(l, 1, &x);
}

// scene depth -> bytes in the shared RGBA8 / RG8 texture of this frame's slot. state = the depth's current state.
void CopyDepth(ID3D12GraphicsCommandList* l, ID3D12Resource* depth, D3D12_RESOURCE_STATES state) {
    LONG f = g_frame.load();
    if (g_depthFrame.load() == f) return;
    AcquireSRWLockShared(&g_tgtLock);
    CaptureTargets t = g_tgt;
    ReleaseSRWLockShared(&g_tgtLock);
    int slot = (int)(f % 3);
    if (!t.wantDepth || !t.depth[slot] || !g_dev) return;
    D3D12_RESOURCE_DESC d = depth->GetDesc();
    if ((UINT)d.Width != t.depthW || d.Height != t.depthH) return;
    if (!g_depthBuf) {
        UINT64 total = 0; UINT rows; UINT64 rowSize;
        g_dev->GetCopyableFootprints(&d, 0, 1, 0, &g_depthFp, &rows, &rowSize, &total);
        D3D12_HEAP_PROPERTIES hp{}; hp.Type = D3D12_HEAP_TYPE_DEFAULT;
        D3D12_RESOURCE_DESC bd{}; bd.Dimension = D3D12_RESOURCE_DIMENSION_BUFFER; bd.Width = total; bd.Height = 1; bd.DepthOrArraySize = 1; bd.MipLevels = 1;
        bd.SampleDesc.Count = 1; bd.Layout = D3D12_TEXTURE_LAYOUT_ROW_MAJOR;
        if (FAILED(g_dev->CreateCommittedResource(&hp, D3D12_HEAP_FLAG_NONE, &bd, D3D12_RESOURCE_STATE_COPY_DEST, nullptr, __uuidof(ID3D12Resource), (void**)&g_depthBuf))) return;
        g_depthBufSize = total;
        LOGI("recon: scene depth %llux%u fmt %d -> footprint fmt %d pitch %u (%llu bytes)", (unsigned long long)d.Width, d.Height, (int)d.Format,
             (int)g_depthFp.Footprint.Format, g_depthFp.Footprint.RowPitch, (unsigned long long)total);
    }
    Transition(l, depth, state, D3D12_RESOURCE_STATE_COPY_SOURCE, 0);
    D3D12_TEXTURE_COPY_LOCATION src{}, dst{};
    src.pResource = depth; src.Type = D3D12_TEXTURE_COPY_TYPE_SUBRESOURCE_INDEX; src.SubresourceIndex = 0;
    dst.pResource = g_depthBuf; dst.Type = D3D12_TEXTURE_COPY_TYPE_PLACED_FOOTPRINT; dst.PlacedFootprint = g_depthFp;
    l->CopyTextureRegion(&dst, 0, 0, 0, &src, nullptr);
    Transition(l, depth, D3D12_RESOURCE_STATE_COPY_SOURCE, state, 0);
    Transition(l, g_depthBuf, D3D12_RESOURCE_STATE_COPY_DEST, D3D12_RESOURCE_STATE_COPY_SOURCE);
    D3D12_TEXTURE_COPY_LOCATION bsrc{}, tdst{};
    bsrc.pResource = g_depthBuf; bsrc.Type = D3D12_TEXTURE_COPY_TYPE_PLACED_FOOTPRINT; bsrc.PlacedFootprint = g_depthFp;
    UINT bpp = g_depthFp.Footprint.RowPitch / (g_depthFp.Footprint.Width ? g_depthFp.Footprint.Width : 1);
    bsrc.PlacedFootprint.Footprint.Format = (d.Format == DXGI_FORMAT_R16_TYPELESS || d.Format == DXGI_FORMAT_D16_UNORM) ? DXGI_FORMAT_R8G8_UNORM : DXGI_FORMAT_R8G8B8A8_UNORM;
    (void)bpp;
    tdst.pResource = t.depth[slot]; tdst.Type = D3D12_TEXTURE_COPY_TYPE_SUBRESOURCE_INDEX; tdst.SubresourceIndex = 0;
    Transition(l, t.depth[slot], D3D12_RESOURCE_STATE_COMMON, D3D12_RESOURCE_STATE_COPY_DEST);
    l->CopyTextureRegion(&tdst, 0, 0, 0, &bsrc, nullptr);
    Transition(l, t.depth[slot], D3D12_RESOURCE_STATE_COPY_DEST, D3D12_RESOURCE_STATE_COMMON);
    Transition(l, g_depthBuf, D3D12_RESOURCE_STATE_COPY_SOURCE, D3D12_RESOURCE_STATE_COPY_DEST);
    g_depthFrame = f;
}

void CopyNoUi(ID3D12GraphicsCommandList* l, ID3D12Resource* finalRt) {
    LONG f = g_frame.load();
    if (g_noUiFrame.load() == f) return;
    AcquireSRWLockShared(&g_tgtLock); CaptureTargets t = g_tgt; ReleaseSRWLockShared(&g_tgtLock);
    int slot = (int)(f % 3);
    if (!t.wantNoUi || !t.noUi[slot]) return;
    Transition(l, finalRt, D3D12_RESOURCE_STATE_RENDER_TARGET, D3D12_RESOURCE_STATE_COPY_SOURCE);
    Transition(l, t.noUi[slot], D3D12_RESOURCE_STATE_COMMON, D3D12_RESOURCE_STATE_COPY_DEST);
    l->CopyResource(t.noUi[slot], finalRt);
    Transition(l, t.noUi[slot], D3D12_RESOURCE_STATE_COPY_DEST, D3D12_RESOURCE_STATE_COMMON);
    Transition(l, finalRt, D3D12_RESOURCE_STATE_COPY_SOURCE, D3D12_RESOURCE_STATE_RENDER_TARGET);
    g_noUiFrame = f; s_noUiCopies++;
}

// true stereo: the first eye's finished picture, copied when the second eye's render first binds the back buffer (the
// copy is recorded in that list, so on the GPU it runs after everything the first eye drew and before the second eye
// overwrites it). The second eye's draws into the final image start counting from zero again (UI split).
void CopyEye0(ID3D12GraphicsCommandList* l, ID3D12Resource* finalRt, D3D12_RESOURCE_STATES state = D3D12_RESOURCE_STATE_RENDER_TARGET) {
    LONG f = g_frame.load();
    if (g_eye0Frame.load() == f) return;
    // only if the first eye's render really wrote the back buffer this frame - else it holds an older picture
    if (g_bbTouch0Frame.load() != f) { s_eye0Skipped++; g_eye0Frame = f - 1000000; return; }
    AcquireSRWLockShared(&g_tgtLock); CaptureTargets t = g_tgt; ReleaseSRWLockShared(&g_tgtLock);
    int slot = (int)(f % 3);
    if (!t.wantEye0 || !t.eye0[slot]) return;
    g_eye0Frame = f;
    Transition(l, finalRt, state, D3D12_RESOURCE_STATE_COPY_SOURCE);
    Transition(l, t.eye0[slot], D3D12_RESOURCE_STATE_COMMON, D3D12_RESOURCE_STATE_COPY_DEST);
    l->CopyResource(t.eye0[slot], finalRt);
    Transition(l, t.eye0[slot], D3D12_RESOURCE_STATE_COPY_DEST, D3D12_RESOURCE_STATE_COMMON);
    Transition(l, finalRt, D3D12_RESOURCE_STATE_COPY_SOURCE, state);
    g_finalDraws = 0; s_eye0Copies++;
}

// true stereo, copy-presented frames (this game writes its final picture into the back buffer with a copy): right after
// the first eye's copy, the copy's source still holds the first eye's picture in COPY_SOURCE state - copied from there.
int FormatFamily(DXGI_FORMAT f) {
    switch (f) {
    case DXGI_FORMAT_R10G10B10A2_TYPELESS: case DXGI_FORMAT_R10G10B10A2_UNORM: case DXGI_FORMAT_R10G10B10A2_UINT: return 1;
    case DXGI_FORMAT_R8G8B8A8_TYPELESS: case DXGI_FORMAT_R8G8B8A8_UNORM: case DXGI_FORMAT_R8G8B8A8_UNORM_SRGB: case DXGI_FORMAT_R8G8B8A8_UINT: case DXGI_FORMAT_R8G8B8A8_SNORM: case DXGI_FORMAT_R8G8B8A8_SINT: return 2;
    case DXGI_FORMAT_B8G8R8A8_TYPELESS: case DXGI_FORMAT_B8G8R8A8_UNORM: case DXGI_FORMAT_B8G8R8A8_UNORM_SRGB: return 3;
    case DXGI_FORMAT_R16G16B16A16_TYPELESS: case DXGI_FORMAT_R16G16B16A16_FLOAT: case DXGI_FORMAT_R16G16B16A16_UNORM: case DXGI_FORMAT_R16G16B16A16_UINT: case DXGI_FORMAT_R16G16B16A16_SNORM: case DXGI_FORMAT_R16G16B16A16_SINT: return 4;
    default: return 100 + (int)f;
    }
}
void CopyEye0FromSource(ID3D12GraphicsCommandList* l, const D3D12_TEXTURE_COPY_LOCATION& src) {
    LONG f = g_frame.load();
    if (g_eye0Frame.load() == f) return;
    AcquireSRWLockShared(&g_tgtLock); CaptureTargets t = g_tgt; ReleaseSRWLockShared(&g_tgtLock);
    int slot = (int)(f % 3);
    if (!t.wantEye0 || !t.eye0[slot] || !src.pResource) return;
    D3D12_RESOURCE_DESC sd = src.pResource->GetDesc(), ed = t.eye0[slot]->GetDesc();
    if (sd.Width != ed.Width || sd.Height != ed.Height || sd.SampleDesc.Count != 1 || FormatFamily(sd.Format) != FormatFamily(ed.Format)) return;   // not the full picture / not copyable
    g_eye0Frame = f;
    Transition(l, t.eye0[slot], D3D12_RESOURCE_STATE_COMMON, D3D12_RESOURCE_STATE_COPY_DEST);
    D3D12_TEXTURE_COPY_LOCATION dst{}; dst.pResource = t.eye0[slot]; dst.Type = D3D12_TEXTURE_COPY_TYPE_SUBRESOURCE_INDEX; dst.SubresourceIndex = 0;
    o_copyTex(l, &dst, 0, 0, 0, &src, nullptr);
    Transition(l, t.eye0[slot], D3D12_RESOURCE_STATE_COPY_DEST, D3D12_RESOURCE_STATE_COMMON);
    s_eye0Copies++;
}
void BackBufferCopied(ID3D12GraphicsCommandList* l, const D3D12_TEXTURE_COPY_LOCATION& src) {
    int ph = EngineNativePhase();
    if (ph >= 0 && GetCurrentThreadId() != EngineNativeThread()) s_bbOtherThread++;
    if (ph == 0) { s_bbCopies0++; g_bbTouch0Frame = g_frame.load(); if (LS(l).direct) CopyEye0FromSource(l, src); }
    else if (ph == 1) s_bbCopies1++;
}

// is this draw UI? (final-image split, or the picked / automatic UI layer)
bool DrawIsUi(ListState& s) {
    if (!g_set.uiHooks || !s.rt) return false;
    if (s.isUi) return true;
    if (!s.isFinal) return false;
    // true stereo: the eyes are drawn inside the game's renderer view render (RendererRenderView, hooked); the HUD is
    // drawn after it returns. Nothing drawn inside either eye's render is UI - late blended passes there are the
    // game's effects (lens flares, light glows): 0.10.28 took them for UI from the second eye's first one on, so they
    // were missing from the right eye (and its picture was copied too early - black flashes). After both renders:
    // blended depth-less 2D draws are the HUD.
    if (EngineEffectiveMode() == VRMODE_NATIVE && EngineNativeAvailable() && g_set.vrMode == "native") {
        if (EngineNativePhase() >= 0 || !EngineNativePairDone()) return false;
        if (g_set.hudSplit == "auto" && !s.pso2d) return false;
        g_finalDraws.fetch_add(1);
        return true;
    }
    uint32_t n = g_finalDraws.fetch_add(1) + 1;
    const std::string& m = g_set.hudSplit;
    if (m == "all") return true;
    if (m == "count") return n > (uint32_t)(g_set.hudSceneDraws < 0 ? 0 : g_set.hudSceneDraws);
    // auto: after the first full-screen pass (the 3D picture), and only blended depth-less 2D draws (the HUD is atlas
    // sprites and text, HUDAtlasSprite): a second opaque post pass into the final image is never taken for UI
    return n > 1 && s.pso2d;
}

// scale the UI draw about the eye's UI centre (guide 10.2, A.5)
bool ScaleUi(ListState& s) {
    FrameInfo fi;
    UINT W = s.rtW, H = s.rtH;
    if (EngineEffectiveMode() == VRMODE_NATIVE) return false;   // true stereo: the HUD goes to its panel, the game's own layout
    // safe: the game lays the HUD out inside its own (inset) safe area - only moved to the eye's centre, not scaled
    float cx = W * 0.5f, cy = H * 0.5f, k = g_set.hudMode == "safe" ? 1.f : g_set.uiScale;
    if (EngineFrameForRecording(&fi)) {
        const Tan4& p = fi.pic;
        float tc = 0;
        if (fi.eye >= 0) {
            float ipd = sqrtf((fi.eyePose[1].px - fi.eyePose[0].px) * (fi.eyePose[1].px - fi.eyePose[0].px) + (fi.eyePose[1].py - fi.eyePose[0].py) * (fi.eyePose[1].py - fi.eyePose[0].py) +
                              (fi.eyePose[1].pz - fi.eyePose[0].pz) * (fi.eyePose[1].pz - fi.eyePose[0].pz));
            float D = g_set.uiDepth > 0.1f ? g_set.uiDepth : 0.1f;
            tc = (fi.eye == 0 ? 1.f : -1.f) * ipd / (2 * D);
        } else {
            // centre view: keep the HUD's size relative to an eye
            float eyeSpan = tanf(fi.eyeFov[0].right) - tanf(fi.eyeFov[0].left), picSpan = p.r - p.l;
            if (picSpan > 1e-3f && g_set.hudMode != "safe") k *= eyeSpan / picSpan;
        }
        float px = tc, py = 0;
        if (fi.picCant[0] != 0.f || fi.picCant[1] != 0.f) CantToPic(fi.picCant, tc, 0, &px, &py);   // canted picture
        float xn = (2 * px - (p.r + p.l)) / (p.r - p.l), yn = (2 * py - (p.u + p.d)) / (p.u - p.d);
        cx = (xn + 1) * 0.5f * W; cy = (1 - yn) * 0.5f * H - g_set.uiOffsetY * H;
    } else return false;   // flat frames (menus): the game's own layout
    D3D12_VIEWPORT v = s.vpSet ? s.vp : D3D12_VIEWPORT{ 0, 0, (float)W, (float)H, 0, 1 };
    v.TopLeftX = cx + (v.TopLeftX - W * 0.5f) * k; v.TopLeftY = cy + (v.TopLeftY - H * 0.5f) * k; v.Width *= k; v.Height *= k;
    D3D12_RECT r = s.scSet ? s.sc : D3D12_RECT{ 0, 0, (LONG)W, (LONG)H };
    D3D12_RECT r2{ (LONG)(cx + (r.left - W * 0.5f) * k), (LONG)(cy + (r.top - H * 0.5f) * k), (LONG)(cx + (r.right - W * 0.5f) * k), (LONG)(cy + (r.bottom - H * 0.5f) * k) };
    r2.left = r2.left < 0 ? 0 : r2.left; r2.top = r2.top < 0 ? 0 : r2.top;
    r2.right = r2.right > (LONG)W ? (LONG)W : r2.right; r2.bottom = r2.bottom > (LONG)H ? (LONG)H : r2.bottom;
    o_vp(s.list, 1, &v); o_sc(s.list, 1, &r2);
    return true;
}
void RestoreVp(ListState& s) {
    D3D12_VIEWPORT v = s.vpSet ? s.vp : D3D12_VIEWPORT{ 0, 0, (float)s.rtW, (float)s.rtH, 0, 1 };
    D3D12_RECT r = s.scSet ? s.sc : D3D12_RECT{ 0, 0, (LONG)s.rtW, (LONG)s.rtH };
    o_vp(s.list, 1, &v); o_sc(s.list, 1, &r);
}

// common pre-draw work. Returns false if the draw must be skipped (hide HUD).
bool BeforeDraw(ID3D12GraphicsCommandList* l, bool* scaled) {
    *scaled = false;
    ListState& s = LS(l);
    if (s.dsIdx >= 0) g_depth[s.dsIdx].draws.fetch_add(1, std::memory_order_relaxed);
    if (s.isFinal) {   // true stereo: a draw into the back buffer - it is in RENDER_TARGET state now
        int ph = EngineNativePhase();
        if (ph >= 0 && GetCurrentThreadId() != EngineNativeThread()) s_bbOtherThread++;
        if (ph == 0) g_bbTouch0Frame = g_frame.load();
        else if (ph == 1 && s.direct) CopyEye0(l, s.rt);
    }
    if (s.rtIdx >= 0) {
        g_rt[s.rtIdx].draws.fetch_add(1, std::memory_order_relaxed);
        if (s.pso2d) g_rt[s.rtIdx].draws2d.fetch_add(1, std::memory_order_relaxed);
        if (s.ds && s.ds == g_sceneDepth.load(std::memory_order_relaxed)) g_rt[s.rtIdx].withScene.fetch_add(1, std::memory_order_relaxed);
    }
    if (!DrawIsUi(s)) return true;
    // the picture before the UI, and the scene depth if its barrier did not come
    if (s.direct && s.isFinal) {
        CopyNoUi(l, s.rt);
        ID3D12Resource* sd = g_sceneDepth.load();
        if (sd && g_depthFrame.load() != g_frame.load()) { CopyDepth(l, sd, D3D12_RESOURCE_STATE_DEPTH_WRITE); s_depthAtUi++; }
    }
    g_uiDraws++;
    if (g_set.hideHud && s.isFinal) { g_uiHidden++; return false; }
    if (g_set.hudMode == "scale" || g_set.hudMode == "safe") { *scaled = ScaleUi(s); if (*scaled) { g_uiScaled++; g_uiSeen = true; } }
    return true;
}

// ---------------------------------------------------------------- detours
void STDMETHODCALLTYPE H_CreateRtv(ID3D12Device* d, ID3D12Resource* r, const D3D12_RENDER_TARGET_VIEW_DESC* desc, D3D12_CPU_DESCRIPTOR_HANDLE h) {
    o_createRtv(d, r, desc, h);
    AcquireSRWLockExclusive(&g_descLock); if (r) g_rtv[h.ptr] = r; else g_rtv.erase(h.ptr); ReleaseSRWLockExclusive(&g_descLock);
}
void STDMETHODCALLTYPE H_CreateDsv(ID3D12Device* d, ID3D12Resource* r, const D3D12_DEPTH_STENCIL_VIEW_DESC* desc, D3D12_CPU_DESCRIPTOR_HANDLE h) {
    o_createDsv(d, r, desc, h);
    AcquireSRWLockExclusive(&g_descLock); if (r) g_dsv[h.ptr] = r; else g_dsv.erase(h.ptr); ReleaseSRWLockExclusive(&g_descLock);
}
void STDMETHODCALLTYPE H_CopySimple(ID3D12Device* d, UINT n, D3D12_CPU_DESCRIPTOR_HANDLE dst, D3D12_CPU_DESCRIPTOR_HANDLE src, D3D12_DESCRIPTOR_HEAP_TYPE t) {
    o_copySimple(d, n, dst, src, t);
    if (t != D3D12_DESCRIPTOR_HEAP_TYPE_RTV && t != D3D12_DESCRIPTOR_HEAP_TYPE_DSV) return;
    auto& m = t == D3D12_DESCRIPTOR_HEAP_TYPE_RTV ? g_rtv : g_dsv;
    UINT inc = d->GetDescriptorHandleIncrementSize(t);
    AcquireSRWLockExclusive(&g_descLock);
    for (UINT i = 0; i < n; i++) { auto it = m.find(src.ptr + i * inc); if (it != m.end()) m[dst.ptr + i * inc] = it->second; }
    ReleaseSRWLockExclusive(&g_descLock);
}
HRESULT STDMETHODCALLTYPE H_CreatePso(ID3D12Device* d, const D3D12_GRAPHICS_PIPELINE_STATE_DESC* desc, REFIID riid, void** out) {
    HRESULT hr = o_createPso(d, desc, riid, out);
    s_psoTotal++;
    if (SUCCEEDED(hr) && out && *out && desc && !desc->DepthStencilState.DepthEnable && desc->NumRenderTargets == 1 &&
        desc->BlendState.RenderTarget[0].BlendEnable && UiFormat(desc->RTVFormats[0])) { Pso2dInsert(*out); s_pso2d++; }
    if (SUCCEEDED(hr) && out && *out && desc && desc->DepthStencilState.DepthEnable && desc->DepthStencilState.DepthWriteMask == D3D12_DEPTH_WRITE_MASK_ALL &&
        desc->NumRenderTargets >= 1 && !desc->BlendState.RenderTarget[0].BlendEnable) { PsoInsert(g_psoOpaque, *out); s_psoOpaque++; }
    return hr;
}
HRESULT STDMETHODCALLTYPE H_Reset(ID3D12GraphicsCommandList* l, ID3D12CommandAllocator* a, ID3D12PipelineState* p) {
    ListState& s = LS(l);
    ID3D12GraphicsCommandList5* l5 = s.l5; bool chk = s.l5Checked; bool direct = s.direct;
    s = ListState{}; s.list = l; s.l5 = l5; s.l5Checked = chk; s.direct = direct; s.pso2d = Pso2d(p); s.psoOpaque = PsoIn(g_psoOpaque, p);
    return o_reset(l, a, p);
}
void STDMETHODCALLTYPE H_Vp(ID3D12GraphicsCommandList* l, UINT n, const D3D12_VIEWPORT* v) {
    ListState& s = LS(l); if (n && v) { s.vp = v[0]; s.vpSet = true; }
    o_vp(l, n, v);
}
void STDMETHODCALLTYPE H_Sc(ID3D12GraphicsCommandList* l, UINT n, const D3D12_RECT* r) {
    ListState& s = LS(l); if (n && r) { s.sc = r[0]; s.scSet = true; }
    o_sc(l, n, r);
}
// which eye the recording thread's frame is for (cached per Present), and that eye's shown part of the picture
static int VrsEyeNow() {
    thread_local LONG at = -1; thread_local int eye = -1;
    LONG pc = EnginePresentCount();
    if (pc == at) return eye;
    at = pc; eye = -1;
    FrameInfo fi;
    if (EngineEffectiveMode() == VRMODE_NATIVE || !EngineFrameForRecording(&fi) || fi.eye < 0 || fi.eye > 1) return eye;
    const Tan4& p = fi.pic; float pw = p.r - p.l, ph = p.u - p.d;
    if (!(pw > 0.1f && ph > 0.1f)) return eye;
    const xrb::IpcFov& fv = fi.eyeFov[fi.eye];
    float sh = tanf(g_set.aerAlignH * 0.0174533f) * (fi.eye == 0 ? -1.f : 1.f), sv = tanf(g_set.aerAlignV * 0.0174533f) * (fi.eye == 0 ? 1.f : -1.f);
    float wl = tanf(fv.left) * g_set.viewWidth + sh, wr = tanf(fv.right) * g_set.viewWidth + sh;
    float wu = tanf(fv.up) * g_set.viewHeight + sv, wd = tanf(fv.down) * g_set.viewHeight + sv;
    auto pm = [](float v) { int i = (int)lroundf(v * 1000.f); return i < 0 ? 0 : i > 1000 ? 1000 : i; };
    // the eye's window and lens axis in the picture's tangents (a canted picture: turned into its frame, outline sampled)
    float ax = 0, ay = 0, bl = wl, br = wr, bu = wu, bd = wd;
    if (fi.picCant[0] != 0.f || fi.picCant[1] != 0.f) {
        CantToPic(fi.picCant, 0, 0, &ax, &ay);
        bl = br = ax; bu = bd = ay;
        for (int i = 0; i <= 16; i++) {
            float t = i / 16.f, x = wl + (wr - wl) * t, y = wd + (wu - wd) * t, qx, qy;
            const float pts[4][2] = { { x, wu }, { x, wd }, { wl, y }, { wr, y } };
            for (auto& pt : pts) { CantToPic(fi.picCant, pt[0], pt[1], &qx, &qy); bl = fminf(bl, qx); br = fmaxf(br, qx); bd = fminf(bd, qy); bu = fmaxf(bu, qy); }
        }
    }
    VrsRect r;
    r.x0 = pm((bl - p.l) / pw - 0.03f); r.x1 = pm((br - p.l) / pw + 0.03f);    // + 3 % margin: eye align, edge filtering
    r.y0 = pm((p.u - bu) / ph - 0.03f); r.y1 = pm((p.u - bd) / ph + 0.03f);
    r.cx = pm((ax - p.l) / pw); r.cy = pm((p.u - ay) / ph);                     // the lens axis (tangent 0)
    if (r.x1 - r.x0 < 300 || r.y1 - r.y0 < 300) return eye;                     // implausible: keep the image for both
    g_vrsEyeRect[fi.eye].store(PackRect(r), std::memory_order_relaxed);
    return eye = fi.eye;
}
void VrsApply(ID3D12GraphicsCommandList* l, ListState& s) {
    ID3D12Resource* img = nullptr;
    if (s.vrsTarget && s.psoOpaque) {
        int slot = -1;
        for (int k = 0; k < 2 && slot < 0; k++) if (s.rtW == g_vrsW[k].load(std::memory_order_relaxed) && s.rtH == g_vrsH[k].load(std::memory_order_relaxed)) slot = k;
        if (slot >= 0) { int e = VrsEyeNow(); img = VrsFor(slot, e == 0 || e == 1 ? e : 2); }
    }
    bool want = img != nullptr;
    if (want == s.vrsBound && (!want || img == s.vrsImgBound)) return;
    s.vrsImgBound = want ? img : nullptr;
    if (!s.l5Checked) { s.l5Checked = true; l->QueryInterface(AWRVR_IID_LIST5, (void**)&s.l5); }
    if (!s.l5) return;
    if (want) {
        D3D12_SHADING_RATE_COMBINER c[2] = { D3D12_SHADING_RATE_COMBINER_PASSTHROUGH, D3D12_SHADING_RATE_COMBINER_OVERRIDE };
        s.l5->RSSetShadingRate(D3D12_SHADING_RATE_1X1, c); s.l5->RSSetShadingRateImage(img); s_vrsBinds++;
    } else { s.l5->RSSetShadingRateImage(nullptr); s.l5->RSSetShadingRate(D3D12_SHADING_RATE_1X1, nullptr); }
    s.vrsBound = want;
}
void STDMETHODCALLTYPE H_Pso(ID3D12GraphicsCommandList* l, ID3D12PipelineState* p) {
    ListState& s = LS(l); s.pso2d = Pso2d(p); s.psoOpaque = PsoIn(g_psoOpaque, p);
    o_pso(l, p);
    if (s.vrsTarget || s.vrsBound) VrsApply(l, s);
}
void STDMETHODCALLTYPE H_Om(ID3D12GraphicsCommandList* l, UINT n, const D3D12_CPU_DESCRIPTOR_HANDLE* rts, BOOL single, const D3D12_CPU_DESCRIPTOR_HANDLE* ds) {
    o_om(l, n, rts, single, ds);
    ListState& s = LS(l);
    s.rt = n && rts ? Lookup(g_rtv, rts[0].ptr) : nullptr;
    s.ds = ds ? Lookup(g_dsv, ds->ptr) : nullptr;
    s.dsIdx = s.ds ? DepthIndex(s.ds) : -1;
    s.rtW = s.rtH = 0; s.isFinal = s.isUi = false; s.rtIdx = -1;
    if (s.rt) {
        D3D12_RESOURCE_DESC d = s.rt->GetDesc();
        s.rtW = (UINT)d.Width; s.rtH = d.Height; s.rtFmt = d.Format;
        s.isFinal = IsBackBuffer(s.rt);
        if (s.isFinal) {   // (no copy here: the back buffer may still be waiting for its barrier to RENDER_TARGET)
            int ph = EngineNativePhase();
            if (ph == 0) s_bbBinds0++; else if (ph == 1) s_bbBinds1++;
        }
        if (!s.isFinal && UiFormat(d.Format) && s.rtW == g_bbW && s.rtH == g_bbH) {
            s.rtIdx = RtIndex(s.rt, s.rtW, s.rtH, d.Format);
            g_rt[s.rtIdx].order = g_bindOrder.fetch_add(1) + 1;
            s.isUi = s.rt == g_uiLayer.load(std::memory_order_relaxed) && !(s.ds && s.ds == g_sceneDepth.load());
        }
    }
    if (s.ds && s.ds == g_sceneDepth.load(std::memory_order_relaxed)) {   // any pass with the scene depth: the HUD comes after it
        uint32_t o = g_bindOrder.fetch_add(1) + 1, cur = g_sceneBindOrder.load(std::memory_order_relaxed);
        while (o > cur && !g_sceneBindOrder.compare_exchange_weak(cur, o)) {}
    }
    // foveated rendering: eye-size passes with a depth buffer, and in them only the solid geometry (see the PSO flags)
    s.vrsTarget = s.rt && s.ds && !s.isFinal && g_set.fovMode != "off" &&
                  ((s.rtW == g_vrsW[0].load(std::memory_order_relaxed) && s.rtH == g_vrsH[0].load(std::memory_order_relaxed) && g_vrsImg[0][2].load(std::memory_order_relaxed)) ||
                   (s.rtW == g_vrsW[1].load(std::memory_order_relaxed) && s.rtH == g_vrsH[1].load(std::memory_order_relaxed) && g_vrsImg[1][2].load(std::memory_order_relaxed)));
    VrsApply(l, s);
}
void STDMETHODCALLTYPE H_ClearRt(ID3D12GraphicsCommandList* l, D3D12_CPU_DESCRIPTOR_HANDLE h, const FLOAT* c, UINT n, const D3D12_RECT* r) {
    // true stereo: the second eye may clear the back buffer before binding it
    int ph = EngineNativePhase();
    if (ph >= 0) {
        ID3D12Resource* res = Lookup(g_rtv, h.ptr);
        if (res && IsBackBuffer(res)) {
            if (ph == 0) g_bbTouch0Frame = g_frame.load();
            else if (LS(l).direct && g_eye0Frame.load(std::memory_order_relaxed) != g_frame.load(std::memory_order_relaxed)) CopyEye0(l, res);   // RENDER_TARGET state (required by the clear)
        }
    }
    o_clearRt(l, h, c, n, r);
}
void STDMETHODCALLTYPE H_CopyRes(ID3D12GraphicsCommandList* l, ID3D12Resource* dst, ID3D12Resource* src) {
    o_copyRes(l, dst, src);
    if (dst && src && EngineNativePhase() >= 0 && IsBackBuffer(dst)) {
        D3D12_TEXTURE_COPY_LOCATION sl{}; sl.pResource = src; sl.Type = D3D12_TEXTURE_COPY_TYPE_SUBRESOURCE_INDEX; sl.SubresourceIndex = 0;
        BackBufferCopied(l, sl);
    }
}
void STDMETHODCALLTYPE H_CopyTex(ID3D12GraphicsCommandList* l, const D3D12_TEXTURE_COPY_LOCATION* dst, UINT x, UINT y, UINT z, const D3D12_TEXTURE_COPY_LOCATION* src, const D3D12_BOX* box) {
    o_copyTex(l, dst, x, y, z, src, box);
    if (dst && src && EngineNativePhase() >= 0 && dst->Type == D3D12_TEXTURE_COPY_TYPE_SUBRESOURCE_INDEX && dst->SubresourceIndex == 0 && IsBackBuffer(dst->pResource) &&
        !x && !y && !box && src->Type == D3D12_TEXTURE_COPY_TYPE_SUBRESOURCE_INDEX)
        BackBufferCopied(l, *src);
}
void STDMETHODCALLTYPE H_Draw(ID3D12GraphicsCommandList* l, UINT a, UINT b, UINT c, UINT d) {
    bool sc; if (!BeforeDraw(l, &sc)) return;
    o_draw(l, a, b, c, d);
    if (sc) RestoreVp(LS(l));
}
void STDMETHODCALLTYPE H_DrawIdx(ID3D12GraphicsCommandList* l, UINT a, UINT b, UINT c, INT d, UINT e) {
    bool sc; if (!BeforeDraw(l, &sc)) return;
    o_drawIdx(l, a, b, c, d, e);
    if (sc) RestoreVp(LS(l));
}
void STDMETHODCALLTYPE H_ExecInd(ID3D12GraphicsCommandList* l, ID3D12CommandSignature* sig, UINT n, ID3D12Resource* a, UINT64 ao, ID3D12Resource* c, UINT64 co) {
    ListState& s = LS(l); if (s.dsIdx >= 0) g_depth[s.dsIdx].draws.fetch_add(n ? n : 1, std::memory_order_relaxed);
    o_execInd(l, sig, n, a, ao, c, co);
}
void STDMETHODCALLTYPE H_Barrier(ID3D12GraphicsCommandList* l, UINT n, const D3D12_RESOURCE_BARRIER* b) {
    // true stereo: the second eye's first touch of the back buffer may be a barrier - copy the first eye before it
    // (whole-resource, non-split transitions only)
    if (b && EngineNativePhase() == 0)
        for (UINT i = 0; i < n; i++) if (b[i].Type == D3D12_RESOURCE_BARRIER_TYPE_TRANSITION && IsBackBuffer(b[i].Transition.pResource)) { g_bbTouch0Frame = g_frame.load(); break; }
    if (b && EngineNativePhase() == 1 && g_eye0Frame.load(std::memory_order_relaxed) != g_frame.load(std::memory_order_relaxed))
        for (UINT i = 0; i < n; i++)
            if (b[i].Type == D3D12_RESOURCE_BARRIER_TYPE_TRANSITION && b[i].Flags == D3D12_RESOURCE_BARRIER_FLAG_NONE && IsBackBuffer(b[i].Transition.pResource) &&
                b[i].Transition.Subresource == D3D12_RESOURCE_BARRIER_ALL_SUBRESOURCES) {
                if (LS(l).direct) { s_bbBinds1++; CopyEye0(l, b[i].Transition.pResource, b[i].Transition.StateBefore); }
                break;
            }
    o_barrier(l, n, b);
    ID3D12Resource* sd = g_sceneDepth.load(std::memory_order_relaxed);
    if (!sd || !b || g_depthFrame.load(std::memory_order_relaxed) == g_frame.load(std::memory_order_relaxed)) return;
    for (UINT i = 0; i < n; i++)
        if (b[i].Type == D3D12_RESOURCE_BARRIER_TYPE_TRANSITION && b[i].Transition.pResource == sd &&
            (b[i].Transition.StateBefore & D3D12_RESOURCE_STATE_DEPTH_WRITE) && !(b[i].Transition.StateAfter & D3D12_RESOURCE_STATE_DEPTH_WRITE)) {
            ListState& s = LS(l);
            if (s.direct) { CopyDepth(l, sd, b[i].Transition.StateAfter); s_depthAtBarrier++; }
            break;
        }
}

using ExecFn = void(STDMETHODCALLTYPE*)(ID3D12CommandQueue*, UINT, ID3D12CommandList* const*);
ExecFn o_exec = nullptr;
void STDMETHODCALLTYPE H_Exec(ID3D12CommandQueue* q, UINT n, ID3D12CommandList* const* lists) {
    int ph = EngineNativePhase();
    if (ph == 0) s_exec0 += n; else if (ph == 1) s_exec1 += n;
    o_exec(q, n, lists);
}
bool Hook(void** vt, int slot, void* det, void** orig, const char* name) {
    if (MH_CreateHook(vt[slot], det, orig) == MH_OK && MH_EnableHook(vt[slot]) == MH_OK) return true;
    LOGE("d3d12: hooking %s failed", name); return false;
}
} // namespace

static bool D3DHooksInstallLocked();
// The game thread (factory hook) and the init thread can both get here first. Re-entry on the same thread happens when
// the mod is dxgi.dll: creating the throw-away D3D12 device makes d3d12.dll call CreateDXGIFactory - the mod's own
// export - whose factory hook calls this again (it must return, not wait for its own lock).
static thread_local bool t_installing = false;
bool D3DHooksInstall() {
    if (t_installing) return g_installed;
    static SRWLOCK lock = SRWLOCK_INIT;
    t_installing = true;
    AcquireSRWLockExclusive(&lock);
    bool ok = D3DHooksInstallLocked();
    ReleaseSRWLockExclusive(&lock);
    t_installing = false;
    return ok;
}
static bool D3DHooksInstallLocked() {
    if (g_installed) return true;
    HMODULE d3d12 = LoadLibraryW(L"d3d12.dll");
    auto create = d3d12 ? (PFN_D3D12_CREATE_DEVICE)GetProcAddress(d3d12, "D3D12CreateDevice") : nullptr;
    if (!create) { LOGE("d3d12: D3D12CreateDevice not found"); return false; }
    ID3D12Device* dev = nullptr; ID3D12CommandAllocator* alloc = nullptr; ID3D12GraphicsCommandList* list = nullptr;
    if (FAILED(create(nullptr, D3D_FEATURE_LEVEL_11_0, __uuidof(ID3D12Device), (void**)&dev)) || !dev) { LOGE("d3d12: dummy device failed"); return false; }
    dev->CreateCommandAllocator(D3D12_COMMAND_LIST_TYPE_DIRECT, __uuidof(ID3D12CommandAllocator), (void**)&alloc);
    if (alloc) dev->CreateCommandList(0, D3D12_COMMAND_LIST_TYPE_DIRECT, alloc, nullptr, __uuidof(ID3D12GraphicsCommandList), (void**)&list);
    if (!list) { LOGE("d3d12: dummy command list failed"); SafeRelease(alloc); SafeRelease(dev); return false; }
    void** dv = *(void***)dev; void** lv = *(void***)list;
    int ok = 0;
    ok += Hook(dv, DEV_CreateRenderTargetView, (void*)&H_CreateRtv, (void**)&o_createRtv, "CreateRenderTargetView");
    ok += Hook(dv, DEV_CreateDepthStencilView, (void*)&H_CreateDsv, (void**)&o_createDsv, "CreateDepthStencilView");
    ok += Hook(dv, DEV_CopyDescriptorsSimple, (void*)&H_CopySimple, (void**)&o_copySimple, "CopyDescriptorsSimple");
    ok += Hook(dv, DEV_CreateGraphicsPipelineState, (void*)&H_CreatePso, (void**)&o_createPso, "CreateGraphicsPipelineState");
    ok += Hook(lv, CL_Reset, (void*)&H_Reset, (void**)&o_reset, "Reset");
    ok += Hook(lv, CL_DrawInstanced, (void*)&H_Draw, (void**)&o_draw, "DrawInstanced");
    ok += Hook(lv, CL_DrawIndexedInstanced, (void*)&H_DrawIdx, (void**)&o_drawIdx, "DrawIndexedInstanced");
    ok += Hook(lv, CL_RSSetViewports, (void*)&H_Vp, (void**)&o_vp, "RSSetViewports");
    ok += Hook(lv, CL_RSSetScissorRects, (void*)&H_Sc, (void**)&o_sc, "RSSetScissorRects");
    ok += Hook(lv, CL_SetPipelineState, (void*)&H_Pso, (void**)&o_pso, "SetPipelineState");
    ok += Hook(lv, CL_ResourceBarrier, (void*)&H_Barrier, (void**)&o_barrier, "ResourceBarrier");
    ok += Hook(lv, CL_OMSetRenderTargets, (void*)&H_Om, (void**)&o_om, "OMSetRenderTargets");
    ok += Hook(lv, CL_ExecuteIndirect, (void*)&H_ExecInd, (void**)&o_execInd, "ExecuteIndirect");
    ok += Hook(lv, CL_ClearRenderTargetView, (void*)&H_ClearRt, (void**)&o_clearRt, "ClearRenderTargetView");
    ok += Hook(lv, CL_CopyResource, (void*)&H_CopyRes, (void**)&o_copyRes, "CopyResource");
    ok += Hook(lv, CL_CopyTextureRegion, (void*)&H_CopyTex, (void**)&o_copyTex, "CopyTextureRegion");
    {   // command queue: counting only (true stereo diagnostics); optional - not counted in the 16
        D3D12_COMMAND_QUEUE_DESC qd{}; qd.Type = D3D12_COMMAND_LIST_TYPE_DIRECT; ID3D12CommandQueue* q = nullptr;
        if (SUCCEEDED(dev->CreateCommandQueue(&qd, __uuidof(ID3D12CommandQueue), (void**)&q)) && q) {
            if (!Hook(*(void***)q, 10, (void*)&H_Exec, (void**)&o_exec, "ExecuteCommandLists")) o_exec = nullptr;
            q->Release();
        }
    }
    list->Close(); SafeRelease(list); SafeRelease(alloc); SafeRelease(dev);
    g_installed = ok == 16;
    LOGI("d3d12: %d of 16 device / command list hooks installed (before the game's device)", ok);
    return g_installed;
}

void D3DHooksSetTargets(const CaptureTargets& t) { AcquireSRWLockExclusive(&g_tgtLock); g_tgt = t; ReleaseSRWLockExclusive(&g_tgtLock); }

FrameCapture D3DHooksOnPresent(IDXGISwapChain3* sc, ID3D12Device* dev) {
    g_dev = dev;
    FrameCapture fc;
    LONG f = g_frame.load();
    fc.slot = (int)(f % 3);
    fc.noUi = g_noUiFrame.load() == f; fc.depth = g_depthFrame.load() == f; fc.eye0 = g_eye0Frame.load() == f;
    fc.finalDraws = g_finalDraws.exchange(0); fc.uiDraws = g_uiDraws.exchange(0); fc.uiScaled = g_uiScaled.exchange(0);
    // back buffers (for "the final image")
    DXGI_SWAP_CHAIN_DESC d{}; sc->GetDesc(&d);
    g_bbW = d.BufferDesc.Width; g_bbH = d.BufferDesc.Height; g_bbFmt = d.BufferDesc.Format;
    for (UINT i = 0; i < 4; i++) {
        ID3D12Resource* r = nullptr;
        if (i < d.BufferCount && SUCCEEDED(sc->GetBuffer(i, __uuidof(ID3D12Resource), (void**)&r)) && r) { g_bb[i] = r; r->Release(); }
        else g_bb[i] = nullptr;
    }
    // scene depth = the depth buffer of the back buffer's size and shape with the most draws this frame (a shadow map
    // such as 8192x4096 can have more draws - it must never win); changes only after 30 frames in a row
    int best = -1; uint32_t bestDraws = 0;
    for (int i = 0; i < kDepth; i++) {
        uint32_t n = g_depth[i].draws.exchange(0); g_depth[i].last = n;
        UINT dw = g_depth[i].w, dh = g_depth[i].h;
        bool shape = dw && dh && g_bbW && g_bbH && fabsf((float)dw / dh - (float)g_bbW / g_bbH) < 0.02f * g_bbW / g_bbH &&
                     dw * 3 >= g_bbW && dw <= g_bbW * 2;   // (an upscaler renders the scene smaller: down to 1/3)
        if (g_depth[i].res.load() && shape && n > bestDraws) { best = i; bestDraws = n; }
    }
    ID3D12Resource* sd = best >= 0 ? g_depth[best].res.load() : nullptr;
    static ID3D12Resource* cand = nullptr; static int candRun = 0;
    if (sd != g_sceneDepth.load()) {
        candRun = sd == cand ? candRun + 1 : 1; cand = sd;
        if (candRun >= 30 || !g_sceneDepth.load()) {
            g_sceneDepth = sd; candRun = 0;
            if (sd) { g_sdW = g_depth[best].w; g_sdH = g_depth[best].h; g_sdFmt = g_depth[best].fmt; SafeRelease(g_depthBuf);
                      LOGI("ui: scene depth -> %ux%u fmt %d (%u draws)", g_sdW, g_sdH, (int)g_sdFmt, bestDraws); }
        }
    } else candRun = 0;
    sd = g_sceneDepth.load();
    fc.sceneDepth = sd; fc.sceneDepthW = g_sdW; fc.sceneDepthH = g_sdH; fc.sceneDepthFmt = g_sdFmt;
    // UI layer candidates: full screen, UI format, never drawn with the scene depth; picked by ui_pick, else the
    // one bound last (only when ui_layers = one / all, and only when nothing is drawn into the final image after the 3D)
    for (auto& c : g_rt) { uint32_t n = c.draws.exchange(0); c.last = n; c.draws2d = 0; c.unseen = n ? 0 : c.unseen + 1; uint32_t w = c.withScene.exchange(0); if (w) c.last = 0; }
    ID3D12Resource* pick = nullptr;
    if (g_set.uiPick > 0) {
        int k = 0;
        for (auto& c : g_rt) if (c.res.load() && c.unseen < 75 && ++k == g_set.uiPick) pick = c.res.load();
    } else if (fc.finalDraws <= 1) {
        // the HUD layer: at least 2 draws, bound after the last pass with the scene depth (after the 3D picture) and never
        // drawn with it - an effect buffer (shadow mask, AO, glow) must never be taken and shrunk as the HUD
        uint32_t bestOrder = 0, scene = g_sceneBindOrder.exchange(0);
        for (auto& c : g_rt) if (c.res.load() && c.last >= 2 && c.order > scene && c.order > bestOrder) { bestOrder = c.order; pick = c.res.load(); }
        // a confirmed layer (picked 24 frames in a row) is kept at any draw count while it is drawn after the 3D scene:
        // with only subtitles on screen it has 1 draw, and dropping it put the subtitles into each eye at the same
        // screen spot (wrong depth) - framework fix (subtitles)
        static ID3D12Resource* confirmed = nullptr; static ID3D12Resource* lastPick = nullptr; static int streak = 0;
        if (!pick && confirmed)
            for (auto& c : g_rt) if (c.res.load() == confirmed && c.last >= 1 && c.order > scene) { pick = confirmed; break; }
        if (pick && pick == lastPick) { if (++streak == 24 && confirmed != pick) { confirmed = pick; LOGI("ui: HUD layer confirmed (24 frames) - kept at any draw count after the 3D scene"); } }
        else streak = pick ? 1 : 0;
        lastPick = pick;
        if (confirmed) { bool seen = false; for (auto& c : g_rt) if (c.res.load() == confirmed && c.unseen < 75) seen = true; if (!seen) confirmed = nullptr; }
    }
    g_uiLayer = pick;
    g_frame.fetch_add(1);
    return fc;
}

// one R8_UINT shading-rate image for one size and one eye variant
//   unseen: only where this eye never looks (outside its shown part of the picture, + 3 %) - 4x4; the rest full rate.
//   quality / balanced / performance / custom: that, plus two zones around the lens axis (no dithering: the dithered
//   border of 0.10.18 showed as a faint pattern over the picture). Radii in half picture heights, wider by fov_wide.
//   Presets keep full rate out to ~40 / 35 / 29 degrees above / below the lens axis, where the Dream Air-class lenses
//   are already soft. fov_debug: the coarsest rate in both zones, to see where they are.
static void VrsBuild(int slot, int var, ID3D12Device* dev, ID3D12GraphicsCommandList* list, UINT w, UINT h, const VrsRect& rect) {
    LONG f = g_frame.load();
    auto drop = [&] { if (g_vrsImg[slot][var].load()) { g_vrsRetire.push_back(g_vrsImg[slot][var].exchange(nullptr)); g_vrsRetireAt.push_back(f); } };
    if (g_set.fovMode == "off" || !g_vrsTier2 || !w || !h) { drop(); if (var == 2) { g_vrsW[slot] = 0; g_vrsH[slot] = 0; } return; }
    float in = g_set.fovInner, out = g_set.fovOuter;
    if (g_set.fovMode == "quality") { in = 0.85f; out = 1.25f; } else if (g_set.fovMode == "balanced") { in = 0.70f; out = 1.05f; }
    else if (g_set.fovMode == "performance") { in = 0.55f; out = 0.85f; } else if (g_set.fovMode == "unseen") { in = out = 1e9f; }
    VrsKey k{ g_set.fovMode, in, out, g_set.fovWide, g_set.fovDebug, w, h, rect };
    const VrsKey& o = g_vrsKey[slot][var];
    bool same = g_vrsImg[slot][var].load() && k.mode == o.mode && k.in == o.in && k.out == o.out && k.wide == o.wide && k.dbg == o.dbg && k.w == o.w && k.h == o.h && k.r == o.r;
    if (same || rc::TickMs() - g_vrsBuilt[slot][var] < 1000) return;
    UINT tw = (w + g_vrsTile - 1) / g_vrsTile, th = (h + g_vrsTile - 1) / g_vrsTile;
    D3D12_HEAP_PROPERTIES hp{}; hp.Type = D3D12_HEAP_TYPE_DEFAULT;
    D3D12_RESOURCE_DESC td{}; td.Dimension = D3D12_RESOURCE_DIMENSION_TEXTURE2D; td.Width = tw; td.Height = th; td.DepthOrArraySize = 1; td.MipLevels = 1;
    td.Format = DXGI_FORMAT_R8_UINT; td.SampleDesc.Count = 1;
    ID3D12Resource* img = nullptr;
    if (FAILED(dev->CreateCommittedResource(&hp, D3D12_HEAP_FLAG_NONE, &td, D3D12_RESOURCE_STATE_COPY_DEST, nullptr, __uuidof(ID3D12Resource), (void**)&img))) return;
    D3D12_PLACED_SUBRESOURCE_FOOTPRINT fp; UINT rows; UINT64 rs, total;
    dev->GetCopyableFootprints(&td, 0, 1, 0, &fp, &rows, &rs, &total);
    ID3D12Resource*& upl = g_vrsUpload[slot][var];
    if (upl) { g_vrsRetire.push_back(upl); g_vrsRetireAt.push_back(f); upl = nullptr; }
    D3D12_HEAP_PROPERTIES up{}; up.Type = D3D12_HEAP_TYPE_UPLOAD;
    D3D12_RESOURCE_DESC bd{}; bd.Dimension = D3D12_RESOURCE_DIMENSION_BUFFER; bd.Width = total; bd.Height = 1; bd.DepthOrArraySize = 1; bd.MipLevels = 1; bd.SampleDesc.Count = 1; bd.Layout = D3D12_TEXTURE_LAYOUT_ROW_MAJOR;
    if (FAILED(dev->CreateCommittedResource(&up, D3D12_HEAP_FLAG_NONE, &bd, D3D12_RESOURCE_STATE_GENERIC_READ, nullptr, __uuidof(ID3D12Resource), (void**)&upl))) { img->Release(); return; }
    uint8_t* p = nullptr; upl->Map(0, nullptr, (void**)&p);
    UINT8 mid = g_set.fovMode == "quality" || g_set.fovMode == "custom" ? D3D12_SHADING_RATE_2X1 : D3D12_SHADING_RATE_2X2;
    UINT8 outer = g_set.fovMode == "quality" ? D3D12_SHADING_RATE_2X2 : g_set.fovMode == "balanced" || g_set.fovMode == "custom" ? D3D12_SHADING_RATE_4X2 : D3D12_SHADING_RATE_4X4;
    if (g_set.fovDebug) mid = outer = D3D12_SHADING_RATE_4X4;
    float cx = rect.cx * 0.001f * tw, cy = rect.cy * 0.001f * th;
    UINT seen = 0;
    for (UINT y = 0; y < th; y++) for (UINT x = 0; x < tw; x++) {
        float fx = (x + 0.5f) / tw * 1000.f, fy = (y + 0.5f) / th * 1000.f;
        UINT8 rate;
        if (fx < rect.x0 || fx > rect.x1 || fy < rect.y0 || fy > rect.y1) rate = D3D12_SHADING_RATE_4X4;   // never shown to this eye
        else {
            float dx = (x + 0.5f - cx) / (th * 0.5f * g_set.fovWide), dy = (y + 0.5f - cy) / (th * 0.5f), rr = sqrtf(dx * dx + dy * dy);
            rate = rr < in ? D3D12_SHADING_RATE_1X1 : rr < out ? mid : outer; seen++;
        }
        p[y * fp.Footprint.RowPitch + x] = rate;
    }
    upl->Unmap(0, nullptr);
    D3D12_TEXTURE_COPY_LOCATION sl{}, dd{};
    sl.pResource = upl; sl.Type = D3D12_TEXTURE_COPY_TYPE_PLACED_FOOTPRINT; sl.PlacedFootprint = fp;
    dd.pResource = img; dd.Type = D3D12_TEXTURE_COPY_TYPE_SUBRESOURCE_INDEX;
    list->CopyTextureRegion(&dd, 0, 0, 0, &sl, nullptr);
    Transition(list, img, D3D12_RESOURCE_STATE_COPY_DEST, D3D12_RESOURCE_STATE_SHADING_RATE_SOURCE);
    ID3D12Resource* old = g_vrsImg[slot][var].exchange(img);
    if (var == 2) { g_vrsW[slot] = w; g_vrsH[slot] = h; }
    if (old) { g_vrsRetire.push_back(old); g_vrsRetireAt.push_back(f); }
    g_vrsKey[slot][var] = k; g_vrsBuilt[slot][var] = rc::TickMs();
    static const char* kVar[] = { "left eye", "right eye", "both eyes" };
    LOGI("foveated: %s image for %ux%u%s, %s: %ux%u tiles, %u %% shown (x %.2f-%.2f, y %.2f-%.2f, lens %.2f %.2f) (inner %.2f, outer %.2f, wide %.2f%s)",
         g_set.fovMode.c_str(), w, h, slot ? " (the upscaler's render size)" : "", kVar[var], tw, th, seen * 100 / (tw * th),
         rect.x0 * 0.001f, rect.x1 * 0.001f, rect.y0 * 0.001f, rect.y1 * 0.001f, rect.cx * 0.001f, rect.cy * 0.001f,
         in > 1e8f ? 0.f : in, out > 1e8f ? 0.f : out, g_set.fovWide, g_set.fovDebug ? ", debug" : "");
}
static void VrsBuildSize(int slot, ID3D12Device* dev, ID3D12GraphicsCommandList* list, UINT w, UINT h) {
    if (!g_vrsChecked) {
        g_vrsChecked = true;
        D3D12_FEATURE_DATA_D3D12_OPTIONS6 o6{};
        if (SUCCEEDED(dev->CheckFeatureSupport(D3D12_FEATURE_D3D12_OPTIONS6, &o6, sizeof o6))) { g_vrsTier2 = o6.VariableShadingRateTier >= D3D12_VARIABLE_SHADING_RATE_TIER_2; g_vrsTile = o6.ShadingRateImageTileSize ? o6.ShadingRateImageTileSize : 16; }
        LOGI("foveated: variable rate shading tier %s, tile %u px", g_vrsTier2 ? "2 (available)" : "< 2 (not available)", g_vrsTile);
    }
    VrsBuild(slot, 2, dev, list, w, h, VrsRect{});
    for (int e = 0; e < 2; e++) {
        uint64_t v = g_vrsEyeRect[e].load(std::memory_order_relaxed);
        if (v) VrsBuild(slot, e, dev, list, g_vrsW[slot] ? w : 0, h, UnpackRect(v));
        else if (g_vrsImg[slot][e].load()) VrsBuild(slot, e, dev, list, 0, 0, VrsRect{});
    }
}

void D3DHooksVrsUpdate(ID3D12Device* dev, ID3D12GraphicsCommandList* list, UINT w, UINT h) {
    LONG f = g_frame.load();
    for (size_t i = 0; i < g_vrsRetire.size();) { if (f - g_vrsRetireAt[i] > 8) { g_vrsRetire[i]->Release(); g_vrsRetire.erase(g_vrsRetire.begin() + i); g_vrsRetireAt.erase(g_vrsRetireAt.begin() + i); } else i++; }
    VrsBuildSize(0, dev, list, w, h);
    // the scene's render size (= the scene depth's) when an upscaler draws the 3D smaller than the output
    UINT sw = g_sceneDepth.load() ? g_sdW : 0, sh = g_sceneDepth.load() ? g_sdH : 0;
    if (sw == w && sh == h) sw = sh = 0;
    VrsBuildSize(1, dev, list, sw, sh);
}

int D3DHooksUiCandidates() { int n = 0; for (auto& c : g_rt) if (c.res.load() && c.unseen < 75) n++; return n; }

void D3DHooksReport() {
    char line[1200]; int n = 0, k = 0;
    for (auto& c : g_rt) if (c.res.load() && c.unseen < 75 && n < 1100)
        n += snprintf(line + n, sizeof line - n, " [%d: %ux%u fmt %d, draws %u, order %u%s]", ++k, c.w, c.h, (int)c.fmt, c.last, c.order.load(), c.res.load() == g_uiLayer.load() ? ", IN USE" : "");
    LOGI("ui: %s | full-screen layers (bind order):%s", g_uiLayer.load() ? "UI layer in use" : "UI drawn into the final image", n ? line : " none");
    LOGI("ui: draws into the final image: 3D + UI %u, UI %u (moved onto the eye %u, hidden %u) | pipelines %u (2D %u)",
         g_finalDraws.load(), g_uiDraws.load(), g_uiScaled.load(), g_uiHidden.load(), s_psoTotal.load(), s_pso2d.load());
    LOGI("capture: depth copies at barrier %u, at first UI draw %u, pictures before UI %u | foveated binds %u",
         s_depthAtBarrier.load(), s_depthAtUi.load(), s_noUiCopies.load(), s_vrsBinds.load());
    if (EngineEffectiveMode() == VRMODE_NATIVE || s_bbBinds0.load() || s_bbBinds1.load() || s_bbCopies0.load())
        LOGI("true stereo: back buffer while the first eye renders: binds %u, copies into it %u | second eye: binds %u, copies %u | first eye captured %u, skipped (first eye never reached the back buffer) %u | other threads %u | lists submitted during eye 0 %u, eye 1 %u",
             s_bbBinds0.load(), s_bbCopies0.load(), s_bbBinds1.load(), s_bbCopies1.load(), s_eye0Copies.load(), s_eye0Skipped.load(), s_bbOtherThread.load(), s_exec0.load(), s_exec1.load());
    s_depthAtBarrier = s_depthAtUi = s_noUiCopies = s_vrsBinds = 0; g_uiHidden = 0; s_bbBinds0 = s_bbBinds1 = s_eye0Copies = 0; s_bbCopies0 = s_bbCopies1 = s_eye0Skipped = 0; s_bbOtherThread = s_exec0 = s_exec1 = 0;
}
bool D3DHooksUiSeen() { return g_uiSeen.load(); }
