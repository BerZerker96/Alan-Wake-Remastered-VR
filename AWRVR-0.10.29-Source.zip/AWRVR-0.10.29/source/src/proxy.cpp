// Proxy loader (x64). The game statically imports both dxgi.dll (CreateDXGIFactory) and dbghelp.dll
// (MiniDumpWriteDump), so the Windows loader takes either from the game folder before the game's code runs.
// The one DLL exports both sets: named dxgi.dll (default) it forwards the DXGI exports to the real dxgi.dll
// (System32, or dxgi_chain.dll in the game folder to chain e.g. ReShade); named dbghelp.dll it forwards the
// dbghelp exports to System32. CreateDXGIFactory / 1 / 2 are the mod's own (dxgi_hooks.cpp). Exports the real
// DLL lacks return 0. Any other name (.asi): nothing is forwarded.
#include <windows.h>
#include <string>
#include <cwctype>

static const int kProxyCount = 85;
static const char* const kProxyNames[kProxyCount] = {
    "MiniDumpWriteDump", "MiniDumpReadDumpStream", "SymInitialize", "SymInitializeW", "SymCleanup", "SymSetOptions",
    "SymGetOptions", "SymFromAddr", "SymFromAddrW", "SymFromName", "SymFromNameW", "SymGetSymFromAddr64",
    "SymGetLineFromAddr64", "SymGetLineFromAddrW64", "SymGetModuleBase64", "SymGetModuleInfo64", "SymGetModuleInfoW64", "SymFunctionTableAccess64",
    "SymLoadModule64", "SymLoadModuleEx", "SymLoadModuleExW", "SymUnloadModule64", "SymRefreshModuleList", "SymGetSearchPath",
    "SymGetSearchPathW", "SymSetSearchPath", "SymSetSearchPathW", "SymEnumSymbols", "SymEnumSymbolsW", "SymEnumerateModules64",
    "SymEnumerateModulesW64", "SymGetTypeInfo", "SymSetContext", "SymRegisterCallback64", "SymRegisterCallbackW64", "SymFindFileInPath",
    "SymFindFileInPathW", "SymSrvGetFileIndexInfoW", "SymGetHomeDirectory", "SymFromInlineContext", "SymFromInlineContextW", "SymGetLineFromInlineContext",
    "SymGetLineFromInlineContextW", "SymAddrIncludeInlineTrace", "SymQueryInlineTrace", "StackWalk64", "StackWalkEx", "UnDecorateSymbolName",
    "UnDecorateSymbolNameW", "ImageNtHeader", "ImageDirectoryEntryToData", "ImageDirectoryEntryToDataEx", "ImageRvaToVa", "EnumerateLoadedModules64",
    "EnumerateLoadedModulesW64", "EnumerateLoadedModulesEx", "EnumerateLoadedModulesExW", "MakeSureDirectoryPathExists", "SearchTreeForFile", "SearchTreeForFileW",
    "ImagehlpApiVersion", "ImagehlpApiVersionEx", "SymGetSymNext64", "SymGetSymPrev64", "SymMatchString", "SymSearch",
    "SymSearchW", "SymGetModuleBase", "SymFunctionTableAccess", "StackWalk", "SymGetSymFromAddr", "SymGetLineFromAddr",
    "SymGetModuleInfo", "SymLoadModule", "SymSetScopeFromAddr", "SymGetScope", "SymEnumTypes", "SymGetTypeFromName",
    "SymSetExtendedOption", "SymGetExtendedOption", "SymSetParentWindow", "SymNext", "SymPrev", "SymFromIndex",
    "SymGetSourceFile",
};

// dxgi.dll exports other than CreateDXGIFactory* (Windows 10 / 11 list; missing ones return 0)
static const int kDxCount = 17;
static const char* const kDxNames[kDxCount] = {
    "ApplyCompatResolutionQuirking", "CompatString", "CompatValue", "DXGID3D10CreateDevice", "DXGID3D10CreateLayeredDevice",
    "DXGID3D10GetLayeredDeviceSize", "DXGID3D10RegisterLayers", "DXGIDeclareAdapterRemovalSupport", "DXGIDisableVBlankVirtualization",
    "DXGIDumpJournal", "DXGIGetDebugInterface1", "DXGIReportAdapterConfiguration", "PIXBeginCapture", "PIXEndCapture",
    "PIXGetCaptureState", "SetAppCompatStringPointer", "UpdateHMDEmulationStatus",
};

extern "C" { FARPROC g_px[kProxyCount] = {}; FARPROC g_dx[kDxCount] = {}; }
extern "C" __int64 ProxyMissing() { return 0; }

std::wstring g_proxyName;    // lower-case file name we were loaded as
std::wstring g_chainName;    // the real dxgi in use (for the log)
static HMODULE g_realDxgi = nullptr;
static HMODULE g_self = nullptr;

static std::wstring SysPath(const wchar_t* dll) { wchar_t sys[MAX_PATH]; GetSystemDirectoryW(sys, MAX_PATH); return std::wstring(sys) + L"\\" + dll; }

// Loaded as dxgi.dll: dxgi_chain.dll next to us if present (another dxgi mod), else System32. Otherwise: System32
// (only the mod's own factories use it then). Never this module itself.
HMODULE RealDxgi() {
    if (g_realDxgi) return g_realDxgi;
    if (g_proxyName == L"dxgi.dll") {
        wchar_t me[MAX_PATH]; GetModuleFileNameW(g_self, me, MAX_PATH);
        std::wstring dir = me; dir = dir.substr(0, dir.find_last_of(L'\\'));
        std::wstring chain = dir + L"\\dxgi_chain.dll";
        if (GetFileAttributesW(chain.c_str()) != INVALID_FILE_ATTRIBUTES) {
            HMODULE m = LoadLibraryW(chain.c_str());
            if (m && m != g_self) { g_realDxgi = m; g_chainName = chain; return m; }
        }
    }
    std::wstring sys = SysPath(L"dxgi.dll");
    HMODULE m = LoadLibraryW(sys.c_str());
    if (m == g_self) m = nullptr;
    g_realDxgi = m; g_chainName = sys;
    return m;
}
FARPROC RealDxgiProc(const char* name) { HMODULE m = RealDxgi(); return m ? GetProcAddress(m, name) : nullptr; }

void ProxyLoad(HMODULE self) {
    g_self = self;
    wchar_t me[MAX_PATH]; GetModuleFileNameW(self, me, MAX_PATH);
    std::wstring n = me; n = n.substr(n.find_last_of(L'\\') + 1);
    for (auto& c : n) c = (wchar_t)towlower(c);
    g_proxyName = n;
    HMODULE help = n == L"dbghelp.dll" ? LoadLibraryW(SysPath(L"dbghelp.dll").c_str()) : nullptr;
    for (int i = 0; i < kProxyCount; i++) {
        FARPROC p = help ? GetProcAddress(help, kProxyNames[i]) : nullptr;
        g_px[i] = p ? p : (FARPROC)&ProxyMissing;
    }
    HMODULE dx = n == L"dxgi.dll" ? RealDxgi() : nullptr;
    for (int i = 0; i < kDxCount; i++) {
        FARPROC p = dx ? GetProcAddress(dx, kDxNames[i]) : nullptr;
        g_dx[i] = p ? p : (FARPROC)&ProxyMissing;
    }
}

// x64 stubs: jmp through the table (rip-relative).
#define PX(i) asm(".text\n.globl Proxy_" #i "\nProxy_" #i ":\n\tjmp *g_px+" #i "*8(%rip)\n");
PX(0)
PX(1)
PX(2)
PX(3)
PX(4)
PX(5)
PX(6)
PX(7)
PX(8)
PX(9)
PX(10)
PX(11)
PX(12)
PX(13)
PX(14)
PX(15)
PX(16)
PX(17)
PX(18)
PX(19)
PX(20)
PX(21)
PX(22)
PX(23)
PX(24)
PX(25)
PX(26)
PX(27)
PX(28)
PX(29)
PX(30)
PX(31)
PX(32)
PX(33)
PX(34)
PX(35)
PX(36)
PX(37)
PX(38)
PX(39)
PX(40)
PX(41)
PX(42)
PX(43)
PX(44)
PX(45)
PX(46)
PX(47)
PX(48)
PX(49)
PX(50)
PX(51)
PX(52)
PX(53)
PX(54)
PX(55)
PX(56)
PX(57)
PX(58)
PX(59)
PX(60)
PX(61)
PX(62)
PX(63)
PX(64)
PX(65)
PX(66)
PX(67)
PX(68)
PX(69)
PX(70)
PX(71)
PX(72)
PX(73)
PX(74)
PX(75)
PX(76)
PX(77)
PX(78)
PX(79)
PX(80)
PX(81)
PX(82)
PX(83)
PX(84)

// dxgi stubs
#define DX(i) asm(".text\n.globl DxProxy_" #i "\nDxProxy_" #i ":\n\tjmp *g_dx+" #i "*8(%rip)\n");
DX(0)
DX(1)
DX(2)
DX(3)
DX(4)
DX(5)
DX(6)
DX(7)
DX(8)
DX(9)
DX(10)
DX(11)
DX(12)
DX(13)
DX(14)
DX(15)
DX(16)
