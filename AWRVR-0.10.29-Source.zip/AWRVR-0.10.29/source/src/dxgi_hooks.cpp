// DXGI hooks: the game's factory -> its swap chain (D3D12: the "device" argument is the command queue) -> Present.
// The factory is caught in the mod's own CreateDXGIFactory / 1 / 2 exports (loaded as dxgi.dll: the game's import
// binds to them), through the exe's import table (loaded as dbghelp.dll / .asi: patched before the game's code runs),
// and as a fallback by hooking the methods of a factory of our own.
#include <windows.h>
#include <dxgi1_4.h>
#include <d3d12.h>
#include "log.h"
#include "scan.h"
#include "MinHook.h"
#include "settings.h"
#include "d3d12hooks.h"
#include "dxgireal.h"
#include <string>
#include <dxgi1_3.h>

bool CompositorOnPresent(IDXGISwapChain* sc);         // compositor.cpp
void CompositorOnResize(IDXGISwapChain* sc);
void CompositorSetQueue(ID3D12CommandQueue* q, IDXGISwapChain* sc);
bool CompositorIsGameSwap(IDXGISwapChain* sc);

void ResolutionKeepWindow(HWND w, unsigned bufW, unsigned bufH);   // resolution.cpp
namespace {
using CreateFactoryFn = HRESULT(WINAPI*)(REFIID, void**);
using CreateFactory2Fn = HRESULT(WINAPI*)(UINT, REFIID, void**);
CreateFactoryFn o_CDF = nullptr, o_CDF1 = nullptr;
CreateFactory2Fn o_CDF2 = nullptr;

using CreateSCFn = HRESULT(STDMETHODCALLTYPE*)(IDXGIFactory*, IUnknown*, DXGI_SWAP_CHAIN_DESC*, IDXGISwapChain**);
using CreateSCHwndFn = HRESULT(STDMETHODCALLTYPE*)(IDXGIFactory2*, IUnknown*, HWND, const DXGI_SWAP_CHAIN_DESC1*,
                                                   const DXGI_SWAP_CHAIN_FULLSCREEN_DESC*, IDXGIOutput*, IDXGISwapChain1**);
using PresentFn = HRESULT(STDMETHODCALLTYPE*)(IDXGISwapChain*, UINT, UINT);
using Present1Fn = HRESULT(STDMETHODCALLTYPE*)(IDXGISwapChain1*, UINT, UINT, const DXGI_PRESENT_PARAMETERS*);
using ResizeFn = HRESULT(STDMETHODCALLTYPE*)(IDXGISwapChain*, UINT, UINT, UINT, DXGI_FORMAT, UINT);
using FullFn = HRESULT(STDMETHODCALLTYPE*)(IDXGISwapChain*, BOOL, IDXGIOutput*);
using MwaFn = HRESULT(STDMETHODCALLTYPE*)(IDXGIFactory*, HWND, UINT);
using Resize1Fn = HRESULT(STDMETHODCALLTYPE*)(IDXGISwapChain3*, UINT, UINT, UINT, DXGI_FORMAT, UINT, const UINT*, IUnknown* const*);
using ColorSpaceFn = HRESULT(STDMETHODCALLTYPE*)(IDXGISwapChain3*, DXGI_COLOR_SPACE_TYPE);
ColorSpaceFn o_colorSpace = nullptr;
CreateSCFn o_createSC = nullptr;
CreateSCHwndFn o_createSCHwnd = nullptr;
PresentFn o_present = nullptr;
Present1Fn o_present1 = nullptr;
ResizeFn o_resize = nullptr;
Resize1Fn o_resize1 = nullptr;
FullFn o_full = nullptr;
MwaFn o_mwa = nullptr;
UINT g_swapFlags = 0; bool g_latencySet = false;
int g_outColorSpace = 0;   // 0 SDR, 1 scRGB, 2 PQ
bool g_factoryHooked = false, g_swapHooked = false;
thread_local int t_inPresent = 0;
volatile LONG g_presentCalls = 0;

void PresentOptions(IDXGISwapChain* sc, UINT* sync, UINT* flags) {
    if (!CompositorIsGameSwap(sc)) return;
    if (g_set.vsyncOff) { *sync = 0; if (g_swapFlags & DXGI_SWAP_CHAIN_FLAG_ALLOW_TEARING) *flags |= DXGI_PRESENT_ALLOW_TEARING; }
    if (!g_latencySet) {
        g_latencySet = true;
        IDXGISwapChain2* s2 = nullptr;
        if (g_set.maxFrameLatency > 0 && (g_swapFlags & DXGI_SWAP_CHAIN_FLAG_FRAME_LATENCY_WAITABLE_OBJECT) && SUCCEEDED(sc->QueryInterface(__uuidof(IDXGISwapChain2), (void**)&s2)) && s2) {
            HRESULT hr = s2->SetMaximumFrameLatency((UINT)g_set.maxFrameLatency); s2->Release();
            LOGI("dxgi: frames queued ahead %d (%08lx)", g_set.maxFrameLatency, hr);
        } else LOGI("dxgi: frames queued ahead: the game's own (its swap chain does not allow setting it)");
    }
}
HRESULT STDMETHODCALLTYPE H_Present(IDXGISwapChain* sc, UINT sync, UINT flags) {
    if (!t_inPresent && !(flags & DXGI_PRESENT_TEST)) { t_inPresent++; CompositorOnPresent(sc); InterlockedIncrement(&g_presentCalls); t_inPresent--; PresentOptions(sc, &sync, &flags); }
    t_inPresent++;
    HRESULT hr = o_present(sc, sync, flags);
    t_inPresent--;
    return hr;
}
HRESULT STDMETHODCALLTYPE H_Present1(IDXGISwapChain1* sc, UINT sync, UINT flags, const DXGI_PRESENT_PARAMETERS* p) {
    if (!t_inPresent && !(flags & DXGI_PRESENT_TEST)) { t_inPresent++; CompositorOnPresent(sc); InterlockedIncrement(&g_presentCalls); t_inPresent--; PresentOptions(sc, &sync, &flags); }
    t_inPresent++;
    HRESULT hr = o_present1(sc, sync, flags, p);
    t_inPresent--;
    return hr;
}
HRESULT STDMETHODCALLTYPE H_Resize(IDXGISwapChain* sc, UINT n, UINT w, UINT h, DXGI_FORMAT f, UINT fl) {
    CompositorOnResize(sc);
    HRESULT hr = o_resize(sc, n, w, h, f, fl);
    LOGI("dxgi: ResizeBuffers %ux%u fmt %d -> %08lx", w, h, (int)f, hr);
    return hr;
}
HRESULT STDMETHODCALLTYPE H_Resize1(IDXGISwapChain3* sc, UINT n, UINT w, UINT h, DXGI_FORMAT f, UINT fl, const UINT* m, IUnknown* const* q) {
    CompositorOnResize(sc);
    HRESULT hr = o_resize1(sc, n, w, h, f, fl, m, q);
    LOGI("dxgi: ResizeBuffers1 %ux%u fmt %d -> %08lx", w, h, (int)f, hr);
    return hr;
}

// 1.33 renders SDR into a 10-bit back buffer too: only the colour space says whether the output is HDR
HRESULT STDMETHODCALLTYPE H_ColorSpace(IDXGISwapChain3* sc, DXGI_COLOR_SPACE_TYPE cs) {
    HRESULT hr = o_colorSpace(sc, cs);
    if (SUCCEEDED(hr)) {
        int k = cs == DXGI_COLOR_SPACE_RGB_FULL_G2084_NONE_P2020 ? 2 : cs == DXGI_COLOR_SPACE_RGB_FULL_G10_NONE_P709 ? 1 : 0;
        if (k != g_outColorSpace) LOGI("dxgi: game output colour space %d -> %s", (int)cs, k == 2 ? "HDR10 (PQ)" : k == 1 ? "scRGB (linear)" : "SDR");
        g_outColorSpace = k;
    }
    return hr;
}
HRESULT STDMETHODCALLTYPE H_Full(IDXGISwapChain* sc, BOOL full, IDXGIOutput* o) {
    if (full && g_set.forceWindowed) { LOGI("dxgi: exclusive fullscreen refused (force_windowed)"); return S_OK; }
    return o_full(sc, full, o);
}
HRESULT STDMETHODCALLTYPE H_Mwa(IDXGIFactory* f, HWND w, UINT fl) {
    if (g_set.forceWindowed) fl |= DXGI_MWA_NO_ALT_ENTER;
    return o_mwa(f, w, fl);
}
void HookVt(void** vt, int slot, void* det, void** orig, const char* name) {
    if (*orig) return;
    if (MH_CreateHook(vt[slot], det, orig) == MH_OK && MH_EnableHook(vt[slot]) == MH_OK) LOGI("dxgi: hooked %s", name);
    else { LOGE("dxgi: hooking %s failed", name); *orig = nullptr; }
}

void OnSwapChain(IUnknown* dev, IDXGISwapChain* sc) {
    if (!sc) return;
    ID3D12CommandQueue* q = nullptr;
    if (!dev || FAILED(dev->QueryInterface(__uuidof(ID3D12CommandQueue), (void**)&q)) || !q) {
        LOGW("dxgi: swap chain %p was not created on a D3D12 queue - ignored", sc);
        return;
    }
    DXGI_SWAP_CHAIN_DESC d{}; sc->GetDesc(&d);
    LOGI("dxgi: swap chain %p on D3D12 queue %p: %ux%u fmt %d, %u buffers, swap effect %d, flags %x", sc, q, d.BufferDesc.Width,
         d.BufferDesc.Height, (int)d.BufferDesc.Format, d.BufferCount, (int)d.SwapEffect, d.Flags);
    g_swapFlags = d.Flags;
    CompositorSetQueue(q, sc);
    q->Release();
    if (!g_swapHooked) {
        g_swapHooked = true;
        void** vt = *(void***)sc;
        HookVt(vt, 8, (void*)&H_Present, (void**)&o_present, "IDXGISwapChain::Present");
        HookVt(vt, 13, (void*)&H_Resize, (void**)&o_resize, "IDXGISwapChain::ResizeBuffers");
        HookVt(vt, 10, (void*)&H_Full, (void**)&o_full, "IDXGISwapChain::SetFullscreenState");
        IDXGISwapChain1* s1 = nullptr;
        if (SUCCEEDED(sc->QueryInterface(__uuidof(IDXGISwapChain1), (void**)&s1)) && s1) {
            HookVt(*(void***)s1, 22, (void*)&H_Present1, (void**)&o_present1, "IDXGISwapChain1::Present1"); s1->Release();
        }
        IDXGISwapChain3* s3 = nullptr;
        if (SUCCEEDED(sc->QueryInterface(__uuidof(IDXGISwapChain3), (void**)&s3)) && s3) {
            HookVt(*(void***)s3, 39, (void*)&H_Resize1, (void**)&o_resize1, "IDXGISwapChain3::ResizeBuffers1");
            HookVt(*(void***)s3, 38, (void*)&H_ColorSpace, (void**)&o_colorSpace, "IDXGISwapChain3::SetColorSpace1"); s3->Release();
        }
    }
}

HRESULT STDMETHODCALLTYPE H_CreateSC(IDXGIFactory* f, IUnknown* dev, DXGI_SWAP_CHAIN_DESC* d, IDXGISwapChain** out) {
    HRESULT hr = o_createSC(f, dev, d, out);
    if (SUCCEEDED(hr) && out) OnSwapChain(dev, *out);
    return hr;
}
HRESULT STDMETHODCALLTYPE H_CreateSCHwnd(IDXGIFactory2* f, IUnknown* dev, HWND w, const DXGI_SWAP_CHAIN_DESC1* d,
                                         const DXGI_SWAP_CHAIN_FULLSCREEN_DESC* fs, IDXGIOutput* o, IDXGISwapChain1** out) {
    HRESULT hr = o_createSCHwnd(f, dev, w, d, fs, o, out);
    if (SUCCEEDED(hr) && out) OnSwapChain(dev, *out);
    if (SUCCEEDED(hr) && d) ResolutionKeepWindow(w, d->Width, d->Height);
    return hr;
}

void HookFactory(void* p) {
    if (g_factoryHooked || !p) return;
    IDXGIFactory2* f2 = nullptr;
    IUnknown* u = (IUnknown*)p;
    if (FAILED(u->QueryInterface(__uuidof(IDXGIFactory2), (void**)&f2)) || !f2) { LOGW("dxgi: factory without IDXGIFactory2"); return; }
    g_factoryHooked = true;
    void** vt = *(void***)f2;
    HookVt(vt, 10, (void*)&H_CreateSC, (void**)&o_createSC, "IDXGIFactory::CreateSwapChain");
    HookVt(vt, 15, (void*)&H_CreateSCHwnd, (void**)&o_createSCHwnd, "IDXGIFactory2::CreateSwapChainForHwnd");
    HookVt(vt, 8, (void*)&H_Mwa, (void**)&o_mwa, "IDXGIFactory::MakeWindowAssociation");
    D3DHooksInstall();   // before the game creates its device (it asks the factory for an adapter first)
    f2->Release();
}

HRESULT WINAPI H_CDF(REFIID r, void** pp) { HRESULT hr = o_CDF(r, pp); if (SUCCEEDED(hr) && pp) HookFactory(*pp); return hr; }
HRESULT WINAPI H_CDF1(REFIID r, void** pp) { HRESULT hr = o_CDF1(r, pp); if (SUCCEEDED(hr) && pp) HookFactory(*pp); return hr; }
HRESULT WINAPI H_CDF2(UINT fl, REFIID r, void** pp) { HRESULT hr = o_CDF2(fl, r, pp); if (SUCCEEDED(hr) && pp) HookFactory(*pp); return hr; }
} // namespace

extern std::wstring g_proxyName, g_chainName;
int DxgiOutputColorSpace() { return g_outColorSpace; }

// ---------------------------------------------------------------- the mod's own dxgi exports (exports.def)
static bool g_loggedReal = false;
static void LogReal() { if (!g_loggedReal) { g_loggedReal = true; LOGI("dxgi: real dxgi.dll = %ls", g_chainName.c_str()); } }
extern "C" HRESULT WINAPI AwrvrCreateDXGIFactory(REFIID r, void** pp) {
    static auto f = (CreateFactoryFn)RealDxgiProc("CreateDXGIFactory");
    if (!f) return E_NOINTERFACE;
    HRESULT hr = f(r, pp); LogReal();
    if (SUCCEEDED(hr) && pp) HookFactory(*pp);
    return hr;
}
extern "C" HRESULT WINAPI AwrvrCreateDXGIFactory1(REFIID r, void** pp) {
    static auto f = (CreateFactoryFn)RealDxgiProc("CreateDXGIFactory1");
    if (!f) return E_NOINTERFACE;
    HRESULT hr = f(r, pp); LogReal();
    if (SUCCEEDED(hr) && pp) HookFactory(*pp);
    return hr;
}
extern "C" HRESULT WINAPI AwrvrCreateDXGIFactory2(UINT fl, REFIID r, void** pp) {
    static auto f = (CreateFactory2Fn)RealDxgiProc("CreateDXGIFactory2");
    if (!f) return E_NOINTERFACE;
    HRESULT hr = f(fl, r, pp); LogReal();
    if (SUCCEEDED(hr) && pp) HookFactory(*pp);
    return hr;
}
HRESULT RealCreateDXGIFactory1(REFIID r, void** pp) {
    static auto f = (CreateFactoryFn)RealDxgiProc("CreateDXGIFactory1");
    return f ? f(r, pp) : E_NOINTERFACE;
}

// While the proxy loads (DllMain): patch the exe's imports. Only memory writes, safe under the loader lock.
void DxgiPatchImports() {
    if (!g_exe.base) ScanInit();
    if (g_proxyName == L"dxgi.dll") { LOGI("dxgi: loaded as dxgi.dll - the game's CreateDXGIFactory import is the mod's own"); return; }
    void* p;
    if ((p = PatchImport("dxgi.dll", "CreateDXGIFactory", (void*)&H_CDF))) { o_CDF = (CreateFactoryFn)p; LOGI("dxgi: exe import CreateDXGIFactory patched"); }
    if ((p = PatchImport("dxgi.dll", "CreateDXGIFactory1", (void*)&H_CDF1))) { o_CDF1 = (CreateFactoryFn)p; LOGI("dxgi: exe import CreateDXGIFactory1 patched"); }
    if ((p = PatchImport("dxgi.dll", "CreateDXGIFactory2", (void*)&H_CDF2))) { o_CDF2 = (CreateFactory2Fn)p; LOGI("dxgi: exe import CreateDXGIFactory2 patched"); }
}

// Init thread: a factory of our own gives the vtables if the imports were not patched (dynamic loading, ASI loader
// started late). Hooking the factory's methods catches the game's swap chain whenever it is created.
void DxgiInstallFallback() {
    if (g_factoryHooked) return;
    IDXGIFactory2* f = nullptr;
    if (SUCCEEDED(RealCreateDXGIFactory1(__uuidof(IDXGIFactory2), (void**)&f)) && f) {
        LOGI("dxgi: imports not used yet - hooking the factory methods directly");
        HookFactory(f);
        f->Release();
    }
}

LONG DxgiPresentCount() { return g_presentCalls; }
