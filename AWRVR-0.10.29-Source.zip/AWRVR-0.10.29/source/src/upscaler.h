#pragma once
#include <cstdint>
// Upscalers (the game's DLSS / DLAA, OptiScaler's FSR / XeSS behind it, any other one) and frame generation.
void UpscalerInstall();
bool UpscalerActive();
int DlssMode();                                // the game's DLSS setting: -1 unknown, 0 off, 1..4 Ultra Performance..Quality, 5 DLAA                         // a temporal upscaler evaluated in the last 2 s
void UpscalerReport();
const char* UpscalerStatus();                  // short text for the panel status ("" when none)
bool FrameGenerationSuspected();
