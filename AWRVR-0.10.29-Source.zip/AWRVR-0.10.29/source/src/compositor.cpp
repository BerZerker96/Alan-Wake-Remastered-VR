// Compositor: at every game Present, take the picture (D3D12 back buffer, plus the picture before the UI and the
// scene depth captured by d3d12hooks), make the eye images for the stereo method in use, draw the panels, and submit
// to the XrBridge host (in-process OpenXR thread, or XrBridgeHost.exe) through keyed-mutex atlases.
// Atlas per slot: left eye (0,0,E) | right eye (Ew,0,E) on the top row, HUD / flat screen / menu (0,Eh, W x H).
#include <windows.h>
#include <d3d11_4.h>
#include <d3d12.h>
#include <dxgi1_4.h>
#include <d3dcompiler.h>
#include <cmath>
#include <string>
#include <vector>
#include <thread>
#include <mmsystem.h>
#include "log.h"
#include "config.h"
#include "engine.h"
#include "headaim.h"
#include "upscaler.h"
#include "game.h"
#include "settings.h"
#include "dxgireal.h"
int DxgiOutputColorSpace();   // dxgi_hooks.cpp: 0 SDR, 1 scRGB, 2 PQ
#include "version.h"
#include "d3d12hooks.h"
#include "refresh.h"
#include "shaders.h"
#include "vrmath.h"
#include "xrbridge/client.h"
#include "realclock.h"

extern std::wstring g_gameDir, g_modDir;
void ResolutionSaveHeadset(unsigned w, unsigned h, const char* system, double hz);
bool ResolutionHeadsetRefresh(const char* system, double* hz);
void ResolutionPoll();
ID3D11Texture2D* MenuUpdate(ID3D11Device* dev, ID3D11DeviceContext* ctx);
void MenuNoteFps(float fps);
#include "hotkeys.h"
bool PngWrite(const std::wstring& path, const uint8_t* rgba, unsigned w, unsigned h, unsigned pitch);
bool XrHostStartThread(const char* name, const std::wstring& logPath);
void FlatToggleState(bool* flat);

unsigned ResolutionWantedW(); unsigned ResolutionWantedH(); bool ResolutionClampLifted();   // resolution.cpp
void ScratchPadReport();   // scratchpad.cpp
void DiagSetAdapter(IDXGIAdapter1* a); void DiagReport(); void DiagNoteRate(double rawHz, double knownHz); void DiagNoteFps(float fps); void DiagNoteRenderSize(unsigned w, unsigned h);   // diag.cpp
bool ResolutionPixelScale(double* sx, double* sy);   // resolution.cpp
namespace {
template <class T> void SafeRelease(T*& p) { if (p) { p->Release(); p = nullptr; } }

// ---------------------------------------------------------------- game side (D3D12)
ID3D12CommandQueue* g_queue = nullptr; ID3D12Device* g_dev12 = nullptr; IDXGISwapChain* g_swap = nullptr;
constexpr int kAlloc = 4;
ID3D12CommandAllocator* g_alloc[kAlloc] = {}; UINT64 g_allocDone[kAlloc] = {};
ID3D12GraphicsCommandList* g_list = nullptr;
ID3D12Fence* g_fenceLocal = nullptr; UINT64 g_localVal = 0; HANDLE g_evt = nullptr; int g_allocIdx = 0;

// ---------------------------------------------------------------- ours (D3D11)
ID3D11Device* g_dev = nullptr; ID3D11DeviceContext* g_ctx = nullptr; ID3D11Device5* g_dev5 = nullptr; ID3D11DeviceContext4* g_ctx4 = nullptr;
ID3D11VertexShader* g_vs = nullptr; ID3D11PixelShader *g_psCrop = nullptr, *g_psUi = nullptr;
ID3D11Buffer *g_cb = nullptr;
ID3D11SamplerState* g_smp = nullptr; ID3D11BlendState* g_blendPremul = nullptr; ID3D11RasterizerState* g_rs = nullptr;
bool g_gpuSync = false;
ID3D12Fence* g_f12 = nullptr; ID3D11Fence* g_f12in11 = nullptr; UINT64 g_v12 = 0;
ID3D11Fence* g_f11 = nullptr; ID3D12Fence* g_f11in12 = nullptr; UINT64 g_v11 = 0;
ID3D11Query* g_query = nullptr;

struct Shared { ID3D11Texture2D* t11 = nullptr; ID3D11ShaderResourceView* srv = nullptr; ID3D11RenderTargetView* rtv = nullptr; ID3D12Resource* t12 = nullptr; };
Shared g_inter[3], g_noUi[3], g_mirror;
Shared g_eye0[3];                 // true stereo: the first eye's picture (made only when that mode is used)
bool g_eye0Failed = false;
int g_interIdx = 0;
UINT g_w = 0, g_h = 0; DXGI_FORMAT g_bbFmt = DXGI_FORMAT_UNKNOWN; bool g_floatSrc = false;

struct Rt { ID3D11Texture2D* t = nullptr; ID3D11RenderTargetView* rtv = nullptr; ID3D11ShaderResourceView* srv = nullptr; ID3D11UnorderedAccessView* uav = nullptr; };
Rt g_eye[2], g_flat, g_hud;
UINT g_ew = 0, g_eh = 0;                         // eye image size
bool g_haveEye[2] = {}; xrb::IpcPose g_eyePose[2] = {}; xrb::IpcFov g_eyeFovSent[2] = {}; int64_t g_eyeTime[2] = {}; uint32_t g_eyeTick[2] = {};
float g_eyeAng[3] = {};

struct Slot { ID3D11Texture2D* tex = nullptr; IDXGIKeyedMutex* mx = nullptr; ID3D11RenderTargetView* rtv = nullptr; };
Slot g_slots[xrb::kSlots]; int g_nextSlot = 0;
UINT g_atlasW = 0, g_atlasH = 0;
ID3D11Texture2D* g_menuSeen = nullptr; ID3D11ShaderResourceView* g_menuSrv = nullptr;
ID3D11Texture2D* g_shotStage = nullptr; int g_shotWait = -1; UINT g_shotW = 0, g_shotH = 0;

bool g_init = false, g_initFailed = false, g_xrInit = false;
RefreshTracker g_refresh; double g_capHz = 90;
LARGE_INTEGER g_qpf; double g_nextDeadline = 0; bool g_timerRes = false;
unsigned s_submitted = 0, s_busy = 0, s_noHost = 0, s_captured = 0, s_stereo = 0, s_head = 0, s_flat = 0, s_pairWait = 0, s_limited = 0, s_native = 0;
double s_workMs = 0, s_workMax = 0, s_waitMs = 0, s_frameMax = 0, g_lastPresentT = 0;
DWORD g_lastReport = 0, g_fpsTick = 0; unsigned g_fpsCount = 0;
unsigned g_recW = 0, g_recH = 0;

double Now() { LARGE_INTEGER t; rc::Qpc(&t); return double(t.QuadPart) / double(g_qpf.QuadPart); }

DXGI_FORMAT Typeless(DXGI_FORMAT f, DXGI_FORMAT* view, bool* isFloat) {
    *isFloat = false;
    switch (f) {
    case DXGI_FORMAT_R8G8B8A8_UNORM: case DXGI_FORMAT_R8G8B8A8_UNORM_SRGB: case DXGI_FORMAT_R8G8B8A8_TYPELESS: *view = DXGI_FORMAT_R8G8B8A8_UNORM; return DXGI_FORMAT_R8G8B8A8_TYPELESS;
    case DXGI_FORMAT_B8G8R8A8_UNORM: case DXGI_FORMAT_B8G8R8A8_UNORM_SRGB: case DXGI_FORMAT_B8G8R8A8_TYPELESS: *view = DXGI_FORMAT_B8G8R8A8_UNORM; return DXGI_FORMAT_B8G8R8A8_TYPELESS;
    case DXGI_FORMAT_R10G10B10A2_UNORM: case DXGI_FORMAT_R10G10B10A2_TYPELESS: *view = DXGI_FORMAT_R10G10B10A2_UNORM; return DXGI_FORMAT_R10G10B10A2_TYPELESS;
    case DXGI_FORMAT_R16G16B16A16_FLOAT: case DXGI_FORMAT_R16G16B16A16_TYPELESS: *view = DXGI_FORMAT_R16G16B16A16_FLOAT; *isFloat = true; return DXGI_FORMAT_R16G16B16A16_TYPELESS;
    default: *view = f; return f;
    }
}

bool CreateDevice11() {
    LUID luid = g_dev12->GetAdapterLuid();
    IDXGIFactory1* fac = nullptr; IDXGIAdapter1* ad = nullptr;
    if (SUCCEEDED(RealCreateDXGIFactory1(__uuidof(IDXGIFactory1), (void**)&fac))) {
        for (UINT i = 0; fac->EnumAdapters1(i, &ad) != DXGI_ERROR_NOT_FOUND; i++) {
            DXGI_ADAPTER_DESC1 d; ad->GetDesc1(&d);
            if (d.AdapterLuid.LowPart == luid.LowPart && d.AdapterLuid.HighPart == luid.HighPart) { LOGI("compositor: game GPU %ls (%llu MB)", d.Description, (unsigned long long)(d.DedicatedVideoMemory >> 20)); DiagSetAdapter(ad); break; }
            ad->Release(); ad = nullptr;
        }
        fac->Release();
    }
    D3D_FEATURE_LEVEL fl[] = { D3D_FEATURE_LEVEL_11_1, D3D_FEATURE_LEVEL_11_0 };
    HRESULT hr = D3D11CreateDevice(ad, ad ? D3D_DRIVER_TYPE_UNKNOWN : D3D_DRIVER_TYPE_HARDWARE, nullptr, D3D11_CREATE_DEVICE_BGRA_SUPPORT, fl, 2, D3D11_SDK_VERSION, &g_dev, nullptr, &g_ctx);
    if (ad) ad->Release();
    if (FAILED(hr)) { LOGE("compositor: D3D11CreateDevice failed %08lx", hr); return false; }
    g_dev->QueryInterface(__uuidof(ID3D11Device5), (void**)&g_dev5);
    g_ctx->QueryInterface(__uuidof(ID3D11DeviceContext4), (void**)&g_ctx4);
    return true;
}

ID3DBlob* Compile(const char* src, const char* entry, const char* target) {
    ID3DBlob *b = nullptr, *err = nullptr;
    if (FAILED(D3DCompile(src, strlen(src), "awrvr", nullptr, nullptr, entry, target, D3DCOMPILE_OPTIMIZATION_LEVEL3, 0, &b, &err))) {
        LOGE("compositor: shader %s failed: %s", entry, err ? (const char*)err->GetBufferPointer() : "?"); SafeRelease(err); return nullptr;
    }
    SafeRelease(err); return b;
}
bool CreateShaders() {
    ID3DBlob* b;
    if (!(b = Compile(kShaderGfx, "VS", "vs_5_0"))) return false; g_dev->CreateVertexShader(b->GetBufferPointer(), b->GetBufferSize(), nullptr, &g_vs); b->Release();
    if (!(b = Compile(kShaderGfx, "PSCrop", "ps_5_0"))) return false; g_dev->CreatePixelShader(b->GetBufferPointer(), b->GetBufferSize(), nullptr, &g_psCrop); b->Release();
    if (!(b = Compile(kShaderGfx, "PSUiSplit", "ps_5_0"))) return false; g_dev->CreatePixelShader(b->GetBufferPointer(), b->GetBufferSize(), nullptr, &g_psUi); b->Release();
    D3D11_BUFFER_DESC bd{}; bd.Usage = D3D11_USAGE_DYNAMIC; bd.BindFlags = D3D11_BIND_CONSTANT_BUFFER; bd.CPUAccessFlags = D3D11_CPU_ACCESS_WRITE;
    bd.ByteWidth = 80; g_dev->CreateBuffer(&bd, nullptr, &g_cb);
    D3D11_SAMPLER_DESC sd{}; sd.Filter = D3D11_FILTER_MIN_MAG_MIP_LINEAR; sd.AddressU = sd.AddressV = sd.AddressW = D3D11_TEXTURE_ADDRESS_CLAMP; sd.MaxLOD = D3D11_FLOAT32_MAX;
    g_dev->CreateSamplerState(&sd, &g_smp);
    D3D11_BLEND_DESC bl{}; auto& r = bl.RenderTarget[0];
    r.BlendEnable = TRUE; r.SrcBlend = D3D11_BLEND_ONE; r.DestBlend = D3D11_BLEND_INV_SRC_ALPHA; r.BlendOp = D3D11_BLEND_OP_ADD;
    r.SrcBlendAlpha = D3D11_BLEND_ONE; r.DestBlendAlpha = D3D11_BLEND_INV_SRC_ALPHA; r.BlendOpAlpha = D3D11_BLEND_OP_ADD; r.RenderTargetWriteMask = 0xF;
    g_dev->CreateBlendState(&bl, &g_blendPremul);
    D3D11_RASTERIZER_DESC rd{}; rd.FillMode = D3D11_FILL_SOLID; rd.CullMode = D3D11_CULL_NONE; rd.DepthClipEnable = TRUE;
    g_dev->CreateRasterizerState(&rd, &g_rs);
    return g_vs && g_psCrop && g_psUi && g_cb && g_smp && g_blendPremul && g_rs;
}

bool CreateSync() {
    if (g_dev5 && g_ctx4) {
        HANDLE h = nullptr;
        bool ok = SUCCEEDED(g_dev12->CreateFence(0, D3D12_FENCE_FLAG_SHARED, __uuidof(ID3D12Fence), (void**)&g_f12)) &&
                  SUCCEEDED(g_dev12->CreateSharedHandle(g_f12, nullptr, GENERIC_ALL, nullptr, &h)) && SUCCEEDED(g_dev5->OpenSharedFence(h, __uuidof(ID3D11Fence), (void**)&g_f12in11));
        if (h) { CloseHandle(h); h = nullptr; }
        ok = ok && SUCCEEDED(g_dev5->CreateFence(0, D3D11_FENCE_FLAG_SHARED, __uuidof(ID3D11Fence), (void**)&g_f11)) &&
             SUCCEEDED(g_f11->CreateSharedHandle(nullptr, GENERIC_ALL, nullptr, &h)) && SUCCEEDED(g_dev12->OpenSharedHandle(h, __uuidof(ID3D12Fence), (void**)&g_f11in12));
        if (h) CloseHandle(h);
        g_gpuSync = ok;
        if (!ok) { SafeRelease(g_f12); SafeRelease(g_f12in11); SafeRelease(g_f11); SafeRelease(g_f11in12); }
    }
    if (!g_gpuSync) { D3D11_QUERY_DESC qd{ D3D11_QUERY_EVENT, 0 }; g_dev->CreateQuery(&qd, &g_query); }
    LOGI("compositor: D3D12 -> D3D11 sync: %s", g_gpuSync ? "shared fences (GPU waits)" : "CPU waits (no ID3D11Device5)");
    return true;
}

bool CreateCapture12() {
    for (auto& a : g_alloc) if (FAILED(g_dev12->CreateCommandAllocator(D3D12_COMMAND_LIST_TYPE_DIRECT, __uuidof(ID3D12CommandAllocator), (void**)&a))) return false;
    if (FAILED(g_dev12->CreateCommandList(0, D3D12_COMMAND_LIST_TYPE_DIRECT, g_alloc[0], nullptr, __uuidof(ID3D12GraphicsCommandList), (void**)&g_list))) return false;
    g_list->Close();
    if (FAILED(g_dev12->CreateFence(0, D3D12_FENCE_FLAG_NONE, __uuidof(ID3D12Fence), (void**)&g_fenceLocal))) return false;
    g_evt = CreateEventW(nullptr, FALSE, FALSE, nullptr);
    return true;
}
void WaitLocal(UINT64 v) { if (g_fenceLocal && g_fenceLocal->GetCompletedValue() < v) { g_fenceLocal->SetEventOnCompletion(v, g_evt); WaitForSingleObject(g_evt, 2000); } }

// a D3D11 texture shared with D3D12 (NT handle)
bool MakeShared(Shared& s, UINT w, UINT h, DXGI_FORMAT fmt, DXGI_FORMAT view, bool rtv) {
    D3D11_TEXTURE2D_DESC d{}; d.Width = w; d.Height = h; d.MipLevels = 1; d.ArraySize = 1; d.Format = fmt; d.SampleDesc.Count = 1;
    d.Usage = D3D11_USAGE_DEFAULT; d.BindFlags = D3D11_BIND_SHADER_RESOURCE | (rtv ? D3D11_BIND_RENDER_TARGET : 0);
    d.MiscFlags = D3D11_RESOURCE_MISC_SHARED_NTHANDLE | D3D11_RESOURCE_MISC_SHARED;
    HRESULT hr = g_dev->CreateTexture2D(&d, nullptr, &s.t11);
    if (FAILED(hr) && fmt != view) { LOGW("compositor: shared typeless fmt %d refused - using %d", (int)fmt, (int)view); d.Format = view; hr = g_dev->CreateTexture2D(&d, nullptr, &s.t11); }
    if (FAILED(hr)) { LOGE("compositor: shared texture %ux%u fmt %d failed %08lx", w, h, (int)fmt, hr); return false; }
    D3D11_SHADER_RESOURCE_VIEW_DESC sv{}; sv.Format = view; sv.ViewDimension = D3D11_SRV_DIMENSION_TEXTURE2D; sv.Texture2D.MipLevels = 1;
    g_dev->CreateShaderResourceView(s.t11, &sv, &s.srv);
    if (rtv) { D3D11_RENDER_TARGET_VIEW_DESC rv{}; rv.Format = view; rv.ViewDimension = D3D11_RTV_DIMENSION_TEXTURE2D; g_dev->CreateRenderTargetView(s.t11, &rv, &s.rtv); }
    IDXGIResource1* r1 = nullptr; HANDLE sh = nullptr;
    if (SUCCEEDED(s.t11->QueryInterface(__uuidof(IDXGIResource1), (void**)&r1))) { r1->CreateSharedHandle(nullptr, DXGI_SHARED_RESOURCE_READ | DXGI_SHARED_RESOURCE_WRITE, nullptr, &sh); r1->Release(); }
    hr = sh ? g_dev12->OpenSharedHandle(sh, __uuidof(ID3D12Resource), (void**)&s.t12) : E_FAIL;
    if (sh) CloseHandle(sh);
    if (FAILED(hr) || !s.t12) { LOGE("compositor: opening a shared texture in D3D12 failed %08lx", hr); return false; }
    return true;
}
void FreeShared(Shared& s) { SafeRelease(s.rtv); SafeRelease(s.srv); SafeRelease(s.t11); SafeRelease(s.t12); }
// textures the game's own command lists write (first eye, picture without UI) are freed only 8 presents later: a list
// the game recorded with the old pointer (a render thread that read the targets just before they changed) may still
// be waiting to execute - freeing at once could make the GPU write freed memory (device removed)
struct Retired { Shared s; LONG at; };
std::vector<Retired> g_retired;
void Retire(Shared& s) { if (s.t11 || s.t12) g_retired.push_back({ s, EnginePresentCount() }); s = Shared{}; }
void RetireSweep(bool all) {
    LONG now = EnginePresentCount();
    for (size_t i = 0; i < g_retired.size();) {
        if (all || now - g_retired[i].at > 8) { FreeShared(g_retired[i].s); g_retired.erase(g_retired.begin() + i); } else i++;
    }
}
bool MakeRt(Rt& r, UINT w, UINT h, bool uav) {
    D3D11_TEXTURE2D_DESC d{}; d.Width = w; d.Height = h; d.MipLevels = 1; d.ArraySize = 1; d.Format = DXGI_FORMAT_R8G8B8A8_UNORM; d.SampleDesc.Count = 1;
    d.Usage = D3D11_USAGE_DEFAULT; d.BindFlags = D3D11_BIND_RENDER_TARGET | D3D11_BIND_SHADER_RESOURCE | (uav ? D3D11_BIND_UNORDERED_ACCESS : 0);
    if (FAILED(g_dev->CreateTexture2D(&d, nullptr, &r.t))) return false;
    g_dev->CreateRenderTargetView(r.t, nullptr, &r.rtv); g_dev->CreateShaderResourceView(r.t, nullptr, &r.srv);
    if (uav) g_dev->CreateUnorderedAccessView(r.t, nullptr, &r.uav);
    return r.rtv && r.srv;
}
void FreeRt(Rt& r) { SafeRelease(r.uav); SafeRelease(r.srv); SafeRelease(r.rtv); SafeRelease(r.t); }

void PublishTargets() {
    CaptureTargets t;
    for (int i = 0; i < 3; i++) { t.noUi[i] = g_noUi[i].t12; t.eye0[i] = g_eye0[i].t12; }
    int m = EngineEffectiveMode();
    t.wantNoUi = g_noUi[0].t12 && (m == VRMODE_NATIVE || g_set.hudMode == "panel");
    t.wantEye0 = g_eye0[0].t12 && m == VRMODE_NATIVE;
    t.wantDepth = false;   // (depth copies were for stereo reconstruction, removed)
    D3DHooksSetTargets(t);
}

void ReleaseSized() {
    if (g_fenceLocal) WaitLocal(g_localVal);
    D3DHooksSetTargets(CaptureTargets{});
    if (g_ctx) { g_ctx->ClearState(); g_ctx->Flush(); }
    for (int i = 0; i < 3; i++) { FreeShared(g_inter[i]); Retire(g_noUi[i]); Retire(g_eye0[i]); }
    g_eye0Failed = false;
    FreeShared(g_mirror);
    FreeRt(g_eye[0]); FreeRt(g_eye[1]); FreeRt(g_flat); FreeRt(g_hud);
    for (auto& s : g_slots) { SafeRelease(s.rtv); SafeRelease(s.mx); SafeRelease(s.tex); }
    SafeRelease(g_shotStage); g_shotWait = -1;
    g_haveEye[0] = g_haveEye[1] = false; g_w = g_h = 0;
}

// true stereo: the first eye's capture textures, back-buffer sized, made the first time the mode is used
bool EnsureEye0() {
    if (g_eye0[0].t12) return true;
    if (g_eye0Failed || !g_w) return false;
    DXGI_FORMAT view; bool isFloat; DXGI_FORMAT tl = Typeless(g_bbFmt, &view, &isFloat);
    for (int i = 0; i < 3; i++) if (!MakeShared(g_eye0[i], g_w, g_h, tl, view, false)) {
        for (auto& e : g_eye0) FreeShared(e);
        g_eye0Failed = true; LOGE("true stereo: first eye textures failed"); return false;
    }
    LOGI("true stereo: first eye capture textures %ux%u", g_w, g_h);
    return true;
}

// eye image size: the headset's recommended size x render scale (even), capped
void EyeSize(UINT* w, UINT* h) {
    UINT rw = g_recW ? g_recW : g_w, rh = g_recH ? g_recH : g_h;
    float s = g_set.renderScale < 0.3f ? 0.3f : g_set.renderScale > 1.5f ? 1.5f : g_set.renderScale;
    *w = ((UINT)(rw * s) + 1) & ~1u; *h = ((UINT)(rh * s) + 1) & ~1u;
    UINT mx = (UINT)(g_set.renderMaxSide > 512 ? g_set.renderMaxSide : 512);
    if (*w > mx) { *h = *h * mx / *w; *w = mx; } if (*h > mx) { *w = *w * mx / *h; *h = mx; }
}

bool EnsureSized(UINT w, UINT h, DXGI_FORMAT fmt) {
    UINT ew, eh;
    if (g_w == w && g_h == h && g_bbFmt == fmt && g_slots[0].tex) { EyeSize(&ew, &eh); if (ew == g_ew && eh == g_eh) return true; }
    ReleaseSized();
    g_w = w; g_h = h; g_bbFmt = fmt;
    DXGI_FORMAT view; bool isFloat; DXGI_FORMAT tl = Typeless(fmt, &view, &isFloat);
    g_floatSrc = isFloat;
    if (fmt == DXGI_FORMAT_R10G10B10A2_UNORM) LOGI("compositor: 10-bit back buffer (1.33 uses it for SDR too); HDR follows the game's colour space (hdr_input = %s)", g_set.hdrInput.c_str());
    for (int i = 0; i < 3; i++) if (!MakeShared(g_inter[i], w, h, tl, view, false) || !MakeShared(g_noUi[i], w, h, tl, view, false)) return false;
    if (!MakeShared(g_mirror, w, h, tl, view, true)) LOGW("compositor: mirror texture unavailable (monitor shows the game's frames)");
    EyeSize(&ew, &eh); g_ew = ew; g_eh = eh;
    if (!MakeRt(g_eye[0], ew, eh, true) || !MakeRt(g_eye[1], ew, eh, true) || !MakeRt(g_flat, w, h, false) || !MakeRt(g_hud, w, h, false)) { LOGE("compositor: eye textures failed"); return false; }
    g_atlasW = ew * 2 > w ? ew * 2 : w; g_atlasH = eh + h;
    D3D11_TEXTURE2D_DESC d{}; d.Width = g_atlasW; d.Height = g_atlasH; d.MipLevels = 1; d.ArraySize = 1; d.Format = DXGI_FORMAT_R8G8B8A8_UNORM;
    d.SampleDesc.Count = 1; d.BindFlags = D3D11_BIND_SHADER_RESOURCE | D3D11_BIND_RENDER_TARGET; d.MiscFlags = D3D11_RESOURCE_MISC_SHARED_KEYEDMUTEX;
    xrb::TextureSet ts; ts.atlasWidth = d.Width; ts.atlasHeight = d.Height; ts.dxgiFormat = d.Format; ts.sync = xrb::SYNC_KEYED_MUTEX;
    ts.eyeRect[0] = { 0, 0, (int)ew, (int)eh }; ts.eyeRect[1] = { (int)ew, 0, (int)ew, (int)eh }; ts.hudRect = { 0, (int)eh, (int)w, (int)h };
    for (int i = 0; i < xrb::kSlots; i++) {
        if (FAILED(g_dev->CreateTexture2D(&d, nullptr, &g_slots[i].tex))) { LOGE("compositor: atlas %ux%u failed", d.Width, d.Height); return false; }
        g_slots[i].tex->QueryInterface(__uuidof(IDXGIKeyedMutex), (void**)&g_slots[i].mx);
        g_dev->CreateRenderTargetView(g_slots[i].tex, nullptr, &g_slots[i].rtv);
        IDXGIResource* r = nullptr; HANDLE sh = nullptr;
        if (SUCCEEDED(g_slots[i].tex->QueryInterface(__uuidof(IDXGIResource), (void**)&r))) { r->GetSharedHandle(&sh); r->Release(); }
        ts.handles[i] = (uint64_t)(uintptr_t)sh;
    }
    xrb::ClientPublishTextures(ts);
    DiagNoteRenderSize(w, h);
    LOGI("resolution: game render size %ux%u (fmt %d), eye images %ux%u (headset recommends %ux%u x render scale %.2f), atlases %ux%u",
         w, h, (int)fmt, ew, eh, g_recW, g_recH, g_set.renderScale, g_atlasW, g_atlasH);
    { unsigned ww = ResolutionWantedW(), wh = ResolutionWantedH();
      if (ww && wh && (w != ww || h != wh))
          LOGW("resolution: the game renders %ux%u, not the %ux%u written to resolution.xml (%s) - the eye images are scaled from it and look softer",
               w, h, ww, wh, ResolutionClampLifted() ? "clamp lifted: the size came from elsewhere, please send this log" : "the game's monitor-size clamp is still on"); }
    PublishTargets();
    return true;
}

void InitXr() {
    g_xrInit = true;
    xrb::ClientSettings s;
    s.instanceName = "AWRVR"; s.appName = "Alan Wake Remastered VR";
    s.hostLogPath = g_modDir + L"\\xrhost.log";
    s.hostExePath = g_set.hostMode == "exe" ? g_gameDir + L"\\XrBridgeHost.exe" : L"";
    s.hudDistance = g_set.uiDepth; s.hudWidth = g_set.menuPanelWidth; s.hudOffsetY = g_set.uiOffsetY; s.hudFollowHead = true; s.hudPremultiplied = true;
    s.menuDistance = g_set.screenDistance; s.menuWidth = g_set.screenWidth;
    xrb::ClientInit(s);
    if (g_set.hostMode != "exe") {
        bool ok = XrHostStartThread("AWRVR", s.hostLogPath);
        LOGI("xr: OpenXR host %s inside the game (thread)", ok ? "started" : "FAILED to start");
    }
}


bool Init() {
    g_init = true;
    rc::Qpf(&g_qpf);
    if (!g_dev12 || !g_queue) { g_initFailed = true; return false; }
    if (!CreateDevice11() || !CreateShaders() || !CreateCapture12() || !CreateSync()) { g_initFailed = true; LOGE("compositor: init failed - no VR output"); return false; }
    if (g_set.xrOutput) { if (!g_xrInit) InitXr(); } else LOGW("xr: xr_output = false - no VR output (troubleshooting)");
    LOGI("compositor: ready");
    return true;
}

// ---------------------------------------------------------------- drawing helpers
struct CbGfx { float pic[4], win[4], opt[4], opt2[4], cant[4]; };
void Draw(ID3D11PixelShader* ps, ID3D11ShaderResourceView* a, ID3D11ShaderResourceView* b, ID3D11RenderTargetView* dst, float x, float y, float w, float h,
          const CbGfx& cb, bool blend) {
    D3D11_MAPPED_SUBRESOURCE m;
    if (SUCCEEDED(g_ctx->Map(g_cb, 0, D3D11_MAP_WRITE_DISCARD, 0, &m))) { memcpy(m.pData, &cb, sizeof cb); g_ctx->Unmap(g_cb, 0); }
    D3D11_VIEWPORT vp{ x, y, w, h, 0, 1 };
    g_ctx->OMSetRenderTargets(1, &dst, nullptr);
    g_ctx->OMSetBlendState(blend ? g_blendPremul : nullptr, nullptr, 0xFFFFFFFF);
    g_ctx->OMSetDepthStencilState(nullptr, 0); g_ctx->RSSetState(g_rs); g_ctx->RSSetViewports(1, &vp);
    g_ctx->IASetInputLayout(nullptr); g_ctx->IASetPrimitiveTopology(D3D11_PRIMITIVE_TOPOLOGY_TRIANGLELIST);
    g_ctx->VSSetShader(g_vs, nullptr, 0); g_ctx->PSSetShader(ps, nullptr, 0);
    g_ctx->PSSetConstantBuffers(0, 1, &g_cb); g_ctx->PSSetSamplers(0, 1, &g_smp);
    ID3D11ShaderResourceView* srv[2] = { a, b }; g_ctx->PSSetShaderResources(0, 2, srv);
    g_ctx->Draw(3, 0);
    ID3D11ShaderResourceView* nul[2] = {}; g_ctx->PSSetShaderResources(0, 2, nul);
}
// auto: the swap chain's colour space (SetColorSpace1), a float back buffer is scRGB; off: always SDR (a float buffer is
// still linear and converted)
float HdrMode() {
    if (g_set.hdrInput == "pq") return 2.f;
    if (g_set.hdrInput == "scrgb" || g_floatSrc) return 1.f;
    if (g_set.hdrInput == "auto") return (float)DxgiOutputColorSpace();
    return 0.f;
}
// comfort fade: every switch between 3D and the theater / flat screen fades in from black
float g_fade = 0; double g_fadeStart = -1; int g_lastView = -1;   // 0 3D, 1 flat, 2 theater
void UpdateFade(int view, double now) {
    if (view != g_lastView) { if (g_lastView >= 0 && g_set.theaterFade && (view == 2 || g_lastView == 2)) g_fadeStart = now; g_lastView = view; }
    const double T = 0.45;
    g_fade = g_fadeStart < 0 ? 0.f : (float)(1.0 - (now - g_fadeStart) / T);
    if (g_fade <= 0) { g_fade = 0; g_fadeStart = -1; }
}
// the flat screen's size: the theater for cutscenes and videos, else the normal virtual screen
float g_menuSentD = -1, g_menuSentW = -1;
void ScreenFor(bool theater) {
    float d = g_set.screenDistance, w = g_set.screenWidth;
    if (theater) {
        float a = g_set.theaterSize < 30 ? 30 : g_set.theaterSize > 170 ? 170 : g_set.theaterSize;
        d = g_set.theaterDistance < 1 ? 1 : g_set.theaterDistance;
        w = 2.f * d * tanf(a * 0.5f * 0.0174533f);
    }
    if (d != g_menuSentD || w != g_menuSentW) { xrb::ClientSetMenu(d, w); g_menuSentD = d; g_menuSentW = w; LOGI("xr: flat screen %s - %.1f m wide at %.1f m", theater ? "theater" : "normal", w, d); }
}
// the HUD panel: as wide as UI scale x one eye's view at UI depth (the same size the scaled HUD has)
float HudPanelWidth() {
    float span = 0; int n = 0;
    for (auto& f : g_eyeFovSent) { float sp = tanf(f.right) - tanf(f.left); if (sp > 0.2f && sp < 20.f) { span += sp; n++; } }
    span = n ? span / n : 2.f;
    float d = g_set.uiDepth > 0.1f ? g_set.uiDepth : 0.1f;
    return g_set.uiScale * span * d;
}
// the head-locked layer is shared by the HUD panel and this mod's menu: the menu (while open) at its own distance and
// width, else the HUD panel at UI depth
float g_hudSentD = -1, g_hudSentW = -1, g_hudSentY = -1;
void HudLayerFor(bool menuOpen) {
    float d = menuOpen ? g_set.menuDistance : g_set.uiDepth, w = menuOpen ? g_set.menuPanelWidth : HudPanelWidth();
    // UI height is a fraction of the view's height (as for the scaled HUD) -> metres at the panel's distance
    float vs = 0; int n = 0;
    for (auto& f : g_eyeFovSent) { float v = tanf(f.up) - tanf(f.down); if (v > 0.2f && v < 20.f) { vs += v; n++; } }
    float oy = menuOpen ? g_set.uiOffsetY : g_set.uiOffsetY * (n ? vs / n : 2.f) * d;
    if (fabsf(d - g_hudSentD) < 1e-3f && fabsf(w - g_hudSentW) < 1e-3f && fabsf(oy - g_hudSentY) < 1e-3f) return;
    xrb::ClientSetHud(d, w, oy, true); g_hudSentD = d; g_hudSentW = w; g_hudSentY = oy;
}
CbGfx Copy(bool alpha) { CbGfx c{}; c.opt[3] = g_set.hdrPaperWhite; c.opt2[0] = 1; c.opt2[1] = alpha ? 1.f : 0.f; return c; }

// the eye's window (its headset FOV x picture size options, + eye align) inside the drawn picture
CbGfx CropCb(const Tan4& pic, const xrb::IpcFov& fov, int eye, float alignH, float alignV, const float* picCant = nullptr) {
    CbGfx c{};
    c.pic[0] = pic.l; c.pic[1] = pic.r; c.pic[2] = pic.u; c.pic[3] = pic.d;
    c.cant[2] = g_set.viewWidth > 0.05f ? g_set.viewWidth : 1.f; c.cant[3] = g_set.viewHeight > 0.05f ? g_set.viewHeight : 1.f;
    if (picCant) { c.cant[0] = picCant[0]; c.cant[1] = picCant[1]; }
    { double sx, sy; if ((!picCant || (picCant[0] == 0.f && picCant[1] == 0.f)) && g_set.matchedView && ResolutionPixelScale(&sx, &sy)) c.opt2[2] = 1.f; }   // 1:1 copy
    float sh = tanf(alignH * 0.0174533f) * (eye == 0 ? -1.f : 1.f), sv = tanf(alignV * 0.0174533f) * (eye == 0 ? 1.f : -1.f);
    c.win[0] = tanf(fov.left) * g_set.viewWidth + sh; c.win[1] = tanf(fov.right) * g_set.viewWidth + sh;
    c.win[2] = tanf(fov.up) * g_set.viewHeight + sv; c.win[3] = tanf(fov.down) * g_set.viewHeight + sv;
    c.opt[0] = g_set.edgeFill ? 1.f : 0.f; c.opt[1] = g_set.sharpen; c.opt[2] = HdrMode(); c.opt[3] = g_set.hdrPaperWhite;
    c.opt2[3] = g_fade;
    return c;
}
void CropInto(ID3D11ShaderResourceView* src, Rt& dst, const FrameInfo& fi, int eye, float ah, float av) {
    CbGfx cb = CropCb(fi.pic, fi.eyeFov[eye], eye, ah, av, fi.picCant);
    Draw(g_psCrop, src, nullptr, dst.rtv, 0, 0, (float)g_ew, (float)g_eh, cb, false);
    // what the eye gets of the rendered picture: the shown part's share of the picture, so its pixel density against
    // the headset's (eye image = the headset's recommended size); logged when it changes
    static int lastKey = -1;
    if (fi.eye < 0 || fi.eye == eye) {
        float pw = cb.pic[1] - cb.pic[0], ph = cb.pic[2] - cb.pic[3], sw = cb.win[1] - cb.win[0], sv = cb.win[2] - cb.win[3];
        if (cb.cant[0] != 0.f || cb.cant[1] != 0.f) {   // canted: the window's span measured in the picture's frame
            float bl = 1e9f, br = -1e9f, bd = 1e9f, bu = -1e9f;
            for (int i = 0; i <= 16; i++) {
                float t = i / 16.f, x = cb.win[0] + (cb.win[1] - cb.win[0]) * t, y = cb.win[3] + (cb.win[2] - cb.win[3]) * t, qx, qy;
                const float pts[4][2] = { { x, cb.win[2] }, { x, cb.win[3] }, { cb.win[0], y }, { cb.win[1], y } };
                for (auto& pt : pts) { CantToPic(cb.cant, pt[0], pt[1], &qx, &qy); bl = fminf(bl, qx); br = fmaxf(br, qx); bd = fminf(bd, qy); bu = fmaxf(bu, qy); }
            }
            sw = br - bl; sv = bu - bd;
        }
        if (pw > 0.1f && ph > 0.1f && sw > 0.1f && sv > 0.1f) {
            float dx = sw / pw, dy = sv / ph; if (dx > 1) dx = 1; if (dy > 1) dy = 1;
            int key = (int)(dx * 1000) * 1000 + (int)(dy * 1000);
            if (key != lastKey) {
                lastKey = key;
                LOGI("resolution: eye %d shows tangents %.2f..%.2f x %.2f..%.2f of a picture drawn at %.2f..%.2f x %.2f..%.2f (%s) - "
                     "the shown part gets %.0f %% x %.0f %% of the headset's pixel density%s", eye, cb.win[0], cb.win[1], cb.win[3], cb.win[2],
                     cb.pic[0], cb.pic[1], cb.pic[3], cb.pic[2], cb.cant[0] != 0.f || cb.cant[1] != 0.f ? "canted view" : g_set.matchedView ? "matched view" : "the eye's own view", dx * 100, dy * 100,
                     dx < 0.9f || dy < 0.9f ? " (canted views: each eye a symmetric view covering exactly its field)" : "");
            }
        }
    }
}

int AcquireSlot() {
    int last = xrb::ClientLastSubmittedSlot();
    for (int k = 0; k < xrb::kSlots; k++) {
        int s = (g_nextSlot + k) % xrb::kSlots;
        if (g_slots[s].mx->AcquireSync(0, 0) == S_OK || (s != last && g_slots[s].mx->AcquireSync(1, 0) == S_OK)) { g_nextSlot = (s + 1) % xrb::kSlots; return s; }
    }
    return -1;
}
void ClearRect(ID3D11RenderTargetView* rtv, LONG x, LONG y, LONG w, LONG h) {
    float z[4] = {}; D3D11_RECT r{ x, y, x + w, y + h };
    ID3D11DeviceContext1* c1 = nullptr;
    if (SUCCEEDED(g_ctx->QueryInterface(__uuidof(ID3D11DeviceContext1), (void**)&c1)) && c1) { c1->ClearView(rtv, z, &r, 1); c1->Release(); }
}

ID3D11ShaderResourceView* MenuSrv(ID3D11Texture2D* menu) {
    if (menu != g_menuSeen) {
        SafeRelease(g_menuSrv);
        D3D11_SHADER_RESOURCE_VIEW_DESC sv{}; sv.Format = DXGI_FORMAT_R8G8B8A8_UNORM; sv.ViewDimension = D3D11_SRV_DIMENSION_TEXTURE2D; sv.Texture2D.MipLevels = 1;
        if (menu) g_dev->CreateShaderResourceView(menu, &sv, &g_menuSrv);
        g_menuSeen = menu;
    }
    return g_menuSrv;
}
// a panel drawn into both eye images (panel_layers = composite): centred in each eye's view, sized by angle
void CompositeIntoEyes(ID3D11ShaderResourceView* src, float srcAspect, float widthM, float distM, bool alpha, float upFrac = 0) {
    for (int e = 0; e < 2; e++) {
        const xrb::IpcFov& f = g_eyeFovSent[e];
        float l = tanf(f.left), r = tanf(f.right), u = tanf(f.up), d = tanf(f.down);
        float hw = widthM * 0.5f / distM, hh = hw / srcAspect, c = upFrac * (u - d);   // c: centre raised by a fraction of the view's height
        float x0 = (-hw - l) / (r - l) * g_ew, x1 = (hw - l) / (r - l) * g_ew, y0 = (u - (c + hh)) / (u - d) * g_eh, y1 = (u - (c - hh)) / (u - d) * g_eh;
        Draw(g_psCrop, src, nullptr, g_eye[e].rtv, x0, y0, x1 - x0, y1 - y0, Copy(alpha), alpha);
    }
}
bool PanelsComposite() {
    if (g_set.panelLayers == "composite") return true;
    if (g_set.panelLayers == "quad") return false;
    // auto: drawn into the eye images on Pimax (its quad layers were unreliable), quad layers elsewhere
    std::string n = xrb::ClientRuntimeName(); for (auto& c : n) c = (char)tolower((unsigned char)c);
    return n.find("pimax") != std::string::npos;
}

// D3D12: copy the D3D11 mirror texture into the back buffer before the game's Present (mirror = left)
void MirrorToBackBuffer(IDXGISwapChain3* s3) {
    if (!g_mirror.t12 || !g_gpuSync) return;
    UINT bi = s3->GetCurrentBackBufferIndex(); ID3D12Resource* bb = nullptr;
    if (FAILED(s3->GetBuffer(bi, __uuidof(ID3D12Resource), (void**)&bb)) || !bb) return;
    int a = g_allocIdx; g_allocIdx = (g_allocIdx + 1) % kAlloc;
    WaitLocal(g_allocDone[a]); g_alloc[a]->Reset(); g_list->Reset(g_alloc[a], nullptr);
    D3D12_RESOURCE_BARRIER b[2] = {};
    for (auto& x : b) { x.Type = D3D12_RESOURCE_BARRIER_TYPE_TRANSITION; x.Transition.Subresource = D3D12_RESOURCE_BARRIER_ALL_SUBRESOURCES; }
    b[0].Transition.pResource = bb; b[0].Transition.StateBefore = D3D12_RESOURCE_STATE_PRESENT; b[0].Transition.StateAfter = D3D12_RESOURCE_STATE_COPY_DEST;
    b[1].Transition.pResource = g_mirror.t12; b[1].Transition.StateBefore = D3D12_RESOURCE_STATE_COMMON; b[1].Transition.StateAfter = D3D12_RESOURCE_STATE_COPY_SOURCE;
    g_list->ResourceBarrier(2, b);
    g_list->CopyResource(bb, g_mirror.t12);
    for (auto& x : b) std::swap(x.Transition.StateBefore, x.Transition.StateAfter);
    g_list->ResourceBarrier(2, b);
    g_list->Close();
    g_queue->Wait(g_f11in12, g_v11);
    ID3D12CommandList* l[] = { g_list }; g_queue->ExecuteCommandLists(1, l);
    g_queue->Signal(g_fenceLocal, ++g_localVal); g_allocDone[a] = g_localVal;
    bb->Release();
}

void ScreenshotStart() {
    if (!g_eye[0].t || g_shotWait >= 0) return;
    bool full = g_set.screenshotView == "full";
    ID3D11Texture2D* src = full ? g_inter[(g_interIdx + 2) % 3].t11 : g_eye[0].t;
    D3D11_TEXTURE2D_DESC d; src->GetDesc(&d);
    if (full && g_floatSrc) { src = g_eye[0].t; src->GetDesc(&d); }
    SafeRelease(g_shotStage);
    D3D11_TEXTURE2D_DESC s = d; s.Usage = D3D11_USAGE_STAGING; s.BindFlags = 0; s.CPUAccessFlags = D3D11_CPU_ACCESS_READ; s.MiscFlags = 0;
    if (s.Format == DXGI_FORMAT_R8G8B8A8_TYPELESS) s.Format = DXGI_FORMAT_R8G8B8A8_UNORM;
    if (FAILED(g_dev->CreateTexture2D(&s, nullptr, &g_shotStage))) return;
    g_ctx->CopyResource(g_shotStage, src); g_shotW = d.Width; g_shotH = d.Height; g_shotWait = 0;
}
void ScreenshotPoll() {
    if (g_shotWait < 0 || !g_shotStage) return;
    D3D11_MAPPED_SUBRESOURCE m;
    if (g_ctx->Map(g_shotStage, 0, D3D11_MAP_READ, D3D11_MAP_FLAG_DO_NOT_WAIT, &m) != S_OK) { if (++g_shotWait > 120) { g_shotWait = -1; SafeRelease(g_shotStage); } return; }
    D3D11_TEXTURE2D_DESC d; g_shotStage->GetDesc(&d);
    bool bgra = d.Format == DXGI_FORMAT_B8G8R8A8_UNORM || d.Format == DXGI_FORMAT_B8G8R8A8_TYPELESS, ten = d.Format == DXGI_FORMAT_R10G10B10A2_UNORM || d.Format == DXGI_FORMAT_R10G10B10A2_TYPELESS;
    std::vector<uint8_t> px((size_t)g_shotW * g_shotH * 4);
    for (UINT y = 0; y < g_shotH; y++) {
        const uint8_t* row = (const uint8_t*)m.pData + (size_t)y * m.RowPitch; uint8_t* o = &px[(size_t)y * g_shotW * 4];
        for (UINT x = 0; x < g_shotW; x++) {
            if (ten) { uint32_t v = ((const uint32_t*)row)[x]; o[x * 4] = (uint8_t)((v & 1023) >> 2); o[x * 4 + 1] = (uint8_t)(((v >> 10) & 1023) >> 2); o[x * 4 + 2] = (uint8_t)(((v >> 20) & 1023) >> 2); }
            else { o[x * 4] = row[x * 4 + (bgra ? 2 : 0)]; o[x * 4 + 1] = row[x * 4 + 1]; o[x * 4 + 2] = row[x * 4 + (bgra ? 0 : 2)]; }
            o[x * 4 + 3] = 255;
        }
    }
    g_ctx->Unmap(g_shotStage, 0); SafeRelease(g_shotStage); g_shotWait = -1;
    SYSTEMTIME st; GetLocalTime(&st);
    wchar_t name[96]; wsprintfW(name, L"\\AWRVR_%04d%02d%02d_%02d%02d%02d.png", st.wYear, st.wMonth, st.wDay, st.wHour, st.wMinute, st.wSecond);
    std::wstring path = (g_modDir.compare(0, g_gameDir.size(), g_gameDir) == 0 ? g_gameDir : g_modDir) + name; unsigned w = g_shotW, h = g_shotH;
    std::thread([path, w, h, px = std::move(px)]() { bool ok = PngWrite(path, px.data(), w, h, w * 4); LOGI("screenshot: %s %ls (%ux%u)", ok ? "saved" : "FAILED", path.c_str(), w, h); }).detach();
}

// deadline-based limiter (performance manual 3, 9.3): next = previous deadline + period, re-anchored when late
void Limit(int mode, bool vrFrame) {
    double hz = 0;
    if (g_set.fpsUnlocked) hz = 0;
    else if (vrFrame || g_set.fpsLimit == "headset") hz = g_capHz;
    if (hz <= 1) { g_nextDeadline = 0; return; }
    (void)mode;
    if (!g_timerRes) { g_timerRes = true; timeBeginPeriod(1); }
    double period = 1.0 / hz, t = Now();
    if (g_nextDeadline == 0 || t - g_nextDeadline > period) g_nextDeadline = t;
    double target = g_nextDeadline;
    double t0 = t;
    while (t < target) { double left = target - t; if (left > 0.002) Sleep(1); else YieldProcessor(); t = Now(); }
    if (t > t0 + 1e-5) { s_limited++; s_waitMs += (t - t0) * 1000; }
    g_nextDeadline = target + period;
}

void Report(DWORD now, bool connected) {
    if (now - g_lastReport < 10000) return;
    unsigned frames = s_captured ? s_captured : 1;
    LOGI("xr: host %s (%s), submitted %u, ring busy (skipped, not waited) %u, no host %u | eyes: aer/synced %u, true stereo %u, head %u, flat %u, pair waits %u",
         connected ? "connected" : "not connected", xrb::ClientHostVisible() ? "visible" : "not visible", s_submitted, s_busy, s_noHost, s_stereo, s_native, s_head, s_flat, s_pairWait);
    LOGI("perf: mod work at Present %.2f ms avg, %.2f max | longest game frame %.1f ms | fps limiter: %s %.1f fps, waited %u frames (%.1f ms)",
         s_workMs / frames, s_workMax, s_frameMax * 1000, g_set.fpsUnlocked ? "uncapped" : "cap", g_set.fpsUnlocked ? 0.0 : g_capHz, s_limited, s_waitMs);
    if (*xrb::ClientHostError()) LOGW("xr: host error: %s", xrb::ClientHostError());
    EngineReport(); D3DHooksReport(); GameReport(); HeadAimReport(); UpscalerReport(); ScratchPadReport(); DiagReport();
    s_submitted = s_busy = s_noHost = s_captured = s_stereo = s_head = s_flat = s_pairWait = s_limited = s_native = 0; s_workMs = s_workMax = s_waitMs = s_frameMax = 0;
    g_lastReport = now;
}
} // namespace

// ---------------------------------------------------------------- called from the DXGI hooks
void CompositorSetQueue(ID3D12CommandQueue* q, IDXGISwapChain* sc) {
    if (!q) return;
    if (g_queue == q && g_swap == sc) return;
    if (g_init && g_queue && g_queue != q) ReleaseSized();
    if (q != g_queue) { if (g_queue) g_queue->Release(); g_queue = q; g_queue->AddRef(); }
    if (!g_dev12) q->GetDevice(__uuidof(ID3D12Device), (void**)&g_dev12);
    g_swap = sc;
}
void CompositorOnResize(IDXGISwapChain* sc) { if (sc == g_swap && g_init && !g_initFailed) ReleaseSized(); }
bool CompositorIsGameSwap(IDXGISwapChain* sc) { return sc == g_swap; }

bool CompositorOnPresent(IDXGISwapChain* sc) {
    if (sc != g_swap) return false;
    if (!g_qpf.QuadPart) rc::Qpf(&g_qpf);
    double t0 = Now();
    if (g_lastPresentT > 0 && t0 - g_lastPresentT > s_frameMax) s_frameMax = t0 - g_lastPresentT;
    g_lastPresentT = t0;
    if (!g_init) Init();
    bool shot = false; HotkeysPoll(&shot);
    DWORD now = rc::TickMs(); g_fpsCount++;
    if (now - g_fpsTick >= 1000) { MenuNoteFps(g_fpsCount * 1000.f / (now - g_fpsTick)); DiagNoteFps(g_fpsCount * 1000.f / (now - g_fpsTick)); g_fpsTick = now; g_fpsCount = 0; GameApplySettings(); ResolutionPoll(); }
    if (g_dev12 && (g_fpsCount & 15) == 0) { HRESULT dr = g_dev12->GetDeviceRemovedReason(); if (FAILED(dr)) EngineNoteDeviceRemoved((long)dr); }

    IDXGISwapChain3* s3 = nullptr;
    if (FAILED(sc->QueryInterface(__uuidof(IDXGISwapChain3), (void**)&s3)) || !s3) return false;
    FrameCapture fc = g_dev12 ? D3DHooksOnPresent(s3, g_dev12) : FrameCapture{};
    DXGI_SWAP_CHAIN_DESC sd{}; sc->GetDesc(&sd);
    UINT w = sd.BufferDesc.Width, h = sd.BufferDesc.Height;
    bool flatNow = false; FlatToggleState(&flatNow);
    if (g_set.flatVideos && GameVideoPlaying(g_set.flatVideoMinWidth)) flatNow = true;
    FrameInfo fi = EngineOnPresent(h ? (float)w / (float)h : 0.f, flatNow);
    if (g_initFailed || !g_xrInit) { s3->Release(); return false; }

    xrb::IpcPose pose[2]; xrb::IpcFov fov[2]; int64_t pt = 0;
    bool connected = xrb::ClientHostConnected();
    Report(now, connected);
    if (connected && xrb::ClientGetLatestPoses(pose, fov, &pt)) EngineSetPoses(pose, fov, pt); else EngineNoPoses();
    static bool savedSize = false;
    if (!savedSize && connected) {
        unsigned rw = 0, rh = 0; savedSize = true;
        if (xrb::ClientWaitRecommendedSize(&rw, &rh, 5) && rw && rh) {
            g_recW = rw; g_recH = rh;
            double hz = 0; ResolutionHeadsetRefresh(xrb::ClientSystemName(), &hz);
            ResolutionSaveHeadset(rw, rh, xrb::ClientSystemName(), 0);
            g_refresh.SetRuntime(xrb::ClientRuntimeName());
            LOGI("pacing: runtime '%s', headset '%s'%s", xrb::ClientRuntimeName(), xrb::ClientSystemName(), g_refresh.pimax ? " - halved rates are undivided (Pimax)" : " - smoothing detected as a drop from the full rate");
            if (hz > 0) { g_refresh.maxHz = hz; LOGI("pacing: refresh remembered for this headset: %.1f Hz", hz); }
        }
    }
    int64_t per = xrb::ClientDisplayPeriodNs();
    g_refresh.fixedHz = g_set.headsetRefreshHz;
    double newCap = g_refresh.Update(per > 0 ? 1e9 / per : 0, t0);
    if (per > 0 && g_refresh.maxHz > 0) DiagNoteRate(1e9 / per, g_refresh.maxHz);
    if (fabs(newCap - g_capHz) > 0.5) { LOGI("fps limiter: cap %.1f fps (headset)%s", newCap, g_set.headsetRefreshHz > 0 ? " - set by headset_refresh_hz" : ""); g_capHz = newCap; ResolutionSaveHeadset(g_recW, g_recH, xrb::ClientSystemName(), newCap); }
    if (!connected) { s_noHost++; s3->Release(); Limit(fi.mode, false); return false; }
    if (!EnsureSized(w, h, sd.BufferDesc.Format)) { g_initFailed = true; LOGE("compositor: giving up (see above)"); s3->Release(); return false; }
    RetireSweep(false);
    if (EngineEffectiveMode() == VRMODE_NATIVE) EnsureEye0();
    PublishTargets();

    // capture the final picture on the game's queue (after everything it drew)
    int k = g_interIdx; g_interIdx = (g_interIdx + 1) % 3;
    {
        UINT bi = s3->GetCurrentBackBufferIndex(); ID3D12Resource* bb = nullptr;
        if (FAILED(s3->GetBuffer(bi, __uuidof(ID3D12Resource), (void**)&bb)) || !bb) { s3->Release(); return false; }
        int a = g_allocIdx; g_allocIdx = (g_allocIdx + 1) % kAlloc;
        WaitLocal(g_allocDone[a]); g_alloc[a]->Reset(); g_list->Reset(g_alloc[a], nullptr);
        D3D12_RESOURCE_BARRIER b[2] = {};
        for (auto& x : b) { x.Type = D3D12_RESOURCE_BARRIER_TYPE_TRANSITION; x.Transition.Subresource = D3D12_RESOURCE_BARRIER_ALL_SUBRESOURCES; }
        b[0].Transition.pResource = bb; b[0].Transition.StateBefore = D3D12_RESOURCE_STATE_PRESENT; b[0].Transition.StateAfter = D3D12_RESOURCE_STATE_COPY_SOURCE;
        b[1].Transition.pResource = g_inter[k].t12; b[1].Transition.StateBefore = D3D12_RESOURCE_STATE_COMMON; b[1].Transition.StateAfter = D3D12_RESOURCE_STATE_COPY_DEST;
        g_list->ResourceBarrier(2, b);
        g_list->CopyResource(g_inter[k].t12, bb);
        for (auto& x : b) std::swap(x.Transition.StateBefore, x.Transition.StateAfter);
        g_list->ResourceBarrier(2, b);
        D3DHooksVrsUpdate(g_dev12, g_list, w, h);
        g_list->Close();
        if (g_gpuSync && g_v11) g_queue->Wait(g_f11in12, g_v11);   // D3D11 finished with every earlier capture
        ID3D12CommandList* l[] = { g_list }; g_queue->ExecuteCommandLists(1, l);
        g_queue->Signal(g_fenceLocal, ++g_localVal); g_allocDone[a] = g_localVal;
        if (g_gpuSync) g_queue->Signal(g_f12, ++g_v12);
        bb->Release();
    }
    s_captured++;
    if (g_gpuSync) g_ctx4->Wait(g_f12in11, g_v12); else WaitLocal(g_localVal);

    ID3D11ShaderResourceView* finalPic = g_inter[k].srv;
    ID3D11ShaderResourceView* noUi = fc.noUi ? g_noUi[fc.slot].srv : nullptr;
    // the HUD on its own panel (hud_mode = panel): final picture minus the picture before the UI
    bool panelHud = (g_set.hudMode == "panel" || (fi.mode == VRMODE_NATIVE && fi.vr)) && noUi;   // true stereo: the HUD is drawn once - on its panel
    ID3D11ShaderResourceView* scene = panelHud ? noUi : finalPic;
    uint32_t flags = 0;
    bool flat = !fi.vr, submitNow = true;
    int mode = fi.mode;
    bool theater = flat && (EngineCutsceneActive() || (g_set.flatVideos && GameVideoPlaying(g_set.flatVideoMinWidth)));
    if (g_xrInit) ScreenFor(theater);
    {   // the game switches that depend on what is drawn now (true stereo 3D vs theater, a method falling back)
        bool n3d = !flat && mode == VRMODE_NATIVE; int key = EngineEffectiveMode() * 2 + (n3d ? 1 : 0);
        static int lastKey = -1;
        if (key != lastKey) { lastKey = key; EngineNoteNative3d(n3d); GameApplySettings(); }
    }
    UpdateFade(flat ? (theater ? 2 : 1) : 0, Now());
    if (!flat && (mode == VRMODE_AER || mode == VRMODE_SYNCED) && fi.eye >= 0) {
        float ah = g_set.aerAlignH, av = g_set.aerAlignV;
        CropInto(scene, g_eye[fi.eye], fi, fi.eye, ah, av);
        g_haveEye[fi.eye] = true; g_eyePose[fi.eye] = fi.eyePose[fi.eye]; g_eyeFovSent[fi.eye] = fi.eyeFov[fi.eye]; g_eyeTime[fi.eye] = fi.time; g_eyeTick[fi.eye] = fi.tick;
        memcpy(g_eyeAng, fi.angVel, sizeof g_eyeAng);
        if (!g_haveEye[fi.eye ^ 1]) { CropInto(scene, g_eye[fi.eye ^ 1], fi, fi.eye ^ 1, ah, av); g_haveEye[fi.eye ^ 1] = true; g_eyePose[fi.eye ^ 1] = fi.eyePose[fi.eye ^ 1]; g_eyeFovSent[fi.eye ^ 1] = fi.eyeFov[fi.eye ^ 1]; }
        // synchronized pairs: the first eye waits for its twin (the held second tick) - never forever: when the game clock
        // is paused / stopped while 3D is drawn, or 4 first eyes in a row find no twin, the eyes alternate frame by frame
        static int noTwin = 0; static bool alternating = false;
        if (mode == VRMODE_SYNCED && fi.held) noTwin = 0;
        if (mode == VRMODE_SYNCED && g_set.syncSubmit == "pair" && !fi.held) {
            bool alt = ++noTwin > 4;
            if (alt != alternating) { alternating = alt; LOGI("synchronized: %s", alt ? "no second eye for 4 frames (game clock paused / stopped) - eyes alternate frame by frame" : "pairs again"); }
            if (!alt) { submitNow = false; s_pairWait++; }   // wait for its second eye
        }
        s_stereo++;
    } else if (!flat && mode == VRMODE_NATIVE) {
        // picture 0 = the capture between the renders, picture 1 = the back buffer (before its UI when captured)
        bool both = fc.eye0 && g_eye0[fc.slot].srv;
        static uint32_t lastSeq = 0;
        if (fi.seq != lastSeq) { lastSeq = fi.seq; EngineNativeResult(both); }   // repeated frames are no verdict
        ID3D11ShaderResourceView* second = noUi ? noUi : finalPic;
        for (int e = 0; e < 2; e++) {
            int pe = both ? e : 1;                    // without the first eye: the second picture on both eyes
            FrameInfo f = fi; f.pic = fi.eyePic[pe]; f.picCant[0] = fi.eyePicCant[pe][0]; f.picCant[1] = fi.eyePicCant[pe][1];
            CropInto(both && e == 0 ? g_eye0[fc.slot].srv : second, g_eye[e], f, e, 0, 0);
            g_eyePose[e] = fi.eyePose[pe]; g_eyeFovSent[e] = fi.eyeFov[e]; g_eyeTime[e] = fi.time; g_haveEye[e] = true;
        }
        s_native++;
    } else if (!flat) {
        for (int e = 0; e < 2; e++) { CropInto(scene, g_eye[e], fi, e, 0, 0); g_eyePose[e] = fi.pose; g_eyeFovSent[e] = fi.eyeFov[e]; g_eyeTime[e] = fi.time; g_haveEye[e] = true; }
        s_head++;
    } else {
        Draw(g_psCrop, finalPic, nullptr, g_flat.rtv, 0, 0, (float)w, (float)h, [&] { CbGfx c = Copy(false); c.opt[2] = HdrMode(); c.opt2[3] = g_fade; return c; }(), false);
        g_haveEye[0] = g_haveEye[1] = false;
        s_flat++;
    }
    // the UI on its own panel (hud_mode = panel)
    bool hudVisible = false;
    if (!flat && panelHud) {
        ClearRect(g_hud.rtv, 0, 0, w, h);
        CbGfx c = Copy(true); c.opt2[2] = 0.04f; c.opt[2] = HdrMode(); c.opt[3] = g_set.hdrPaperWhite;
        Draw(g_psUi, finalPic, noUi, g_hud.rtv, 0, 0, (float)w, (float)h, c, false);
        hudVisible = true;
    }
    if (g_gpuSync) { g_ctx4->Signal(g_f11, ++g_v11); }
    else if (g_query) { g_ctx->End(g_query); g_ctx->Flush(); double qt = Now(); while (g_ctx->GetData(g_query, nullptr, 0, 0) == S_FALSE && Now() - qt < 0.5) YieldProcessor(); }   // (never hangs on a lost GPU)

    ID3D11Texture2D* menu = MenuUpdate(g_dev, g_ctx);
    bool composite = PanelsComposite();
    if (!composite && !flat) HudLayerFor(menu != nullptr);
    if (menu && !composite) hudVisible = false;      // the shared layer shows the menu while it is open
    if (composite && !flat) {
        if (hudVisible) { CompositeIntoEyes(g_hud.srv, (float)w / h, HudPanelWidth(), g_set.uiDepth, true, g_set.uiOffsetY); hudVisible = false; }
        if (menu) { D3D11_TEXTURE2D_DESC md; menu->GetDesc(&md); CompositeIntoEyes(MenuSrv(menu), (float)md.Width / md.Height, g_set.menuPanelWidth * g_set.menuWidth, g_set.menuDistance, true); menu = nullptr; }
    }
    if (submitNow) {
        int slot = AcquireSlot();
        if (slot < 0) s_busy++;
        else {
            ID3D11Texture2D* atlas = g_slots[slot].tex;
            xrb::IpcPose sp[2] = {}; xrb::IpcFov sf[2] = {};
            if (!flat) {
                // swap_eyes: each image goes to the other eye with the pose and view it was made for (every method)
                int sw = g_set.swapEyes ? 1 : 0;
                g_ctx->CopySubresourceRegion(atlas, 0, 0, 0, 0, g_eye[sw].t, 0, nullptr);
                g_ctx->CopySubresourceRegion(atlas, 0, g_ew, 0, 0, g_eye[sw ^ 1].t, 0, nullptr);
                for (int e = 0; e < 2; e++) { sp[e] = g_eyePose[e ^ sw]; sf[e] = g_eyeFovSent[e ^ sw]; }
                if (hudVisible) { g_ctx->CopySubresourceRegion(atlas, 0, 0, g_eh, 0, g_hud.t, 0, nullptr); flags |= xrb::SLOT_HUD_VISIBLE; }
                else ClearRect(g_slots[slot].rtv, 0, g_eh, w, h);
                if (menu) {
                    D3D11_TEXTURE2D_DESC md; menu->GetDesc(&md);
                    float fw = w * (g_set.menuWidth < 0.2f ? 0.2f : g_set.menuWidth), fh = fw * md.Height / md.Width;
                    if (fh > h) { fh = (float)h; fw = fh * md.Width / md.Height; }
                    Draw(g_psCrop, MenuSrv(menu), nullptr, g_slots[slot].rtv, (w - fw) * 0.5f, g_eh + (h - fh) * 0.5f, fw, fh, Copy(true), true);
                    flags |= xrb::SLOT_HUD_VISIBLE;
                }
            } else {
                g_ctx->CopySubresourceRegion(atlas, 0, 0, g_eh, 0, g_flat.t, 0, nullptr);
                if (menu) {
                    // the menu keeps the angular size it has in 3D, whatever the screen's size (theater: up to 170 deg)
                    D3D11_TEXTURE2D_DESC md; menu->GetDesc(&md);
                    float tanHalf = g_set.menuPanelWidth * (g_set.menuWidth < 0.2f ? 0.2f : g_set.menuWidth) * 0.5f / (g_set.menuDistance > 0.1f ? g_set.menuDistance : 0.1f);
                    float frac = g_menuSentW > 0 && g_menuSentD > 0 ? 2.f * tanHalf * g_menuSentD / g_menuSentW : g_set.menuWidth;
                    frac = frac < 0.1f ? 0.1f : frac > 1.f ? 1.f : frac;
                    float fw = w * frac, fh = fw * md.Height / md.Width;
                    if (fh > h) { fh = (float)h; fw = fh * md.Width / md.Height; }
                    Draw(g_psCrop, MenuSrv(menu), nullptr, g_slots[slot].rtv, (w - fw) * 0.5f, g_eh + (h - fh) * 0.5f, fw, fh, Copy(true), true);
                }
                flags = xrb::SLOT_MENU_MODE | xrb::SLOT_HUD_VISIBLE;
            }
            g_slots[slot].mx->ReleaseSync(1);
            xrb::IpcMotion mo{}; const xrb::IpcMotion* mp = nullptr;
            if (!flat && g_set.cameraReprojection && (mode == VRMODE_AER || mode == VRMODE_SYNCED)) {
                int sw = g_set.swapEyes ? 1 : 0;
                mo.contentTime[0] = g_eyeTime[sw]; mo.contentTime[1] = g_eyeTime[sw ^ 1]; memcpy(mo.angVel, g_eyeAng, sizeof mo.angVel); mp = &mo; flags |= xrb::SLOT_REPROJECT;
            }
            xrb::ClientSubmitSlot(slot, sp, sf, !flat ? (g_eyeTime[0] > g_eyeTime[1] ? g_eyeTime[0] : g_eyeTime[1]) : pt, flags, mp);
            s_submitted++;
        }
    }
    // the monitor: left eye (no flicker) or what the game drew
    if (g_set.mirror == "left" && g_mirror.rtv && !flat && g_haveEye[0]) {
        ClearRect(g_mirror.rtv, 0, 0, w, h);
        float a = (float)g_ew / g_eh, mw = (float)w, mh = mw / a; if (mh > h) { mh = (float)h; mw = mh * a; }
        Draw(g_psCrop, g_eye[0].srv, nullptr, g_mirror.rtv, (w - mw) * 0.5f, (h - mh) * 0.5f, mw, mh, Copy(false), false);
        if (g_gpuSync) { g_ctx4->Signal(g_f11, ++g_v11); g_ctx->Flush(); MirrorToBackBuffer(s3); }
    }
    if (shot) ScreenshotStart();
    ScreenshotPoll();
    g_ctx->Flush();
    s3->Release();
    double ms = (Now() - t0) * 1000.0;
    s_workMs += ms; if (ms > s_workMax) s_workMax = ms;
    Limit(mode, !flat);
    return true;
}

void CompositorRecenter() { if (g_xrInit) xrb::ClientRequestRecenter(); }
void CompositorApplyPanels() {
    if (!g_xrInit) return;
    g_hudSentD = g_hudSentW = -1;      // HUD / menu layer re-sent with the next frame (HudLayerFor)
    g_menuSentD = g_menuSentW = -1;   // re-sent with the next frame (theater or normal size)
    PublishTargets();
}
