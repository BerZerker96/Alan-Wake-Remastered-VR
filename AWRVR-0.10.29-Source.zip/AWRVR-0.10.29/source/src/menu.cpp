// Settings and the VR panel (vrkit): six tabs, labelled sections, the chosen method's rows only, Advanced last with
// the frame rate at its top (guide 13, deep dives J and M). Every option has a help text: what it does, its default,
// its cost. Changes apply live (or are marked restart) and are saved when the panel closes.
#include <windows.h>
#include <d3d11.h>
#include <string>
#include <vector>
#include "log.h"
#include "config.h"
#include "settings.h"
#include "headaim.h"
#include "upscaler.h"
#include "engine.h"
#include "game.h"
#include "d3d12hooks.h"
#include "version.h"
#include "vrkit_options.h"
#include "vrkit_menu.h"
#include "vrkit_menu_core.h"
#include "hotkeys.h"
void ResolutionSettingsChanged(); int SetupProblemCount(); void DiagUserMark(); void DiagReportFolder(); void DiagConfigSnapshot();   // diag.cpp
void PanelMouseSetActive(bool on);
void PanelMouseTake(float* dx, float* dy, float* wheel, bool* l, bool* r);

extern std::wstring g_gameDir, g_cfgPath;
void CompositorRecenter();
void CompositorApplyPanels();
void FlatToggle();
void FirstPersonToggle();

VrSettings g_set;
static bool g_menuInit = false, g_menuFailed = false;
static float g_fps = 0;

const char* ModeName(int m) { static const char* n[] = { "synced", "aer", "head", "screen", "native" }; return m >= 0 && m < VRMODE_COUNT ? n[m] : "?"; }

#define LB(k, f) g_set.f = ConfigBool(k, g_set.f)
#define LF(k, f) g_set.f = ConfigFloat(k, g_set.f)
#define LI(k, f) g_set.f = ConfigInt(k, g_set.f)
#define LS(k, f) g_set.f = ConfigStr(k, g_set.f.c_str())
// eye_view sets how each eye's picture is drawn (matched_view / canted_view / pixel_perfect follow it)
void ApplyEyeView() {
    const std::string& v = g_set.eyeView;
    if (v == "canted") { g_set.cantedView = true; g_set.pixelPerfect = false; }
    else if (v == "matched") { g_set.cantedView = false; g_set.matchedView = true; g_set.pixelPerfect = false; }
    else if (v == "own") { g_set.cantedView = false; g_set.matchedView = false; g_set.pixelPerfect = false; }
    else { g_set.cantedView = false; g_set.matchedView = true; g_set.pixelPerfect = true; }
}
void SettingsLoad() {
    LS("vr_mode", vrMode); LF("world_scale", worldScale); LF("ipd_scale", ipdScale); LB("swap_eyes", swapEyes);
    LS("sync_submit", syncSubmit);
    LB("camera_reprojection", cameraReprojection); LI("aer_frame_delay", aerFrameDelay);
    LB("decoupled_pitch", decoupledPitch); LF("camera_stabilize", cameraStabilize); LF("camera_settle", cameraSettle);
    LF("camera_offset_x", camOffsetX); LF("camera_offset_y", camOffsetY); LF("camera_offset_z", camOffsetZ);
    LB("first_person", firstPerson); LF("fp_offset_x", fpOffsetX); LF("fp_offset_y", fpOffsetY); LF("fp_offset_z", fpOffsetZ); LF("fp_smooth", fpSmooth); LF("fp_near_clip", fpNearClip); LF("fp_eye_height", fpEyeHeight); LS("action_cameras", actionCameras); LS("cutscene_mode", cutsceneMode); LF("theater_size", theaterSize); LF("theater_distance", theaterDistance); LB("theater_fade", theaterFade); LF("camera_shake", cameraShake); LB("stereo_diagnostics", stereoDiag);
    LS("head_aim", headAim); LB("head_aim_from_eyes", headAimFromEyes); LF("head_aim_smoothing", headAimSmooth);
    LS("hud_mode", hudMode); LF("hud_safe_x", hudSafeX); LF("hud_safe_y", hudSafeY); LF("ui_scale", uiScale); LF("ui_depth", uiDepth); LF("ui_offset_y", uiOffsetY); LB("hide_hud", hideHud); LI("ui_pick", uiPick);
    LS("game_aa", gameAA); LB("upscaler_fresh_each_eye", upscalerFreshEyes); LB("motion_blur_off", motionBlurOff); LB("film_grain_off", filmGrainOff); LB("vignette_off", vignetteOff);
    LF("sharpen", sharpen); LF("render_scale", renderScale); LB("no_black_bars", noBlackBars); LB("occlusion_culling", occlusionCulling); LB("true_stereo_occlusion", stereoOcclusion);
    LB("edge_fill", edgeFill); LB("flat_pause_menus", flatPauseMenus); LB("flat_videos", flatVideos);
    LF("screen_distance", screenDistance); LF("screen_width", screenWidth); LF("menu_distance", menuDistance); LF("menu_panel_width", menuPanelWidth); LF("menu_width", menuWidth);
    LS("mirror", mirror); LB("vsync_off", vsyncOff); LS("hdr_input", hdrInput); LS("screenshot_view", screenshotView); LB("force_windowed", forceWindowed); LB("run_in_background", runInBackground);
    LB("fps_unlocked", fpsUnlocked); LS("fps_limit", fpsLimit); LF("headset_refresh_hz", headsetRefreshHz);
    LS("fov_mode", fovMode); LF("fov_inner", fovInner); LF("fov_outer", fovOuter); LF("fov_wide", fovWide); LB("fov_debug", fovDebug);
    LF("view_width", viewWidth); LF("view_height", viewHeight); LB("wide_cull", wideCull); LB("symmetric_view", symmetricView); LB("matched_view", matchedView); LB("canted_view", cantedView); LS("eye_view", eyeView); ApplyEyeView(); LF("cull_margin", cullMargin);
    LF("near_clip", nearClip); LF("units_per_metre", unitsPerMetre);

    LF("aer_align_h", aerAlignH); LF("aer_align_v", aerAlignV); LI("sync_lag", syncLag);
    LS("render_resolution", renderResolution); LS("render_density", renderDensity); LS("headset_smoothing", headsetSmoothing); LI("max_frame_latency", maxFrameLatency);
    LS("ui_layers", uiLayers); LS("hud_split", hudSplit); LI("hud_scene_draws", hudSceneDraws); LF("offset_step_cm", offsetStepCm);
    LI("flat_video_min_width", flatVideoMinWidth); LS("panel_layers", panelLayers); LF("hdr_paper_white", hdrPaperWhite); LS("game_frame_cap", gameFrameCap);
    LS("camera_axes", cameraAxes); LI("render_max_side", renderMaxSide); LI("paced_timeout_ms", pacedTimeoutMs);
    LS("recenter_key", recenterKey); LS("screenshot_key", screenshotKey); LS("fp_key", fpKey);
    LB("camera_hooks", cameraHooks); LB("ui_hooks", uiHooks); LB("xr_output", xrOutput); LF("menu_opacity", menuOpacity);
    LS("ui_pick_sig", uiPickSig); LS("host_mode", hostMode); LB("static_camera_refresh", staticRefresh);
}

namespace xrb { void ClientSetFramePacing(uint32_t mode, uint32_t timeoutMs); }
void SettingsApply() {
    EngineSettingsChanged();
    GameApplySettings();
    HeadAimApplySettings();
    GameFirstPerson(g_set.firstPerson, g_set.fpOffsetX, g_set.fpOffsetY, g_set.fpOffsetZ);
    CompositorApplyPanels();
    vrkit::menu::core::SetBackgroundAlpha(g_set.menuOpacity);
    xrb::ClientSetFramePacing(g_set.headsetSmoothing == "runtime" ? 2 : g_set.headsetSmoothing == "repeat" ? 0 : 1, (uint32_t)g_set.pacedTimeoutMs);
}
void SettingsSave() { vrkit::Options::Get().Save(g_cfgPath); }

void SettingsCycleMode() {
    static const char* order[] = { "synced", "native", "aer", "head", "screen" };
    int i = 0; for (int k = 0; k < 5; k++) if (g_set.vrMode == order[k]) i = k;
    g_set.vrMode = order[(i + 1) % 5];
    LOGI("settings: stereo method -> %s", g_set.vrMode.c_str());
    SettingsApply();
}
void MenuNoteFps(float fps) { g_fps = fps; }

// every option of the panel (also used by the offline preview, tests/menupreview.cpp)
vrkit::menu::Settings MenuRegister() {
    auto& o = vrkit::Options::Get();
    auto apply = [] { SettingsApply(); };
    auto is = [](const char* m) { return [m] { return g_set.vrMode == m; }; };
    std::string grp;
    auto G = [&](vrkit::Option& x) -> vrkit::Option& { x.group = grp; return x; };

    // ================= View
    grp = "Stereo";
    auto& m = G(o.AddChoice("View", "vr_mode", "Stereo method", &g_set.vrMode, { "synced", "native", "aer", "head", "screen" },
        "True stereo (default): the game renders both eyes every frame (full rate, ~2x GPU; TAA and motion blur off while it runs; "
        "protected - falls back by itself and logs where it stopped). Synchronized: both eyes from one game tick. "
        "Alternate eye: one eye per frame. Head: mono. Flat screen. F8 cycles.", apply));
    m.choiceLabels = { "Synchronized", "True stereo", "Alternate eye", "Head (mono)", "Flat screen" };
    G(o.AddFloat("View", "world_scale", "World scale", &g_set.worldScale, 0.25f, 4.f, 0.05f, 2, "1.0 = real size. Larger values make the world look smaller (head movement moves you more).", apply));
    G(o.AddFloat("View", "ipd_scale", "Eye distance x", &g_set.ipdScale, 0.f, 2.f, 0.02f, 2, "1.0 = your headset's IPD. Lower = less depth (world looks bigger), higher = more depth.", apply));
    G(o.AddBool("View", "swap_eyes", "Swap eyes", &g_set.swapEyes, "Use if depth looks inside out.", apply));
    grp = "Synchronized";
    auto& ss = G(o.AddChoice("View", "sync_submit", "Send eyes", &g_set.syncSubmit, { "pair", "each" },
        "Pair: the headset gets both eyes of a tick together (never mismatched). Each: every eye as soon as it is drawn (one frame less latency for the first eye).", apply));
    ss.visible = is("synced"); ss.choiceLabels = { "As a pair", "Each eye" };
    grp = "Alternate eye / synchronized";
    auto aerOrSync = [] { return g_set.vrMode == "aer" || g_set.vrMode == "synced"; };
    G(o.AddBool("View", "camera_reprojection", "Turn the older eye with the camera", &g_set.cameraReprojection,
        "Alternate eye: one eye's image is a frame older. On: the headset turns it by the game camera's own turning speed, so both eyes agree while you turn with the stick. Test option.", apply)).visible = aerOrSync;
    G(o.AddInt("View", "aer_frame_delay", "Frame delay", &g_set.aerFrameDelay, 0, 3, 1,
        "0 = automatic (a frame is shown right after the camera was set for it). If both eyes look the same or depth flickers, try 1 or 2.", apply)).visible = is("aer");
    grp = "Performance";
    G(o.AddBool("View", "fps_unlocked", "Uncapped frame rate", &g_set.fpsUnlocked,
        "Off (default): the game runs at the headset's own refresh rate. On: no cap at all - the game runs as fast as it can; the headset shows the newest frame each refresh.", apply));
    G(o.AddChoice("View", "fps_limit", "FPS limiter", &g_set.fpsLimit, { "headset", "0" },
        "Headset: never more frames than the headset's own refresh rate - never the half rate its motion smoothing runs at. 0: no cap in flat mode (in VR it stays at the headset's rate).", apply)).choiceLabels = { "Headset refresh rate", "Off (flat)" };
    G(o.AddFloat("View", "headset_refresh_hz", "Headset refresh rate (Hz)", &g_set.headsetRefreshHz, 0.f, 240.f, 1.f, 0,
        "0 = automatic: the headset's own rate, never the half rate of its smoothing (remembered per headset). Set it only if the log shows a wrong rate.", apply));
    G(o.AddChoice("View", "fov_mode", "Foveated rendering", &g_set.fovMode, { "off", "unseen", "quality", "balanced", "performance", "custom" },
        "Unseen: only the part of each eye's picture that eye never shows is drawn coarse (about a fifth of it with matched view) - nothing you can see changes. "
        "Quality / balanced / performance: also fewer pixel-shader runs far from the lens centre. GPUs with variable rate shading tier 2 (RTX 20+, RX 6000+, Arc). The HUD is never affected.", apply));
    auto custom = [] { return g_set.fovMode == "custom"; };
    G(o.AddFloat("View", "fov_inner", "Full-detail zone", &g_set.fovInner, 0.1f, 1.5f, 0.05f, 2, "Radius in half image heights from the lens centre.", apply)).visible = custom;
    G(o.AddFloat("View", "fov_outer", "Reduced zone ends at", &g_set.fovOuter, 0.2f, 2.f, 0.05f, 2, "Beyond this: the lowest rate.", apply)).visible = custom;
    G(o.AddFloat("View", "fov_wide", "Zone width", &g_set.fovWide, 0.8f, 2.f, 0.05f, 2, "Above 1 = wider than tall (wide lenses).", apply));
    G(o.AddBool("View", "fov_debug", "Show the zones", &g_set.fovDebug, "Both zones at the coarsest rate, to see where they start.", apply));
    G(o.AddFloat("View", "render_scale", "Render scale", &g_set.renderScale, 0.3f, 1.5f, 0.05f, 2, "Fraction of the headset's recommended size (per eye).")).needsRestart = true;
    grp = "Quick actions";
    G(o.AddAction("View", "Mark an issue in the log", [] { DiagUserMark(); }, "Writes USER MARK #n into awrvr.log at this moment - tell the number with your report."));
    G(o.AddAction("View", "Make a report folder", [] { DiagReportFolder(); }, "Copies both logs, the previous run's logs, the config and the headset files into AWRVR\\report_<date> - send that folder."));
    G(o.AddAction("View", "Recenter view", [] { CompositorRecenter(); }, "Puts the view and the panels in front of you (also F9)."));
    G(o.AddAction("View", "First person on / off", [] { FirstPersonToggle(); }, "Alan's eyes instead of behind his shoulder. Settings: the Camera tab."));
    G(o.AddAction("View", "Flat screen now", [] { FlatToggle(); }, "Shows the flat virtual screen until pressed again (or its hotkey)."));

    // ================= Camera
    grp = "Head aim";
    auto& ham = G(o.AddChoice("Camera", "head_aim", "Head aim", &g_set.headAim, { "off", "always", "aiming" },
        "Aim with your head: the gun, the flashlight beam and aim assist go where you look. Changes only the aim - the camera and the view never turn with it. "
        "While aiming: only while L2 / LT (any controller) or the right mouse button is held. Always: every shot. Works in third and first person.", apply));
    ham.choiceLabels = { "Off", "Always", "While aiming (L2)" };
    G(o.AddFloat("Camera", "head_aim_smoothing", "Head aim smoothing", &g_set.headAimSmooth, 0.f, 1.f, 0.05f, 2,
        "Steadies the aim against small head tremor: 0 = raw head, 1 = steadiest (~0.15 s). Turning with the stick or mouse is never delayed.", apply)).visible = [] { return g_set.headAim != "off"; };
    G(o.AddBool("Camera", "head_aim_from_eyes", "Aim from the eyes", &g_set.headAimFromEyes,
        "On (default): the aim ray starts where your eyes are drawn, so it hits exactly what you look at (first person: from Alan's head). Off: from Alan's shoulder, as the game does.", apply)).visible = [] { return g_set.headAim != "off"; };
    grp = "Camera";
    G(o.AddBool("Camera", "decoupled_pitch", "Decoupled pitch", &g_set.decoupledPitch,
        "Removes the game camera's up / down tilt (and roll): the horizon stays level and only your head pitches the view. Stick / mouse turning (yaw) still applies.", apply));
    G(o.AddFloat("Camera", "camera_stabilize", "Camera shake filter", &g_set.cameraStabilize, 0.f, 1.f, 0.05f, 2,
        "Smooths the game camera's shake (hits, landings, the camera's catch-up jitter): steady walking and turning are followed with no lag, only what deviates from them is removed. 0 = off. Your own head movement is never filtered.", apply));
    G(o.AddFloat("Camera", "camera_settle", "Idle sway lock", &g_set.cameraSettle, 0.f, 1.f, 0.05f, 2,
        "Removes the game camera's small automatic movement while you stand still: the camera only moves once the game's moves more than a little (1.0 = 2.5 degrees / 6 cm), then follows exactly. 0 = off.", apply));
    G(o.AddFloat("Camera", "camera_shake", "Camera shake", &g_set.cameraShake, 0.f, 1.f, 0.05f, 2,
        "How much of the game's own camera shake you get in VR (hits, explosions, weapons, script shakes): 0 = none (default), 1 = the game's. Removed at the source, before the picture is made - the shake filter below only smooths what is left.", apply));
    auto& ac = G(o.AddChoice("Camera", "action_cameras", "Action cameras", &g_set.actionCameras, { "off", "game" },
        "The game's slow-motion moments (dodge, melee, throw) swing the camera around Alan. Off (default): the swing is skipped in VR, the slow motion stays - much easier on the stomach. Game: as the game does it.", apply));
    ac.choiceLabels = { "No camera swing", "As the game" };
    grp = "Camera offset";
    auto step = g_set.offsetStepCm * 0.01f;
    G(o.AddFloat("Camera", "camera_offset_x", "Camera X (right)", &g_set.camOffsetX, -9.f, 9.f, step, 2, "Metres.", apply));
    G(o.AddFloat("Camera", "camera_offset_y", "Camera Y (up)", &g_set.camOffsetY, -9.f, 9.f, step, 2, "Metres.", apply));
    G(o.AddFloat("Camera", "camera_offset_z", "Camera Z (forward)", &g_set.camOffsetZ, -15.f, 15.f, step, 2, "Metres. The game camera is behind Alan's shoulder: forward brings you closer to him.", apply));
    G(o.AddAction("Camera", "Reset camera", [] { g_set.decoupledPitch = true; g_set.camOffsetX = g_set.camOffsetY = g_set.camOffsetZ = 0; SettingsApply(); }, "Decoupled pitch on, offsets 0."));
    grp = "First person";
    G(o.AddBool("Camera", "first_person", "First person (End)", &g_set.firstPerson,
        "Your view is at Alan's head instead of behind his shoulder: the game's own player camera is moved to its pivot (no shoulder offset, no trailing, no toe-in angle). The crosshair still follows the stick, as in third person. Cutscenes and scripted cameras keep the game's camera. End toggles it.", apply));
    G(o.AddFloat("Camera", "fp_offset_x", "Eye X (right)", &g_set.fpOffsetX, -1.5f, 1.5f, step, 2, "Metres from the camera pivot (right). First person only.", apply));
    G(o.AddFloat("Camera", "fp_eye_height", "Eye height", &g_set.fpEyeHeight, 0.f, 2.2f, 0.01f, 2,
        "First-person eye height (calibrated in the headset: 0.60 puts your eyes at Alan's, together with Eye Z 0.60). The game's camera pivot is read from Alan's character each second and the difference applied. 0 = off (Eye Y alone moves the eye from the pivot).", apply));
    G(o.AddFloat("Camera", "fp_offset_y", "Eye Y (up)", &g_set.fpOffsetY, -1.5f, 1.5f, step, 2, "Fine-tune up / down on top of Eye height (metres). First person only.", apply));
    G(o.AddFloat("Camera", "fp_offset_z", "Eye Z (forward)", &g_set.fpOffsetZ, -1.5f, 1.5f, step, 2, "Metres in front of the pivot (0.60 = at Alan's eyes). Raise it if you see the inside of the head. First person only.", apply));
    G(o.AddFloat("Camera", "fp_smooth", "Head bob filter", &g_set.fpSmooth, 0.f, 1.f, 0.05f, 2,
        "Smooths the up / down bob of the first-person view while walking and running (height only). Walking, stairs and jumps are followed without delay. 0 = off.", apply));
    G(o.AddFloat("Camera", "fp_near_clip", "Near clip in first person", &g_set.fpNearClip, 0.f, 0.5f, 0.01f, 2,
        "How close to your eyes the game draws in first person. 0 = the game's own (0.2 m), which also hides the inside of Alan's head; lower shows more of his hands and body up close.", apply));
    G(o.AddAction("Camera", "Reset first person", [] { g_set.fpOffsetX = 0; g_set.fpOffsetY = 0.f; g_set.fpOffsetZ = 0.12f; g_set.fpEyeHeight = 1.68f; g_set.fpSmooth = 0.6f; g_set.fpNearClip = 0.f; SettingsApply(); }, "Eye offsets, bob filter and near clip to their defaults."));

    // ================= HUD
    grp = "HUD";
    auto& hm = G(o.AddChoice("HUD", "hud_mode", "HUD placement", &g_set.hudMode, { "scale", "safe", "panel", "off" },
        "Scale (default): the HUD is moved into the middle of each eye and shrunk (converged at UI depth); where the game bakes its HUD into the picture, the game's safe area is used instead. Safe area: the game itself lays the HUD out closer to the centre (its safe-area setting) - full sharpness, only moved to each eye's centre. Panel: the HUD on its own panel at UI depth. Off: the game's own layout.", apply));
    hm.choiceLabels = { "Scaled into view", "Game safe area", "Own panel", "Game layout" };
    G(o.AddFloat("HUD", "hud_safe_x", "Safe area: sides", &g_set.hudSafeX, 0.f, 0.45f, 0.01f, 2, "HUD placement = Game safe area: how far in from the left / right edge the game places the HUD (fraction of the picture).", apply)).visible = [] { return g_set.hudMode == "safe"; };
    G(o.AddFloat("HUD", "hud_safe_y", "Safe area: top / bottom", &g_set.hudSafeY, 0.f, 0.45f, 0.01f, 2, "HUD placement = Game safe area: how far in from the top / bottom edge.", apply)).visible = [] { return g_set.hudMode == "safe"; };
    G(o.AddFloat("HUD", "ui_scale", "UI scale", &g_set.uiScale, 0.2f, 1.f, 0.01f, 2, "Size of the HUD in your view (scaled HUD and HUD panel): 1 = edge to edge, 0.42 = comfortable.", apply));
    G(o.AddFloat("HUD", "ui_depth", "UI depth (m)", &g_set.uiDepth, 0.5f, 10.f, 0.1f, 1, "How far away the UI appears.", apply));
    G(o.AddFloat("HUD", "ui_offset_y", "UI height", &g_set.uiOffsetY, -0.3f, 0.3f, 0.01f, 2, "Moves the UI up (+) or down (-).", apply));
    G(o.AddBool("HUD", "hide_hud", "Hide the game HUD (F7)", &g_set.hideHud, "Hides everything the game draws over the 3D picture (also F7).", apply));
    grp = "Which UI is scaled";
    G(o.AddInt("HUD", "ui_pick", "UI element (picker)", &g_set.uiPick, 0, 16, 1,
        "0 = automatic. 1, 2, 3 ... = each full-screen layer the game draws 2D / UI into (the log lists them). Step through them with the HUD in view until it shrinks to the UI scale - that one is the HUD.", apply));

    // ================= Graphics
    grp = "Game effects";
    auto& aa = G(o.AddChoice("Graphics", "game_aa", "Game anti-aliasing (TAA)", &g_set.gameAA, { "game", "off", "on" },
        "Game: the mod never touches it. Off / On: the game's TAA switched while this is chosen (nothing is saved). In alternate eye / synchronized TAA mixes the eyes (double image) - off is cleaner.", apply));
    aa.choiceLabels = { "Game", "Off", "On" };
    G(o.AddBool("Graphics", "upscaler_fresh_each_eye", "Upscaler: fresh image each eye", &g_set.upscalerFreshEyes,
        "For DLSS / DLAA (and FSR / XeSS through OptiScaler). The upscaler builds each picture from earlier ones - with one eye per frame those are the other eye's, which can ghost or double. "
        "On: every picture starts fresh (no ghosting between the eyes, a little less smooth). Off (default): as the game does it. Frame generation must be off in VR.", apply));
    G(o.AddBool("Graphics", "motion_blur_off", "Motion blur off", &g_set.motionBlurOff, "The game's camera / object motion blur (vector blur) off - it smears the view when you turn your head.", apply));
    G(o.AddBool("Graphics", "film_grain_off", "Film grain off", &g_set.filmGrainOff, "The film grain overlay off.", apply));
    G(o.AddBool("Graphics", "vignette_off", "Vignette off", &g_set.vignetteOff, "The cinematic darkening at the picture's edges off (the headset's lenses do that already).", apply));
    G(o.AddFloat("Graphics", "sharpen", "Sharpening", &g_set.sharpen, 0.f, 2.f, 0.05f, 2, "Sharpens the 3D image. 0 = off.", apply));
    G(o.AddBool("Graphics", "occlusion_culling", "Occlusion culling", &g_set.occlusionCulling, "On: the game's own (Umbra). Off: if scenery vanishes when you look around quickly. Costs a little speed.", apply));
    G(o.AddBool("Graphics", "true_stereo_occlusion", "Occlusion culling in true stereo", &g_set.stereoOcclusion,
        "On (default): true stereo keeps the game's occlusion culling - with it off the ground was missing in true stereo. Off: only if objects pop in and out between the eyes.", apply));
    grp = "Resolution and speed";
    G(o.AddBool("Graphics", "no_black_bars", "No cutscene black bars (test)", &g_set.noBlackBars,
        "Switches the game's 'Cinematic Mode' off. Test option: whether that is the letterbox in every build is not verified - off if anything looks wrong.", apply));
    auto& fc = G(o.AddChoice("Graphics", "game_frame_cap", "Game's own frame limit", &g_set.gameFrameCap, { "game", "off" },
        "Game: its own 30 / 60 fps limit (set in its options) stays. Off: skipped while chosen, so the mod's headset-rate limiter decides.", apply));
    fc.choiceLabels = { "Game", "Off" };

    // ================= Screen
    grp = "Cutscenes";
    auto& cm = G(o.AddChoice("Screen", "cutscene_mode", "Cutscenes", &g_set.cutsceneMode, { "theater", "3d" },
        "Theater (default): in-game cutscenes and the pre-rendered cinematics play on a big cinema screen in front of you. 3D: in-game cutscenes stay in the scene around you (with head tracking).", apply));
    cm.choiceLabels = { "Theater screen", "3D in the scene" };
    G(o.AddFloat("Screen", "theater_size", "Theater size", &g_set.theaterSize, 40.f, 170.f, 5.f, 0,
        "How much of your view the cinema screen fills (degrees across). 60 = a big TV, 100 = a cinema (default), 140+ = wrap-around, beyond your headset's view.", apply));
    G(o.AddFloat("Screen", "theater_distance", "Theater distance", &g_set.theaterDistance, 2.f, 30.f, 0.5f, 1, "How far away the cinema screen is (metres). The size above stays the same; farther looks bigger and calmer.", apply));
    G(o.AddBool("Screen", "theater_fade", "Fade in and out", &g_set.theaterFade, "Fades in from black whenever a cutscene starts or ends.", apply));
    grp = "Flat screen";
    G(o.AddBool("Screen", "edge_fill", "Edge fill", &g_set.edgeFill, "Where the headset sees past the game's picture, the picture's rim is stretched outward with a blur instead of black.", apply));
    G(o.AddBool("Screen", "flat_pause_menus", "Flat screen in pause menus", &g_set.flatPauseMenus, "Menus, loading and video modes of the game are shown on the flat virtual screen instead of in 3D.", apply));
    G(o.AddBool("Screen", "flat_videos", "Flat screen for video cutscenes", &g_set.flatVideos, "Pre-rendered cutscenes (full-size Bink videos) on the flat screen. Small videos never switch.", apply));
    G(o.AddFloat("Screen", "screen_distance", "Screen distance", &g_set.screenDistance, 1.f, 10.f, 0.1f, 1, "Flat screen mode, loading screens and videos.", apply));
    G(o.AddFloat("Screen", "screen_width", "Screen width", &g_set.screenWidth, 1.f, 10.f, 0.1f, 1, "Metres.", apply));
    grp = "Panels";
    G(o.AddFloat("Screen", "menu_distance", "This menu's distance", &g_set.menuDistance, 0.5f, 4.f, 0.05f, 2, "Metres (in 3D).", apply));
    G(o.AddFloat("Screen", "menu_panel_width", "This menu's panel width", &g_set.menuPanelWidth, 0.4f, 3.f, 0.05f, 2, "Metres (in 3D).", apply));
    G(o.AddFloat("Screen", "menu_width", "Menu size on the panel", &g_set.menuWidth, 0.3f, 1.f, 0.05f, 2, "Fraction of the panel. On the flat screen and in the theater the menu keeps the same size in your view.", apply));
    G(o.AddFloat("Screen", "menu_opacity", "This menu's opacity", &g_set.menuOpacity, 0.25f, 1.f, 0.05f, 2, "1 = solid, lower = the game shows through.", apply));
    grp = "Desktop window";
    auto& mi = G(o.AddChoice("Screen", "mirror", "Monitor shows", &g_set.mirror, { "left", "game" }, "Left: the left eye (no flicker). Game: what the game draws (alternates between the eyes).", apply));
    mi.choiceLabels = { "Left eye", "The game" };
    G(o.AddBool("Screen", "vsync_off", "No vsync on the monitor", &g_set.vsyncOff, "The monitor's refresh rate does not cap VR frames.", apply));
    G(o.AddChoice("Screen", "hdr_input", "HDR input", &g_set.hdrInput, { "auto", "off", "pq", "scrgb" },
        "Auto: follows the game's output colour space (1.33 has HDR, and renders SDR in 10-bit too) and converts HDR for the headset. Off: always treated as SDR. HDR off in the game looks best.", apply)).choiceLabels = { "Automatic", "Off (SDR)", "HDR10 (PQ)", "scRGB" };
    G(o.AddChoice("Screen", "screenshot_view", "Screenshot (Delete)", &g_set.screenshotView, { "headset", "full" },
        "Delete saves the left eye as a PNG next to the game exe. Headset: exactly the image your headset shows. Full: the whole rendered picture.", apply));
    grp = "Start-up";
    G(o.AddBool("Screen", "force_windowed", "Always windowed (next start)", &g_set.forceWindowed,
        "The game runs windowed (its resolution.xml is set to windowed, exclusive fullscreen and Alt+Enter refused), so its window - and the picture - can be the headset's per-eye size.", apply)).needsRestart = true;
    G(o.AddBool("Screen", "run_in_background", "Keep running without focus", &g_set.runInBackground, "The game is not told that its window lost focus (the headset software has it in VR).", apply));

    // ================= Advanced
    grp = "Picture and frustum";
    G(o.AddFloat("Advanced", "view_width", "Picture width", &g_set.viewWidth, 0.7f, 1.3f, 0.01f, 2, "How wide the world looks. Above 1 = narrower (more of the picture squeezed in). 1 = exactly the headset's field of view.", apply));
    G(o.AddFloat("Advanced", "view_height", "Picture height", &g_set.viewHeight, 0.7f, 1.3f, 0.01f, 2, "How tall the world looks. Above 1 = flatter. 1 = the headset's own.", apply));
    auto& ev = G(o.AddChoice("Advanced", "eye_view", "Eye view", &g_set.eyeView, { "pixel", "canted", "matched", "own" },
        "Pixel perfect (default): each eye is drawn symmetric around its lens (the game's lights, flashlight, flares and shadows right in both eyes) and the part "
        "you see is exactly the headset's pixel grid, copied 1:1 - the render is wider by the strip the eye never shows (cheap with foveated rendering Unseen; "
        "the exact size applies from the start after the eyes' fields are first known). Canted: the headset's size, symmetric views turned to each eye "
        "(~91 %). Matched: the headset's size, symmetric around the lens (~79 % wide). Own: the eye's off-centre view (effects wrong).",
        [] { ApplyEyeView(); ResolutionSettingsChanged(); }));
    ev.choiceLabels = { "Pixel perfect", "Canted", "Matched", "Off-centre" }; ev.needsRestart = true;
    G(o.AddBool("Advanced", "wide_cull", "Wide culling (off-centre view only)", &g_set.wideCull,
        "On (default): the game decides what to draw from one symmetric view covering both eyes, while the picture is drawn with the eye's own off-centre view - nothing pops in at the outer sides and nothing extra is rendered.", apply));
    G(o.AddBool("Advanced", "symmetric_view", "One symmetric view for both eyes", &g_set.symmetricView,
        "Off (default): each eye is drawn with its own off-centre view. On: one symmetric view covering both eyes (more pixels drawn than shown).", apply));
    G(o.AddFloat("Advanced", "cull_margin", "FOV / culling margin", &g_set.cullMargin, 1.f, 1.6f, 0.01f, 2, "Renders (and culls) this much more than the headset shows. Raise it if objects pop at the edges.", apply));
    G(o.AddFloat("Advanced", "near_clip", "Near clip (m)", &g_set.nearClip, 0.f, 0.5f, 0.01f, 2, "How close to your eyes the game still draws (only ever closer than the game's). 0 = the game's own.", apply));
    G(o.AddFloat("Advanced", "units_per_metre", "Engine units per metre", &g_set.unitsPerMetre, 0.1f, 200.f, 0.1f, 1, "Calibration: leaning 10 cm should move the view 10 cm. Alan Wake uses metres (1.0).", apply));
    grp = "Eye alignment";
    G(o.AddFloat("Advanced", "aer_align_h", "Eye align sideways", &g_set.aerAlignH, -10.f, 10.f, 0.1f, 1, "Alternate eye / synchronized: degrees (+ apart, - together).", apply)).visible = aerOrSync;
    G(o.AddFloat("Advanced", "aer_align_v", "Eye align up / down", &g_set.aerAlignV, -5.f, 5.f, 0.1f, 1, "Alternate eye / synchronized: degrees the left eye moves up, the right down.", apply)).visible = aerOrSync;
    G(o.AddInt("Advanced", "sync_lag", "Synchronized: clock lag", &g_set.syncLag, -1, 2, 1, "-1 = automatic. Which game tick a picture belongs to. If moving characters do not match between the eyes, try 0, 1 or 2.", apply)).visible = is("synced");
    grp = "Render size and timing";
    G(o.AddChoice("Advanced", "render_resolution", "Render resolution", &g_set.renderResolution, { "auto", "game" },
        "auto: exactly the headset's per-eye size x render scale, written to the game's resolution.xml at start. game: the game's own setting.")).needsRestart = true;
    G(o.AddChoice("Advanced", "headset_smoothing", "Headset smoothing", &g_set.headsetSmoothing, { "full", "runtime", "repeat" },
        "Full rate (default): every headset frame gets a fresh image on time, the runtime's motion smoothing never switches on. Runtime: the headset's own smoothing fills in when the game is slower. Repeat: the newest frame every headset frame.", apply));
    G(o.AddInt("Advanced", "max_frame_latency", "Frames queued ahead", &g_set.maxFrameLatency, 0, 4, 1, "1-2 = the freshest head pose in each frame. 0 = the game's own. Only if the game's swap chain allows it (the log says).")).needsRestart = true;
    grp = "Fine tuning";
    G(o.AddChoice("Advanced", "ui_layers", "UI layers (automatic)", &g_set.uiLayers, { "one", "all" }, "With the picker at 0: One = only the layer bound last; All = every full-screen UI layer.", apply));
    G(o.AddChoice("Advanced", "hud_split", "Where the UI starts", &g_set.hudSplit, { "auto", "count", "all" },
        "auto: after the first full-screen pass that puts the 3D picture into the final image. count: after the number of draws below. all: every draw into the final image is UI.", apply));
    G(o.AddInt("Advanced", "hud_scene_draws", "3D draws before the UI", &g_set.hudSceneDraws, 0, 8, 1, "Only for 'count'.", apply));
    G(o.AddFloat("Advanced", "offset_step_cm", "Offset step (cm per press)", &g_set.offsetStepCm, 1.f, 30.f, 1.f, 0, "How far one press moves the camera / first-person offsets. Default 3 cm.")).needsRestart = true;
    G(o.AddInt("Advanced", "flat_video_min_width", "Video cutscene: minimum width", &g_set.flatVideoMinWidth, 640, 3840, 64, "Videos at least this wide count as cutscenes (pixels).", apply));
    G(o.AddChoice("Advanced", "panel_layers", "Panels shown as", &g_set.panelLayers, { "auto", "composite", "quad" },
        "How this menu, the HUD panel and the flat screen reach the headset. Drawn into the picture works on every headset; separate layers are sharper. Auto: drawn in on Pimax, layers elsewhere.", apply));
    G(o.AddFloat("Advanced", "hdr_paper_white", "HDR paper white (nits)", &g_set.hdrPaperWhite, 80.f, 500.f, 10.f, 0, "HDR input only.", apply));

    HotkeysRegister();   // the "Hotkeys" tab, last

    // display names for every choice that has none (the config keeps the short values)
    struct L { const char* key; std::vector<std::string> names; };
    static const L labels[] = {
        { "screenshot_view", { "Headset view", "Full picture" } }, { "fov_mode", { "Off", "Unseen only", "Quality", "Balanced", "Performance", "Custom" } },
        { "render_resolution", { "From the headset", "The game's" } },
        { "render_density", { "Headset", "Fixed", "Sharp" } }, { "headset_smoothing", { "Full rate", "Runtime", "Repeat" } },
        { "ui_layers", { "One", "All" } }, { "hud_split", { "Automatic", "After N draws", "Everything" } },
        { "panel_layers", { "Automatic", "Drawn in", "Separate layers" } } };
    for (auto& op : o.All())
        if (op.type == vrkit::OptType::Choice && op.choiceLabels.empty())
            for (auto& l : labels) if (op.key == l.key && l.names.size() == op.choices.size()) op.choiceLabels = l.names;

    DiagConfigSnapshot();
    vrkit::menu::Settings s;
    s.title = "Alan Wake Remastered VR";
    s.configPath = g_cfgPath;
    s.backgroundAlpha = g_set.menuOpacity;
    s.statusLine = [] {
        char b[256];
        static const char* names[] = { "Synchronized", "Alternate eye", "Head", "Flat screen", "True stereo" };
        int m = EngineEffectiveMode();
        bool nsOff = g_set.vrMode == "native" && m != VRMODE_NATIVE;   // fell back (see the log)
        int sp = SetupProblemCount(); char setup[48] = ""; if (sp > 0) snprintf(setup, sizeof setup, "   SETUP: %d problem%s (log)", sp, sp == 1 ? "" : "s");
        snprintf(b, sizeof b, "%.0f fps   %s   %s%s%s%s   v" AWRVR_VERSION, g_fps, nsOff ? "Synced - fallback" : m >= 0 && m < VRMODE_COUNT ? names[m] : "?",
                 GameStateName(GameStateNow()), *UpscalerStatus() ? "   " : "", UpscalerStatus(), setup);
        return std::string(b);
    };
    s.input.keyboardToggleVk = VK_INSERT;
    return s;
}

static void MenuInit(ID3D11Device* dev, ID3D11DeviceContext* ctx) {
    g_menuInit = true;
    vrkit::SetLog([](const char* m) { LOGI("vrkit: %s", m); });
    vrkit::menu::Settings s = MenuRegister();
    auto& o = vrkit::Options::Get();
    bool ok = vrkit::menu::Init(dev, ctx, s);
    if (!ok) g_menuFailed = true;
    LOGI("menu: %s (%ux%u), %zu options", ok ? "ready - Insert or L3+R3" : "init FAILED", vrkit::menu::Width(), vrkit::menu::Height(), o.All().size());
}

ID3D11Texture2D* MenuUpdate(ID3D11Device* dev, ID3D11DeviceContext* ctx) {
    if (!dev || !ctx || g_menuFailed) return nullptr;
    if (!g_menuInit) MenuInit(dev, ctx);
    if (g_menuFailed) return nullptr;
    bool wasOpen = vrkit::menu::IsOpen();
    if (wasOpen) {   // the mouse moves the panel's cursor, clicks and scrolls
        vrkit::menu::core::Mouse m; PanelMouseTake(&m.dx, &m.dy, &m.wheel, &m.left, &m.right);
        vrkit::menu::core::FeedMouse(m);
    }
    bool open = vrkit::menu::Update();
    PanelMouseSetActive(open);
    if (open != wasOpen) LOGI("menu: %s", open ? "opened" : "closed");
    return open ? vrkit::menu::Texture() : nullptr;
}
