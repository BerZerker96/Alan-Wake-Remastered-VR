#pragma once
// Everything in the game exe besides the camera (engine.cpp): found by name or code pattern at run time.
//   * Northlight tweakables ("Camera:Near", "TAA:Jitter Scale", ...): global objects registered by name; the value
//     sits at the offset the registration code stores its default to.
//   * Renderer debug switches ("TAA", "Render Vector Blur", "Film grain", "Use Umbra", ...): bytes bound to the
//     debug menu by name.
//   * The main loop's frame timer (synchronized stereo), the game's own frame limiter, the mode classes
//     (game / menu / loading / video / credits), the focus-event handler, the player camera's offsets
//     (first person), the player global, Bink video imports.
#include <windows.h>
#include <cstdint>

enum GameState { GS_UNKNOWN = 0, GS_GAMEPLAY, GS_MENU, GS_LOADING, GS_VIDEO, GS_CREDITS };

struct GameFound {
    // tweakables (value pointers)
    float* camNear = nullptr; float* camFov = nullptr; float* taaJitter = nullptr; float* vignette = nullptr;
    uint8_t* vbEnable = nullptr; uint8_t* vbForce = nullptr; uint8_t* taaResolve = nullptr;
    float* camPos[4] = {};                 // Camera:High / Mid / Low / Safe Pos (vec3: value +B0, min +BC, max +C8)
    uint8_t* safeEnable = nullptr; float* safeX = nullptr; float* safeY = nullptr;   // Safe Area: Tweak enable / X / Y
    float* camCatch = nullptr; float* camAngle = nullptr; float* camModernVel = nullptr;   // first person
    // renderer debug switches
    uint8_t* dbgTaa = nullptr; uint8_t* dbgVectorBlur = nullptr; uint8_t* dbgFilmGrain = nullptr; uint8_t* dbgFilmGrainD3t = nullptr;
    uint8_t* dbgUmbra = nullptr; uint8_t* dbgCinematicMode = nullptr; uint8_t* dbgVsync = nullptr; uint8_t* dbgAA = nullptr;
    // code
    void* frameTimer = nullptr; void* timerLap = nullptr; uint8_t* limiterJump = nullptr;
    void** playerGlobal = nullptr; int playerCharOff = -1;
    int pivotCompOff = -1, pivotHeightOff = -1;   // camera pivot height: character->[comp]->[height]
    bool modesHooked = false, focusHooked = false, binkHooked = false;
};
extern GameFound g_game;

bool GameScan();                       // init thread, after ScanInit
void GameApplySettings();              // writes the game switches from g_set (also once per second, they can be reset)
GameState GameStateNow();              // from the mode classes' per-frame updates
const char* GameStateName(GameState s);
bool GameTaaOn();                       // the game's TAA switch is on (false when not found)
bool GameVideoPlaying(int minWidth);   // a Bink video at least this wide decoded in the last 0.5 s
void GameReport();

// synchronized stereo: the next frame-timer lap of the main loop is held (tiny dt, the real time is banked)
void GameClockHoldNext(bool hold);
bool GameClockLastWasHeld();
uint32_t GameTicks();                  // main-loop ticks seen (frame timer laps)

// first person through the player camera's offsets (gameplay camera only)
void GameFirstPerson(bool on, float x, float y, float z);
float GameFirstPersonLift();          // first person: eye height minus the camera pivot height (m), 0 if off / unknown
void GameNoteWorldLift();             // engine: the lift was applied along world up this frame
