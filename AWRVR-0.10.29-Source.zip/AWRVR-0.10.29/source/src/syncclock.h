#pragma once
// Synchronized stereo: holding the game clock for the second eye of a tick (header-only, unit tested).
// The game's frame-time function (exe+1df8d0 in 1.33) steps the world by the AVERAGE of the previous N lap samples
// (ring of 4, samples clamped to 0.1 s) and feeds the raw lap to other clocks. A held frame must be tiny in both, so
// while synchronized the ring is one entry long and the mod writes that entry together with the lap it returns.
struct SyncClock {
    double bank = 0;                           // real time owed from held frames
    int banked = 0;                            // frames in the bank
    double heldSum = 0;                        // world time the held frames already stepped (counted against the limits)
    static constexpr double kHeldFrac = 1.0 / 32;   // the held tick keeps 1/32 of its time (never ~0: speed = distance / time)
    // real: the timer's own lap (a speed hack scales it - that is the game speed and it is kept); hold: this tick is
    // the second eye; ring: the game's dt ring (1 entry) or null. A tick spans the frames it banked, so the game's own
    // per-frame limits (0.1 s per sample, 0.25 s per lap) are allowed once per frame - the world moves exactly as fast
    // as without the mod at any speed-hack factor.
    double Lap(double real, bool hold, float* ring) {
        if (hold) { double h = real * kHeldFrac; if (h > 0.004) h = 0.004; if (h < 1e-5) h = 1e-5;
                    bank += real - h; banked++; heldSum += h; if (ring) ring[0] = (float)h; return h; }   // the rest is paid back on the next tick
        int frames = banked + 1;
        double total = real + bank, held = heldSum; bank = 0; banked = 0; heldSum = 0;
        if (total < 0) total = 0;
        double lapMax = 0.25 * frames - held, ringMax = 0.1 * frames - held;
        if (lapMax < 0) lapMax = 0; if (ringMax < 0) ringMax = 0;
        if (total > lapMax) total = lapMax;
        if (ring) ring[0] = (float)(total < ringMax ? total : ringMax);
        return total;
    }
};
