#pragma once
// Every user setting (keys = awrvr_config.txt keys). Defaults follow the framework guide's option set (deep dive J/M),
// adapted to Alan Wake Remastered; options the game has no hook for are left out (see README "not applicable").
#include <string>

struct VrSettings {
    // ---- View
    std::string vrMode = "native";            // vr_mode: synced | native | aer | head | screen
    float worldScale = 1.f;                   // world_scale
    float ipdScale = 1.f;                     // ipd_scale
    bool swapEyes = false;                    // swap_eyes
    std::string syncSubmit = "pair";          // sync_submit: pair | each
    bool cameraReprojection = false;          // camera_reprojection
    int aerFrameDelay = 0;                    // aer_frame_delay (0 = automatic)
    // ---- Camera
    std::string headAim = "always";           // head_aim: off | always | aiming (while L2 / LT / right mouse is held)
    bool headAimFromEyes = true;              // head_aim_from_eyes: shots start at the eyes (else Alan's shoulder, the game's)
    float headAimSmooth = 0.3f;               // head_aim_smoothing (0..1: tremor filter, ~45 ms at 0.3)
    bool decoupledPitch = true;               // decoupled_pitch
    float cameraStabilize = 0.35f;            // camera_stabilize
    float cameraSettle = 1.0f;                // camera_settle
    float camOffsetX = 0, camOffsetY = 0, camOffsetZ = 0;   // camera_offset_x/y/z (m)
    bool firstPerson = false;                 // first_person
    float fpOffsetX = 0.f, fpOffsetY = 0.f, fpOffsetZ = 0.60f;   // fp_offset_x/y/z (m; Y: fine-tune on top of fp_eye_height)
    float fpEyeHeight = 0.60f;                // fp_eye_height (calibrated in the headset: 0.60 with Eye Z 0.60; 0 = Eye Y is the offset from the camera pivot)
    float fpSmooth = 0.6f;                    // fp_smooth
    std::string cutsceneMode = "theater";     // cutscene_mode: theater (flat cinema screen) | 3d (in the scene)
    float theaterSize = 100.f;                // theater_size (degrees of your view the screen covers, 40 .. 170)
    float theaterDistance = 10.f;             // theater_distance (m)
    bool theaterFade = true;                  // theater_fade (fade in from black on every 3D <-> theater switch)
    float cameraShake = 0.f;                  // camera_shake (0 = none in VR, 1 = the game's)
    bool stereoDiag = true;                   // stereo_diagnostics (log the renderer view renders every 10 s)
    std::string actionCameras = "off";       // action_cameras: off (VR: no camera swing in dodge / melee slow-motion moments) | game
    float fpNearClip = 0.f;                   // fp_near_clip (m; 0 = the game's own, 0.2 - hides the inside of Alan's head)
    // ---- HUD
    std::string hudMode = "scale";            // hud_mode: scale | panel | off
    float uiScale = 0.42f; float hudSafeX = 0.22f, hudSafeY = 0.20f;   // hud_safe_x / hud_safe_y (hud_mode = safe)                    // ui_scale
    float uiDepth = 1.3f;                     // ui_depth (m)
    float uiOffsetY = -0.03f;                 // ui_offset_y
    bool hideHud = false;                     // hide_hud
    int uiPick = 0;                           // ui_pick
    // ---- Graphics
    std::string gameAA = "game";              // game_aa: game | off | on
    bool motionBlurOff = true;                // motion_blur_off
    bool filmGrainOff = true;                 // film_grain_off
    bool upscalerFreshEyes = false;           // upscaler_fresh_each_eye: DLSS & co. never blend one eye into the other (reset flag)
    bool vignetteOff = true;                  // vignette_off
    float sharpen = 0.f;                      // sharpen
    float renderScale = 1.f;                  // render_scale (restart)
    bool noBlackBars = false;                 // no_black_bars (experimental)
    bool occlusionCulling = true;             // occlusion_culling
    bool stereoOcclusion = true;              // true_stereo_occlusion (keep occlusion culling on in true stereo)
    // ---- Screen
    bool edgeFill = true;                     // edge_fill
    bool flatPauseMenus = true;               // flat_pause_menus
    bool flatVideos = true;                   // flat_videos
    float screenDistance = 2.7f, screenWidth = 3.1f;          // screen_distance / screen_width
    float menuDistance = 1.05f, menuPanelWidth = 1.10f, menuWidth = 0.80f;
    std::string mirror = "left";              // mirror: left | game
    bool vsyncOff = true;                     // vsync_off
    std::string hdrInput = "auto";            // hdr_input: auto (the game's colour space) | off | pq | scrgb
    std::string screenshotView = "headset";   // screenshot_view: headset | full
    bool forceWindowed = true;                // force_windowed (next start)
    bool runInBackground = true;              // run_in_background
    // ---- Advanced
    bool fpsUnlocked = false;                 // fps_unlocked
    std::string fpsLimit = "headset";         // fps_limit: headset | 0
    float headsetRefreshHz = 0.f;             // headset_refresh_hz
    std::string fovMode = "unseen";           // fov_mode: off | unseen | quality | balanced | performance | custom
    float fovInner = 0.6f, fovOuter = 1.0f, fovWide = 1.25f;  // fov_inner / fov_outer / fov_wide
    bool fovDebug = false;                    // fov_debug
    float viewWidth = 1.f, viewHeight = 1.f;  // view_width / view_height
    bool wideCull = true;                     // wide_cull
    bool symmetricView = false;               // symmetric_view
    std::string eyeView = "pixel";            // eye_view: pixel | canted | matched | own (sets the three below)
    bool pixelPerfect = true;                 // pixel_perfect: matched view, the render grown so each eye's shown part is exactly the headset's pixel grid (copied 1:1)
    bool cantedView = false;                   // canted_view: each eye a symmetric frustum turned to the middle of its field (effects right, full density)
    bool matchedView = true;                  // matched_view (each eye: the symmetric frustum around its lens axis, the game's own projection)
    float cullMargin = 1.0f;                  // cull_margin
    float nearClip = 0.1f;                    // near_clip (m, 0 = the game's)
    float unitsPerMetre = 1.f;                // units_per_metre
    float aerAlignH = 0, aerAlignV = 0;       // aer_align_h / _v (deg)
    int syncLag = -1;                         // sync_lag
    std::string renderResolution = "auto";    // render_resolution: auto | game | WxH (restart)
    std::string renderDensity = "headset";    // render_density: headset | fixed (restart)
    std::string headsetSmoothing = "full";    // headset_smoothing: full | runtime | repeat
    int maxFrameLatency = 2;                  // max_frame_latency
    std::string uiLayers = "one";             // ui_layers: all | one
    std::string hudSplit = "auto";            // hud_split: auto | count | all
    int hudSceneDraws = 1;                    // hud_scene_draws
    float offsetStepCm = 3.f;                 // offset_step_cm
    int flatVideoMinWidth = 1280;             // flat_video_min_width
    std::string panelLayers = "auto";         // panel_layers: auto | composite | quad
    float hdrPaperWhite = 200.f;              // hdr_paper_white
    std::string gameFrameCap = "game";        // game_frame_cap: game | off
    // ---- config file only
    std::string cameraAxes = "+0+1+2";        // camera_axes (rows right, up, forward)
    int renderMaxSide = 8192;                 // render_max_side
    int pacedTimeoutMs = 100;                 // paced_timeout_ms
    std::string recenterKey = "F9", screenshotKey = "DELETE", fpKey = "END";
    bool cameraHooks = true, uiHooks = true, xrOutput = true;  // camera_hooks / ui_hooks / xr_output
    float menuOpacity = 0.25f;                // menu_opacity (0.25 = the lowest: the game shows through most)
    std::string uiPickSig;                    // ui_pick_sig
    std::string hostMode = "thread";          // host_mode: thread (in-process OpenXR) | exe (XrBridgeHost.exe)
    bool staticRefresh = true;                // static_camera_refresh
};
extern VrSettings g_set;
// near clip in use: first person has its own (0 = the game's), else near_clip (only ever closer than the game's)
inline float EffectiveNearClip() { return g_set.firstPerson ? g_set.fpNearClip : g_set.nearClip; }
void SettingsLoad();
void SettingsApply();
void SettingsSave();
const char* ModeName(int m);
