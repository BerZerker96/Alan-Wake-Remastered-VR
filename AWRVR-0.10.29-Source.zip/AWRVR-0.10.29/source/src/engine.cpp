// Northlight camera hooks for Alan Wake Remastered (see NOTES.md for the research).
//  * rend::PerspectiveView (RTTI) vtable slot 2 = getProjection(double out[16]); lens fields read from its code:
//    +0 horizontal FOV, +4 zoom, +8 aspect, +C near, +10 far. Culling, shadows and the screen-space effects (light
//    shafts, flares, AO, the focus blur) read the fields directly, the picture's projection comes from getProjection.
//    Matched view (default): the fields get exactly the eye's frustum (symmetric around the lens axis) and the game's
//    own getProjection result is used as it is - every consumer sees the same projection. Off-centre view (option):
//    fields = wide covering frustum, getProjection patched to the eye's own off-centre frustum (guide 6.3).
//  * Every camera move funnels through the node's setTransform(const double m[12]); for the rendered view the mod
//    replaces the matrix by: clean game camera -> camera axes -> decoupled pitch -> shake filter -> idle-sway lock ->
//    offsets -> head / eye pose (guide 6.1).
//  * Methods: synchronized (game clock held for the second eye, game.cpp), alternate eye, head (mono), flat screen.
#include "engine.h"
#include "scratchpad.h"
bool ResolutionPixelScale(double* sx, double* sy); void ResolutionNoteFov(const float t[2][4]);   // resolution.cpp
#include "headaim.h"
#include "scan.h"
#include "log.h"
#include "vrmath.h"
#include "comfort.h"
#include "settings.h"
#include "game.h"
#include "MinHook.h"
#include <cmath>
#include <cstring>
#include <atomic>
#include "realclock.h"
#include <string>

extern std::wstring g_modDir;
// ---- true stereo (native): the renderer's per-view render, RendererD3D12 vtable slot 10 (exe+508970 in 1.33). It takes
// the view in rdx (kept in r14), stores the TAA jitter (exe+46c090), rebuilds the view's lazy matrices (exe+46c890) and
// renders the whole view - scene, shadows, effects, post - through exe+5090b0. Register arguments only, the return value
// is unused by its one caller (exe+4a661b). In true stereo the mod calls it twice per frame: first eye, second eye.
using RenderViewFn = void* (*)(void*, void*, void*, void*);
namespace { RenderViewFn o_renderView = nullptr; }
void NsMarker(bool set);
static void NsSafetyInstall();



namespace {
struct Offsets { int fov = -1, zoom = -1, aspect = -1, nearp = -1, farp = -1, dirty = -1, xform = -1; } g_off;
void* g_getProjFn = nullptr;
bool g_ready = false;

using GetProjFn = void* (*)(void*, double*);
using SetXfFn = void* (*)(void*, const double*);
using SetFloatFn = void (*)(void*, float);
GetProjFn o_getProj = nullptr;
constexpr int kMaxXfHooks = 3;
SetXfFn o_setXf[kMaxXfHooks] = {};
void* g_setXfTarget[kMaxXfHooks] = {};
int g_setXfCount = 0;
SetFloatFn o_setFov = nullptr, o_setAspect = nullptr;

std::atomic<void*> g_main{nullptr};
std::atomic<LONG> g_presents{0};
DWORD g_presentTid = 0;
std::atomic<DWORD> g_camTid{0};
float g_bbAspect = 16.f / 9.f;
std::atomic<bool> g_flatNow{false};

// ---- headset poses (Present thread -> camera hook)
SRWLOCK g_poseLock = SRWLOCK_INIT;
struct PoseCache {
    bool valid = false; xrb::IpcPose pose[2]; xrb::IpcFov fov[2]; int64_t time = 0;
    Tan4 eye[2];                 // per-eye tangents
    float hullH[2], hullV[2];    // per eye: symmetric hull (x cull margin)
    float wideH = 1, wideV = 1;  // both eyes' symmetric hull (wide culling), x cull margin
    float centreH = 1, centreV = 1;   // head-frame covering frustum (head / recon), +2 %
    float cant[2][2]{};          // canted views: per eye yaw, pitch (radians) to the middle of its field
    float cantH[2]{1, 1}, cantV[2]{1, 1};   // the symmetric frustum around that axis covering the eye's field, x cull margin
    float ipd = 0.064f;
} g_poses;

// ---- frame records (camera thread -> Present)
struct FrameRec { std::atomic<uint32_t> target{0xFFFFFFFF}; FrameInfo fi; };
constexpr int kRing = 64;
FrameRec g_ring[kRing];
thread_local FrameInfo* t_lastRec = nullptr;
// latest record set for the main view (the projection rebuilt for it belongs to its current transform)
SRWLOCK g_recLock = SRWLOCK_INIT; FrameInfo g_mainRec; bool g_haveMainRec = false; uint32_t g_recSeq = 0;
// render snapshots: the game clones the camera view into a frame allocator every frame (vtable slot 1, shared by every
// camera class); each clone of the main view carries the record that was current when it was taken
using CloneFn = void* (*)(void*, void*);
CloneFn o_clone = nullptr;
struct CloneRec { std::atomic<void*> view{nullptr}; FrameInfo fi; };
constexpr int kClones = 32;
CloneRec g_clones[kClones]; std::atomic<uint32_t> g_cloneNext{0};
// exact eye at Present: the record of the clone rebuilt last on the thread that presents
thread_local FrameInfo t_renderRec; thread_local bool t_renderRecValid = false; thread_local LONG t_renderRecPresent = -1;
int g_lagHist[4] = {}; int g_measuredLag = -1;
std::atomic<DWORD> g_cineTick{0};
std::atomic<uint32_t> s_clones{0}, s_cloneProj{0}, s_exact{0}, s_byCount{0}, s_dirtyForced{0};
FrameInfo g_lastShown; int g_lastShownAge = 1000;
std::atomic<int> g_doubleUpd{0};

// ---- true stereo state
std::atomic<long> g_nsCount{0}; std::atomic<void*> g_nsView{nullptr}; std::atomic<DWORD> g_nsTid{0};
std::atomic<uint32_t> s_nsBadBase{0}, s_nsXfDuring{0};                  // true stereo: pairs skipped for a broken camera record
std::atomic<int> g_nsPhase{-1};                       // eye being recorded by the renderer (D3D12 hooks read it)
std::atomic<LONGLONG> g_nsPhaseSince{0};              // when the current eye render started (watchdog)
thread_local int t_nsEye = -1; thread_local void* t_nsView = nullptr; thread_local FrameInfo t_nsRec;
std::atomic<uint32_t> s_nsPadBlocks{0}, s_nsPadKept{0};   // scratch pad: the first render's blocks taken back / not
std::atomic<uint32_t> s_nsPairs{0}, s_nsSkipped{0}, s_nsCaptured{0}, s_nsMissed{0};
std::atomic<bool> g_nativeFailed{false}; char g_nativeWhy[200] = "";
std::atomic<LONG> g_nsPairPresent{-1};   // Present count when the last pair finished (the HUD follows it)
int g_nativeMissRun = 0; LONG g_nativeLastPair = 0; LONG g_nativeWaitSince = -1;
std::atomic<long> g_nsPairsTotal{0}; bool g_nsMarkerSet = false;


// ---- camera state
SRWLOCK g_xfLock = SRWLOCK_INIT;
struct LastXf { void* view = nullptr; Xf base{}, out{}; bool valid = false; int hook = 0; } g_last;
std::atomic<LONG> g_lastSetPresent{-1};
thread_local int t_inHook = 0;
V3 g_upAvg{0, 1, 0}, g_worldUp{0, 1, 0};
Stabilizer g_stab; BobFilter g_fpBob; Settler g_settle;
LARGE_INTEGER g_qpf, g_lastFilterT{};
Xf g_syncBase{}; bool g_haveSyncBase = false; uint32_t g_syncTick = 0;
Xf g_prevBase{}; bool g_havePrev = false; double g_prevT = 0; float g_angVel[3]{};
int g_axes[3] = {0, 1, 2}; double g_axSign[3] = {1, 1, 1};

struct Lens { void* view = nullptr; float fov, zoom, aspect, nearp; bool valid = false; } g_savedLens;
std::atomic<bool> g_restoreLens{false};

struct Cand { void* p; void* vt; uint32_t calls; LONG lastPresent; float fov, aspect, farp; };
constexpr int kCands = 24;
Cand g_cands[kCands];
SRWLOCK g_candLock = SRWLOCK_INIT;
LONG g_mainLastSeen = -1000;

std::atomic<uint32_t> s_getProj{0}, s_getProjMain{0}, s_setXf{0}, s_setXfMain{0}, s_applied{0}, s_feedback{0}, s_refresh{0},
    s_lensWrites{0}, s_setFovMain{0}, s_insane{0}, s_projPatched{0}, s_projEyeUnknown{0}, s_flatState{0};
uint32_t s_presentsVr = 0, s_presentsReuse = 0, s_presentsFlat = 0;
char g_eyesDrawn[48] = {}; int g_eyesDrawnN = 0;
char g_status[200] = "engine: not ready";

inline float* Field(void* v, int off) { return (float*)((uint8_t*)v + off); }
bool IsView(void* p) {
    if (!p || !Readable(p, 8)) return false;
    void** vt = *(void***)p;
    return Readable(vt, 3 * sizeof(void*)) && vt[2] == g_getProjFn;
}
bool LensSane(void* v) {
    if (g_off.fov < 0 || !Readable(Field(v, g_off.fov), 20)) return false;
    float f = *Field(v, g_off.fov), a = *Field(v, g_off.aspect), n = *Field(v, g_off.nearp), fa = *Field(v, g_off.farp);
    return f > 0.05f && f < 3.1f && a > 0.2f && a < 6.f && n > 0.f && fa > n;
}
bool GetPoses(PoseCache& out) { AcquireSRWLockShared(&g_poseLock); out = g_poses; ReleaseSRWLockShared(&g_poseLock); return out.valid; }
// canted views (engine.h): on for per-eye pictures unless one symmetric view is chosen
bool Canted() { return g_set.cantedView && !g_set.symmetricView; }

int Mode() {
    // (stereo reconstruction was removed in 0.9.0: configs naming it are moved to synced at load)
    int m = g_set.vrMode == "aer" ? VRMODE_AER : g_set.vrMode == "head" ? VRMODE_HEAD : g_set.vrMode == "screen" ? VRMODE_SCREEN
          : g_set.vrMode == "native" ? VRMODE_NATIVE : VRMODE_SYNCED;
    if (m == VRMODE_NATIVE && (!o_renderView || g_nativeFailed.load(std::memory_order_relaxed))) m = VRMODE_SYNCED;   // falls back
    if (m == VRMODE_SYNCED && !g_game.frameTimer) m = VRMODE_AER;
    return m;
}
bool StereoPerEye(int m) { return m == VRMODE_SYNCED || m == VRMODE_AER; }

int EffectiveLag() {
    int set = Mode() == VRMODE_SYNCED ? g_set.syncLag : g_set.aerFrameDelay - 1;   // aer_frame_delay 0 = automatic
    if (set >= 0) return set;
    if (g_measuredLag >= 0) return g_measuredLag;   // measured from exactly matched frames
    DWORD ct = g_camTid.load();
    return (ct && ct == g_presentTid) ? 0 : 1;
}

// lens (fields) the main view gets: the culling frustum
void LensFor(const PoseCache& pc, int mode, int eye, float* tH, float* tV) {
    if (mode == VRMODE_HEAD || g_set.symmetricView || eye < 0) { *tH = pc.centreH; *tV = pc.centreV; }
    else if (Canted()) { *tH = pc.cantH[eye]; *tV = pc.cantV[eye]; }                 // = the picture (turned): every consumer agrees
    else if (g_set.matchedView) { *tH = pc.hullH[eye]; *tV = pc.hullV[eye]; }      // = the picture: every consumer agrees
    else if (g_set.wideCull) { *tH = pc.wideH; *tV = pc.wideV; }
    else { *tH = pc.hullH[eye]; *tV = pc.hullV[eye]; }
    *tH *= g_set.viewWidth; *tV *= g_set.viewHeight;
}
void ApplyLens(void* v, float tH, float tV) {
    if (g_off.fov < 0) return;
    if (g_savedLens.view != v) {
        g_savedLens = Lens{ v, *Field(v, g_off.fov), *Field(v, g_off.zoom), *Field(v, g_off.aspect), *Field(v, g_off.nearp), true };
        LOGI("camera: node projection - the game's own: fov %.1f deg (horizontal), zoom %.3f, aspect %.3f, near %.3f, far %.1f",
             g_savedLens.fov * 57.2958f, g_savedLens.zoom, g_savedLens.aspect, g_savedLens.nearp, *Field(v, g_off.farp));
    }
    float fov = 2.f * atanf(tH), aspect = tH / tV;
    // the near plane is never written here: a near written into the view alone makes depth and lighting disagree
    // (seen in GOTGVR). A closer near goes through the game's own Camera:Near setting (game.cpp), which the game
    // applies everywhere itself.
    float *pf = Field(v, g_off.fov), *pz = Field(v, g_off.zoom), *pa = Field(v, g_off.aspect);
    if (*pf != fov || *pz != 1.f || *pa != aspect) {
        *pf = fov; *pz = 1.f; *pa = aspect;
        if (g_off.dirty >= 0) *(volatile uint16_t*)((uint8_t*)v + g_off.dirty) = 0;
        s_lensWrites++;
    }
}
void RestoreLens() {
    if (!g_savedLens.valid || !IsView(g_savedLens.view)) { g_savedLens = Lens{}; return; }
    void* v = g_savedLens.view;
    *Field(v, g_off.fov) = g_savedLens.fov; *Field(v, g_off.zoom) = g_savedLens.zoom;
    *Field(v, g_off.aspect) = g_savedLens.aspect;
    if (g_off.dirty >= 0) *(volatile uint16_t*)((uint8_t*)v + g_off.dirty) = 0;
    LOGI("camera: the game's projection restored on view %p", v);
    g_savedLens = Lens{};
}

void UpdateWorldUp(const Xf& b) {
    g_upAvg = g_upAvg * 0.995 + b.r[1] * 0.005;
    double ax = fabs(g_upAvg.x), ay = fabs(g_upAvg.y), az = fabs(g_upAvg.z);
    V3 up = ay >= ax && ay >= az ? V3{0, g_upAvg.y > 0 ? 1.0 : -1.0, 0} : ax >= az ? V3{g_upAvg.x > 0 ? 1.0 : -1.0, 0, 0} : V3{0, 0, g_upAvg.z > 0 ? 1.0 : -1.0};
    if (up.x != g_worldUp.x || up.y != g_worldUp.y || up.z != g_worldUp.z) { g_worldUp = up; LOGI("camera: world up axis (%.0f %.0f %.0f)", up.x, up.y, up.z); }
}

xrb::IpcPose CenterPose(const PoseCache& pc) {
    xrb::IpcPose c = pc.pose[0]; const xrb::IpcPose &a = pc.pose[0], &b = pc.pose[1];
    c.px = (a.px + b.px) * 0.5f; c.py = (a.py + b.py) * 0.5f; c.pz = (a.pz + b.pz) * 0.5f;
    float d = a.qx * b.qx + a.qy * b.qy + a.qz * b.qz + a.qw * b.qw, s = d < 0 ? -1.f : 1.f;
    float qx = a.qx + s * b.qx, qy = a.qy + s * b.qy, qz = a.qz + s * b.qz, qw = a.qw + s * b.qw, l = sqrtf(qx * qx + qy * qy + qz * qz + qw * qw);
    if (l > 1e-6f) { c.qx = qx / l; c.qy = qy / l; c.qz = qz / l; c.qw = qw / l; }
    return c;
}
xrb::IpcPose ScaleIpd(xrb::IpcPose p, const xrb::IpcPose& centre, float k) {
    p.px = centre.px + (p.px - centre.px) * k; p.py = centre.py + (p.py - centre.py) * k; p.pz = centre.pz + (p.pz - centre.pz) * k;
    return p;
}

// game rows -> canonical (right, up, forward) through camera_axes, and back
Xf AxesIn(const Xf& g) { Xf c = g; for (int i = 0; i < 3; i++) c.r[i] = g.r[g_axes[i]] * g_axSign[i]; return c; }
Xf AxesOut(const Xf& c) { Xf g = c; for (int i = 0; i < 3; i++) g.r[g_axes[i]] = c.r[i] * g_axSign[i]; return g; }

double Now() { LARGE_INTEGER t; rc::Qpc(&t); return double(t.QuadPart) / double(g_qpf.QuadPart); }

void TrackAngVel(const Xf& b) {
    double t = Now();
    if (g_havePrev && t - g_prevT > 1e-4 && t - g_prevT < 0.25) {
        // relative rotation in the camera's frame: components of the new axes in the old frame
        double dt = t - g_prevT; V3 w{0, 0, 0};
        w.x = (Dot(b.r[2], g_prevBase.r[1]) - Dot(b.r[1], g_prevBase.r[2])) * 0.5 / dt;
        w.y = (Dot(b.r[0], g_prevBase.r[2]) - Dot(b.r[2], g_prevBase.r[0])) * 0.5 / dt;
        w.z = (Dot(b.r[1], g_prevBase.r[0]) - Dot(b.r[0], g_prevBase.r[1])) * 0.5 / dt;
        // camera-local LH -> OpenXR (pseudo-vector under the z flip), scene turns opposite to the camera
        g_angVel[0] = (float)w.x; g_angVel[1] = (float)w.y; g_angVel[2] = (float)-w.z;
    }
    g_prevBase = b; g_prevT = t; g_havePrev = true;
}

void* SetXfCommon(int hook, void* self, const double* m) {
    s_setXf++;
    SetXfFn orig = o_setXf[hook];
    // true stereo: the game moving the view while one eye of it renders keeps that eye's transform (never the centre
    // halfway through an eye: half of its passes would be drawn from another place)
    if (t_nsEye >= 0 && self == t_nsView && !t_inHook) {
        s_nsXfDuring++;
        const xrb::IpcPose& ep = t_nsRec.eyePose[t_nsEye];
        float q[4] = { ep.qx, ep.qy, ep.qz, ep.qw }, p[3] = { ep.px, ep.py, ep.pz };
        CantQuat(q, t_nsRec.eyePicCant[t_nsEye]);
        double md[12]; XfToDoubles(AxesOut(Compose(EyeFromXr(q, p, t_nsRec.worldScale), XfFromDoubles(t_nsRec.camBase))), md);
        t_inHook++; void* r = orig(self, md); t_inHook--; return r;
    }
    if (self != g_main.load(std::memory_order_relaxed) || t_inHook || !g_set.cameraHooks) return orig(self, m);
    s_setXfMain++;
    Xf game = XfFromDoubles(m);
    if (!XfSane(game)) { s_insane++; return orig(self, m); }
    {
        AcquireSRWLockShared(&g_xfLock);
        bool fb = g_last.valid && g_last.view == self && XfNear(game, g_last.out, 1e-9) && !XfNear(g_last.base, g_last.out, 1e-9);
        if (fb) game = g_last.base;
        ReleaseSRWLockShared(&g_xfLock);
        if (fb) s_feedback++;
    }
    Xf base = AxesIn(game);
    UpdateWorldUp(base);
    g_camTid.store(GetCurrentThreadId(), std::memory_order_relaxed);
    auto remember = [&](const Xf& out) {
        AcquireSRWLockExclusive(&g_xfLock); g_last.view = self; g_last.base = game; g_last.out = out; g_last.valid = true; g_last.hook = hook; ReleaseSRWLockExclusive(&g_xfLock);
        g_lastSetPresent.store(g_presents.load());
    };
    PoseCache pc;
    int mode = Mode();
    GameState gs = GameStateNow();
    // in-engine cutscenes: the game draws them through its CinematicCamera class -> the theater screen
    bool cine = RttiIs(self, ".?AVCinematicCamera@@");
    if (cine) g_cineTick = rc::TickMs();
    bool flatState = g_flatNow || (g_set.flatPauseMenus && (gs == GS_MENU || gs == GS_LOADING || gs == GS_VIDEO || gs == GS_CREDITS)) ||
                     (cine && g_set.cutsceneMode == "theater");
    if (mode == VRMODE_SCREEN || flatState || !GetPoses(pc)) {
        if (flatState) s_flatState++;
        GameClockHoldNext(false);
        if (g_savedLens.view == self) g_restoreLens = true;
        remember(game);
        return orig(self, m);
    }
    LONG now = g_presents.load();
    uint32_t target = (uint32_t)(now + EffectiveLag());

    // comfort filters on the game camera (never on the head pose)
    // The game sets its camera several times per frame (~7 in 1.33). The filters step ONCE per game frame: the first
    // call of a frame saves their state and the frame's time step; later calls of the same frame start again from that
    // state with the newest camera - so the filter sees one sample per frame, the last one the game set.
    static uint32_t s_fFrame = 0xFFFFFFFF; static double s_fDt = 0.011;
    static Stabilizer s_stabPre; static Settler s_setPre; static BobFilter s_bobPre;
    static Xf s_frameLast{}; static bool s_haveFrameLast = false;
    uint32_t fkey = GameTicks() ? GameTicks() : (uint32_t)g_presents.load();
    double dt;
    if (fkey != s_fFrame) {
        double t = Now(); dt = g_lastFilterT.QuadPart ? t - double(g_lastFilterT.QuadPart) / double(g_qpf.QuadPart) : 0.011;
        LARGE_INTEGER tq; rc::Qpc(&tq); g_lastFilterT = tq;
        s_fFrame = fkey; s_fDt = dt; s_stabPre = g_stab; s_setPre = g_settle; s_bobPre = g_fpBob;
        if (s_haveFrameLast) TrackAngVel(s_frameLast);   // the previous frame's final camera: one sample per frame
    } else { dt = s_fDt; g_stab = s_stabPre; g_settle = s_setPre; g_fpBob = s_bobPre; }
    s_frameLast = base; s_haveFrameLast = true;
    Xf b = base;
    bool held = false; int eye = -1; uint32_t tick = GameTicks();
    if (mode == VRMODE_SYNCED) {
        held = GameClockLastWasHeld() && g_haveSyncBase;
        if (held) b = g_syncBase;          // the second eye of a tick uses the first eye's camera
    }
    if (!held) {
        if (g_set.decoupledPitch) b = LevelBasis(b, g_worldUp);
        if (g_set.firstPerson) {
            // eye height: along world up (not the camera's tilted up axis), player camera only (cutscene cameras untouched)
            float lift = GameFirstPersonLift();
            if (lift != 0.f && RttiIs(self, ".?AVPlayerCamera@@")) { b.p = b.p + g_worldUp * (double)(lift * g_set.unitsPerMetre); GameNoteWorldLift(); }
            b.p = g_fpBob.Step(b.p, g_worldUp, dt, g_set.fpSmooth);
        }
        b = g_stab.Step(b, dt, g_set.cameraStabilize);
        if (g_worldUp.y > 0.5) b = g_settle.Step(b, g_set.cameraSettle);
        double ws = (g_set.worldScale > 0.05f ? g_set.worldScale : 1.0) * g_set.unitsPerMetre;
        b.p = b.p + b.r[0] * (g_set.camOffsetX * ws) + b.r[1] * (g_set.camOffsetY * ws) + b.r[2] * (g_set.camOffsetZ * ws);
        if (mode == VRMODE_SYNCED) { g_syncBase = b; g_haveSyncBase = true; g_syncTick = tick; }
    }
    // which eye / view this frame is
    // (swap_eyes is applied once, when the eye images are sent - the same for every method)
    if (mode == VRMODE_SYNCED) eye = held ? 1 : 0;
    else if (mode == VRMODE_AER) eye = (int)(target & 1);
    xrb::IpcPose centre = CenterPose(pc);
    xrb::IpcPose e0 = ScaleIpd(pc.pose[0], centre, g_set.ipdScale), e1 = ScaleIpd(pc.pose[1], centre, g_set.ipdScale);
    xrb::IpcPose used = eye == 0 ? e0 : eye == 1 ? e1 : centre;

    double ws = (g_set.worldScale > 0.05f ? g_set.worldScale : 1.0) * g_set.unitsPerMetre;
    float q[4] = { used.qx, used.qy, used.qz, used.qw }, p[3] = { used.px, used.py, used.pz };
    // head aim: the drawn base and the head (centre) it is drawn with. The main view is the render camera
    // (.?AVBaseCamera@@ in this game, not the PlayerCamera object, which is a separate view the game never draws)
    if (!held) {
        float hq[4] = { centre.qx, centre.qy, centre.qz, centre.qw }, hp[3] = { centre.px, centre.py, centre.pz };
        HeadAimNoteBase(b, ws, hq, hp, base);
    }
    bool cant = Canted() && StereoPerEye(mode) && eye >= 0;
    if (cant) CantQuat(q, pc.cant[eye]);              // canted view: the eye turned to the middle of its field
    Xf out = Compose(EyeFromXr(q, p, ws), b);
    Xf gameOut = AxesOut(out);
    double md[12]; XfToDoubles(gameOut, md);

    // picture frustum
    FrameInfo fi;
    fi.vr = true; fi.mode = mode; fi.eye = eye; fi.held = held; fi.tick = tick; fi.pose = used; fi.time = pc.time;
    fi.eyePose[0] = e0; fi.eyePose[1] = e1; fi.eyeFov[0] = pc.fov[0]; fi.eyeFov[1] = pc.fov[1];
    fi.worldScale = ws; memcpy(fi.angVel, g_angVel, sizeof g_angVel);
    float lh, lv; LensFor(pc, mode, eye, &lh, &lv);
    if (cant) {
        fi.pic = { -pc.cantH[eye] * g_set.viewWidth, pc.cantH[eye] * g_set.viewWidth, pc.cantV[eye] * g_set.viewHeight, -pc.cantV[eye] * g_set.viewHeight };
        fi.picCant[0] = pc.cant[eye][0]; fi.picCant[1] = pc.cant[eye][1];   // symmetric: the game's own projection = the fields
    } else if (StereoPerEye(mode) && !g_set.symmetricView && !g_set.matchedView && eye >= 0) {
        Tan4 t4 = pc.eye[eye];
        fi.pic = { t4.l * g_set.viewWidth, t4.r * g_set.viewWidth, t4.u * g_set.viewHeight, t4.d * g_set.viewHeight };
        fi.projPatched = true;                       // off-centre view: getProjection patched, fields = culling
    } else fi.pic = { -lh, lh, lv, -lv };            // matched / symmetric / head: the game's own projection = the fields
    if (mode == VRMODE_NATIVE) {
        // both eyes are rendered from this one record; each eye gets its own frustum when the renderer draws it
        for (int e = 0; e < 2; e++) {
            Tan4 t4 = Canted() ? Tan4{ -pc.cantH[e], pc.cantH[e], pc.cantV[e], -pc.cantV[e] }
                    : g_set.matchedView || g_set.symmetricView ? Tan4{ -pc.hullH[e], pc.hullH[e], pc.hullV[e], -pc.hullV[e] } : pc.eye[e];
            fi.eyePic[e] = { t4.l * g_set.viewWidth, t4.r * g_set.viewWidth, t4.u * g_set.viewHeight, t4.d * g_set.viewHeight };
            if (Canted()) { fi.eyePicCant[e][0] = pc.cant[e][0]; fi.eyePicCant[e][1] = pc.cant[e][1]; }
        }
        XfToDoubles(b, fi.camBase);
    }
    if (g_off.nearp >= 0) { fi.nearZ = *Field(self, g_off.nearp); fi.farZ = *Field(self, g_off.farp); }
    if (EffectiveNearClip() > 0.f && EffectiveNearClip() < fi.nearZ) fi.nearZ = EffectiveNearClip();

    fi.presentAtSet = now;
    AcquireSRWLockExclusive(&g_recLock); fi.seq = ++g_recSeq; g_mainRec = fi; g_haveMainRec = true; ReleaseSRWLockExclusive(&g_recLock);
    FrameRec& r = g_ring[target % kRing];
    if (r.target.load() == target) g_doubleUpd++;
    r.target.store(0xFFFFFFFF, std::memory_order_release);
    r.fi = fi;
    r.target.store(target, std::memory_order_release);
    t_lastRec = &r.fi;

    if (mode == VRMODE_SYNCED) GameClockHoldNext(!held && (gs == GS_GAMEPLAY || gs == GS_UNKNOWN));
    else GameClockHoldNext(false);
    remember(gameOut);
    ApplyLens(self, lh, lv);
    // The game rebuilds a view's projection only when its projection-dirty byte is clear (exe+46c120, called from the
    // matrix builder exe+46c500), and setTransform clears only the view-dirty byte: without this the per-eye off-centre
    // projection would not be recomputed each frame (both eyes would get the same one).
    if (g_off.dirty >= 0 && fi.projPatched) { *(volatile uint16_t*)((uint8_t*)self + g_off.dirty) = 0; s_dirtyForced++; }
    s_applied++;
    t_inHook++;
    void* ret = orig(self, md);
    t_inHook--;
    return ret;
}
template <int I> void* H_SetXf(void* self, const double* m) { return SetXfCommon(I, self, m); }
SetXfFn kSetXfDetours[kMaxXfHooks] = { &H_SetXf<0>, &H_SetXf<1>, &H_SetXf<2> };

void NoteCandidate(void* self) {
    LONG now = g_presents.load(std::memory_order_relaxed);
    AcquireSRWLockExclusive(&g_candLock);
    int freeI = -1, oldest = 0;
    for (int i = 0; i < kCands; i++) {
        if (g_cands[i].p == self) {
            if (g_cands[i].lastPresent != now) { g_cands[i].calls = 0; g_cands[i].lastPresent = now; }
            g_cands[i].calls++;
            g_cands[i].fov = *Field(self, g_off.fov); g_cands[i].aspect = *Field(self, g_off.aspect); g_cands[i].farp = *Field(self, g_off.farp);
            ReleaseSRWLockExclusive(&g_candLock); return;
        }
        if (!g_cands[i].p && freeI < 0) freeI = i;
        if (g_cands[i].lastPresent < g_cands[oldest].lastPresent) oldest = i;
    }
    int i = freeI >= 0 ? freeI : oldest;
    g_cands[i] = Cand{ self, *(void**)self, 1, now, *Field(self, g_off.fov), *Field(self, g_off.aspect), *Field(self, g_off.farp) };
    ReleaseSRWLockExclusive(&g_candLock);
}

// the record of the frame this thread is setting up / rendering
const FrameInfo* RecordForThisThread() {
    if (GetCurrentThreadId() == g_camTid.load() && t_lastRec) return t_lastRec;
    LONG now = g_presents.load();
    FrameRec& r = g_ring[(uint32_t)now % kRing];
    return r.target.load(std::memory_order_acquire) == (uint32_t)now ? &r.fi : nullptr;
}

const FrameInfo* CloneRecord(void* v, FrameInfo* tmp) {
    for (auto& c : g_clones) if (c.view.load(std::memory_order_acquire) == v) { *tmp = c.fi; if (c.view.load(std::memory_order_acquire) == v) return tmp; }
    return nullptr;
}
const FrameInfo* MainRecord(FrameInfo* tmp) {
    AcquireSRWLockShared(&g_recLock); bool ok = g_haveMainRec; if (ok) *tmp = g_mainRec; ReleaseSRWLockShared(&g_recLock);
    return ok ? tmp : nullptr;
}
void PatchProjection(double* out, const FrameInfo* rec) {
    const Tan4& t = rec->pic;
    out[0] = 2.0 / (t.r - t.l); out[8] = -(t.r + t.l) / (t.r - t.l);
    out[5] = 2.0 / (t.u - t.d); out[9] = -(t.u + t.d) / (t.u - t.d);
    out[1] = out[2] = out[4] = out[6] = 0;
}

void* H_GetProj(void* self, double* out) {
    s_getProj++;
    bool isMain = false;
    // true stereo: the renderer rebuilding the view it draws for one eye (exe+46c890 on the render thread). Matched
    // view: the lens fields already hold this eye's frustum, the game's own matrix is used; else patched off-centre.
    if (t_nsEye >= 0 && self == t_nsView && out) {
        t_inHook++; void* r = o_getProj(self, out); t_inHook--;
        if (!Canted() && !g_set.matchedView && !g_set.symmetricView) { FrameInfo e = t_nsRec; e.pic = t_nsRec.eyePic[t_nsEye]; PatchProjection(out, &e); s_projPatched++; }
        t_renderRec = t_nsRec; t_renderRecValid = true; t_renderRecPresent = g_presents.load();
        return r;
    }
    // a render snapshot (clone) of the main view: patch it with the record it was taken with; remember it for Present
    if (!t_inHook && out && Mode() != VRMODE_SCREEN) {
        FrameInfo tmp; const FrameInfo* crec = self != g_main.load(std::memory_order_relaxed) ? CloneRecord(self, &tmp) : nullptr;
        if (crec) {
            t_inHook++; void* r = o_getProj(self, out); t_inHook--;
            if (crec->vr && crec->projPatched) { PatchProjection(out, crec); s_projPatched++; }
            t_renderRec = *crec; t_renderRecValid = true; t_renderRecPresent = g_presents.load(); s_cloneProj++;
            return r;
        }
    }
    if (!t_inHook && LensSane(self)) {
        NoteCandidate(self);
        isMain = self == g_main.load(std::memory_order_relaxed);
        if (isMain) {
            s_getProjMain++;
            if (g_restoreLens.exchange(false)) RestoreLens();
            PoseCache pc;
            int mode = Mode();
            const FrameInfo* rec = RecordForThisThread();
            if (mode != VRMODE_SCREEN && rec && rec->vr && GetPoses(pc)) {
                float lh, lv; LensFor(pc, rec->mode, rec->eye, &lh, &lv); ApplyLens(self, lh, lv);
                LONG now = g_presents.load();
                if (g_set.staticRefresh && g_lastSetPresent.load() != now && g_camTid.load() == GetCurrentThreadId()) {
                    double md[12]; int hook = -1;
                    AcquireSRWLockShared(&g_xfLock);
                    if (g_last.valid && g_last.view == self) { XfToDoubles(g_last.base, md); hook = g_last.hook; }
                    ReleaseSRWLockShared(&g_xfLock);
                    if (hook >= 0) { s_refresh++; SetXfCommon(hook, self, md); rec = RecordForThisThread(); }
                }
            }
        }
    }
    t_inHook++;
    void* r = o_getProj(self, out);
    t_inHook--;
    if (isMain && out && Mode() != VRMODE_SCREEN) {
        // the projection rebuilt now belongs to the view's current transform: the latest record set for it
        FrameInfo tmp; const FrameInfo* rec = MainRecord(&tmp);
        if (rec && rec->vr && rec->projPatched) { PatchProjection(out, rec); s_projPatched++; }
        else if (rec == nullptr && StereoPerEye(Mode()) && !g_set.symmetricView) s_projEyeUnknown++;
        // the renderer updating the main view itself on its own thread (exe+46c890): this record is the frame it draws
        if (rec && rec->vr && GetCurrentThreadId() != g_camTid.load()) { t_renderRec = *rec; t_renderRecValid = true; t_renderRecPresent = g_presents.load(); }
    }
    return r;
}

void* H_Clone(void* self, void* alloc) {
    // still-camera refresh: the snapshot is taken once per frame; if the game did not move its camera this frame, the
    // head pose is applied again from the last game transform first (camera thread only)
    if (!t_inHook && self == g_main.load(std::memory_order_relaxed) && g_set.staticRefresh && g_set.cameraHooks &&
        g_lastSetPresent.load() != g_presents.load() && g_camTid.load() == GetCurrentThreadId() && Mode() != VRMODE_SCREEN) {
        double md[12]; int hook = -1;
        AcquireSRWLockShared(&g_xfLock);
        if (g_last.valid && g_last.view == self) { XfToDoubles(g_last.base, md); hook = g_last.hook; }
        ReleaseSRWLockShared(&g_xfLock);
        if (hook >= 0) { s_refresh++; SetXfCommon(hook, self, md); }
    }
    void* r = o_clone(self, alloc);
    if (!r || t_inHook) return r;
    if (LensSane(self)) NoteCandidate(self);           // clones are taken once per frame: the busiest is the camera
    if (self == g_main.load(std::memory_order_relaxed) && g_set.cameraHooks && Mode() != VRMODE_SCREEN) {
        FrameInfo tmp; const FrameInfo* rec = MainRecord(&tmp);
        if (rec && rec->vr) {
            CloneRec& c = g_clones[g_cloneNext.fetch_add(1) % kClones];
            c.view.store(nullptr, std::memory_order_release); c.fi = *rec; c.view.store(r, std::memory_order_release);
            // rebuild the snapshot's matrices from its own copy (its projection gets this record's eye)
            if (g_off.dirty >= 0 && rec->projPatched) *(volatile uint16_t*)((uint8_t*)r + g_off.dirty) = 0;
            s_clones++;
        }
    }
    return r;
}


// true stereo: draw the view once per eye. Each eye gets its transform through the game's own setTransform, its frustum
// through the lens fields (matched view: everything the renderer derives - culling, shadows, effects - is that eye's)
// and a forced rebuild of the lazy matrices. The view is put back to the centre afterwards.
void NsEyeSetup(void* view, const FrameInfo& rec, const Xf& base, int hook, int eye, bool lens) {
    const xrb::IpcPose& ep = eye >= 0 ? rec.eyePose[eye] : rec.pose;
    float q[4] = { ep.qx, ep.qy, ep.qz, ep.qw }, p[3] = { ep.px, ep.py, ep.pz };
    if (eye >= 0) CantQuat(q, rec.eyePicCant[eye]);    // canted views (zero otherwise)
    double md[12]; XfToDoubles(AxesOut(Compose(EyeFromXr(q, p, rec.worldScale), base)), md);
    t_inHook++; o_setXf[hook](view, md); t_inHook--;
    if (lens && eye >= 0) { const Tan4& t = rec.eyePic[eye]; ApplyLens(view, fmaxf(-t.l, t.r), fmaxf(t.u, -t.d)); }
    *(volatile uint16_t*)((uint8_t*)view + g_off.dirty) = 0;   // projection and view rebuilt
}
void* H_RenderView(void* renderer, void* view, void* a, void* b) {
    g_nsCount.fetch_add(1, std::memory_order_relaxed); g_nsView.store(view, std::memory_order_relaxed); g_nsTid.store(GetCurrentThreadId(), std::memory_order_relaxed);
    if (t_nsEye >= 0 || Mode() != VRMODE_NATIVE || !g_set.cameraHooks || !view || g_off.dirty < 0 || g_setXfCount == 0) return o_renderView(renderer, view, a, b);
    FrameInfo tmp; const FrameInfo* rec = view == g_main.load(std::memory_order_relaxed) ? MainRecord(&tmp) : CloneRecord(view, &tmp);
    if (!rec || !rec->vr || rec->mode != VRMODE_NATIVE || !IsView(view)) { if (rec) s_nsSkipped++; return o_renderView(renderer, view, a, b); }
    // the live main view (not a snapshot) is only moved from the thread that moves it anyway (no race with the game)
    if (view == g_main.load(std::memory_order_relaxed) && GetCurrentThreadId() != g_camTid.load()) { s_nsSkipped++; return o_renderView(renderer, view, a, b); }
    int hook = 0;
    AcquireSRWLockShared(&g_xfLock); if (g_last.valid && g_last.hook >= 0 && g_last.hook < g_setXfCount) hook = g_last.hook; ReleaseSRWLockShared(&g_xfLock);
    // the game camera this record was made from: finite, with a sane rotation part - never draw from a broken matrix
    // (NaN / zero transforms make NaN frustums: lighting and culling can fail badly)
    {
        bool ok = true; double rs = 0;
        for (int i = 0; i < 12 && ok; i++) ok = std::isfinite(rec->camBase[i]) && fabs(rec->camBase[i]) < 1e7;
        for (int i = 0; i < 9 && ok; i++) rs += rec->camBase[i] * rec->camBase[i];
        if (!ok || rs < 0.3 || rs > 30.0) { s_nsSkipped++; s_nsBadBase++; return o_renderView(renderer, view, a, b); }
    }
    t_nsRec = *rec; t_nsView = view;
    Xf base = XfFromDoubles(rec->camBase);
    bool lens = Canted() || g_set.matchedView || g_set.symmetricView;
    long n = g_nsPairsTotal.load();
    bool trace = n < 3;                                            // the first pairs are logged step by step, flushed
    if (n == 0) NsMarker(true);
    void* r = nullptr;
    for (int k = 0; k < 2; k++) {
        t_nsEye = k;
        NsEyeSetup(view, *rec, base, hook, k, lens);
        LARGE_INTEGER t0; rc::Qpc(&t0); g_nsPhaseSince = t0.QuadPart;
        g_nsPhase.store(k, std::memory_order_release);
        if (trace) { LOGI("true stereo: pair %ld eye %d render start (view %p)", n, k, view); LogFlushDisk(); }
        ScratchMark mark; bool marked = k == 0 && ScratchPadMark(&mark);
        r = o_renderView(renderer, view, a, b);
        if (marked) {   // the first render's leftovers on the scratch pad (its result is not the caller's)
            int got = ScratchPadRelease(mark);
            if (got > 0) s_nsPadBlocks += got; else if (got < 0) s_nsPadKept++;
        }
        if (trace) { LOGI("true stereo: pair %ld eye %d render done", n, k); LogFlushDisk(); }
    }
    g_nsPhase.store(-1, std::memory_order_release);
    // back to the centre view and the culling lens (the main view keeps being used by the game after this)
    t_nsEye = -1;
    NsEyeSetup(view, *rec, base, hook, -1, false);
    { PoseCache pc; if (lens && GetPoses(pc)) { float lh, lv; LensFor(pc, VRMODE_NATIVE, -1, &lh, &lv); ApplyLens(view, lh, lv); } }
    t_nsView = nullptr;
    s_nsPairs++; g_nativeLastPair = g_presents.load(); g_nsPairPresent.store(g_presents.load(), std::memory_order_release);
    if (g_nsPairsTotal.fetch_add(1) + 1 == 600) NsMarker(false);  // 600 good pairs: the game takes it
    return r;
}

void H_SetFov(void* self, float v) {
    if (self == g_main.load(std::memory_order_relaxed) && g_savedLens.view == self) { s_setFovMain++; g_savedLens.fov = v; return; }
    o_setFov(self, v);
}
void H_SetAspect(void* self, float v) {
    if (self == g_main.load(std::memory_order_relaxed) && g_savedLens.view == self) { g_savedLens.aspect = v; return; }
    o_setAspect(self, v);
}

// ---------------------------------------------------------------- locating
bool HasBytes(uint8_t* fn, size_t len, std::initializer_list<uint8_t> op, int disp) {
    uint8_t b[8]; size_t n = 0; for (uint8_t x : op) b[n++] = x; memcpy(b + n, &disp, 4); n += 4;
    return FindBytes(fn, len, b, n) != nullptr;
}
bool FindGetProjection() {
    void** vt = RttiVtable(".?AVPerspectiveView@rend@@");
    uint8_t* fn = nullptr;
    if (vt) { fn = (uint8_t*)vt[2]; LOGI("sig PerspectiveView vtable exe+%x, getProjection (slot 2) exe+%x", Rva(vt), Rva(fn)); }
    else { auto h = ScanText("48 89 5C 24 08 57 48 83 EC ?? F3 0F 10 81 ?? ?? ?? ?? 48 8B DA 0F 5A C0", 4); if (h.size() == 1) fn = h[0];
           LOGW("camera: PerspectiveView RTTI not found; getProjection pattern hits %zu", h.size()); }
    if (!fn || !InText(fn)) return false;
    uint8_t ld[4] = { 0xF3, 0x0F, 0x10, 0x81 };
    uint8_t* at = FindBytes(fn, 0x24, ld, 4);
    if (!at) { LOGE("camera: getProjection does not start with a lens load"); return false; }
    int fov = ReadI32(at + 4), ok = 0;
    ok += HasBytes(fn, 0x220, { 0xF3, 0x0F, 0x10, 0xBF }, fov + 8);
    ok += HasBytes(fn, 0x220, { 0xF3, 0x0F, 0x5C, 0x87 }, fov + 0xC);
    ok += HasBytes(fn, 0x220, { 0xF3, 0x0F, 0x10, 0x8F }, fov + 0x10);
    ok += HasBytes(fn, 0x220, { 0xF3, 0x0F, 0x10, 0x87 }, fov + 4);
    LOGI("camera: lens fields at +%x (fov, zoom +4, aspect +8, near +C, far +10): %d of 4 layout checks", fov, ok);
    if (ok < 2 || fov <= 0 || fov > 0x10000) { LOGE("camera: lens layout not confirmed"); return false; }
    g_off.fov = fov; g_off.zoom = fov + 4; g_off.aspect = fov + 8; g_off.nearp = fov + 0xC; g_off.farp = fov + 0x10;
    g_getProjFn = fn;
    return true;
}
void FindSetters() {
    char pat[128];
    auto mk = [&](int f) { snprintf(pat, sizeof pat, "F3 0F 11 89 %02X %02X %02X %02X 66 C7 81 ?? ?? ?? ?? 00 00 C3", f & 0xFF, (f >> 8) & 0xFF, (f >> 16) & 0xFF, (f >> 24) & 0xFF); return ScanText(pat, 4); };
    auto f = mk(g_off.fov), a = mk(g_off.aspect);
    if (f.size() == 1) { g_off.dirty = ReadI32(f[0] + 11); if (MH_CreateHook(f[0], (void*)&H_SetFov, (void**)&o_setFov) == MH_OK) MH_EnableHook(f[0]); }
    if (a.size() == 1) { g_off.dirty = ReadI32(a[0] + 11); if (MH_CreateHook(a[0], (void*)&H_SetAspect, (void**)&o_setAspect) == MH_OK) MH_EnableHook(a[0]); }
    if (g_off.dirty < 0 || g_off.dirty > 0x10000) g_off.dirty = -1;
    LOGI("sig setFov %s, setAspect %s, lens dirty word +%x", o_setFov ? "hooked" : "-", o_setAspect ? "hooked" : "-", g_off.dirty < 0 ? 0 : g_off.dirty);
}
void AddSetXf(uint8_t* fn, const char* how) {
    if (!fn || !InText(fn)) return;
    for (int i = 0; i < g_setXfCount; i++) if (g_setXfTarget[i] == fn) return;
    if (g_setXfCount >= kMaxXfHooks) return;
    int i = g_setXfCount;
    if (MH_CreateHook(fn, (void*)kSetXfDetours[i], (void**)&o_setXf[i]) != MH_OK || MH_EnableHook(fn) != MH_OK) { LOGE("camera: setTransform hook at exe+%x failed", Rva(fn)); return; }
    g_setXfTarget[i] = fn; g_setXfCount++;
    LOGI("sig NodeSetTransform exe+%x (%s)", Rva(fn), how);
}
bool FindSetTransform() {
    auto a = ScanText("48 8B C4 48 81 EC ?? ?? ?? ?? F3 0F 10 81 ?? ?? ?? ?? 48 8D 50 ?? F3 0F 10 89 ?? ?? ?? ?? 0F 5A C0 0F 5A C9", 8);
    for (uint8_t* p : a) {
        int x0 = ReadI32(p + 14), x1 = ReadI32(p + 26);
        if (x1 != x0 + 4) continue;
        g_off.xform = x0;
        for (uint8_t* q = p + 30; q < p + 0x200; q++)
            if (q[0] == 0xE8 && q[5] == 0x48 && q[6] == 0x81 && q[7] == 0xC4) { LOGI("sig CameraApplyTransform exe+%x (transform +%x)", Rva(p), x0); AddSetXf(Rel32Target(q), "from applyTransform"); break; }
    }
    if (g_setXfCount == 0)
        for (uint8_t* p : ScanText("48 89 5C 24 08 48 89 7C 24 10 55 48 8B EC 48 83 EC ?? 48 8B 02 48 8D 99 ?? ?? ?? ?? 48 89 81 ?? ?? ?? ?? 48 8B F9", 8)) AddSetXf(p, "prologue pattern");
    return g_setXfCount > 0;
}
void ParseAxes() {
    const std::string& s = g_set.cameraAxes;
    int k = 0;
    for (size_t i = 0; i + 1 < s.size() && k < 3; i += 2) {
        if ((s[i] != '+' && s[i] != '-') || s[i + 1] < '0' || s[i + 1] > '2') break;
        g_axSign[k] = s[i] == '-' ? -1 : 1; g_axes[k] = s[i + 1] - '0'; k++;
    }
    if (k != 3) { g_axes[0] = 0; g_axes[1] = 1; g_axes[2] = 2; g_axSign[0] = g_axSign[1] = g_axSign[2] = 1; }
}
} // namespace

bool EngineInstall() {
    rc::Qpf(&g_qpf);
    if (!ScanInit()) return false;
    ParseAxes();
    if (!FindGetProjection() || MH_CreateHook(g_getProjFn, (void*)&H_GetProj, (void**)&o_getProj) != MH_OK || MH_EnableHook(g_getProjFn) != MH_OK) {
        LOGE("camera: getProjection NOT hooked - VR camera disabled (flat screen only)"); return false;
    }
    FindSetters();
    if (void** vt = RttiVtable(".?AVPerspectiveView@rend@@")) {
        uint8_t* cl = (uint8_t*)vt[1];
        // check: it allocates the view's size and copies the lens fields
        bool ok = InText(cl) && FindBytes(cl, 0xC0, (const uint8_t*)"\x8B\x87", 2) != nullptr;
        if (ok && MH_CreateHook(cl, (void*)&H_Clone, (void**)&o_clone) == MH_OK && MH_EnableHook(cl) == MH_OK) LOGI("sig ViewClone (slot 1) exe+%x hooked", Rva(cl));
        else LOGW("camera: view clone not hooked - eye matching by frame count only");
    }
    {
        // the renderer's per-view render (true stereo). Checked: it keeps the view (rdx) in r14 near its start and calls
        // the view's matrix update with it (mov rcx,r14 ; call) - else true stereo is unavailable (falls back to synced)
        void** rv = RttiVtable(".?AVRendererD3D12@rend@@");
        uint8_t* f = rv ? (uint8_t*)rv[10] : nullptr;
        bool ok = f && InText(f) && FindBytes(f, 0x60, (const uint8_t*)"\x4C\x8B\xF2", 3) != nullptr &&
                  FindBytes(f, 0x600, (const uint8_t*)"\x49\x8B\xCE\xE8", 4) != nullptr;
        if (ok && MH_CreateHook(f, (void*)&H_RenderView, (void**)&o_renderView) == MH_OK && MH_EnableHook(f) == MH_OK)
            { LOGI("sig RendererRenderView (slot 10) exe+%x hooked - true stereo available", Rva(f)); NsSafetyInstall(); }
        else { o_renderView = nullptr; LOGW("true stereo: the renderer's view render was not found - vr_mode native falls back to synced"); }
    }
    if (!FindSetTransform()) { LOGE("camera: node setTransform NOT found - head tracking disabled (flat screen only)"); return false; }
    g_ready = true;
    snprintf(g_status, sizeof g_status, "camera ready (lens +%x)", g_off.fov);
    return true;
}
bool EngineReady() { return g_ready; }

// ---- true stereo: state, safety net and diagnostics
static std::atomic<bool> g_native3d{false};
void EngineNoteNative3d(bool on) { g_native3d = on; }
bool EngineNative3d() { return g_native3d.load(); }
DWORD EngineNativeThread() { return g_nsTid.load(std::memory_order_relaxed); }
int EngineNativePhase() { return g_nsPhase.load(std::memory_order_acquire); }
bool EngineNativePairDone() { return g_nsPairPresent.load(std::memory_order_acquire) == g_presents.load(); }   // both eyes of this frame are drawn
bool EngineNativeAvailable() { return o_renderView && !g_nativeFailed.load(); }
const char* EngineNativeState() {
    if (!o_renderView) return "not available (renderer view render not found)";
    if (g_nativeFailed.load()) return g_nativeWhy;
    return g_set.vrMode == "native" ? "active" : "available";
}
static void NativeFail(const char* why) {
    if (g_nativeFailed.exchange(true)) return;
    snprintf(g_nativeWhy, sizeof g_nativeWhy, "off: %s - using synced", why);
    LOGW("true stereo: %s - falling back to synced (choose another method and True stereo again to retry)", why);
}
void EngineNativeResult(bool captured) {
    if (captured) { s_nsCaptured++; g_nativeMissRun = 0; return; }
    s_nsMissed++;
    if (++g_nativeMissRun >= 120) NativeFail("the first eye's picture never reached the back buffer while it rendered (the game finishes its picture after both renders on this build)");
}
// A marker file is written when the first pair is drawn and removed after 600 good pairs or at a clean exit. Found at
// start: the game stopped (freeze / crash) while true stereo ran - it stays off until it is chosen again.
static std::wstring NsMarkerPath() { return g_modDir + L"\\truestereo_running.txt"; }
void NsMarker(bool set) {
    if (g_modDir.empty()) return;
    if (set) {
        HANDLE f = CreateFileW(NsMarkerPath().c_str(), GENERIC_WRITE, 0, nullptr, CREATE_ALWAYS, 0, nullptr);
        if (f != INVALID_HANDLE_VALUE) { const char* t = "true stereo started; if this file is still here at the next start, the game stopped while it ran\r\n"; DWORD w; WriteFile(f, t, (DWORD)strlen(t), &w, nullptr); CloseHandle(f); }
        g_nsMarkerSet = true;
    } else if (g_nsMarkerSet) { DeleteFileW(NsMarkerPath().c_str()); g_nsMarkerSet = false; LOGI("true stereo: %ld eye pairs drawn - the game takes it", g_nsPairsTotal.load()); }
}
// the GPU device was lost (removed / hung): the game cannot go on. If true stereo was drawing, the marker is set again
// so the next start falls back to synced, and the log says so.
void EngineNoteDeviceRemoved(long hr) {
    static std::atomic<bool> once{false};
    if (once.exchange(true)) return;
    bool ns = g_set.vrMode == "native" && !g_nativeFailed.load() && g_nsPairsTotal.load() > 0;
    LOGE("d3d12: the GPU device was lost (reason %08lx)%s - please send this log", (unsigned long)hr,
         ns ? " while true stereo ran: it will be off at the next start (choose it again to retry)" : "");
    if (ns && !g_nsMarkerSet) NsMarker(true);
    LogFlushDisk();
}
void EngineShutdown() { if (g_nsMarkerSet) DeleteFileW(NsMarkerPath().c_str()); }
static void NsAddr(void* a, char* out, size_t n) {
    HMODULE m = nullptr; wchar_t path[MAX_PATH] = L"?";
    if (GetModuleHandleExW(GET_MODULE_HANDLE_EX_FLAG_FROM_ADDRESS | GET_MODULE_HANDLE_EX_FLAG_UNCHANGED_REFCOUNT, (LPCWSTR)a, &m) && m) GetModuleFileNameW(m, path, MAX_PATH);
    const wchar_t* b = wcsrchr(path, L'\\'); b = b ? b + 1 : path;
    snprintf(out, n, "%ls+%llx", b, (unsigned long long)((uint8_t*)a - (uint8_t*)m));
}
static LONG CALLBACK NsVeh(EXCEPTION_POINTERS* e) {
    static std::atomic<int> reported{0};
    DWORD c = e->ExceptionRecord->ExceptionCode;
    bool fatal = c == EXCEPTION_ACCESS_VIOLATION || c == EXCEPTION_ILLEGAL_INSTRUCTION || c == EXCEPTION_STACK_OVERFLOW || c == EXCEPTION_INT_DIVIDE_BY_ZERO;
    if (fatal && g_nsPhase.load() >= 0 && reported.fetch_add(1) < 3) {
        char at[160]; NsAddr(e->ExceptionRecord->ExceptionAddress, at, sizeof at);
        LOGE("true stereo: exception %08lx at %s during eye %d (thread %lu) - please send this log", c, at, g_nsPhase.load(), GetCurrentThreadId());
        LogFlushDisk();
    }
    return EXCEPTION_CONTINUE_SEARCH;
}
// watchdog: an eye render that does not return within 2 s is reported with where the render thread is
static DWORD WINAPI NsWatchdog(LPVOID) {
    LONGLONG reportedFor = 0;
    for (;;) {
        Sleep(250);
        int ph = g_nsPhase.load(); LONGLONG since = g_nsPhaseSince.load();
        if (ph < 0 || since == reportedFor) continue;
        LARGE_INTEGER now; rc::Qpc(&now);
        double ms = double(now.QuadPart - since) * 1000.0 / double(g_qpf.QuadPart);
        if (ms < 2000) continue;
        reportedFor = since;
        char where[1200] = ""; size_t w = 0;
        HANDLE t = OpenThread(THREAD_SUSPEND_RESUME | THREAD_GET_CONTEXT | THREAD_QUERY_INFORMATION, FALSE, g_nsTid.load());
        if (t && SuspendThread(t) != (DWORD)-1) {
            CONTEXT ctx{}; ctx.ContextFlags = CONTEXT_CONTROL | CONTEXT_INTEGER;
            if (GetThreadContext(t, &ctx)) {
                char a[160]; NsAddr((void*)ctx.Rip, a, sizeof a); w += snprintf(where + w, sizeof where - w, "rip %s | stack:", a);
                uint64_t* sp = (uint64_t*)ctx.Rsp; int found = 0;
                for (int i = 0; i < 1024 && found < 14 && w < sizeof where - 40; i++) {
                    if (!Readable(sp + i, 8)) break;
                    void* v = (void*)sp[i];
                    if (InText((uint8_t*)v)) { NsAddr(v, a, sizeof a); w += snprintf(where + w, sizeof where - w, " %s", a); found++; }
                }
            }
            ResumeThread(t);
        }
        if (t) CloseHandle(t);
        LOGE("true stereo: eye %d render has not returned for %.0f ms - %s - please send this log", ph, ms, where);
        LogFlushDisk();
    }
}
static void NsSafetyInstall() {
    AddVectoredExceptionHandler(0, NsVeh);
    CreateThread(nullptr, 0, NsWatchdog, nullptr, 0, nullptr);
    if (GetFileAttributesW(NsMarkerPath().c_str()) != INVALID_FILE_ATTRIBUTES) {
        DeleteFileW(NsMarkerPath().c_str());
        NativeFail("the game stopped while true stereo ran last time");
    }
}

LONG EnginePresentCount() { return g_presents.load(); }
int EngineEffectiveMode() { return Mode(); }
bool EngineCutsceneActive() { DWORD t = g_cineTick.load(); return t && rc::TickMs() - t < 400 && RttiIs(g_main.load(), ".?AVCinematicCamera@@"); }

void EngineSetPoses(const xrb::IpcPose pose[2], const xrb::IpcFov fov[2], int64_t time) {
    PoseCache c; c.valid = true; c.time = time;
    float m = g_set.cullMargin < 1.f ? 1.f : g_set.cullMargin > 1.6f ? 1.6f : g_set.cullMargin;
    c.wideH = c.wideV = 0;
    for (int e = 0; e < 2; e++) {
        c.pose[e] = pose[e]; c.fov[e] = fov[e];
        c.eye[e] = { tanf(fov[e].left) * m, tanf(fov[e].right) * m, tanf(fov[e].up) * m, tanf(fov[e].down) * m };
        c.hullH[e] = fmaxf(-c.eye[e].l, c.eye[e].r); c.hullV[e] = fmaxf(c.eye[e].u, -c.eye[e].d);
        {   // pixel perfect (resolution.cpp): the symmetric frustum at exactly the headset's pixels per tangent
            double sx, sy;
            if (g_set.matchedView && !g_set.cantedView && !g_set.symmetricView && ResolutionPixelScale(&sx, &sy)) {
                float L = tanf(fov[e].left), R = tanf(fov[e].right), U = tanf(fov[e].up), Dn = tanf(fov[e].down);
                float h = (float)(sx * (R - L) * 0.5), v = (float)(sy * (U - Dn) * 0.5);
                if (h >= fmaxf(-L, R) * 0.999f && v >= fmaxf(U, -Dn) * 0.999f) { c.hullH[e] = h; c.hullV[e] = v; }
            }
        }
        c.wideH = fmaxf(c.wideH, c.hullH[e]); c.wideV = fmaxf(c.wideV, c.hullV[e]);
        // canted: the axis to the middle of the field (angles), and the symmetric frustum around it that covers the
        // whole field - the field's outline sampled 33 points a side and turned into the canted frame
        c.cant[e][0] = -(fov[e].left + fov[e].right) * 0.5f;
        c.cant[e][1] = (fov[e].up + fov[e].down) * 0.5f;
        float ch = 0, cv = 0, L = tanf(fov[e].left), R = tanf(fov[e].right), U = tanf(fov[e].up), D = tanf(fov[e].down);
        for (int i = 0; i <= 32; i++) {
            float t = i / 32.f, x = L + (R - L) * t, y = D + (U - D) * t, px, py;
            const float pts[4][2] = { { x, U }, { x, D }, { L, y }, { R, y } };
            for (auto& pt : pts) { CantToPic(c.cant[e], pt[0], pt[1], &px, &py); ch = fmaxf(ch, fabsf(px)); cv = fmaxf(cv, fabsf(py)); }
        }
        c.cantH[e] = ch * m; c.cantV[e] = cv * m;
    }
    { float t[2][4]; for (int e = 0; e < 2; e++) { t[e][0] = tanf(fov[e].left); t[e][1] = tanf(fov[e].right); t[e][2] = tanf(fov[e].up); t[e][3] = tanf(fov[e].down); } ResolutionNoteFov(t); }
    // head frame covering frustum: each eye's corners turned into the head frame (canted displays), +2 %
    xrb::IpcPose ctr = CenterPose(c);
    M3 Rh = QuatToM3(ctr.qx, ctr.qy, ctr.qz, ctr.qw);
    float ch = 0, cv = 0;
    for (int e = 0; e < 2; e++) {
        M3 Re = QuatToM3(pose[e].qx, pose[e].qy, pose[e].qz, pose[e].qw);
        float xs[2] = { tanf(fov[e].left), tanf(fov[e].right) }, ys[2] = { tanf(fov[e].down), tanf(fov[e].up) };
        for (float x : xs) for (float y : ys) {
            double v[3] = { x, y, -1 }, w[3], h[3];
            for (int i = 0; i < 3; i++) w[i] = Re.m[i][0] * v[0] + Re.m[i][1] * v[1] + Re.m[i][2] * v[2];
            for (int i = 0; i < 3; i++) h[i] = Rh.m[0][i] * w[0] + Rh.m[1][i] * w[1] + Rh.m[2][i] * w[2];   // R_head^T
            if (h[2] < -1e-3) { ch = fmaxf(ch, (float)fabs(h[0] / -h[2])); cv = fmaxf(cv, (float)fabs(h[1] / -h[2])); }
        }
    }
    c.centreH = fminf(ch * 1.02f * m, 11.4f); c.centreV = fminf(cv * 1.02f * m, 11.4f);
    c.wideH = fminf(c.wideH, 11.4f); c.wideV = fminf(c.wideV, 11.4f);
    c.ipd = sqrtf((pose[1].px - pose[0].px) * (pose[1].px - pose[0].px) + (pose[1].py - pose[0].py) * (pose[1].py - pose[0].py) + (pose[1].pz - pose[0].pz) * (pose[1].pz - pose[0].pz));
    if (!(c.centreH > 0.1f && c.centreV > 0.1f && c.wideH > 0.1f)) return;
    AcquireSRWLockExclusive(&g_poseLock); g_poses = c; ReleaseSRWLockExclusive(&g_poseLock);
}
void EngineNoPoses() { AcquireSRWLockExclusive(&g_poseLock); g_poses.valid = false; ReleaseSRWLockExclusive(&g_poseLock); }
void EngineSettingsChanged() {
    { void ResolutionSettingsChanged(); ResolutionSettingsChanged(); }
    if (g_set.vrMode != "native" && g_nativeFailed.load()) { g_nativeFailed = false; g_nativeWhy[0] = 0; g_nativeMissRun = 0; g_nativeWaitSince = -1; }
    ParseAxes();
    if (Mode() == VRMODE_SCREEN) g_restoreLens = true;
    if (!g_set.firstPerson) g_fpBob = BobFilter{};
}

static void SelectMain() {
    LONG now = g_presents.load(); void* cur = g_main.load();
    AcquireSRWLockShared(&g_candLock);
    for (auto& c : g_cands) if (c.p && c.p == cur && now - c.lastPresent <= 1) g_mainLastSeen = now;
    void* best = nullptr; uint32_t bestCalls = 0; float bestFar = 0;
    static LONG noMatchSince = -1;
    if (!cur || now - g_mainLastSeen > 30) {
        PoseCache pc; GetPoses(pc);
        for (auto& c : g_cands) {
            if (!c.p || now - c.lastPresent > 1) continue;
            bool ok = fabsf(c.aspect - g_bbAspect) < 0.03f * g_bbAspect;
            if (pc.valid) for (float a : { pc.wideH / pc.wideV, pc.centreH / pc.centreV, pc.hullH[0] / pc.hullV[0], pc.hullH[1] / pc.hullV[1] })
                if (fabsf(c.aspect - a * g_set.viewWidth / g_set.viewHeight) < 1e-3f) ok = true;
            if (!ok) continue;
            if (c.calls > bestCalls || (c.calls == bestCalls && c.farp > bestFar)) { best = c.p; bestCalls = c.calls; bestFar = c.farp; }
        }
        if (!best && !cur) {
            if (noMatchSince < 0) noMatchSince = now;
            if (now - noMatchSince > 300)
                for (auto& c : g_cands) if (c.p && now - c.lastPresent <= 1 && c.farp >= 50.f && (c.calls > bestCalls || (c.calls == bestCalls && c.farp > bestFar))) { best = c.p; bestCalls = c.calls; bestFar = c.farp; }
        } else noMatchSince = -1;
    }
    ReleaseSRWLockShared(&g_candLock);
    if (best && best != cur) {
        if (g_savedLens.valid) RestoreLens();
        g_main.store(best); g_mainLastSeen = now;
        g_stab = Stabilizer{}; g_settle = Settler{}; g_haveSyncBase = false; g_havePrev = false;
        LOGI("camera: main view -> %p %s (%u projection calls per frame, far %.1f)", best, RttiName(best), bestCalls, bestFar);
    } else if (cur && now - g_mainLastSeen > 120) {
        LOGI("camera: main view %p no longer used", cur);
        if (g_savedLens.valid) RestoreLens();
        g_main.store(nullptr);
    }
}

FrameInfo EngineOnPresent(float bbAspect, bool flatNow) {
    g_presentTid = GetCurrentThreadId();
    g_flatNow = flatNow;
    if (bbAspect > 0.1f) g_bbAspect = bbAspect;
    LONG idx = g_presents.load();
    FrameInfo fi;
    if (g_ready) {
        SelectMain();
        FrameRec& r = g_ring[(uint32_t)idx % kRing];
        uint32_t t = r.target.load(std::memory_order_acquire);
        bool live = Mode() != VRMODE_SCREEN && g_main.load() && !flatNow;
        // exact: this thread rebuilt a snapshot of the main view since the last Present - that is the frame shown now
        if (live && t_renderRecValid && t_renderRecPresent == idx && t_renderRec.vr) {
            fi = t_renderRec; s_exact++;
            int lag = (int)(idx - fi.presentAtSet);
            if (lag >= 0 && lag < 4) {
                g_lagHist[lag]++;
                int best = 0; for (int k = 1; k < 4; k++) if (g_lagHist[k] > g_lagHist[best]) best = k;
                if (g_lagHist[best] >= 30 && best != g_measuredLag) { g_measuredLag = best; LOGI("xr: pipeline lag measured: %d frame(s) between the camera and Present", best); }
                if (g_lagHist[best] > 1000) for (int& h : g_lagHist) h /= 2;
            }
        } else if (live && t == (uint32_t)idx) { fi = r.fi; if (r.target.load(std::memory_order_acquire) != t) fi.vr = false; if (fi.vr) s_byCount++; }
        // true stereo: the renderer must draw the main view through its view render (slot 10) - else fall back
        if (fi.vr && fi.mode == VRMODE_NATIVE) {
            if (g_nativeWaitSince < 0) { g_nativeWaitSince = idx; g_nativeLastPair = idx; }
            if (idx - g_nativeLastPair > 240) NativeFail("the renderer's view render never drew the main view");
        } else if (!fi.vr) g_nativeWaitSince = -1;
        if (fi.vr) { g_lastShown = fi; g_lastShownAge = 0; s_presentsVr++; }
        else if (live && g_lastShownAge < 3 && !(GameStateNow() >= GS_MENU && g_set.flatPauseMenus)) { fi = g_lastShown; g_lastShownAge++; s_presentsReuse++; }
        else { fi = FrameInfo{}; g_lastShownAge = 1000; s_presentsFlat++; }
        char c = !fi.vr ? '-' : fi.eye == 0 ? 'L' : fi.eye == 1 ? 'R' : 'C';
        if (g_eyesDrawnN < 40) g_eyesDrawn[g_eyesDrawnN++] = c;
    }
    g_presents.fetch_add(1);
    return fi;
}

// the frame a render / recording thread is working on: the snapshot it rebuilt this frame (exact), else the camera
// thread's own record, else the record targeted at the coming Present
bool EngineFrameForRecording(FrameInfo* out) {
    if (t_renderRecValid && t_renderRecPresent == g_presents.load() && t_renderRec.vr) { *out = t_renderRec; return true; }
    const FrameInfo* r = RecordForThisThread();
    if (!r || !r->vr) return false;
    *out = *r; return true;
}

const char* EngineStatus() { return g_status; }
const char* EngineMainViewClass() { void* m = g_main.load(); return m ? RttiName(m) : ""; }

bool EngineLastGameCameraPos(double out[3]) {
    AcquireSRWLockShared(&g_xfLock);
    bool ok = g_last.valid; if (ok) { out[0] = g_last.base.p.x; out[1] = g_last.base.p.y; out[2] = g_last.base.p.z; }
    ReleaseSRWLockShared(&g_xfLock);
    return ok;
}

void EngineReport() {
    void* m = g_main.load();
    g_eyesDrawn[g_eyesDrawnN] = 0;
    LOGI("camera: node updates %u, main %u, poses applied %u, projections %u (main %u), off-centre patched %u, eye unknown %u, "
         "lens writes %u, still-camera refresh %u, feedback %u, insane %u, flat (pause/menu) %u, double updates %d",
         s_setXf.load(), s_setXfMain.load(), s_applied.load(), s_getProj.load(), s_getProjMain.load(), s_projPatched.load(), s_projEyeUnknown.load(),
         s_lensWrites.load(), s_refresh.load(), s_feedback.load(), s_insane.load(), s_flatState.load(), g_doubleUpd.load());
    LOGI("xr: eyes drawn: %s | presents vr %u, repeated %u, flat %u | method %s, lag %d%s, camera thread %lu, present thread %lu",
         g_eyesDrawn, s_presentsVr, s_presentsReuse, s_presentsFlat, ModeName(Mode()), EffectiveLag(), g_measuredLag >= 0 ? " (measured)" : "",
         (unsigned long)g_camTid.load(), (unsigned long)g_presentTid);
    {
        static long lastCount = 0; static LONG lastPresents = 0;
        long c = g_nsCount.load(); LONG pr = g_presents.load(); void* v = g_nsView.load(); FrameInfo tmp;
        if (o_renderView && pr != lastPresents && (g_set.stereoDiag || g_set.vrMode == "native"))
            LOGI("true stereo: renderer view renders %.2f per Present (last view %p %s, main snapshot %s, thread %lu) | eye pairs %u (total %ld), first eye captured %u, missed %u, skipped %u (broken camera %u), game moves during an eye %u, scratch blocks of the first render taken back %u (left %u) | %s",
                 double(c - lastCount) / double(pr - lastPresents), v, RttiName(v), CloneRecord(v, &tmp) ? "yes" : "no",
                 (unsigned long)g_nsTid.load(), s_nsPairs.load(), g_nsPairsTotal.load(), s_nsCaptured.load(), s_nsMissed.load(), s_nsSkipped.load(), s_nsBadBase.load(), s_nsXfDuring.load(), s_nsPadBlocks.load(), s_nsPadKept.load(), EngineNativeState());
        lastCount = c; lastPresents = pr;
        s_nsPairs = 0; s_nsCaptured = 0; s_nsMissed = 0; s_nsSkipped = 0; s_nsBadBase = 0; s_nsXfDuring = 0; s_nsPadBlocks = 0; s_nsPadKept = 0;
    }
    LOGI("xr: eye sync: exact %u (snapshot rebuilt on the Present thread), by frame count %u | snapshots of the main view %u, rebuilt %u | projection rebuilds forced %u",
         s_exact.load(), s_byCount.load(), s_clones.load(), s_cloneProj.load(), s_dirtyForced.load());
    if (m && g_off.fov >= 0 && Readable(m, 8)) {
        float f = *Field(m, g_off.fov), a = *Field(m, g_off.aspect);
        PoseCache pc; GetPoses(pc);
        LOGI("camera: node projection - the mod's: x %.3f y %.3f -> FOV %.1f x %.1f, near %.3f far %.1f | the game's own: fov %.1f deg | headset eye L %.2f/%.2f R %.2f/%.2f (tan)",
             tanf(f * 0.5f), tanf(f * 0.5f) / a, f * 57.2958f, 2 * atanf(tanf(f * 0.5f) / a) * 57.2958f, *Field(m, g_off.nearp), *Field(m, g_off.farp),
             g_savedLens.valid ? g_savedLens.fov * 57.2958f : f * 57.2958f, pc.eye[0].l, pc.eye[0].r, pc.eye[1].l, pc.eye[1].r);
    } else LOGI("camera: no main view yet (back buffer aspect %.3f)", g_bbAspect);
    {
        AcquireSRWLockShared(&g_candLock);
        LONG now = g_presents.load(); char line[1024]; int n = 0;
        for (auto& c : g_cands) if (c.p && now - c.lastPresent < 600 && n < 900)
            n += snprintf(line + n, sizeof line - n, " [%s calls %u fov %.0f asp %.2f far %.0f age %ld]", RttiName(c.p), c.calls, c.fov * 57.2958f, c.aspect, c.farp, now - c.lastPresent);
        ReleaseSRWLockShared(&g_candLock);
        if (n) LOGI("camera: views:%s", line);
    }
    snprintf(g_status, sizeof g_status, "%s | %s | lag %d", m ? RttiName(m) : "no main view", ModeName(Mode()), EffectiveLag());
    s_getProj = s_getProjMain = s_setXf = s_setXfMain = s_applied = s_feedback = s_refresh = s_lensWrites = s_setFovMain = s_insane = 0;
    s_projPatched = s_projEyeUnknown = s_flatState = 0; g_doubleUpd = 0;
    s_presentsVr = s_presentsReuse = s_presentsFlat = 0; g_eyesDrawnN = 0;
}
