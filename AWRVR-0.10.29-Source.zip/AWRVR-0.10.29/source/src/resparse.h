#pragma once
// resolution.xml: the width / height numbers inside a screen_resolution entry of unknown layout ("3840x2160",
// w= / h=, x= / y=, child elements...): the first two numbers >= 480 that stand close together (header-only, tested).
#include <string>
#include <cctype>
#include <cstdlib>
#include <cstring>
// a value by name: key="v" / key = v (attribute), <key>v</key>, or <key value="v"/> (an element with a value attribute,
// the layout Alan Wake Remastered writes: <screen_resolution> <width value="3840"/> <height value="2160"/> ...)
inline bool FindValue(const std::string& s, size_t from, size_t span, const char* key, size_t* pos, size_t* len) {
    size_t end = from + span < s.size() ? from + span : s.size(), k = from;
    while ((k = s.find(key, k)) != std::string::npos && k < end) {
        size_t p = k + strlen(key); bool element = k > 0 && s[k - 1] == '<';
        if (p < s.size() && (isalnum((unsigned char)s[p]) || s[p] == '_')) { k++; continue; }   // a longer name
        while (p < s.size() && (s[p] == ' ' || s[p] == '\t')) p++;
        char close = '<';
        if (element) {
            if (p < s.size() && s[p] == '>') p++;
            else {   // <key value="v"/>: the value attribute inside this tag
                size_t te = s.find('>', p); if (te == std::string::npos) { k++; continue; }
                size_t v = s.find("value", p); if (v == std::string::npos || v > te) { k++; continue; }
                v += 5; while (v < te && (s[v] == ' ' || s[v] == '=')) v++;
                if (v < te && (s[v] == '"' || s[v] == '\'')) { close = s[v]; v++; } else close = ' ';
                size_t q = v; while (q < te && s[q] != close && s[q] != '/' && !(close == ' ' && isspace((unsigned char)s[q]))) q++;
                *pos = v; *len = q - v; return true;
            }
        }
        else { if (p >= s.size() || s[p] != '=') { k++; continue; } p++; while (p < s.size() && s[p] == ' ') p++; if (p < s.size() && (s[p] == '"' || s[p] == '\'')) { close = s[p]; p++; } else close = ' '; }
        size_t q = p; while (q < s.size() && s[q] != close && s[q] != '/' && s[q] != '>' && !(close == ' ' && isspace((unsigned char)s[q]))) q++;
        *pos = p; *len = q - p; return true;
    }
    return false;
}
inline bool ResFindPair(const std::string& e, size_t* p0, size_t* l0, size_t* p1, size_t* l1) {
    size_t prevP = 0, prevL = 0, prevEnd = 0; bool havePrev = false;
    for (size_t k = 0; k < e.size();) {
        if (!isdigit((unsigned char)e[k])) { k++; continue; }
        size_t q = k; while (q < e.size() && isdigit((unsigned char)e[q])) q++;
        bool frac = (k > 0 && e[k - 1] == '.') || (q < e.size() && e[q] == '.');   // 59.94 is not a size
        unsigned v = (unsigned)atoi(e.substr(k, q - k).c_str());
        if (!frac && v >= 480 && v <= 16384) {
            if (havePrev && k - prevEnd <= 16) { *p0 = prevP; *l0 = prevL; *p1 = k; *l1 = q - k; return true; }
            prevP = k; prevL = q - k; prevEnd = q; havePrev = true;
        }
        k = q;
    }
    return false;
}
