// AWRVR - Alan Wake Remastered VR. dbghelp.dll proxy (the game imports dbghelp.dll by name), or an .asi.
#include <windows.h>
#include <string>
#include <cstring>
#include <vector>
#include "log.h"
#include "config.h"
#include "settings.h"
#include "engine.h"
#include "game.h"
#include "d3d12hooks.h"
#include "MinHook.h"
#include "version.h"
#include "realclock.h"
#include <cmath>

void ProxyLoad(HMODULE self);
extern std::wstring g_proxyName;
void DxgiPatchImports();
void DxgiInstallFallback();
LONG DxgiPresentCount();
void ResolutionApplyAtStartup();
void SettingsCycleMode();
void CompositorRecenter();

std::wstring g_gameDir, g_modDir, g_cfgPath;   // g_cfgPath: awrvr_config.txt (game folder, or %LOCALAPPDATA%\AWRVR)
HMODULE g_self = nullptr;
static const int kConfigVersion = 3;

static const char* kDefaultConfig =
    "# Alan Wake Remastered VR (AWRVR) settings. Lines: key = value. Delete this file to get the defaults back.\n"
    "# Everything here is also in the VR panel (Insert, or hold L3 + R3), with help texts.\n"
    "config_version = 3\n"
    "\n"
    "# ---- View: synced (default) | native (true stereo) | aer | head | screen   (F8 cycles)\n"
    "vr_mode = native\nworld_scale = 1.0\nipd_scale = 1.0\nswap_eyes = false\n"
    "sync_submit = pair\ncamera_reprojection = false\naer_frame_delay = 0\n"
    "\n# ---- Camera\n"
    "head_aim = always\nhead_aim_from_eyes = true\nhead_aim_smoothing = 0.3\n"
    "decoupled_pitch = true\ncamera_stabilize = 0.35\ncamera_settle = 1.0\naction_cameras = off\ncamera_shake = 0.0\ncamera_offset_x = 0.0\ncamera_offset_y = 0.0\ncamera_offset_z = 0.0\n"
    "first_person = false\nfp_eye_height = 0.60\nfp_offset_x = 0.0\nfp_offset_y = 0.0\nfp_offset_z = 0.60\nfp_smooth = 0.6\nfp_near_clip = 0.0\n"
    "\n# ---- HUD: scale | panel | off\n"
    "hud_mode = scale\nhud_safe_x = 0.22\nhud_safe_y = 0.20\nui_scale = 0.42\nui_depth = 1.3\nui_offset_y = -0.03\nhide_hud = false\nui_pick = 0\n"
    "\n# ---- Graphics (game = the game's own setting; nothing is saved over your game options)\n"
    "game_aa = game\nupscaler_fresh_each_eye = false\nmotion_blur_off = true\nfilm_grain_off = true\nvignette_off = true\nsharpen = 0.0\nrender_scale = 1.0\n"
    "no_black_bars = false\nocclusion_culling = true\ntrue_stereo_occlusion = true\ngame_frame_cap = game\n"
    "\n# ---- Screen\n"
    "cutscene_mode = theater\ntheater_size = 100\ntheater_distance = 10\ntheater_fade = true\n"
    "edge_fill = true\nflat_pause_menus = true\nflat_videos = true\nscreen_distance = 2.7\nscreen_width = 3.1\n"
    "menu_distance = 1.05\nmenu_panel_width = 1.10\nmenu_width = 0.80\nmirror = left\nvsync_off = true\nhdr_input = auto\n"
    "screenshot_view = headset\nforce_windowed = true\nrun_in_background = true\n"
    "\n# ---- Advanced\n"
    "fps_unlocked = false\nfps_limit = headset\nheadset_refresh_hz = 0\n"
    "fov_mode = unseen\nfov_inner = 0.60\nfov_outer = 1.00\nfov_wide = 1.25\nfov_debug = false\n"
    "view_width = 1.0\nview_height = 1.0\neye_view = pixel\nwide_cull = true\nsymmetric_view = false\ncull_margin = 1.0\nnear_clip = 0.1\nunits_per_metre = 1.0\n"
    "aer_align_h = 0.0\naer_align_v = 0.0\nsync_lag = -1\n"
    "render_resolution = auto\nheadset_smoothing = full\nmax_frame_latency = 2\n"
    "ui_layers = one\nhud_split = auto\nhud_scene_draws = 1\noffset_step_cm = 3\nflat_video_min_width = 1280\npanel_layers = auto\nhdr_paper_white = 200\n"
    "\n# ---- config file only\n"
    "camera_axes = +0+1+2\nrender_max_side = 8192\npaced_timeout_ms = 100\nrecenter_key = F9\nscreenshot_key = DELETE\nfp_key = END\nhotkey_screenshot = DELETE\n"
    "camera_hooks = true\nui_hooks = true\nxr_output = true\nmenu_opacity = 0.25\nui_pick_sig =\nhost_mode = thread\nstatic_camera_refresh = true\nstereo_diagnostics = true\n"
    "\n# keys: Insert / L3+R3 panel, F9 recentre, End first person, F8 method, F7 HUD, F6 flat screen, Delete screenshot\n";
const char* DefaultConfigText() { return kDefaultConfig; }

// rewrite key = value lines in place (comments kept); append missing keys
static void ConfigSetKeys(const std::wstring& path, const std::vector<std::pair<std::string, std::string>>& kv, const std::vector<std::string>& drop) {
    FILE* f = _wfopen(path.c_str(), L"rb"); if (!f) return;
    std::string s; char b[4096]; size_t n; while ((n = fread(b, 1, sizeof b, f)) > 0) s.append(b, n); fclose(f);
    std::string out; size_t i = 0; std::vector<bool> done(kv.size());
    while (i < s.size()) {
        size_t e = s.find('\n', i); std::string line = s.substr(i, e == std::string::npos ? std::string::npos : e - i + 1); i = e == std::string::npos ? s.size() : e + 1;
        size_t eq = line.find('='); std::string key = eq == std::string::npos ? "" : line.substr(0, eq);
        while (!key.empty() && (key.back() == ' ' || key.back() == '\t')) key.pop_back();
        size_t ks = key.find_first_not_of(" \t"); if (ks != std::string::npos) key = key.substr(ks);
        bool skip = false;
        for (auto& d : drop) if (key == d) skip = true;
        for (size_t k = 0; k < kv.size() && !skip; k++) if (key == kv[k].first) { line = key + " = " + kv[k].second + "\n"; done[k] = true; }
        if (!skip) out += line;
    }
    for (size_t k = 0; k < kv.size(); k++) if (!done[k]) out += kv[k].first + " = " + kv[k].second + "\n";
    if ((f = _wfopen(path.c_str(), L"wb"))) { fwrite(out.data(), 1, out.size(), f); fclose(f); }
}

// migrations: only provably wrong / renamed values, each logged (guide: the player decides the rest)
static void MigrateConfig(const std::wstring& path) {
    int v = ConfigInt("config_version", 1);
    if (v >= kConfigVersion) return;
    std::vector<std::pair<std::string, std::string>> set; std::vector<std::string> drop;
    if (v < 2) {
    // 0.1.0 -> 0.2.0: renamed keys and the old method names
    std::string mode = ConfigStr("vr_mode", "");
    if (mode == "stereo") { set.push_back({ "vr_mode", "aer" }); LOGI("config: vr_mode stereo (0.1 alternate eye) -> aer"); }
    std::string lag = ConfigStr("frame_lag", "");
    if (!lag.empty()) { int l = lag == "auto" ? 0 : atoi(lag.c_str()) + 1; set.push_back({ "aer_frame_delay", std::to_string(l) }); drop.push_back("frame_lag"); LOGI("config: frame_lag %s -> aer_frame_delay %d", lag.c_str(), l); }
    std::string m = ConfigStr("fov_margin", "");
    if (!m.empty()) { set.push_back({ "cull_margin", m }); drop.push_back("fov_margin"); LOGI("config: fov_margin -> cull_margin %s", m.c_str()); }
    std::string pos = ConfigStr("positional_tracking", "");
    if (!pos.empty()) { drop.push_back("positional_tracking"); LOGI("config: positional_tracking removed (head position is always used; world_scale / ipd_scale adjust it)"); }
    std::string hf = ConfigStr("headset_fov", "");
    if (!hf.empty()) { drop.push_back("headset_fov"); LOGI("config: headset_fov removed (the picture always matches the headset; view_width / view_height adjust it)"); }
    for (const char* k : { "menu_height" }) if (!ConfigStr(k, "").empty()) { drop.push_back(k); LOGI("config: %s removed (ui_offset_y)", k); }
    }
    if (v < 3) {
        // 0.9.0: stereo reconstruction was removed (it froze the game) -> synchronized
        std::string mode = ConfigStr("vr_mode", "");
        if (mode == "recon") { set.push_back({ "vr_mode", "synced" }); LOGI("config: vr_mode recon (removed in 0.9.0) -> synced"); }
        for (const char* k : { "recon_parallax", "recon_gap_reach", "recon_depth", "recon_align_h", "recon_align_v", "recon_debug" })
            if (!ConfigStr(k, "").empty()) drop.push_back(k);
        // first person: the old defaults put the eye ~1 m too high and inside the head (measured in the headset: eye
        // height 0.60, Eye Z 0.60). Only the untouched old defaults are moved; values you set yourself stay.
        { std::string e = ConfigStr("fp_eye_height", ""); if (!e.empty() && fabs(atof(e.c_str()) - 1.68) < 1e-3) { set.push_back({ "fp_eye_height", "0.60" }); LOGI("config: fp_eye_height 1.68 (old default) -> 0.60"); } }
        { std::string z = ConfigStr("fp_offset_z", ""); if (!z.empty() && fabs(atof(z.c_str()) - 0.12) < 1e-3) { set.push_back({ "fp_offset_z", "0.60" }); LOGI("config: fp_offset_z 0.12 (old default) -> 0.60"); } }
        if (ConfigStr("matched_view", "").empty()) set.push_back({ "matched_view", "true" });
    }
    set.push_back({ "config_version", std::to_string(kConfigVersion) });
    ConfigSetKeys(path, set, drop);
    ConfigLoad(path.c_str());
    LOGI("config: migrated from version %d to %d", v, kConfigVersion);
}

static DWORD WINAPI FlushThread(LPVOID) { SetThreadPriority(GetCurrentThread(), THREAD_PRIORITY_BELOW_NORMAL); for (;;) { Sleep(1000); LogFlushDisk(); } }

static DWORD WINAPI InitThread(LPVOID) {
    LARGE_INTEGER f, a, b; rc::Qpf(&f); rc::Qpc(&a);
    D3DHooksInstall();
    bool ok = EngineInstall();
    GameScan();
    { void HeadAimInstall(); HeadAimInstall(); }
    { void UpscalerInstall(); UpscalerInstall(); }
    GameApplySettings();
    GameFirstPerson(g_set.firstPerson, g_set.fpOffsetX, g_set.fpOffsetY, g_set.fpOffsetZ);
    rc::Qpc(&b);
    LOGI("scan: %s (%.0f ms)", ok ? "camera hooks installed" : "camera NOT usable on this build - flat screen only, please send this log", double(b.QuadPart - a.QuadPart) * 1000.0 / double(f.QuadPart));
    for (int i = 0; i < 100 && DxgiPresentCount() == 0; i++) Sleep(100);
    if (DxgiPresentCount() == 0) DxgiInstallFallback();
    return 0;
}

// ---------------------------------------------------------------- hotkeys (Present thread)
static bool g_flatToggle = false;
void FlatToggle() { g_flatToggle = !g_flatToggle; LOGI("keys: flat screen %s", g_flatToggle ? "on" : "off"); }
void FlatToggleState(bool* flat) { *flat = g_flatToggle; }
void FirstPersonToggle() { g_set.firstPerson = !g_set.firstPerson; SettingsApply(); SettingsSave(); }
static void Init() {
    wchar_t exe[MAX_PATH]; GetModuleFileNameW(nullptr, exe, MAX_PATH);
    g_gameDir = exe; g_gameDir = g_gameDir.substr(0, g_gameDir.find_last_of(L'\\'));
    g_modDir = g_gameDir + L"\\AWRVR";
    std::wstring cfg = g_gameDir + L"\\awrvr_config.txt";
    // the game folder may not be writable (Program Files, a locked store folder): then everything the mod writes
    // (config, log, headset cache, screenshots) goes to %LOCALAPPDATA%\AWRVR, and the log says why (GOTGVR Q.5)
    DWORD why = 0;
    {
        CreateDirectoryW(g_modDir.c_str(), nullptr);
        std::wstring probe = g_modDir + L"\\write_test.tmp";
        HANDLE t = CreateFileW(probe.c_str(), GENERIC_WRITE, 0, nullptr, CREATE_ALWAYS, FILE_FLAG_DELETE_ON_CLOSE, nullptr);
        if (t == INVALID_HANDLE_VALUE) why = GetLastError(); else CloseHandle(t);
        if (!why && GetFileAttributesW(cfg.c_str()) == INVALID_FILE_ATTRIBUTES) {   // the config itself sits in the game folder
            std::wstring p2 = g_gameDir + L"\\awrvr_write_test.tmp";
            HANDLE t2 = CreateFileW(p2.c_str(), GENERIC_WRITE, 0, nullptr, CREATE_ALWAYS, FILE_FLAG_DELETE_ON_CLOSE, nullptr);
            if (t2 == INVALID_HANDLE_VALUE) why = GetLastError(); else CloseHandle(t2);
        }
    }
    wchar_t lad[MAX_PATH] = L"";
    if (why && GetEnvironmentVariableW(L"LOCALAPPDATA", lad, MAX_PATH) && lad[0]) {
        std::wstring alt = std::wstring(lad) + L"\\AWRVR";
        CreateDirectoryW(alt.c_str(), nullptr);
        std::wstring altCfg = alt + L"\\awrvr_config.txt";
        if (GetFileAttributesW(altCfg.c_str()) == INVALID_FILE_ATTRIBUTES && GetFileAttributesW(cfg.c_str()) != INVALID_FILE_ATTRIBUTES)
            CopyFileW(cfg.c_str(), altCfg.c_str(), TRUE);   // the player's config from the game folder is kept
        g_modDir = alt; cfg = altCfg;
    }
    g_cfgPath = cfg;
    LogInit((g_modDir + L"\\awrvr.log").c_str());
    MoveFileExW((g_modDir + L"\\xrhost.log").c_str(), (g_modDir + L"\\xrhost.prev.log").c_str(), MOVEFILE_REPLACE_EXISTING);
    { void DiagInit(); DiagInit(); }
    if (why) LOGW("files: the game folder is not writable (error %lu) - config, log and cache are in %ls", why, g_modDir.c_str());
    if (GetFileAttributesW(cfg.c_str()) == INVALID_FILE_ATTRIBUTES) {
        HANDLE f = CreateFileW(cfg.c_str(), GENERIC_WRITE, 0, nullptr, CREATE_NEW, 0, nullptr);
        if (f != INVALID_HANDLE_VALUE) { DWORD w; WriteFile(f, kDefaultConfig, (DWORD)strlen(kDefaultConfig), &w, nullptr); CloseHandle(f); }
    }
    ConfigLoad(cfg.c_str());
    char pn[64]; WideCharToMultiByte(CP_UTF8, 0, g_proxyName.c_str(), -1, pn, 64, nullptr, nullptr);
    char en[MAX_PATH]; WideCharToMultiByte(CP_UTF8, 0, exe, -1, en, MAX_PATH, nullptr, nullptr);
    LOGI("AWRVR %s loaded as %s into %s (pid %lu)", AWRVR_VERSION, pn, en, GetCurrentProcessId());
    MigrateConfig(cfg);
    SettingsLoad();
    LOGI("config: method %s, hud %s, render %s x %.2f, host %s", g_set.vrMode.c_str(), g_set.hudMode.c_str(), g_set.renderResolution.c_str(), g_set.renderScale, g_set.hostMode.c_str());
    ResolutionApplyAtStartup();
    if (MH_Initialize() != MH_OK) LOGE("MH_Initialize failed");
    { void ResolutionInstallLoadHook(); ResolutionInstallLoadHook(); }
    { void ScratchPadPatch(); ScratchPadPatch(); void MessageBoxLogInstall(); MessageBoxLogInstall(); }
    DxgiPatchImports();
    CreateThread(nullptr, 0, FlushThread, nullptr, 0, nullptr);
    CreateThread(nullptr, 0, InitThread, nullptr, 0, nullptr);
}

// searches the main module's mapped image (headers' section table) for a byte string - no API calls (loader lock)
static bool ExeContains(const char* str) {
    uint8_t* base = (uint8_t*)GetModuleHandleW(nullptr);
    auto* dos = (IMAGE_DOS_HEADER*)base; if (dos->e_magic != IMAGE_DOS_SIGNATURE) return false;
    auto* nt = (IMAGE_NT_HEADERS*)(base + dos->e_lfanew);
    auto* sec = IMAGE_FIRST_SECTION(nt); size_t n = strlen(str);
    for (int i = 0; i < nt->FileHeader.NumberOfSections; i++, sec++) {
        if (sec->Characteristics & IMAGE_SCN_MEM_EXECUTE) continue;
        uint8_t* p = base + sec->VirtualAddress; size_t len = sec->SizeOfRawData < sec->Misc.VirtualSize ? sec->SizeOfRawData : sec->Misc.VirtualSize;
        for (size_t k = 0; k + n <= len; k++) if (p[k] == (uint8_t)str[0] && !memcmp(p + k, str, n)) return true;
    }
    return false;
}

BOOL WINAPI DllMain(HINSTANCE h, DWORD reason, LPVOID) {
    if (reason == DLL_PROCESS_ATTACH) {
        g_self = h;
        DisableThreadLibraryCalls(h);
        ProxyLoad(h);
        wchar_t exe[MAX_PATH]; GetModuleFileNameW(nullptr, exe, MAX_PATH);
        std::wstring e = exe; e = e.substr(e.find_last_of(L'\\') + 1);
        for (auto& c : e) c = (wchar_t)towlower(c);
        // the game: by its file name (Game_f_x64_EOS.exe on Epic; Game_f_x64*.exe in any other store / build), or - if the
        // exe was renamed - by its contents (its settings folder name)
        bool named = e.find(L"game_f") != std::wstring::npos || e.find(L"alanwake") != std::wstring::npos || e.find(L"alan wake") != std::wstring::npos;
        if (!named && !ExeContains("AlanWakeRemastered\\")) return TRUE;
        wchar_t mx[64]; wsprintfW(mx, L"Local\\AWRVR_%lu", GetCurrentProcessId());
        HANDLE m = CreateMutexW(nullptr, TRUE, mx);
        if (m && GetLastError() == ERROR_ALREADY_EXISTS) { void DiagNoteSecondCopy(); DiagNoteSecondCopy(); return TRUE; }
        Init();
    } else if (reason == DLL_PROCESS_DETACH && !g_modDir.empty()) {
        EngineShutdown();   // a clean exit is not a true-stereo freeze
    }
    return TRUE;
}
