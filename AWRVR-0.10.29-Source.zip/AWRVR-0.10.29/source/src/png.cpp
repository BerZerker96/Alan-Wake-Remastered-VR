// Minimal PNG writer for screenshots (RGBA8): zlib stream with stored (uncompressed) deflate blocks, CRC32 + Adler32.
#include <windows.h>
#include <cstdio>
#include <cstdint>
#include <string>
#include <vector>

static uint32_t Crc(const uint8_t* p, size_t n, uint32_t c = 0xFFFFFFFFu) {
    static uint32_t t[256]; static bool init = false;
    if (!init) { for (uint32_t i = 0; i < 256; i++) { uint32_t v = i; for (int k = 0; k < 8; k++) v = v & 1 ? 0xEDB88320u ^ (v >> 1) : v >> 1; t[i] = v; } init = true; }
    for (size_t i = 0; i < n; i++) c = t[(c ^ p[i]) & 255] ^ (c >> 8);
    return c;
}
static void Be32(std::vector<uint8_t>& o, uint32_t v) { o.push_back(v >> 24); o.push_back(v >> 16); o.push_back(v >> 8); o.push_back(v); }
static void Chunk(std::vector<uint8_t>& out, const char* type, const std::vector<uint8_t>& data) {
    Be32(out, (uint32_t)data.size());
    size_t start = out.size();
    out.insert(out.end(), type, type + 4); out.insert(out.end(), data.begin(), data.end());
    Be32(out, Crc(&out[start], out.size() - start) ^ 0xFFFFFFFFu);
}

bool PngWrite(const std::wstring& path, const uint8_t* rgba, unsigned w, unsigned h, unsigned pitch) {
    std::vector<uint8_t> raw; raw.reserve((size_t)(w * 4 + 1) * h);
    for (unsigned y = 0; y < h; y++) { raw.push_back(0); raw.insert(raw.end(), rgba + (size_t)y * pitch, rgba + (size_t)y * pitch + w * 4); }
    std::vector<uint8_t> z; z.push_back(0x78); z.push_back(0x01);
    uint32_t a = 1, b = 0;
    for (size_t i = 0; i < raw.size(); i++) { a = (a + raw[i]) % 65521; b = (b + a) % 65521; }
    for (size_t off = 0; off < raw.size() || off == 0; off += 65535) {
        size_t n = raw.size() - off < 65535 ? raw.size() - off : 65535;
        z.push_back(off + n >= raw.size() ? 1 : 0);
        z.push_back(n & 255); z.push_back(n >> 8); z.push_back(~n & 255); z.push_back((~n >> 8) & 255);
        z.insert(z.end(), raw.begin() + off, raw.begin() + off + n);
        if (off + n >= raw.size()) break;
    }
    Be32(z, (b << 16) | a);
    std::vector<uint8_t> out = { 0x89, 'P', 'N', 'G', 13, 10, 26, 10 };
    std::vector<uint8_t> ihdr; Be32(ihdr, w); Be32(ihdr, h); ihdr.push_back(8); ihdr.push_back(6); ihdr.push_back(0); ihdr.push_back(0); ihdr.push_back(0);
    Chunk(out, "IHDR", ihdr); Chunk(out, "IDAT", z); Chunk(out, "IEND", {});
    FILE* f = _wfopen(path.c_str(), L"wb"); if (!f) return false;
    bool ok = fwrite(out.data(), 1, out.size(), f) == out.size(); fclose(f);
    return ok;
}
