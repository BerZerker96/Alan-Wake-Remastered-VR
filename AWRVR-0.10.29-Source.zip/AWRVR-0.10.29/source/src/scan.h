#pragma once
// Exe scanning for version-agnostic hooks: sections, AOB patterns with wildcards, RTTI vtable lookup,
// rel32 / rip-relative helpers and a tiny instruction-field reader. Nothing here uses a hard-coded address.
#include <windows.h>
#include <cstdint>
#include <vector>
#include <cstring>

struct ExeImage {
    uint8_t* base = nullptr; size_t size = 0;
    uint8_t* text = nullptr; size_t textSize = 0;          // first executable section
    struct Sec { uint8_t* p; size_t n; DWORD ch; char name[9]; };
    std::vector<Sec> secs;
};
extern ExeImage g_exe;

bool ScanInit();                                            // the game exe (main module), once
bool ScanInitModule(HMODULE m);                             // a given image (tests)
bool InText(const void* p);
uint32_t Rva(const void* p);
// "48 8B ?? 05" style pattern. Returns up to maxHits matches in [start, start+len).
std::vector<uint8_t*> ScanPattern(const char* pattern, uint8_t* start, size_t len, int maxHits = 16);
std::vector<uint8_t*> ScanText(const char* pattern, int maxHits = 16);
// Vtable of a class by its mangled RTTI name (".?AVPerspectiveView@rend@@"), complete-object offset 0.
void** RttiVtable(const char* mangledName, uint32_t colOffset = 0);
// MSVC class name of a live object (".?AVPlayerCamera@@"), "" if it has no RTTI.
const char* RttiName(const void* obj);
bool RttiIs(const void* obj, const char* mangledName);
// Reads a little-endian int32 at p.
inline int32_t ReadI32(const uint8_t* p) { int32_t v; memcpy(&v, p, 4); return v; }
// rip-relative target of the instruction at p (displacement at p+dispOff, instruction length len)
inline uint8_t* RipTarget(uint8_t* p, int dispOff, int len) { return p + len + ReadI32(p + dispOff); }
// address of a zero-terminated string in the exe's data sections (exact match), nullptr if absent
uint8_t* FindString(const char* s);
// Target of E8/E9 rel32 at p.
uint8_t* Rel32Target(uint8_t* p);
// Searches forward from p (up to len bytes) for an exact byte sequence; returns the address or nullptr.
uint8_t* FindBytes(uint8_t* p, size_t len, const uint8_t* bytes, size_t n);
// Patch an import address table entry of the exe (module name case-insensitive). Returns the old pointer.
void* PatchImport(const char* dll, const char* func, void* replacement);
// Readable memory check (cached per 4 KB page for 50 ms, VirtualQuery gets slow in big processes).
bool Readable(const void* p, size_t n);
