#pragma once
// Head aim, the part without hooks (unit tested in tests/test_headaim.cpp).
//
// Alan Wake Remastered keeps the player's aim in one object (the aim of PlayerInputReader, +0x50; the global the
// game's getter returns): +0x00 aim point (what a ray from the aim origin hits), +0x0C aim origin (a point on Alan's
// shoulder), +0x18 aim direction, +0x24 yaw, +0x28 pitch (radians). Once a frame the game turns yaw / pitch by the
// stick / mouse (and aim assist), clamps the pitch, builds the direction from the angles, casts the ray and stores the
// hit as the aim point. The gun, the flashlight, Alan's arms and aim assist use the direction / point; the player
// camera looks along the direction.
//
// Head aim (aim only): around that update the angles are swapped for the head's, so the game builds the direction and
// casts the ray where the head looks (from the eyes, optionally). Afterwards the angles go back to the game's own plus
// the turn the player made this frame (stick, mouse, assist) - the camera keeps turning only with the stick - and the
// camera's reads of the direction get the game's own direction. Shots and the flashlight go where the head looks.
#include "vrmath.h"
#include <cmath>
#include <cstring>

namespace ha {

constexpr double kPi = 3.14159265358979323846;
inline double WrapPi(double a) { while (a > kPi) a -= 2 * kPi; while (a < -kPi) a += 2 * kPi; return a; }

// the game's own math (found in the exe; fakes in the test)
struct GameFns {
    void (*dirToAngles)(const float* dir, float* pitch, float* yaw) = nullptr;   // exe+29b8a0 in 1.33
    void (*euler)(float* out, float pitch, float yaw, float roll, int order) = nullptr;   // exe+14c4c0: 3x3, row 2 = direction
    float pitchLo = -1.2f, pitchHi = 1.2f;   // Aim:Min / Max Vertical Angle (radians)
};
inline V3 DirFromAngles(const GameFns& g, float pitch, float yaw) {
    float m[16] = {}; g.euler(m, pitch, yaw, 0.f, 0);
    return Norm(V3{ m[6], m[7], m[8] });
}

// head forward in tracking space (OpenXR: -Z forward) from the head quaternion
inline V3 HeadFwdTracking(const float q[4]) {
    M3 R = QuatToM3(q[0], q[1], q[2], q[3]);
    return { -R.m[0][2], -R.m[1][2], -R.m[2][2] };
}
// a tracking-space vector in the world, through the drawn camera base (rows right / up / forward, +z forward)
inline V3 TrackingToWorld(const Xf& b, V3 t) { return Norm(b.r[0] * t.x + b.r[1] * t.y + b.r[2] * (-t.z)); }
inline V3 EyesWorld(const Xf& b, const float p[3], double ws) { return b.p + b.r[0] * (p[0] * ws) + b.r[1] * (p[1] * ws) + b.r[2] * (-p[2] * ws); }

// time-based tremor filter in tracking space: a stick turn of the camera is never delayed (it is applied after)
struct Smoother {
    V3 v{ 0, 0, -1 }; bool have = false;
    V3 Step(V3 in, double dt, double smoothing) {
        if (smoothing > 0.01 && have) { if (dt > 0) { double k = 1.0 - exp(-dt / (0.15 * smoothing)); v = Norm(v + (in - v) * k); } }
        else v = in;
        have = true; return v;
    }
};

// One aim update with the head. aim = the game's aim object; update = the game's own update (called once).
// headWorld: where the head looks (world). Returns the game's own direction (what the camera must see).
struct Result { V3 gameDir, headDir; float gameYaw, gamePitch, headYaw, headPitch; bool ok; };
template <class Update>
Result AimWithHead(const GameFns& g, unsigned char* aim, V3 headWorld, double blend, Update update) {
    Result r{}; float y0, p0; memcpy(&y0, aim + 0x24, 4); memcpy(&p0, aim + 0x28, 4);
    V3 g0 = DirFromAngles(g, p0, y0);
    V3 d = Norm(g0 * (1.0 - blend) + headWorld * blend);
    if (Len(d) < 0.5) d = g0;
    float dir[3] = { (float)d.x, (float)d.y, (float)d.z }, hp = p0, hy = y0;
    g.dirToAngles(dir, &hp, &hy);
    float lo = g.pitchLo < g.pitchHi ? g.pitchLo : g.pitchHi, hi = g.pitchLo < g.pitchHi ? g.pitchHi : g.pitchLo;
    hp = hp < lo ? lo : hp > hi ? hi : hp;   // within the game's limits: its clamp never eats the stick's turn
    memcpy(aim + 0x24, &hy, 4); memcpy(aim + 0x28, &hp, 4);
    update();                                      // the game: + stick / mouse / assist, direction, ray, aim point
    float y1, p1; memcpy(&y1, aim + 0x24, 4); memcpy(&p1, aim + 0x28, 4);
    double dy = WrapPi((double)y1 - hy), dp = (double)p1 - hp;
    float gy = (float)WrapPi((double)y0 + dy), gp = (float)((double)p0 + dp);
    gp = gp < lo ? lo : gp > hi ? hi : gp;
    memcpy(aim + 0x24, &gy, 4); memcpy(aim + 0x28, &gp, 4);   // the camera keeps the game's own angles
    float hd[3]; memcpy(hd, aim + 0x18, 12);
    r.headDir = { hd[0], hd[1], hd[2] }; r.gameDir = DirFromAngles(g, gp, gy);
    r.gameYaw = gy; r.gamePitch = gp; r.headYaw = y1; r.headPitch = p1; r.ok = true;
    return r;
}

// after a ray cast from the eyes: the game's own origin (the shoulder) goes back into the object and the direction
// becomes shoulder -> aim point, so everything that aims from Alan points at what the player looks at. Not when the
// point is too close (or behind): then the head's direction stays. Returns the direction that is left in the object.
inline V3 ConvergeFromShoulder(unsigned char* aim, V3 shoulder, V3 headDir, double minDist) {
    float tp[3], sh[3] = { (float)shoulder.x, (float)shoulder.y, (float)shoulder.z }; memcpy(tp, aim, 12);
    memcpy(aim + 0x0C, sh, 12);
    V3 v = V3{ tp[0], tp[1], tp[2] } - shoulder;
    if (Len(v) > minDist && Dot(Norm(v), headDir) > 0.5) {
        V3 d = Norm(v); float df[3] = { (float)d.x, (float)d.y, (float)d.z }; memcpy(aim + 0x18, df, 12); return d;
    }
    return headDir;
}

inline double AngleDeg(V3 a, V3 b) { double d = Dot(Norm(a), Norm(b)); d = d > 1 ? 1 : d < -1 ? -1 : d; return acos(d) * 57.29577951; }

} // namespace ha
