// Mouse for the VR panel: while the panel is open, a low-level mouse hook (own thread, own message loop) takes the
// mouse's movement, buttons and wheel and keeps them from the game (no camera turning or shooting while you click in
// the panel); the panel draws its own cursor. Only while the game window is in front - on the desktop the mouse is
// left alone. The hook exists only while the panel is open.
#include <windows.h>
#include <atomic>
#include "log.h"

namespace {
std::atomic<DWORD> g_tid{0};
std::atomic<bool> g_want{false}, g_hooked{false};
std::atomic<long> g_dx{0}, g_dy{0}, g_wheel{0};
std::atomic<bool> g_l{false}, g_r{false};
std::atomic<int> g_extraVk{0};      // last middle / side button pressed (hotkey capture)
std::atomic<long> g_rDowns{0};      // right-button presses (cancels a hotkey capture)
HHOOK g_hook = nullptr;
constexpr UINT WM_AWRVR_SYNC = WM_APP + 0x51;

bool GameInFront() {
    HWND fg = GetForegroundWindow(); DWORD pid = 0;
    if (fg) GetWindowThreadProcessId(fg, &pid);
    return pid == GetCurrentProcessId();
}
LRESULT CALLBACK Proc(int code, WPARAM wp, LPARAM lp) {
    if (code != HC_ACTION || !g_want.load(std::memory_order_relaxed) || !GameInFront()) return CallNextHookEx(nullptr, code, wp, lp);
    const MSLLHOOKSTRUCT* m = (const MSLLHOOKSTRUCT*)lp;
    if (m->flags & LLMHF_INJECTED) return CallNextHookEx(nullptr, code, wp, lp);   // another tool's synthetic input
    switch (wp) {
    case WM_MOUSEMOVE:
        // the event is blocked, so the system cursor stays where it is: movement = the event's point - the cursor now
        // (also right if the game moves the cursor itself)
        { POINT c; if (GetCursorPos(&c)) { g_dx += m->pt.x - c.x; g_dy += m->pt.y - c.y; } } break;
    case WM_LBUTTONDOWN: g_l = true; break;
    case WM_RBUTTONDOWN: g_r = true; g_rDowns++; break;
    case WM_MBUTTONDOWN: g_extraVk = VK_MBUTTON; break;
    case WM_XBUTTONDOWN: g_extraVk = HIWORD(m->mouseData) == XBUTTON1 ? VK_XBUTTON1 : VK_XBUTTON2; break;
    case WM_MOUSEWHEEL: g_wheel += (short)HIWORD(m->mouseData); break;
    // releases always reach the game: a button held when the panel opened must not stay "down" in the game
    case WM_LBUTTONUP: g_l = false; return CallNextHookEx(nullptr, code, wp, lp);
    case WM_RBUTTONUP: g_r = false; return CallNextHookEx(nullptr, code, wp, lp);
    case WM_MBUTTONUP: case WM_XBUTTONUP: return CallNextHookEx(nullptr, code, wp, lp);
    default: break;   // horizontal wheel: also kept from the game
    }
    return 1;
}
DWORD WINAPI Thread(LPVOID) {
    MSG msg; PeekMessageW(&msg, nullptr, WM_USER, WM_USER, PM_NOREMOVE);   // create the queue
    g_tid = GetCurrentThreadId();
    while (GetMessageW(&msg, nullptr, 0, 0) > 0) {
        if (msg.message == WM_AWRVR_SYNC) {
            bool want = g_want.load();
            if (want && !g_hook) {
                // the cursor to the middle of the game's screen: at an edge, movement towards it would be lost
                HWND fg = GetForegroundWindow(); DWORD pid = 0; if (fg) GetWindowThreadProcessId(fg, &pid);
                if (fg && pid == GetCurrentProcessId()) { RECT rc; if (GetWindowRect(fg, &rc)) SetCursorPos((rc.left + rc.right) / 2, (rc.top + rc.bottom) / 2); }
                g_hook = SetWindowsHookExW(WH_MOUSE_LL, Proc, GetModuleHandleW(nullptr), 0);
                g_hooked = g_hook != nullptr;
                if (!g_hook) LOGW("panel mouse: hook failed (%lu) - the panel works with the gamepad / keyboard", GetLastError());
            } else if (!want && g_hook) {
                UnhookWindowsHookEx(g_hook); g_hook = nullptr; g_hooked = false; g_l = g_r = false;
            }
        }
    }
    return 0;
}
}  // namespace

// Present thread: open / closed state of the panel
void PanelMouseSetActive(bool on) {
    if (on == g_want.load()) return;
    if (!g_tid.load()) { CreateThread(nullptr, 0, Thread, nullptr, 0, nullptr); for (int i = 0; i < 100 && !g_tid.load(); i++) Sleep(1); }
    g_want = on;
    if (on) { g_dx = 0; g_dy = 0; g_wheel = 0; }
    PostThreadMessageW(g_tid.load(), WM_AWRVR_SYNC, 0, 0);
}
// movement since the last call (pixels), wheel in notches, buttons now
void PanelMouseTake(float* dx, float* dy, float* wheel, bool* l, bool* r) {
    *dx = (float)g_dx.exchange(0); *dy = (float)g_dy.exchange(0); *wheel = g_wheel.exchange(0) / 120.f;
    *l = g_l.load(); *r = g_r.load();
}
int PanelMouseTakeExtraButton() { return g_extraVk.exchange(0); }
long PanelMouseRightPresses() { return g_rDowns.load(); }
