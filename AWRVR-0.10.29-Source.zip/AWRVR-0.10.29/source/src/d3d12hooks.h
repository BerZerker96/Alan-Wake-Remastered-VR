#pragma once
// D3D12 command list / device hooks (guide 10, 11b, E.1, D.2): render-target and depth tracking, the scene depth,
// the picture before the UI, UI classification + viewport scaling, hide HUD, foveated rendering (VRS tier 2).
#include <windows.h>
#include <d3d12.h>
#include <dxgi1_4.h>
#include <cstdint>

struct CaptureTargets {                 // set by the compositor (its shared textures, opened in D3D12)
    ID3D12Resource* noUi[3] = {};       // same format family as the back buffer
    ID3D12Resource* depth[3] = {};      // RGBA8 (4-byte depth) / RG8 (16-bit depth) bytes of the scene depth
    UINT depthW = 0, depthH = 0;
    DXGI_FORMAT depthFmt = DXGI_FORMAT_UNKNOWN;   // the game's depth resource format
    bool wantNoUi = false, wantDepth = false;
    ID3D12Resource* eye0[3] = {};       // true stereo: the first eye's final picture (same format as noUi)
    bool wantEye0 = false;
};

struct FrameCapture {                    // what the hooks captured for the Present being made
    bool noUi = false, depth = false;
    bool eye0 = false;                   // true stereo: the first eye's picture was copied this frame
    int slot = 0;
    UINT finalDraws = 0, uiDraws = 0, uiScaled = 0;
    ID3D12Resource* sceneDepth = nullptr; UINT sceneDepthW = 0, sceneDepthH = 0; DXGI_FORMAT sceneDepthFmt = DXGI_FORMAT_UNKNOWN;
};

bool D3DHooksInstall();                                   // init thread: dummy device -> vtables -> hooks
void D3DHooksSetTargets(const CaptureTargets& t);         // Present thread
FrameCapture D3DHooksOnPresent(IDXGISwapChain3* sc, ID3D12Device* dev);   // Present thread, before our capture list
void D3DHooksVrsUpdate(ID3D12Device* dev, ID3D12GraphicsCommandList* list, UINT w, UINT h); // Present thread, our own list
void D3DHooksReport();
int D3DHooksUiCandidates();
bool D3DHooksUiSeen();                                    // the HUD has been found as separate draws at least once                               // for the panel's status line
