#pragma once
// Math for the Northlight camera. The engine stores a node transform as 12 doubles: three rotation rows
// (right, up, forward: the local x / y / z axes in world space) followed by the position, and uses row vectors
// (v_world = v_local * R + pos). Camera space is left-handed: x right, y up, +z forward (the projection has
// m[2][3] = 1). OpenXR poses are right-handed with -z forward, so a vector converts by flipping z.
#include <cmath>
#include <cstring>

struct V3 { double x, y, z; };
inline V3 operator+(V3 a, V3 b) { return { a.x + b.x, a.y + b.y, a.z + b.z }; }
inline V3 operator-(V3 a, V3 b) { return { a.x - b.x, a.y - b.y, a.z - b.z }; }
inline V3 operator*(V3 a, double s) { return { a.x * s, a.y * s, a.z * s }; }
inline double Dot(V3 a, V3 b) { return a.x * b.x + a.y * b.y + a.z * b.z; }
inline V3 Cross(V3 a, V3 b) { return { a.y * b.z - a.z * b.y, a.z * b.x - a.x * b.z, a.x * b.y - a.y * b.x }; }
inline double Len(V3 a) { return sqrt(Dot(a, a)); }
inline V3 Norm(V3 a) { double l = Len(a); return l > 1e-12 ? a * (1.0 / l) : V3{ 0, 0, 0 }; }

// node transform: r[0] right, r[1] up, r[2] forward, p position
struct Xf { V3 r[3]; V3 p; };
inline Xf XfFromDoubles(const double* d) {
    Xf x; for (int i = 0; i < 3; i++) x.r[i] = { d[i * 3], d[i * 3 + 1], d[i * 3 + 2] };
    x.p = { d[9], d[10], d[11] }; return x;
}
inline void XfToDoubles(const Xf& x, double* d) {
    for (int i = 0; i < 3; i++) { d[i * 3] = x.r[i].x; d[i * 3 + 1] = x.r[i].y; d[i * 3 + 2] = x.r[i].z; }
    d[9] = x.p.x; d[10] = x.p.y; d[11] = x.p.z;
}
inline double XfDet(const Xf& x) { return Dot(x.r[0], Cross(x.r[1], x.r[2])); }
inline bool XfSane(const Xf& x) {
    for (int i = 0; i < 3; i++) { double l = Len(x.r[i]); if (!(l > 0.9 && l < 1.1)) return false; }
    if (!(fabs(Dot(x.r[0], x.r[1])) < 0.1 && fabs(Dot(x.r[1], x.r[2])) < 0.1 && fabs(Dot(x.r[0], x.r[2])) < 0.1)) return false;
    double m = fabs(x.p.x) + fabs(x.p.y) + fabs(x.p.z);
    return m == m && m < 1e8;
}
inline bool XfNear(const Xf& a, const Xf& b, double eps) {
    for (int i = 0; i < 3; i++) if (Len(a.r[i] - b.r[i]) > eps) return false;
    return Len(a.p - b.p) < eps * 100;
}

// rotation matrix (column vectors, v' = R v) from a unit quaternion
struct M3 { double m[3][3]; };
inline M3 QuatToM3(double x, double y, double z, double w) {
    M3 r;
    r.m[0][0] = 1 - 2 * (y * y + z * z); r.m[0][1] = 2 * (x * y - z * w);     r.m[0][2] = 2 * (x * z + y * w);
    r.m[1][0] = 2 * (x * y + z * w);     r.m[1][1] = 1 - 2 * (x * x + z * z); r.m[1][2] = 2 * (y * z - x * w);
    r.m[2][0] = 2 * (x * z - y * w);     r.m[2][1] = 2 * (y * z + x * w);     r.m[2][2] = 1 - 2 * (x * x + y * y);
    return r;
}

// Local eye transform in the engine's camera space (left-handed, +z forward) from an OpenXR pose.
// S = diag(1,1,-1): R_lh = S R S. The rows of a node rotation are the local axes in parent space = the columns of R_lh.
struct EyeLocal { V3 r[3]; V3 p; };
inline EyeLocal EyeFromXr(const float q[4], const float pos[3], double scale) {
    M3 R = QuatToM3(q[0], q[1], q[2], q[3]);
    double s[3] = { 1, 1, -1 };
    double L[3][3];
    for (int i = 0; i < 3; i++) for (int j = 0; j < 3; j++) L[i][j] = s[i] * R.m[i][j] * s[j];
    EyeLocal e;
    for (int i = 0; i < 3; i++) e.r[i] = { L[0][i], L[1][i], L[2][i] };
    e.p = { pos[0] * scale, pos[1] * scale, -pos[2] * scale };
    return e;
}

// world transform of the eye = eye (local, row vectors) composed with the camera base transform
inline Xf Compose(const EyeLocal& e, const Xf& b) {
    Xf o;
    for (int i = 0; i < 3; i++) o.r[i] = b.r[0] * e.r[i].x + b.r[1] * e.r[i].y + b.r[2] * e.r[i].z;
    o.p = b.p + b.r[0] * e.p.x + b.r[1] * e.p.y + b.r[2] * e.p.z;
    return o;
}

// Removes pitch and roll from a camera basis around the given world up axis, keeping yaw and the basis handedness.
inline Xf LevelBasis(const Xf& b, V3 up) {
    V3 f = b.r[2] - up * Dot(b.r[2], up);
    if (Len(f) < 1e-4) {   // looking straight up / down: heading from the up row
        V3 u = b.r[1] - up * Dot(b.r[1], up);
        f = Dot(b.r[2], up) > 0 ? u * -1.0 : u;
    }
    f = Norm(f);
    double hand = XfDet(b) >= 0 ? 1.0 : -1.0;
    Xf o = b;
    o.r[1] = up; o.r[2] = f; o.r[0] = Cross(up, f) * hand;
    return o;
}
