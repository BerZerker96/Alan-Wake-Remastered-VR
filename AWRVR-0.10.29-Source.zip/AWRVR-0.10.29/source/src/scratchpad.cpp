// The game's per-thread scratch pad (a frame allocator, reset once per frame): the main thread's is made with
// ScratchPadInit(0x400000) at exe+347781 (ScratchPadInit exe+3c2fa0 frees the old buffer, sets +4 = size and
// allocates; a request past the end raises "Scratch pad is full (trying to allocate %d bytes, total size %d)" from
// exe+3c2bfb as a fatal error box). True stereo renders the main view twice per frame, so one frame can need about
// twice the game's 4 MB - the game stopped with that error box during true stereo (0.10.22). The size is raised to
// 16 MB before the game makes the pad (patched at load; 12 MB more memory, nothing else changes).
#include <windows.h>
#include <cstdint>
#include <cstring>
#include "log.h"
#include "MinHook.h"
#include "scratchpad.h"

// the game's scratch pads (exe+d25940, 12 x 0x30: +0 thread id, +4 size, +8 in use now, +0xc used last frame, +0x10
// most ever used, +0x18 buffer) - found from ScratchPadInit's call to the pad getter, which loads the array first
static uint8_t* s_pads = nullptr;

void ScratchPadPatch() {
    uint8_t* base = (uint8_t*)GetModuleHandleW(nullptr);
    auto* dos = (IMAGE_DOS_HEADER*)base; if (dos->e_magic != IMAGE_DOS_SIGNATURE) return;
    auto* nt = (IMAGE_NT_HEADERS*)(base + dos->e_lfanew);
    auto* sec = IMAGE_FIRST_SECTION(nt);
    // ScratchPadInit's own start, to confirm the call target
    static const uint8_t initSig[] = { 0x48,0x89,0x5c,0x24,0x08, 0x57, 0x48,0x83,0xec,0x30, 0x48,0x63,0xf9, 0x33,0xc9, 0xe8 };
    uint8_t* hit = nullptr; int hits = 0;
    for (unsigned i = 0; i < nt->FileHeader.NumberOfSections; i++) {
        if (!(sec[i].Characteristics & IMAGE_SCN_MEM_EXECUTE)) continue;
        uint8_t* p = base + sec[i].VirtualAddress; size_t n = sec[i].Misc.VirtualSize;
        for (size_t k = 10; k + 10 <= n; k++) {
            // mov ecx,1 / call x / mov ecx,0x400000 / call ScratchPadInit
            if (p[k] != 0xb9 || memcmp(p + k + 1, "\x00\x00\x40\x00\xe8", 5) || p[k - 10] != 0xb9 || memcmp(p + k - 9, "\x01\x00\x00\x00\xe8", 5)) continue;
            uint8_t* tgt = p + k + 10 + *(int32_t*)(p + k + 6);
            if (tgt < base || tgt + sizeof initSig > base + nt->OptionalHeader.SizeOfImage || memcmp(tgt, initSig, sizeof initSig)) continue;
            if (!hit) hit = p + k; hits++;
        }
    }
    if (hits == 1) {   // ScratchPadInit +0xf: call getter; getter +0x11: lea rsi,[pads]
        uint8_t* fn = hit + 10 + *(int32_t*)(hit + 6);
        uint8_t* get = fn + 0x14 + *(int32_t*)(fn + 0x10);
        if (get[0x11] == 0x48 && get[0x12] == 0x8d && get[0x13] == 0x35) s_pads = get + 0x18 + *(int32_t*)(get + 0x14);
    }
    if (hits != 1) { LOGW("game: the main thread's scratch pad size not found (%d matches) - true stereo may stop with \"Scratch pad is full\"", hits); return; }
    DWORD op; if (!VirtualProtect(hit + 1, 4, PAGE_EXECUTE_READWRITE, &op)) return;
    *(uint32_t*)(hit + 1) = 0x1000000;
    VirtualProtect(hit + 1, 4, op, &op); FlushInstructionCache(GetCurrentProcess(), hit, 5);
    LOGI("game: the main thread's scratch pad 4 MB -> 16 MB (exe+%llx) - room for the two renders of true stereo", (unsigned long long)(hit - base));
}

// every report: each thread's pad, how full it got (true stereo renders twice per frame)
void ScratchPadReport() {
    if (!s_pads) return;
    char line[600]; int n = 0;
    for (int i = 0; i < 12; i++) {
        const uint8_t* e = s_pads + i * 0x30;
        unsigned tid = *(const unsigned*)e, size = *(const unsigned*)(e + 4), last = *(const unsigned*)(e + 0xc), peak = *(const unsigned*)(e + 0x10);
        if (!size) continue;
        n += snprintf(line + n, sizeof line - n, " [thread %u: %u KB, last frame %u KB, most %u KB]", tid, size >> 10, last >> 10, peak >> 10);
        if (n > (int)sizeof line - 80) break;
    }
    if (n) LOGI("game: scratch pads%s", line);
}

// the game's fatal errors end in a message box (exe+70b501): its text goes to the log too
using MsgW = int(WINAPI*)(HWND, LPCWSTR, LPCWSTR, UINT);
using MsgA = int(WINAPI*)(HWND, LPCSTR, LPCSTR, UINT);
static MsgW o_msgW; static MsgA o_msgA;
static int WINAPI H_MsgW(HWND h, LPCWSTR t, LPCWSTR c, UINT f) {
    LOGE("message box '%ls': %ls", c ? c : L"", t ? t : L""); ScratchPadReport();
    return o_msgW(h, t, c, f);
}
static int WINAPI H_MsgA(HWND h, LPCSTR t, LPCSTR c, UINT f) {
    LOGE("message box '%s': %s", c ? c : "", t ? t : ""); ScratchPadReport();
    return o_msgA(h, t, c, f);
}
void MessageBoxLogInstall() {
    HMODULE u = LoadLibraryW(L"user32.dll"); if (!u) return;
    void* w = (void*)GetProcAddress(u, "MessageBoxW"); void* a = (void*)GetProcAddress(u, "MessageBoxA");
    if (w && MH_CreateHook(w, (void*)H_MsgW, (void**)&o_msgW) == MH_OK) MH_EnableHook(w);
    if (a && MH_CreateHook(a, (void*)H_MsgA, (void**)&o_msgA) == MH_OK) MH_EnableHook(a);
}

// ---- true stereo: what the first of the two renders leaves on the scratch pad
// The caller of RendererRenderView gets one result and frees what that render left on the main thread's pad. With
// two renders per frame the first render's leftovers stay below the second's: the pad is a stack (a free that is not
// on top is only marked, and taken back when everything above it goes), so they were never taken back - the most
// used grew ~1.5 MB per 10 s until "Scratch pad is full" (0.10.24 log: 0.9 -> 16.2 MB in 70 s). After the first
// render the pad is put back to where it was before it (only when every block above that point is the first
// render's own - checked by walking the block list down to it).
bool ScratchPadMark(ScratchMark* m) {
    m->entry = nullptr;
    if (!s_pads) return false;
    unsigned tid = GetCurrentThreadId();
    for (int i = 0; i < 12; i++) {
        uint8_t* e = s_pads + i * 0x30;
        if (*(unsigned*)e == tid && *(unsigned*)(e + 4)) {
            m->entry = e; m->top = *(void**)(e + 0x28); m->cur = *(void**)(e + 0x20); m->used = *(int*)(e + 8);
            return true;
        }
    }
    return false;
}
int ScratchPadRelease(const ScratchMark& m) {
    if (!m.entry) return -1;
    uint8_t* e = (uint8_t*)m.entry;
    void* node = *(void**)(e + 0x28); int n = 0;
    while (node && node != m.top && n < 100000) { node = *(void**)((uint8_t*)node + 8); n++; }
    if (node != m.top) return -1;                 // the list does not lead back to the mark: leave the pad alone
    *(void**)(e + 0x28) = m.top; *(void**)(e + 0x20) = m.cur; *(int*)(e + 8) = m.used;
    return n;
}
