// Diagnostics and the SETUP CHECK (framework "Warnings and Fixes", sections 3 and 8).
//   * Everything runs once at start, on an event, or with the 10 s report - never per frame. Nothing here changes an
//     option: it only reports.
//   * SETUP CHECK: what is known to break VR in a player's setup and is not an AWRVR bug - motion smoothing, other
//     mods / loaders / a second copy, overlays that hook rendering, a cropped field of view, upscaling or a low render
//     size, TAA with eye-alternating stereo, changed stereo settings. ERROR lines in ===== frames, printed when the
//     result changes and every 5 minutes while there is anything; a count on the VR panel's status line.
//   * Diagnostics: run header (the previous run's logs are kept as *.prev.log), system summary, config differences
//     from the defaults and every option change, a crash report, VRAM over budget, LOW FPS FOR THIS MODE, UNCAPPED
//     FRAME RATE IN VR, HEALTH every 60 s, USER MARK #n and a report folder (panel buttons).
#include <windows.h>
#include <dxgi1_4.h>
#include <psapi.h>
#include <shellapi.h>
#include <cstdio>
#include <cstring>
#include <cmath>
#include <string>
#include <vector>
#include <map>
#include <atomic>
#include <algorithm>
#include "log.h"
#include "settings.h"
#include "engine.h"
#include "game.h"
#include "upscaler.h"
#include "version.h"
#include "realclock.h"
#include "vrkit_options.h"
#include "xrbridge/client.h"

extern std::wstring g_modDir, g_cfgPath, g_proxyName;
extern HMODULE g_self;
const char* DefaultConfigText();        // main.cpp
unsigned ResolutionWantedW(); unsigned ResolutionWantedH();

namespace {
std::atomic<int> g_problemCount{0};
std::atomic<float> g_rawHz{0}, g_knownHz{0}, g_gameFps{0};
std::atomic<bool> g_smoothing{false};
IDXGIAdapter3* g_adapter = nullptr;
std::atomic<unsigned> g_renderW{0}, g_renderH{0};
std::string g_lastSetup = "\x01"; DWORD g_lastSetupAt = 0;   // "\x01": nothing printed yet
int g_markN = 0;
LPTOP_LEVEL_EXCEPTION_FILTER g_prevFilter = nullptr;
std::map<std::string, std::string> g_snapshot;

std::string Lower(std::string s) { for (auto& c : s) c = (char)tolower((unsigned char)c); return s; }
std::wstring LowerW(std::wstring s) { for (auto& c : s) c = (wchar_t)towlower(c); return s; }
std::string Narrow(const std::wstring& w) { std::string s; for (wchar_t c : w) s += c < 128 ? (char)c : '?'; return s; }
bool RegDword(HKEY root, const wchar_t* key, const wchar_t* val, DWORD* out, REGSAM extra = 0) {
    DWORD sz = sizeof(DWORD);
    return RegGetValueW(root, key, val, RRF_RT_REG_DWORD | (extra ? RRF_SUBKEY_WOW6464KEY : 0), nullptr, out, &sz) == ERROR_SUCCESS;
}
std::wstring RegStr(HKEY root, const wchar_t* key, const wchar_t* val) {
    wchar_t buf[512]; DWORD sz = sizeof buf;
    if (RegGetValueW(root, key, val, RRF_RT_REG_SZ, nullptr, buf, &sz) != ERROR_SUCCESS) return L"";
    return buf;
}
std::wstring ExeDir() { wchar_t p[MAX_PATH]; GetModuleFileNameW(nullptr, p, MAX_PATH); std::wstring s = p; return s.substr(0, s.find_last_of(L'\\')); }
std::wstring SelfPath() { wchar_t p[MAX_PATH] = L""; GetModuleFileNameW(g_self, p, MAX_PATH); return p; }

// ---------------------------------------------------------------- crash report
void AddrText(DWORD64 a, char* out, size_t n) {
    HMODULE m = nullptr; wchar_t path[MAX_PATH] = L"?";
    if (GetModuleHandleExW(GET_MODULE_HANDLE_EX_FLAG_FROM_ADDRESS | GET_MODULE_HANDLE_EX_FLAG_UNCHANGED_REFCOUNT, (LPCWSTR)a, &m) && m) GetModuleFileNameW(m, path, MAX_PATH);
    else { snprintf(out, n, "%llx", (unsigned long long)a); return; }
    const wchar_t* b = wcsrchr(path, L'\\'); b = b ? b + 1 : path;
    snprintf(out, n, "%ls+%llx", b, (unsigned long long)(a - (DWORD64)m));
}
bool IsCode(DWORD64 a) {
    MEMORY_BASIC_INFORMATION mi;
    if (a < 0x10000 || !VirtualQuery((void*)a, &mi, sizeof mi) || mi.State != MEM_COMMIT) return false;
    return (mi.Protect & (PAGE_EXECUTE | PAGE_EXECUTE_READ | PAGE_EXECUTE_READWRITE | PAGE_EXECUTE_WRITECOPY)) && mi.Type == MEM_IMAGE;
}
LONG WINAPI CrashFilter(EXCEPTION_POINTERS* e) {
    static std::atomic<int> once{0};
    if (once.fetch_add(1) == 0 && e && e->ExceptionRecord && e->ContextRecord) {
        const EXCEPTION_RECORD* r = e->ExceptionRecord; const CONTEXT* c = e->ContextRecord;
        char at[160]; AddrText((DWORD64)r->ExceptionAddress, at, sizeof at);
        LOGE("CRASH: exception %08lx at %s (thread %lu)%s", (unsigned long)r->ExceptionCode, at, GetCurrentThreadId(),
             r->ExceptionCode == EXCEPTION_ACCESS_VIOLATION && r->NumberParameters >= 2 ? (r->ExceptionInformation[0] ? " - writing" : " - reading") : "");
        if (r->ExceptionCode == EXCEPTION_ACCESS_VIOLATION && r->NumberParameters >= 2) LOGE("CRASH: address %llx", (unsigned long long)r->ExceptionInformation[1]);
        LOGE("CRASH: rax %llx rbx %llx rcx %llx rdx %llx rsi %llx rdi %llx rbp %llx rsp %llx", c->Rax, c->Rbx, c->Rcx, c->Rdx, c->Rsi, c->Rdi, c->Rbp, c->Rsp);
        LOGE("CRASH: r8 %llx r9 %llx r10 %llx r11 %llx r12 %llx r13 %llx r14 %llx r15 %llx", c->R8, c->R9, c->R10, c->R11, c->R12, c->R13, c->R14, c->R15);
        std::string st; int n = 0;
        const DWORD64* sp = (const DWORD64*)c->Rsp;
        for (int i = 0; i < 512 && n < 16; i++) {
            MEMORY_BASIC_INFORMATION mi;
            if (!VirtualQuery(sp + i, &mi, sizeof mi) || mi.State != MEM_COMMIT) break;
            DWORD64 v = sp[i];
            if (IsCode(v)) { char t[160]; AddrText(v, t, sizeof t); st += " "; st += t; n++; }
        }
        LOGE("CRASH: stack code addresses:%s", st.c_str());
        LOGE("CRASH: mod state - method %s (%d), game state %s, presents %ld - please send this log (and awrvr.prev.log after a restart)",
             g_set.vrMode.c_str(), EngineEffectiveMode(), GameStateName(GameStateNow()), (long)EnginePresentCount());
        LogFlushDisk();
    }
    return g_prevFilter ? g_prevFilter(e) : EXCEPTION_CONTINUE_SEARCH;
}
void InstallCrashFilter(const char* when) {
    LPTOP_LEVEL_EXCEPTION_FILTER prev = SetUnhandledExceptionFilter(CrashFilter);
    if (prev != CrashFilter) g_prevFilter = prev;
    LOGI("diag: crash report installed (%s)%s", when, prev && prev != CrashFilter ? " - chained to the game's own" : "");
}

// ---------------------------------------------------------------- system summary (once, at the first report)
void SystemSummary() {
    OSVERSIONINFOEXW v{ sizeof v };
    using RtlGetVersionFn = LONG(WINAPI*)(OSVERSIONINFOEXW*);
    if (auto f = (RtlGetVersionFn)GetProcAddress(GetModuleHandleW(L"ntdll.dll"), "RtlGetVersion")) f(&v);
    std::wstring cpu = RegStr(HKEY_LOCAL_MACHINE, L"HARDWARE\\DESCRIPTION\\System\\CentralProcessor\\0", L"ProcessorNameString");
    MEMORYSTATUSEX ms{ sizeof ms }; GlobalMemoryStatusEx(&ms);
    DWORD hags = 0, gm = 1; bool haveHags = RegDword(HKEY_LOCAL_MACHINE, L"SYSTEM\\CurrentControlSet\\Control\\GraphicsDrivers", L"HwSchMode", &hags);
    bool haveGm = RegDword(HKEY_CURRENT_USER, L"Software\\Microsoft\\GameBar", L"AutoGameModeEnabled", &gm);
    DEVMODEW dm{}; dm.dmSize = sizeof dm; EnumDisplaySettingsW(nullptr, ENUM_CURRENT_SETTINGS, &dm);
    while (!cpu.empty() && cpu.back() == L' ') cpu.pop_back();
    LOGI("system: Windows %lu.%lu build %lu | CPU %ls (%lu threads) | RAM %llu GB | HAGS %s | Game Mode %s | monitor %lux%lu %lu Hz",
         v.dwMajorVersion, v.dwMinorVersion, v.dwBuildNumber, cpu.c_str(), GetActiveProcessorCount(ALL_PROCESSOR_GROUPS),
         (unsigned long long)((ms.ullTotalPhys + (1ull << 29)) >> 30), haveHags ? (hags == 2 ? "on" : "off") : "?", haveGm ? (gm ? "on" : "off") : "on (default)",
         dm.dmPelsWidth, dm.dmPelsHeight, dm.dmDisplayFrequency);
    wchar_t exe[MAX_PATH]; GetModuleFileNameW(nullptr, exe, MAX_PATH);
    WIN32_FILE_ATTRIBUTE_DATA fa{}; GetFileAttributesExW(exe, GetFileExInfoStandard, &fa);
    std::wstring en = LowerW(exe); std::wstring store = en.find(L"_eos") != std::wstring::npos ? L"Epic" : en.find(L"steamapps") != std::wstring::npos ? L"Steam" : L"other";
    LOGI("system: store %ls, exe %ls (%llu bytes) | OpenXR runtime %s, headset %s | the mod: %ls loaded as %ls",
         store.c_str(), wcsrchr(exe, L'\\') ? wcsrchr(exe, L'\\') + 1 : exe, ((unsigned long long)fa.nFileSizeHigh << 32) | fa.nFileSizeLow,
         *xrb::ClientRuntimeName() ? xrb::ClientRuntimeName() : "(not started yet)", *xrb::ClientSystemName() ? xrb::ClientSystemName() : "?",
         SelfPath().c_str(), g_proxyName.c_str());
    if (g_adapter) {
        DXGI_ADAPTER_DESC1 d{}; g_adapter->GetDesc1(&d);
        LARGE_INTEGER umd{}; std::string drv = "?";
        if (SUCCEEDED(g_adapter->CheckInterfaceSupport(__uuidof(IDXGIDevice), &umd))) {
            char b[64]; snprintf(b, sizeof b, "%u.%u.%u.%u", HIWORD(umd.HighPart), LOWORD(umd.HighPart), HIWORD(umd.LowPart), LOWORD(umd.LowPart)); drv = b;
        }
        LOGI("system: GPU %ls, driver %s, VRAM %llu MB", d.Description, drv.c_str(), (unsigned long long)(d.DedicatedVideoMemory >> 20));
    }
}

// ---------------------------------------------------------------- SETUP CHECK
struct Problem { int order; std::string text; };
const char* kProxyNames[] = { "dinput8.dll", "winmm.dll", "version.dll", "d3d11.dll", "d3d12.dll", "dxgi.dll", "xinput1_3.dll", "xinput1_4.dll",
                              "dsound.dll", "d3d9.dll", "winhttp.dll", "wininet.dll", "reshade64.dll", "reshade.ini", "dxgi_chain.dll", "dbghelp.dll" };   // the mod's own file is skipped
const char* kModuleWords[] = { ".asi", "reshade", "toolkit", "vectorxr", "xr_apilayer", "api_layer", "freepie", "igcs", "specialk", "dxvk", "fsr3", "framegen",
                               "lossless", "uevr", "vorpx", "optiscaler", "dlssg_to_fsr3" };   // nvngx_dlssg.dll ships with the game: frame generation is measured instead
struct Overlay { const char* file; const char* name; };
const Overlay kOverlays[] = { { "rtsshooks64.dll", "RivaTuner Statistics Server / MSI Afterburner" }, { "discordhook64.dll", "Discord overlay" },
                              { "graphics-hook64.dll", "OBS game capture" }, { "igo64.dll", "EA app overlay" }, { "overlay64.dll", "an overlay (overlay64.dll)" } };

void FilesNextToExe(std::vector<Problem>& out) {
    std::wstring dir = ExeDir(); std::wstring self = LowerW(SelfPath());
    std::string found;
    for (const char* n : kProxyNames) {
        if (!*n) continue;
        std::wstring p = dir + L"\\" + std::wstring(n, n + strlen(n));
        if (LowerW(p) == self) continue;
        if (GetFileAttributesW(p.c_str()) != INVALID_FILE_ATTRIBUTES) { found += found.empty() ? "" : ", "; found += n; }
    }
    const wchar_t* sub[] = { L"", L"\\scripts", L"\\plugins" };
    for (auto s : sub) {
        WIN32_FIND_DATAW fd; HANDLE h = FindFirstFileW((dir + s + L"\\*.asi").c_str(), &fd);
        if (h == INVALID_HANDLE_VALUE) continue;
        do { found += found.empty() ? "" : ", "; found += Narrow(std::wstring(s) + (*s ? L"\\" : L"") + fd.cFileName); } while (FindNextFileW(h, &fd));
        FindClose(h);
    }
    if (!found.empty()) out.push_back({ 2, "OTHER MOD FILES next to the game's exe: " + found + " - remove them (AWRVR is the only dxgi.dll / mod needed)" });
}
void LoadedModules(std::vector<Problem>& out) {
    HMODULE mods[1024]; DWORD need = 0;
    if (!K32EnumProcessModules(GetCurrentProcess(), mods, sizeof mods, &need)) return;
    std::string other, overlays;
    for (DWORD i = 0; i < need / sizeof(HMODULE); i++) {
        if (mods[i] == g_self) continue;
        wchar_t p[MAX_PATH]; if (!GetModuleFileNameW(mods[i], p, MAX_PATH)) continue;
        std::wstring full = LowerW(p); const wchar_t* b = wcsrchr(full.c_str(), L'\\'); std::string base = Narrow(b ? b + 1 : full.c_str());
        for (auto& o : kOverlays) if (base == o.file) { overlays += overlays.empty() ? "" : ", "; overlays += o.name; }
        bool hit = false;
        for (const char* w : kModuleWords) if (base.find(w) != std::string::npos) hit = true;
        // the game's own DLSS (nvngx_dlss.dll) is fine; frame generation / its replacements are not
        if (hit) { other += other.empty() ? "" : ", "; other += base; }
    }
    if (!other.empty()) out.push_back({ 2, "OTHER MODS / TOOLS LOADED in the game: " + other + " - remove them while using AWRVR" });
    if (!overlays.empty()) out.push_back({ 4, "OVERLAYS HOOK THE GAME'S RENDERING: " + overlays + " - turn their in-game overlay off" });
}
void SecondCopy(std::vector<Problem>& out) {
    wchar_t name[64]; wsprintfW(name, L"Local\\AWRVR_dup_%lu", GetCurrentProcessId());
    HANDLE m = OpenFileMappingW(FILE_MAP_READ, FALSE, name);
    if (!m) return;
    if (const wchar_t* p = (const wchar_t*)MapViewOfFile(m, FILE_MAP_READ, 0, 0, 0)) {
        out.push_back({ 2, "AWRVR IS INSTALLED TWICE: a second copy was loaded from " + Narrow(std::wstring(p, wcsnlen(p, 520))) + " (it stays off) - keep only one" });
        UnmapViewOfFile(p);
    }
    CloseHandle(m);
}
void Loader(std::vector<Problem>& out) {
    if (!g_proxyName.empty() && g_proxyName != L"dxgi.dll" && g_proxyName != L"dbghelp.dll")
        out.push_back({ 3, "LOADED THROUGH ANOTHER LOADER as " + Narrow(g_proxyName) + " - install AWRVR as dxgi.dll next to the game's exe, without a loader" });
}
void Fov(std::vector<Problem>& out) {
    xrb::IpcPose p[2]; xrb::IpcFov f[2]; int64_t t = 0;
    if (!xrb::ClientGetLatestPoses(p, f, &t)) return;
    for (int e = 0; e < 2; e++) {
        float h = (-f[e].left + f[e].right) * 57.2958f, v = (f[e].up - f[e].down) * 57.2958f;   // angles: atan(-l) + atan(r)
        if (h > 1 && v > 1 && (h < 75 || v < 75)) {
            char b[200]; snprintf(b, sizeof b, "CROPPED FIELD OF VIEW from the headset runtime: %.0f x %.0f deg per eye (FOV-tangent multiplier / runtime FOV setting) - set it back to full", h, v);
            out.push_back({ 5, b }); return;
        }
    }
}
void Upscaling(std::vector<Problem>& out) {
    std::string s;
    int dl = DlssMode();
    if (dl >= 1 && dl <= 4) s += "the game's DLSS is on";
    if (UpscalerActive() && s.empty()) s += "a temporal upscaler is running";
    if (g_set.renderScale < 0.95f) { char b[64]; snprintf(b, sizeof b, "%srender_scale %.2f", s.empty() ? "" : ", ", g_set.renderScale); s += b; }
    unsigned rw = g_renderW.load(), rh = g_renderH.load(), ww = ResolutionWantedW(), wh = ResolutionWantedH();
    if (rw && ww && (rw < ww * 0.95 || rh < wh * 0.95)) { char b[96]; snprintf(b, sizeof b, "%sthe game renders %ux%u instead of %ux%u", s.empty() ? "" : ", ", rw, rh, ww, wh); s += b; }
    if (!s.empty()) out.push_back({ 6, "UPSCALING / LOWER RESOLUTION: " + s + " - test picture problems without it first" });
}
void TemporalAA(std::vector<Problem>& out) {
    int m = EngineEffectiveMode();
    bool alternating = m == VRMODE_SYNCED || m == VRMODE_AER;
    if (!alternating) return;
    bool taa = g_set.gameAA == "on" || (g_set.gameAA == "game" && GameTaaOn());
    if (taa || UpscalerActive())
        out.push_back({ 7, std::string("TEMPORAL AA WITH EYE-ALTERNATING STEREO: ") + (UpscalerActive() ? "DLSS / an upscaler" : "the game's TAA") +
                           " mixes the two eyes (ghosts, shimmer) - Game anti-aliasing: Off, or True stereo" });
}
void StereoSettings(std::vector<Problem>& out) {
    std::string s;
    if (g_set.swapEyes) s += "swap_eyes on";
    if (fabsf(g_set.ipdScale - 1.f) > 0.001f) { char b[48]; snprintf(b, sizeof b, "%sipd_scale %.2f", s.empty() ? "" : ", ", g_set.ipdScale); s += b; }
    if (fabsf(g_set.worldScale - 1.f) > 0.001f) { char b[48]; snprintf(b, sizeof b, "%sworld_scale %.2f", s.empty() ? "" : ", ", g_set.worldScale); s += b; }
    if (!s.empty()) out.push_back({ 8, "CHANGED STEREO SETTINGS: " + s + " - set them back to test scale / depth problems" });
}
void Smoothing(std::vector<Problem>& out) {
    if (g_smoothing.load()) {
        char b[200]; snprintf(b, sizeof b, "MOTION SMOOTHING IS HALVING THE FRAME RATE: the runtime runs the game at %.1f Hz instead of %.1f Hz (Oculus ASW / SteamVR / VD SSW / Pimax Smart Smoothing) - turn it off",
                              g_rawHz.load(), g_knownHz.load());
        out.push_back({ 0, b });
    }
}

void SetupCheck(bool force) {
    std::vector<Problem> p;
    Smoothing(p); FilesNextToExe(p); LoadedModules(p); SecondCopy(p); Loader(p); Fov(p); Upscaling(p); TemporalAA(p); StereoSettings(p);
    std::sort(p.begin(), p.end(), [](const Problem& a, const Problem& b) { return a.order < b.order; });
    std::string key; for (auto& x : p) key += x.text + "\n";
    g_problemCount = (int)p.size();
    DWORD now = rc::TickMs();
    bool changed = key != g_lastSetup;
    if (!force && !changed && (p.empty() || now - g_lastSetupAt < 300000)) return;
    g_lastSetup = key; g_lastSetupAt = now;
    if (p.empty()) { LOGI("SETUP CHECK: clean - AWRVR alone, no other mods, full field of view, no upscaling, no smoothing"); return; }
    LOGE("==================================================================================================");
    LOGE("SETUP CHECK: %d PROBLEM(S) IN THIS SETUP - known to break VR, NOT AWRVR bugs. Fix these before reporting:", (int)p.size());
    for (size_t i = 0; i < p.size(); i++) LOGE("SETUP [%zu] %s", i + 1, p[i].text.c_str());
    LOGE("==================================================================================================");
    // OpenXR API layers: the in-process host loads the runtime directly, so they never reach AWRVR - listed once for reports
    static bool layersSaid = false;
    if (!layersSaid) { layersSaid = true; LOGI("SETUP: OpenXR API layers are not loaded by AWRVR's in-process host - they do not change what the mod gets (listed in xrhost.log)"); }
}

// ---------------------------------------------------------------- health, VRAM, low fps, uncapped, clock
void Health(DWORD now) {
    static DWORD last = 0;
    if (now - last < 60000) return;
    last = now;
    DXGI_QUERY_VIDEO_MEMORY_INFO mi{};
    bool vram = g_adapter && SUCCEEDED(g_adapter->QueryVideoMemoryInfo(0, DXGI_MEMORY_SEGMENT_GROUP_LOCAL, &mi));
    LOGI("HEALTH: %.0f game fps, method %s, game state %s, render %ux%u, VRAM %llu / %llu MB, setup problems %d, v" AWRVR_VERSION,
         g_gameFps.load(), g_set.vrMode.c_str(), GameStateName(GameStateNow()), g_renderW.load(), g_renderH.load(),
         vram ? (unsigned long long)(mi.CurrentUsage >> 20) : 0ull, vram ? (unsigned long long)(mi.Budget >> 20) : 0ull, g_problemCount.load());
}
void Vram() {
    static bool over = false;
    DXGI_QUERY_VIDEO_MEMORY_INFO mi{};
    if (!g_adapter || FAILED(g_adapter->QueryVideoMemoryInfo(0, DXGI_MEMORY_SEGMENT_GROUP_LOCAL, &mi)) || !mi.Budget) return;
    bool o = mi.CurrentUsage > mi.Budget;
    if (o && !over) LOGW("VRAM OVER BUDGET: %llu MB used of a %llu MB budget - textures stream from system memory (stutter): lower render scale / texture quality",
                         (unsigned long long)(mi.CurrentUsage >> 20), (unsigned long long)(mi.Budget >> 20));
    else if (!o && over) LOGI("VRAM: back under budget (%llu / %llu MB)", (unsigned long long)(mi.CurrentUsage >> 20), (unsigned long long)(mi.Budget >> 20));
    over = o;
}
void LowFps() {
    static int low = 0; static bool said = false;
    int m = EngineEffectiveMode();
    bool alt = m == VRMODE_SYNCED || m == VRMODE_AER;
    bool play = GameStateNow() == GS_GAMEPLAY;
    float f = g_gameFps.load();
    if (alt && play && f > 1 && f < 60) { if (++low >= 3 && !said) { said = true; LOGW("LOW FPS FOR THIS MODE: %.0f game fps with an eye-alternating method (each eye under 30 images / s) - lower render scale / settings, or True stereo", f); } }
    else { low = 0; if (said && f >= 60) said = false; }
}
void Uncapped() {
    static bool said = false;
    if (g_set.fpsUnlocked && xrb::ClientHostVisible() && !said) { said = true; LOGW("UNCAPPED FRAME RATE IN VR: the game can take the headset thread's time - check late frames in xrhost.log before anything else"); }
    if (!g_set.fpsUnlocked) said = false;
}
} // namespace

// ---------------------------------------------------------------- public
// main.cpp, right after the log is opened (the previous run's logs were kept as *.prev.log)
void DiagInit() {
    SYSTEMTIME st; GetLocalTime(&st);
    LOGI("run: %04u-%02u-%02u %02u:%02u:%02u, id %08lx%04lx, AWRVR " AWRVR_VERSION " - the previous run is in awrvr.prev.log / xrhost.prev.log",
         st.wYear, st.wMonth, st.wDay, st.wHour, st.wMinute, st.wSecond, (unsigned long)GetTickCount(), (unsigned long)GetCurrentProcessId());
    InstallCrashFilter("at start");
}
// main.cpp DllMain: this copy lost the one-instance lock - the running copy reports where it was loaded from
void DiagNoteSecondCopy() {
    wchar_t name[64]; wsprintfW(name, L"Local\\AWRVR_dup_%lu", GetCurrentProcessId());
    HANDLE m = CreateFileMappingW(INVALID_HANDLE_VALUE, nullptr, PAGE_READWRITE, 0, 1040, name);
    if (!m) return;
    if (wchar_t* p = (wchar_t*)MapViewOfFile(m, FILE_MAP_WRITE, 0, 0, 0)) { std::wstring s = SelfPath(); wcsncpy(p, s.c_str(), 519); p[519] = 0; UnmapViewOfFile(p); }
    // the mapping stays open for the life of the process (this copy stays loaded, off)
}
void DiagSetAdapter(IDXGIAdapter1* a) { if (a && !g_adapter) a->QueryInterface(__uuidof(IDXGIAdapter3), (void**)&g_adapter); }
void DiagNoteRate(double rawHz, double knownHz) {
    // the runtime's predicted display period vs the shortest one seen for this headset: > known + 3 % = paced at a fraction
    if (rawHz <= 0 || knownHz <= 0) return;
    bool sm = rawHz < knownHz / 1.03;
    g_rawHz = (float)rawHz; g_knownHz = (float)knownHz;
    if (sm && !g_smoothing.exchange(true)) LOGE("SETUP: MOTION SMOOTHING ON - the runtime runs the app at %.1f Hz instead of %.1f Hz (Oculus ASW / SteamVR / VD SSW / Pimax Smart Smoothing) - not supported, turn it off", rawHz, knownHz);
    else if (!sm && g_smoothing.exchange(false)) LOGI("SETUP: motion smoothing off again (%.1f Hz)", rawHz);
}
void DiagNoteFps(float fps) { g_gameFps = fps; }
void DiagNoteRenderSize(unsigned w, unsigned h) { g_renderW = w; g_renderH = h; }
// compositor, every 10 s report
void DiagReport() {
    static bool first = true; static DWORD t0 = rc::TickMs();
    DWORD now = rc::TickMs();
    if (first) { first = false; SystemSummary(); }
    static bool refilter = false;
    if (!refilter && now - t0 > 30000) { refilter = true; InstallCrashFilter("again after 30 s - the game sets its own"); }
    SetupCheck(false); Vram(); LowFps(); Uncapped(); Health(now);
}
int SetupProblemCount() { return g_problemCount.load(); }
void DiagUserMark() {
    LOGW("USER MARK #%d - the player marked this moment (method %s, game state %s, %.0f fps)", ++g_markN, g_set.vrMode.c_str(), GameStateName(GameStateNow()), g_gameFps.load());
    LogFlushDisk();
}
void DiagReportFolder() {
    SYSTEMTIME st; GetLocalTime(&st);
    wchar_t sub[64]; wsprintfW(sub, L"\\report_%04u%02u%02u_%02u%02u%02u", st.wYear, st.wMonth, st.wDay, st.wHour, st.wMinute, st.wSecond);
    std::wstring dir = g_modDir + sub;
    if (!CreateDirectoryW(dir.c_str(), nullptr)) { LOGW("diag: could not make %ls", dir.c_str()); return; }
    LogFlushDisk();
    const wchar_t* files[] = { L"awrvr.log", L"awrvr.prev.log", L"xrhost.log", L"xrhost.prev.log", L"headset.txt", L"truestereo_running.txt" };
    int n = 0;
    for (auto f : files) if (CopyFileW((g_modDir + L"\\" + f).c_str(), (dir + L"\\" + f).c_str(), FALSE)) n++;
    if (CopyFileW(g_cfgPath.c_str(), (dir + L"\\awrvr_config.txt").c_str(), FALSE)) n++;
    LOGI("diag: report folder %ls (%d files) - send this folder", dir.c_str(), n);
}
// vrkit: every option change ("key: old -> new"); the first call takes the snapshot of all keys
static void OptionChanged(const vrkit::Option& o) {
    std::string now = vrkit::Options::Get().ValueText(o);
    auto it = g_snapshot.find(o.key);
    std::string old = it != g_snapshot.end() ? it->second : "?";
    if (old != now) LOGI("config: option %s: %s -> %s", o.key.c_str(), old.c_str(), now.c_str());
    g_snapshot[o.key] = now;
}
// menu.cpp, after every option is registered: the settings that differ from the defaults, and the change hook
void DiagConfigSnapshot() {
    std::map<std::string, std::string> def;
    const char* t = DefaultConfigText();
    while (t && *t) {
        const char* e = strchr(t, '\n'); std::string line(t, e ? e - t : strlen(t)); t = e ? e + 1 : nullptr;
        size_t q = line.find('='); if (line.empty() || line[0] == '#' || q == std::string::npos) continue;
        auto trim = [](std::string s) { while (!s.empty() && (s.back() == ' ' || s.back() == '\r')) s.pop_back(); while (!s.empty() && s[0] == ' ') s.erase(0, 1); return s; };
        def[trim(line.substr(0, q))] = trim(line.substr(q + 1));
    }
    std::string diff; int n = 0;
    for (auto& o : vrkit::Options::Get().All()) {
        if (o.key.empty()) continue;
        std::string v = vrkit::Options::Get().ValueText(o);
        g_snapshot[o.key] = v;
        auto it = def.find(o.key);
        auto same = [](const std::string& a, const std::string& b) { char* e1; char* e2; double x = strtod(a.c_str(), &e1), y = strtod(b.c_str(), &e2);
            return a == b || (e1 != a.c_str() && !*e1 && e2 != b.c_str() && !*e2 && fabs(x - y) < 1e-6); };
        if (it != def.end() && !same(it->second, v)) { diff += " " + o.key + "=" + v + " (default " + it->second + ")"; n++; }
    }
    LOGI("config: %d setting(s) differ from the defaults:%s", n, n ? diff.c_str() : " none");
    vrkit::SetChangeHook(&OptionChanged);
}
