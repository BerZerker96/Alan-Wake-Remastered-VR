#pragma once
#include <cmath>
// Northlight camera (Alan Wake Remastered): the node transform of the rendered view and its lens / projection.
// Everything is located at run time (RTTI + code patterns), so the mod does not depend on one exe build.
#include <windows.h>
#include <cstdint>
#include "xrbridge/ipc.h"

enum VrMode { VRMODE_SYNCED = 0, VRMODE_AER, VRMODE_HEAD, VRMODE_SCREEN, VRMODE_NATIVE, VRMODE_COUNT };

struct Tan4 { float l, r, u, d; };          // tangents, l/d negative

// Canted symmetric eye views (view_shape = canted, the default): each eye is drawn with a SYMMETRIC frustum whose
// axis is turned (yaw, then pitch, in the eye's own frame) to the middle of that eye's field of view. Every game effect
// that assumes a centred projection (light culling grids, volumetrics, flares, screen-space shadows) is then right,
// and the picture covers the eye's view with almost no unseen pixels - for any headset (asymmetric left / right and
// up / down fields, canted displays: the cant is relative to the eye pose the runtime gives).
// eye-space tangent (tx, ty) -> the canted picture's tangent
inline void CantToPic(const float cant[2], float tx, float ty, float* ox, float* oy) {
    float ct = cosf(cant[0]), st = sinf(cant[0]), ca = cosf(cant[1]), sa = sinf(cant[1]);
    float x1 = ct * tx + st, z1 = st * tx - ct;               // R_y(-yaw) (tx, ty, -1)
    float y2 = ca * ty + sa * z1, z2 = -sa * ty + ca * z1;      // R_x(-pitch)
    float w = -z2; if (w < 1e-4f) w = 1e-4f;
    *ox = x1 / w; *oy = y2 / w;
}
inline void QMul(const float a[4], const float b[4], float o[4]) {   // (x, y, z, w)
    float x = a[3] * b[0] + a[0] * b[3] + a[1] * b[2] - a[2] * b[1];
    float y = a[3] * b[1] - a[0] * b[2] + a[1] * b[3] + a[2] * b[0];
    float z = a[3] * b[2] + a[0] * b[1] - a[1] * b[0] + a[2] * b[3];
    float w = a[3] * b[3] - a[0] * b[0] - a[1] * b[1] - a[2] * b[2];
    o[0] = x; o[1] = y; o[2] = z; o[3] = w;
}
// the eye's orientation turned by its cant (local yaw, then local pitch)
inline void CantQuat(float q[4], const float c[2]) {
    if (c[0] == 0.f && c[1] == 0.f) return;
    float yq[4] = { 0, sinf(c[0] * 0.5f), 0, cosf(c[0] * 0.5f) }, xq[4] = { sinf(c[1] * 0.5f), 0, 0, cosf(c[1] * 0.5f) }, t[4];
    QMul(q, yq, t); QMul(t, xq, q);
}


struct FrameInfo {
    bool vr = false;                         // this Present shows a frame the mod set up (else: flat screen)
    int mode = VRMODE_SCREEN;
    int eye = -1;                            // AER / synced: 0 left, 1 right; head / recon: -1 (centre view)
    bool held = false;                       // synced: the second eye of a tick
    uint32_t tick = 0;                       // synced: game tick of this picture
    xrb::IpcPose pose{};                     // pose the picture was rendered from (OpenXR, reference space)
    Tan4 pic{};                              // frustum the picture was rendered with
    float picCant[2]{};                      // the picture's cant (yaw, pitch; radians) against the eye it was drawn for
    xrb::IpcPose eyePose[2]{};               // both eyes at that moment (recon rebuilds them; others: display)
    xrb::IpcFov eyeFov[2]{};                 // the headset's FOV per eye at that moment
    float nearZ = 0.1f, farZ = 1000.f;       // picture's depth range (recon)
    double worldScale = 1;                   // eye offsets were multiplied by this (recon parallax)
    float angVel[3]{};                       // game camera rotation rate (camera_reprojection)
    LONG presentAtSet = 0;                   // Present count when the camera was set (measures the pipeline lag)
    uint32_t seq = 0;                        // record number
    int64_t time = 0;
    bool projPatched = false;                // the picture used the eye's off-centre projection
    // true stereo (native): the renderer draws the view twice per frame, once per eye
    Tan4 eyePic[2]{};                        // each eye's own frustum (matched: symmetric around its lens axis)
    float eyePicCant[2][2]{};                // each eye's cant (canted views)
    double camBase[12]{};                    // the filtered game camera (canonical axes) the eyes are placed on
};

bool EngineInstall();
bool EngineReady();
void EngineSetPoses(const xrb::IpcPose pose[2], const xrb::IpcFov fov[2], int64_t time);
void EngineNoPoses();
FrameInfo EngineOnPresent(float backBufferAspect, bool flatNow);   // Present thread, once per Present
bool EngineFrameForRecording(FrameInfo* out);                     // the record of the frame being recorded (UI hooks)
void EngineReport();
void EngineSettingsChanged();
const char* EngineStatus();
const char* EngineMainViewClass();
int EngineEffectiveMode();                                        // synced falls back to AER without a clock hook
LONG EnginePresentCount();
bool EngineCutsceneActive();                                      // the drawn camera is the game's CinematicCamera
bool EngineLastGameCameraPos(double out[3]);
// true stereo: which eye the renderer is recording now (-1 none, 0 first, 1 second) - read by the D3D12 hooks
int EngineNativePhase();
bool EngineNativePairDone();                                       // true stereo: this frame's two renders are done
DWORD EngineNativeThread();                                       // the thread drawing the eyes (diagnostics)
void EngineNativeResult(bool firstEyeCaptured);                   // Present thread, once per new native VR frame
bool EngineNativeAvailable();
const char* EngineNativeState();
void EngineNoteNative3d(bool on);                                 // compositor: true stereo is drawing 3D now
bool EngineNative3d();
void EngineShutdown();                                            // clean exit (true stereo's marker file)
void EngineNoteDeviceRemoved(long hr);                            // the GPU device was lost (logged; true stereo off next start)
