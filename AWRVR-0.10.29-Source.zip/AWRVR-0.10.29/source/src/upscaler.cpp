// Upscalers and frame generation.
// * The game's DLSS: NGX is linked into the exe; its evaluate helper (NGX_D3D12_EVALUATE_DLSS_EXT, exe+4a5800 in 1.33)
//   is found by signature and checked by the "Jitter.Offset.X" parameter name it sets. Its eval parameters give the
//   render size (InRenderSubrectDimensions, +0x30) and the output, so the log can say what is rendered at what size.
//   OptiScaler and similar tools replace DLSS behind NGX: the same helper still runs.
// * Everything in this mod that depends on sizes works at the upscaler's render size too: the scene depth (any size
//   down to a third of the output, same shape) and foveated rendering (its own shading-rate image for that size).
// * The upscaler needs the game's jitter: while one is active the mod never switches the game's TAA / jitter off.
// * Optional (Graphics tab): "fresh image each eye" sets the upscaler's reset flag on every evaluation, so it never
//   blends one eye's picture into the other's (costs its temporal smoothing).
// * Frame generation (DLSS-G, FSR 3 FG through OptiScaler / mods) makes extra frames the game never rendered: the eyes
//   would get pictures from no camera at all. Detected by its modules and by Presents per game frame; logged and shown.
#include <windows.h>
#include <d3d12.h>
#include <atomic>
#include <cstring>
#include <string>
#include "upscaler.h"
#include "scan.h"
#include "log.h"
#include "settings.h"
#include "engine.h"
#include "game.h"
#include "MinHook.h"
#include "realclock.h"

namespace {
using EvalFn = int (*)(void* list, void* handle, void* params, unsigned char* ev);
EvalFn o_eval = nullptr;
std::atomic<uint32_t> s_evals{0}, s_resets{0};
std::atomic<DWORD> g_lastEval{0};
std::atomic<uint32_t> g_rw{0}, g_rh{0}, g_ow{0}, g_oh{0};
bool g_hooked = false;
// the game's own DLSS state (globals found through its DLSS manager update and evaluate):
//   mode 0 Off, 1 Ultra Performance, 2 Performance, 3 Balanced, 4 Quality, 5 DLAA (the Graphics menu's order)
//   render size = the size the game creates its 3D targets at (separate textures, not a sub-rectangle)
volatile int* g_dlssMode = nullptr; volatile uint32_t* g_renderW = nullptr; volatile uint32_t* g_renderH = nullptr; volatile uint32_t* g_outW = nullptr;
// the game's own resolution scale (Graphics menu "resolutionscale", debug name g_fRenderScale): slider / 10 + 0.5, so
// 0.5 .. 1.5 x the output. Used only while DLSS is off (render size = output x scale, upscaled by the game's TAA path;
// above 1 = supersampling). There is no dynamic resolution in this game (the DLSS dynamic-size names are NGX's).
volatile float* g_renderScale = nullptr;
const char* DlssModeName(int m) { static const char* n[] = { "off", "Ultra Performance", "Performance", "Balanced", "Quality", "DLAA" }; return m >= 0 && m < 6 ? n[m] : "?"; }
std::string g_modules;
std::atomic<bool> g_fg{false};
char g_status[96] = "";

int H_Eval(void* list, void* handle, void* params, unsigned char* ev) {
    s_evals++; g_lastEval = rc::TickMs() | 1;
    if (ev && Readable(ev, 0x48)) {
        uint32_t w = *(uint32_t*)(ev + 0x30), h = *(uint32_t*)(ev + 0x34);
        ID3D12Resource* out = *(ID3D12Resource**)(ev + 8);
        if ((!w || !h) && *(ID3D12Resource**)ev) { D3D12_RESOURCE_DESC d = (*(ID3D12Resource**)ev)->GetDesc(); w = (uint32_t)d.Width; h = d.Height; }
        if (w && h) { g_rw = w; g_rh = h; }
        if (out) { D3D12_RESOURCE_DESC d = out->GetDesc(); g_ow = (uint32_t)d.Width; g_oh = d.Height; }
        int m = EngineEffectiveMode();
        bool perEye = m == VRMODE_SYNCED || m == VRMODE_AER || m == VRMODE_NATIVE;
        if (g_set.upscalerFreshEyes && perEye) { *(int*)(ev + 0x38) = 1; s_resets++; }   // InReset
    }
    return o_eval(list, handle, params, ev);
}
bool Loaded(const wchar_t* n) { return GetModuleHandleW(n) != nullptr; }
std::string Modules() {
    std::string s;
    struct M { const wchar_t* dll; const char* what; } ms[] = {
        { L"nvngx_dlss.dll", "DLSS" }, { L"nvngx_dlssg.dll", "DLSS frame generation" }, { L"nvngx_dlssd.dll", "DLSS ray reconstruction" },
        { L"OptiScaler.dll", "OptiScaler" }, { L"OptiScaler.asi", "OptiScaler" }, { L"nvngx.dll", "an NGX replacement (OptiScaler / DLSS enabler)" },
        { L"amd_fidelityfx_dx12.dll", "FSR 3 (FidelityFX)" }, { L"amd_fidelityfx_upscaler_dx12.dll", "FSR 4" }, { L"amd_fidelityfx_framegeneration_dx12.dll", "FSR frame generation" },
        { L"ffx_fsr2_api_dx12_x64.dll", "FSR 2" }, { L"libxess.dll", "XeSS" }, { L"libxess_fg.dll", "XeSS frame generation" },
        { L"dlssg_to_fsr3_amd_is_better.dll", "DLSS-G to FSR 3 frame generation" }, { L"nvngx_dlssg_to_fsr3.dll", "DLSS-G to FSR 3 frame generation" },
        { L"sl.interposer.dll", "Streamline" }, { L"sl.dlss_g.dll", "DLSS frame generation (Streamline)" },
    };
    for (auto& m : ms) if (Loaded(m.dll) && s.find(m.what) == std::string::npos) { if (!s.empty()) s += ", "; s += m.what; }
    return s;
}
bool FgModule(const std::string& m) { return m.find("frame generation") != std::string::npos; }
} // namespace

void UpscalerInstall() {
    auto hits = ScanText("48 89 5C 24 08 48 89 6C 24 10 48 89 74 24 18 57 48 83 EC 40 49 8B D8 0F 29 74 24 30 4D 8B 01 48 8B F2 48 8B E9", 2);
    uint8_t* fn = hits.size() == 1 ? hits[0] : nullptr;
    // proof: it sets the "Jitter.Offset.X" parameter (lea rdx, [rip+name] within its first 0x100 bytes)
    uint8_t* name = fn ? FindString("Jitter.Offset.X") : nullptr; bool ok = false;
    for (uint8_t* q = fn; fn && name && q < fn + 0x100 && !ok; q++) if (q[0] == 0x48 && q[1] == 0x8D && q[2] == 0x15 && RipTarget(q, 3, 7) == name) ok = true;
    if (ok && MH_CreateHook(fn, (void*)&H_Eval, (void**)&o_eval) == MH_OK && MH_EnableHook(fn) == MH_OK) {
        g_hooked = true; LOGI("sig DlssEvaluate exe+%x (the game's DLSS / anything behind NGX) - render size and output are logged", Rva(fn));
    } else LOGI("upscaler: the game's DLSS evaluate not found (%zu hits%s) - upscalers are still recognised by the scene's render size", hits.size(), fn && !ok ? ", not confirmed" : "");
    // the DLSS manager's per-frame update starts with `mov eax,[mode]; mov rbx,rcx; test eax,eax`; it compares the output
    // size (`mov rax,[output w/h]; cmp eax,[rcx+..]`); the evaluate reads the render size (`mov ebx,[w] ... mov edi,[h]`)
    auto mh = ScanText("8B 05 ?? ?? ?? ?? 48 8B D9 85 C0 75 ?? 48 8B 81 ?? ?? 00 00 48 85 C0", 2);
    auto oh = ScanText("48 8B 05 ?? ?? ?? ?? 3B 81 ?? ?? 00 00 0F 85", 2);
    auto rh = ScanText("8B 1D ?? ?? ?? ?? 48 8D 8C 24 ?? ?? ?? ?? 8B 3D ?? ?? ?? ?? 33 C0", 2);
    if (mh.size() == 1 && oh.size() == 1 && rh.size() == 1 && oh[0] > mh[0] && oh[0] < mh[0] + 0x80) {
        g_dlssMode = (volatile int*)RipTarget(mh[0], 2, 6); g_outW = (volatile uint32_t*)RipTarget(oh[0], 3, 7);
        g_renderW = (volatile uint32_t*)RipTarget(rh[0], 2, 6); g_renderH = (volatile uint32_t*)RipTarget(rh[0] + 14, 2, 6);
        if (!Readable((void*)g_dlssMode, 4) || !Readable((void*)g_outW, 8) || !Readable((void*)g_renderW, 4) || !Readable((void*)g_renderH, 4)) g_dlssMode = nullptr;
    }
    auto sc = ScanText("F3 0F 10 35 ?? ?? ?? ?? 48 8B 49 08 48 8B 01 83 3D ?? ?? ?? ?? 00", 2);
    if (sc.size() == 1 && g_dlssMode && (volatile int*)RipTarget(sc[0] + 15, 2, 7) == g_dlssMode) {   // checks the DLSS mode next: confirmed
        g_renderScale = (volatile float*)RipTarget(sc[0], 4, 8);
        if (!Readable((void*)g_renderScale, 4)) g_renderScale = nullptr;
    }
    if (g_renderScale) LOGI("sig RenderScale exe+%x (the game's resolution scale, used while DLSS is off)", Rva((void*)g_renderScale));
    if (g_dlssMode) LOGI("sig DlssState exe+%x (mode), render size exe+%x, output exe+%x", Rva((void*)g_dlssMode), Rva((void*)g_renderW), Rva((void*)g_outW));
    else LOGI("upscaler: the game's DLSS settings not found - DLSS is seen by its evaluations only");
    g_modules = Modules();
    LOGI("upscaler: modules loaded: %s", g_modules.empty() ? "none" : g_modules.c_str());
}

int DlssMode() { return g_dlssMode && Readable((void*)g_dlssMode, 4) ? *g_dlssMode : -1; }
bool UpscalerActive() { DWORD t = g_lastEval.load(); return (t && rc::TickMs() - t < 2000) || DlssMode() > 0; }
bool FrameGenerationSuspected() { return g_fg.load(); }
const char* UpscalerStatus() { return g_status; }

void UpscalerReport() {
    static LONG lastPresents = 0; static uint32_t lastTicks = 0, lastTicksPrev = 0;
    LONG pr = EnginePresentCount(); uint32_t tk = GameTicks();
    double ratio = (tk - lastTicks) ? double(pr - lastPresents) / double(tk - lastTicks) : 0;
    lastPresents = pr; lastTicks = tk;
    std::string mods = Modules();
    if (mods != g_modules) { g_modules = mods; LOGI("upscaler: modules loaded now: %s (loaded is not the same as switched on)", mods.empty() ? "none" : mods.c_str()); }
    // frame generation is on only when it is measured: more Presents than game frames. A loaded frame-generation module
    // alone says nothing (the driver / NVIDIA app can load nvngx_dlssg.dll for any game) - it is only mentioned
    // (gameplay only: menus and loading screens tick the game far less often than they present - 0.10.15 warned in the menu)
    bool measured = (tk - lastTicksPrev) > 100 && GameStateNow() == GS_GAMEPLAY;
    bool fg = measured ? ratio > 1.6 : g_fg.load();
    lastTicksPrev = tk;
    if (fg && !g_fg.load()) LOGW("upscaler: FRAME GENERATION is on (%.2f Presents per game frame%s) - the generated frames come from no camera: turn frame generation off for VR",
                                  ratio, FgModule(mods) ? ", its module is loaded" : "");
    if (!fg && g_fg.load()) LOGI("upscaler: frame generation is off again (%.2f Presents per game frame)", ratio);
    g_fg = fg;
    uint32_t n = s_evals.exchange(0), r = s_resets.exchange(0);
    int dm = DlssMode();
    if (dm >= 0 && (dm > 0 || n))
        LOGI("upscaler: the game's DLSS: %s (mode %d), 3D rendered at %ux%u, output %ux%u", DlssModeName(dm), dm, *g_renderW, *g_renderH, g_outW[0], g_outW[1]);
    float rsc = g_renderScale && Readable((void*)g_renderScale, 4) ? *g_renderScale : 1.f;
    if (dm == 0 && g_renderScale && (rsc < 0.99f || rsc > 1.01f))
        LOGI("upscaler: the game's resolution scale %.0f %% (DLSS off): 3D rendered at %ux%u, output %ux%u%s", rsc * 100, *g_renderW, *g_renderH, g_outW[0], g_outW[1],
             rsc > 1.01f ? " - supersampling" : "");
    if (n || UpscalerActive())
        LOGI("upscaler: %u evaluations (%u with a fresh image), render %ux%u -> output %ux%u (%.0f %%)%s",
             n, r, g_rw.load(), g_rh.load(), g_ow.load(), g_oh.load(), g_ow.load() ? 100.0 * g_rw.load() / g_ow.load() : 0.0, g_hooked ? "" : " (seen by the scene size)");
    if (g_fg.load()) snprintf(g_status, sizeof g_status, "FRAME GENERATION ON - turn it off");
    else if (dm > 0) snprintf(g_status, sizeof g_status, "DLSS %s", DlssModeName(dm));
    else if (dm == 0 && g_renderScale && (rsc < 0.99f || rsc > 1.01f)) snprintf(g_status, sizeof g_status, "scale %.0f%%", rsc * 100);
    else if (UpscalerActive()) snprintf(g_status, sizeof g_status, "upscaler %u%%", g_ow.load() ? (unsigned)(100.0 * g_rw.load() / g_ow.load() + 0.5) : 0u);
    else g_status[0] = 0;
}
