
// scratchpad.cpp (not in the scan test)
#include "../src/scratchpad.h"
bool ScratchPadMark(ScratchMark* m) { m->entry = nullptr; return false; }
int ScratchPadRelease(const ScratchMark&) { return -1; }

// resolution.cpp (not in the scan test)
bool ResolutionPixelScale(double*, double*) { return false; }
void ResolutionNoteFov(const float (*)[4]) {}
