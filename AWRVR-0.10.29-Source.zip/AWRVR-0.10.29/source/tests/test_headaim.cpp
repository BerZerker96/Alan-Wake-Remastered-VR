// Head aim without the game: a fake aim object and a fake aim update with the game's behaviour (angles + stick turn,
// pitch clamp, direction from the angles, aim point = origin + direction x range).
// g++ -O1 -std=c++17 -Isrc tests/test_headaim.cpp -o test_headaim && ./test_headaim
#include <cstdio>
#include <cmath>
#include <cstring>
#include <string>
#include "headaim_core.h"

static int fails = 0;
static void Check(bool c, const std::string& w) { printf("%s %s\n", c ? "ok  " : "FAIL", w.c_str()); if (!c) fails++; }

// the fake game's convention: Y up, yaw about Y (0 = +Z), pitch up positive
static void FakeEuler(float* out, float pitch, float yaw, float, int) {
    memset(out, 0, 36);
    out[6] = cosf(pitch) * sinf(yaw); out[7] = sinf(pitch); out[8] = cosf(pitch) * cosf(yaw);
}
static void FakeDirToAngles(const float* d, float* pitch, float* yaw) { *pitch = asinf(d[1]); *yaw = atan2f(d[0], d[2]); }
static float g_inYaw = 0, g_inPitch = 0, g_lo = -1.0f, g_hi = 1.0f;
static unsigned char g_aim[0x40];
static void FakeUpdate() {   // the game's own aim update
    float y, p; memcpy(&y, g_aim + 0x24, 4); memcpy(&p, g_aim + 0x28, 4);
    y += g_inYaw; p += g_inPitch; p = p < g_lo ? g_lo : p > g_hi ? g_hi : p;
    memcpy(g_aim + 0x24, &y, 4); memcpy(g_aim + 0x28, &p, 4);
    float m[9]; FakeEuler(m, p, y, 0, 0); memcpy(g_aim + 0x18, m + 6, 12);
    float o[3] = { 0, 1.6f, 0 }, t[3] = { o[0] + m[6] * 100, o[1] + m[7] * 100, o[2] + m[8] * 100 };
    memcpy(g_aim + 0x0C, o, 12); memcpy(g_aim, t, 12);
}
static void SetAngles(float y, float p) { memcpy(g_aim + 0x24, &y, 4); memcpy(g_aim + 0x28, &p, 4); }
static V3 AimDir() { float d[3]; memcpy(d, g_aim + 0x18, 12); return { d[0], d[1], d[2] }; }

int main() {
    ha::GameFns g; g.euler = FakeEuler; g.dirToAngles = FakeDirToAngles; g.pitchLo = g_lo; g.pitchHi = g_hi;
    Xf b; b.r[0] = { 1, 0, 0 }; b.r[1] = { 0, 1, 0 }; b.r[2] = { 0, 0, 1 }; b.p = { 10, 2, 5 };   // drawn camera: looking +Z
    // 1. the head turned 0.5 rad to the left (OpenXR +yaw about +Y)
    float th = 0.5f, q[4] = { 0, sinf(th / 2), 0, cosf(th / 2) };
    V3 head = ha::TrackingToWorld(b, ha::HeadFwdTracking(q));
    Check(head.x < -0.4 && fabs(head.y) < 1e-6 && head.z > 0.8, "a head turned left looks left of the camera (-X)");
    SetAngles(0, 0); g_inYaw = 0; g_inPitch = 0;
    ha::Result r = ha::AimWithHead(g, g_aim, head, 1.0, FakeUpdate);
    Check(Dot(AimDir(), head) > 0.9995, "the aim direction follows the head");
    float y, p; memcpy(&y, g_aim + 0x24, 4); memcpy(&p, g_aim + 0x28, 4);
    Check(fabs(y) < 1e-5 && fabs(p) < 1e-5, "the game's own angles (the camera's) are unchanged");
    Check(Dot(r.gameDir, V3{ 0, 0, 1 }) > 0.99999, "the camera gets the game's own direction");
    float t[3]; memcpy(t, g_aim, 12);
    V3 tp{ t[0], t[1] - 1.6, t[2] }; Check(Dot(Norm(tp), head) > 0.9995, "the aim point lies along the head direction");
    // 2. a stick turn this frame: the camera turns by it at once, the aim = head + the same turn (never delayed)
    SetAngles(0.2f, 0); g_inYaw = 0.1f;
    r = ha::AimWithHead(g, g_aim, head, 1.0, FakeUpdate);
    memcpy(&y, g_aim + 0x24, 4);
    Check(fabs(y - 0.3f) < 1e-5, "the stick turn reaches the camera's angles the same frame");
    float hy, hp; float hd[3] = { (float)head.x, (float)head.y, (float)head.z }; FakeDirToAngles(hd, &hp, &hy);
    Check(fabs(r.headYaw - (hy + 0.1f)) < 1e-4, "the aim gets the same stick turn on top of the head");
    // 3. pitch limits: a head looking far down is clamped by the game's limit, the stick still turns the camera
    g_inYaw = 0; g_inPitch = 0.05f; SetAngles(0, 0.2f);
    float qd[4] = { sinf(-1.4f / 2), 0, 0, cosf(-1.4f / 2) };   // 1.4 rad down
    V3 down = ha::TrackingToWorld(b, ha::HeadFwdTracking(qd));
    r = ha::AimWithHead(g, g_aim, down, 1.0, FakeUpdate);
    memcpy(&p, g_aim + 0x28, 4);
    Check(fabs(p - 0.25f) < 1e-5, "with the head beyond the pitch limit the camera still gets the stick's pitch");
    Check(fabs(r.headPitch - (g_lo + 0.05f)) < 1e-4, "the aim stops at the game's own pitch limit (plus the stick)");
    // 4. blend 0.5: halfway between the game's and the head's direction
    g_inPitch = 0; SetAngles(0, 0);
    r = ha::AimWithHead(g, g_aim, head, 0.5, FakeUpdate);
    double a = ha::AngleDeg(AimDir(), V3{ 0, 0, 1 }), full = ha::AngleDeg(head, V3{ 0, 0, 1 });
    Check(fabs(a - full * 0.5) < 0.5, "blend 0.5 aims halfway (" + std::to_string(a) + " of " + std::to_string(full) + " deg)");
    // 5. aim from the eyes: the head 10 cm up and 5 cm forward of the tracking origin, 1 unit per metre
    float hp3[3] = { 0, 0.10f, -0.05f };
    V3 e = ha::EyesWorld(b, hp3, 1.0);
    Check(Len(e - V3{ 10, 2.10, 5.05 }) < 1e-6, "the eyes are where the picture draws them");
    // 6. smoothing: time based, a head turn is damped, nothing at smoothing 0
    ha::Smoother s; s.Step(V3{ 0, 0, -1 }, 0.01, 1.0);
    V3 turned = ha::HeadFwdTracking(q), v = s.Step(turned, 0.01, 1.0);
    double moved = ha::AngleDeg(v, V3{ 0, 0, -1 });
    Check(moved > 1.0 && moved < 5.0, "smoothing 1.0: 10 ms after a 0.5 rad head turn the aim moved " + std::to_string(moved) + " deg");
    ha::Smoother s0; s0.Step(V3{ 0, 0, -1 }, 0.01, 0.0); v = s0.Step(turned, 0.01, 0.0);
    Check(ha::AngleDeg(v, turned) < 1e-6, "smoothing 0: the raw head");
    v = s.Step(turned, 0.0, 1.0); Check(ha::AngleDeg(v, turned) > 1.0, "a step with no time passed keeps the filtered value");
    // 7. after the ray from the eyes: origin back at the shoulder, direction from the shoulder through the aim point
    {
        float pt[3] = { 0, 1.5f, 20 }; memcpy(g_aim, pt, 12);
        V3 sh{ 0.3, 1.4, 0 }, hd = Norm(V3{ 0, 0.005, 1 });
        V3 d = ha::ConvergeFromShoulder(g_aim, sh, hd, 0.5);
        float o[3], dd[3]; memcpy(o, g_aim + 0x0C, 12); memcpy(dd, g_aim + 0x18, 12);
        Check(fabs(o[0] - 0.3f) < 1e-6 && fabs(o[1] - 1.4f) < 1e-6, "the game's own origin (the shoulder) is back in the object");
        V3 hit = sh + V3{ dd[0], dd[1], dd[2] } * 20.0; double miss = Len(V3{ hit.x - 0, hit.y - 1.5, 0 });
        Check(Dot(d, Norm(V3{ -0.3, 0.1, 20 })) > 0.99999 && miss < 0.02, "the direction from the shoulder passes through the aim point");
        float near[3] = { 0.3f, 1.4f, 0.2f }; memcpy(g_aim, near, 12);
        d = ha::ConvergeFromShoulder(g_aim, sh, hd, 0.5);
        Check(Dot(d, hd) > 0.99999, "an aim point closer than the limit keeps the head's direction");
    }
    printf(fails ? "%d FAILED\n" : "all passed\n", fails);
    return fails != 0;
}
