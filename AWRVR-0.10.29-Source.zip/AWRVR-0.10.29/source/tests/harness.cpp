// Pretends to be the game: imports dbghelp.dll from its own folder (our proxy), calls two forwarded exports.
#include <windows.h>
#include <dbghelp.h>
#include <cstdio>
int main() {
    DWORD o = SymGetOptions();
    printf("SymGetOptions via proxy -> %08lx\n", o);
    BOOL r = SymInitialize(GetCurrentProcess(), nullptr, FALSE);
    printf("SymInitialize via proxy -> %d\n", r);
    Sleep(3000);   // init thread: engine scan (fails here: this is not the game) + dxgi fallback wait
    return 0;
}
