// The game's frame-time step, modelled from exe+1df8d0 (1.33): dt_used = average of the previous ring samples, then the
// lap (clamped to 0.1 s) is pushed. Shows that holding only the lap does NOT freeze the world (old method) and that
// the one-entry ring + lap together do (synced eyes from the same world state).
// g++ -std=c++17 -Isrc tests/test_syncclock.cpp && ./a.out
#include "syncclock.h"
#include <cstdio>
#include <cmath>
#include <initializer_list>
static int fails = 0;
static void Check(bool c, const char* w) { printf("%s %s\n", c ? "ok  " : "FAIL", w); if (!c) fails++; }
struct GameStep {             // the game's averaging ring
    float ring[4] = {}; int idx = 0, count = 0, size = 4;
    float Frame(double lap) {
        float sum = 0; for (int i = 0; i < count; i++) sum += ring[i];
        float used = count ? sum / count : 0;
        ring[idx] = (float)fmin(lap, 0.1); idx = (idx + 1) >= size ? 0 : idx + 1; if (count < size) count++;
        return used;
    }
};
int main() {
    const double T = 1.0 / 90;   // headset frame
    // old method: hold only the lap (tiny), pay back on the next
    { GameStep g; double bank = 0, heldMax = 0, worldTime = 0, real = 0;
      for (int f = 0; f < 400; f++) {
          bool hold = f & 1; double lap;
          if (hold) { bank += T; lap = 1e-4; } else { lap = T + bank - 1e-4 * 0; bank = 0; }
          float used = g.Frame(lap); worldTime += used; real += T;
          if (f > 20 && hold) heldMax = fmax(heldMax, used);
      }
      printf("     old method: world step on the held (second-eye) frame = %.2f ms (a normal frame is %.2f ms)\n", heldMax * 1000, T * 1000);
      Check(heldMax > 0.5 * T, "old method really is broken (world moves between the eyes)"); }
    // new method: one-entry ring written with the lap
    { GameStep g; g.size = 1; g.count = 1; g.idx = 0; SyncClock c; double heldMax = 0, worldTime = 0, real = 0; double minNormal = 1;
      for (int f = 0; f < 400; f++) {
          bool hold = f & 1;
          double lap = c.Lap(T, hold, g.ring);   // the mod's lap hook writes ring[0] before the game averages
          float used = g.Frame(lap); worldTime += used; real += T;
          if (f > 20 && hold) heldMax = fmax(heldMax, used);
          if (f > 20 && !hold) minNormal = fmin(minNormal, used);
      }
      printf("     new method: held frame step %.3f ms, normal frame step %.2f ms, world time %.3f s for %.3f s real\n", heldMax * 1000, minNormal * 1000, worldTime, real);
      Check(heldMax < T / 16 && heldMax > 0, "new method: the second eye's frame steps only 1/32 of a frame (never 0)");
      Check(fabs(minNormal + heldMax - 2 * T) < 2e-4, "new method: the two frames together step both frames' time");
      Check(fabs(worldTime - real) < 0.03, "new method: game time keeps up with real time"); }
    // speed hack (Cheat Engine): the game's lap is scaled by the factor; synchronized must move the world exactly as
    // fast as the game would without the mod, at any factor
    for (double speed : { 0.01, 0.1, 0.5, 2.0, 5.0, 8.0, 20.0 }) {
        GameStep van; double vanWorld = 0;
        GameStep g; g.size = 1; g.count = 1; g.idx = 0; SyncClock c; double world = 0;
        for (int f = 0; f < 400; f++) {
            vanWorld += van.Frame(T * speed);
            world += g.Frame(c.Lap(T * speed, f & 1, g.ring));
        }
        char w[160]; snprintf(w, sizeof w, "speed x%.2f: world %.3f s with the mod, %.3f s without (synchronized keeps the game's speed)", speed, world, vanWorld);
        Check(fabs(world - vanWorld) < 0.02 * vanWorld + 0.002, w);
    }
    printf(fails ? "%d FAILED\n" : "all passed\n", fails); return fails != 0;
}
