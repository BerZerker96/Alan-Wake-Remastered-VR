// Runs the mod's real discovery code (scan.cpp + engine.cpp + game.cpp) against a game exe mapped into this process.
// Build: see tests/run_wine_tests.sh. Usage: scantest.exe <Game_f_x64_EOS.exe> <log path>
// The exe is mapped without running it: hooks are only found and installed, nothing is called.
#include <windows.h>
#include <cstdio>
#include <string>
#include "log.h"
#include "scan.h"
#include "engine.h"
#include "game.h"
#include "settings.h"
#include "MinHook.h"
#include "headaim.h"
#include "upscaler.h"
VrSettings g_set;
const char* ModeName(int m) { static const char* n[] = { "synced", "aer", "head", "screen", "native" }; return m >= 0 && m < 5 ? n[m] : "?"; }
bool D3DHooksUiSeen() { return false; }
void ResolutionSettingsChanged() {}
std::wstring g_modDir;
int wmain(int argc, wchar_t** argv) {
    if (argc < 3) return 2;
    LogInit(argv[2]);
    HMODULE m = LoadLibraryExW(argv[1], nullptr, DONT_RESOLVE_DLL_REFERENCES);
    if (!m) { LOGE("LoadLibraryEx failed %lu", GetLastError()); return 3; }
    LOGI("mapped game exe at %p", m);
    MH_Initialize();
    ScanInitModule(m);
    bool ok = EngineInstall();
    LOGI("EngineInstall -> %d, ready %d, status '%s'", ok, EngineReady(), EngineStatus());
    bool g = GameScan();
    LOGI("GameScan -> %d", g);
    GameReport();
    HeadAimInstall();
    LOGI("HeadAimInstall -> %d", HeadAimAvailable());
    UpscalerInstall();
    LogFlushDisk();
    return ok && g && HeadAimAvailable() ? 0 : 1;
}
