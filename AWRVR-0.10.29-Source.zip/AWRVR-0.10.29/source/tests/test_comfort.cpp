// g++ -std=c++17 -Isrc tests/test_comfort.cpp && ./a.out
#include "comfort.h"
#include "refresh.h"
#include <cstdio>
static int fails = 0;
static void Check(bool c, const char* w) { printf("%s %s\n", c ? "ok  " : "FAIL", w); if (!c) fails++; }
static Xf Make(double yaw, double pitch, V3 p, bool lh = true) { Ypr a{yaw, pitch, 0}; return FromYpr(a, p, lh); }
static bool Ortho(const Xf& x) { return fabs(Len(x.r[0]) - 1) < 1e-6 && fabs(Len(x.r[1]) - 1) < 1e-6 && fabs(Dot(x.r[0], x.r[1])) < 1e-6 && fabs(Dot(x.r[1], x.r[2])) < 1e-6; }
int main() {
    // FromYpr / ToYpr round trip, handedness
    for (bool h : {true, false}) {
        Xf x = Make(0.7, -0.3, {1, 2, 3}, h); Ypr a = ToYpr(x);
        Check(fabs(a.yaw - 0.7) < 1e-6 && fabs(a.pitch + 0.3) < 1e-6 && fabs(a.roll) < 1e-6, h ? "ypr round trip (det+)" : "ypr round trip (det-)");
        Check((XfDet(x) > 0) == h && Ortho(x), "ypr frame orthonormal, handedness kept");
    }
    Check(Len(Make(0, 0, {0,0,0}).r[1] - V3{0,1,0}) < 1e-9 && Len(Make(0,0,{0,0,0}).r[0] - V3{1,0,0}) < 1e-9, "yaw 0 = identity basis");
    // settle: sway inside the slack gives zero output motion
    Settler st; Xf base = Make(0.2, 0.1, {5, 1, 5});
    Xf o0 = st.Step(base, 1.0);
    double maxMove = 0;
    for (int i = 0; i < 200; i++) {
        double s = sin(i * 0.1);
        Xf in = Make(0.2 + s * 1.15 * M_PI / 180 * 0.9, 0.1, {5 + s * 0.03, 1, 5});
        Xf o = st.Step(in, 1.0);
        maxMove = fmax(maxMove, Len(o.r[2] - o0.r[2]) + Len(o.p - o0.p));
    }
    Check(maxMove < 1e-9, "settle: 1.15 deg / 3 cm sway inside the slack -> no motion");
    Xf big = Make(0.2 + 57 * M_PI / 180, 0.1, {5, 1, 5});
    Xf ob = st.Step(big, 1.0); Ypr ab = ToYpr(ob);
    Check(fabs(WrapPi(ab.yaw - (0.2 + 57 * M_PI / 180))) <= 2.5 * M_PI / 180 + 1e-9, "settle: 57 deg turn followed within the slack");
    Check(Ortho(ob) && XfDet(ob) > 0, "settle: orthonormal, same handedness");
    // stabilizer: jump passes at once, small shake is smoothed
    Stabilizer sb; Xf a = Make(0, 0, {0,0,0}); sb.Step(a, 0.011, 0.35);
    Xf shaken = a; shaken.p.y += 0.05; Xf o = sb.Step(shaken, 0.011, 0.35);
    Check(o.p.y > 0 && o.p.y < 0.05, "stabilizer: shake smoothed");
    Xf cut = a; cut.p.x += 5; o = sb.Step(cut, 0.011, 0.35);
    Check(fabs(o.p.x - 5) < 1e-9, "stabilizer: cut passes at once");
    // stabilizer: a steady walk (1.5 m/s) and a steady stick turn (90 deg/s) are followed with no lag
    { Stabilizer s2; double lagP = 0, lagA = 0;
      for (int i = 0; i < 400; i++) { double t = i * 0.011; Xf in = Make(t * M_PI / 2 * 0 + 0.3, 0, {1.5 * t, 1.7, 0});
          Xf o = s2.Step(in, 0.011, 1.0); if (i > 200) lagP = fmax(lagP, Len(o.p - in.p)); }
      Stabilizer s3;
      for (int i = 0; i < 400; i++) { double t = i * 0.011; Xf in = Make(t * M_PI / 2, 0, {0, 1.7, 0});
          Xf o = s3.Step(in, 0.011, 1.0); if (i > 200) lagA = fmax(lagA, fabs(WrapPi(ToYpr(o).yaw - ToYpr(in).yaw))); }
      Check(lagP < 0.002, "stabilizer: steady walk followed (< 2 mm)");
      Check(lagA < 0.1 * M_PI / 180, "stabilizer: steady 90 deg/s turn followed (< 0.1 deg)");
      // 8 Hz shake of 3 cm on top of the walk is reduced
      Stabilizer s4; double amp = 0;
      for (int i = 0; i < 600; i++) { double t = i * 0.011; Xf in = Make(0.3, 0, {1.5 * t, 1.7 + 0.03 * sin(2 * M_PI * 8 * t), 0});
          Xf o = s4.Step(in, 0.011, 1.0); if (i > 300) amp = fmax(amp, fabs(o.p.y - 1.7)); }
      Check(amp < 0.02, "stabilizer: 8 Hz shake reduced"); printf("     (8 Hz 3 cm shake -> %.1f cm)\n", amp * 100); }
    // head bob: 2 Hz bob reduced, stairs (steady climb) followed, walking never delayed
    { BobFilter bf; double amp = 0, lagUp = 0, lagFwd = 0; V3 up{0, 1, 0};
      for (int i = 0; i < 900; i++) { double t = i * 0.011; V3 in = {1.5 * t, 1.7 + 0.04 * sin(2 * M_PI * 2 * t) + (t > 6 ? 0.4 * (t - 6) : 0), 0};
          V3 o = bf.Step(in, up, 0.011, 0.6);
          if (i > 200 && t < 6) amp = fmax(amp, fabs(o.y - 1.7));
          if (t > 8) lagUp = fmax(lagUp, fabs(o.y - (1.7 + 0.4 * (t - 6))) - 0.04);
          lagFwd = fmax(lagFwd, fabs(o.x - in.x)); }
      Check(amp < 0.03, "head bob: 2 Hz 4 cm bob reduced"); printf("     (2 Hz 4 cm bob -> %.1f cm)\n", amp * 100);
      Check(lagUp < 0.01, "head bob: climbing stairs followed");
      Check(lagFwd == 0, "head bob: walking direction never filtered"); }
    // refresh: smoothing halving never lowers the cap; a steady lower setting is followed after 20 s
    RefreshTracker r; double hz = 0;
    for (int i = 0; i < 100; i++) hz = r.Update(90, i * 0.011);
    Check(fabs(hz - 90) < 1e-9, "refresh: 90 Hz");
    for (int i = 0; i < 3000; i++) hz = r.Update(45, 2 + i * 0.022);
    Check(fabs(hz - 90) < 1e-9, "refresh: 45 Hz smoothing keeps 90");
    for (int i = 0; i < 3000; i++) hz = r.Update(72, 100 + i * 0.014);
    Check(fabs(hz - 72) < 1e-9, "refresh: steady 72 Hz for 20 s is followed");
    RefreshTracker p; p.SetRuntime("Pimax OpenXR");
    hz = p.Update(36, 0); Check(fabs(hz - 72) < 1e-9, "refresh: Pimax halved 36 -> 72");
    RefreshTracker q; q.SetRuntime("VirtualDesktopXR"); hz = q.Update(60, 0); Check(fabs(hz - 60) < 1e-9, "refresh: VDXR 60 Hz is real");
    printf(fails ? "%d FAILED\n" : "all passed\n", fails); return fails != 0;
}
