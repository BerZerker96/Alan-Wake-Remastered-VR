// Speed-hack test: patches QueryPerformanceCounter and GetTickCount the way Cheat Engine's speedhack does (an inline
// jump at the start of the exported functions to a version running N times faster) and checks that the mod's clock
// (realclock.h) still runs at real speed.
// x86_64-w64-mingw32-g++ -O1 -Isrc -static -o test_realclock.exe tests/test_realclock.cpp && wine test_realclock.exe
#include "realclock.h"
#include <cstdio>
#include <cstring>
#include <cstdint>

static const double kSpeed = 4.0;
static LARGE_INTEGER g_base{}; static DWORD g_baseTick = 0;
static BOOL WINAPI FastQpc(LARGE_INTEGER* c) {
    LARGE_INTEGER r, f; rc::NtQpc()(&r, &f);
    c->QuadPart = g_base.QuadPart + (LONGLONG)((r.QuadPart - g_base.QuadPart) * kSpeed); return TRUE;
}
static DWORD WINAPI FastTick() { return g_baseTick + (DWORD)((rc::TickMs() - g_baseTick) * kSpeed); }
static bool Patch(void* target, void* to) {
    uint8_t code[12] = { 0x48, 0xB8, 0, 0, 0, 0, 0, 0, 0, 0, 0xFF, 0xE0 };   // mov rax, imm64 ; jmp rax
    memcpy(code + 2, &to, 8);
    DWORD old; if (!VirtualProtect(target, sizeof code, PAGE_EXECUTE_READWRITE, &old)) return false;
    memcpy(target, code, sizeof code); VirtualProtect(target, sizeof code, old, &old);
    FlushInstructionCache(GetCurrentProcess(), target, sizeof code); return true;
}
int main() {
    int fails = 0;
    rc::Freq(); rc::NtQpc();
    rc::Qpc(&g_base); g_baseTick = rc::TickMs();
    HMODULE k32 = GetModuleHandleW(L"kernel32.dll");
    void* qpc = (void*)GetProcAddress(k32, "QueryPerformanceCounter"); void* gtc = (void*)GetProcAddress(k32, "GetTickCount");
    bool p1 = Patch(qpc, (void*)&FastQpc), p2 = Patch(gtc, (void*)&FastTick);
    printf("patched QueryPerformanceCounter %s, GetTickCount %s (x%.0f)\n", p1 ? "ok" : "FAILED", p2 ? "ok" : "FAILED", kSpeed);
    LARGE_INTEGER a, b, ra, rb, f; QueryPerformanceFrequency(&f);
    auto pQpc = (BOOL(WINAPI*)(LARGE_INTEGER*))qpc; auto pGtc = (DWORD(WINAPI*)())gtc;
    pQpc(&a); rc::Qpc(&ra); DWORD ta = pGtc(), rta = rc::TickMs();
    Sleep(300);
    pQpc(&b); rc::Qpc(&rb); DWORD tb = pGtc(), rtb = rc::TickMs();
    double hooked = double(b.QuadPart - a.QuadPart) / f.QuadPart, real = double(rb.QuadPart - ra.QuadPart) / rc::Freq();
    printf("Sleep(300): hooked QPC %.3f s, hooked GetTickCount %lu ms | mod clock %.3f s, %lu ms\n", hooked, (unsigned long)(tb - ta), real, (unsigned long)(rtb - rta));
    auto check = [&](bool c, const char* w) { printf("%s %s\n", c ? "ok  " : "FAIL", w); if (!c) fails++; };
    check(p1 && p2, "speed hack installed");
    check(hooked > 1.0, "the hooked clock really runs fast (the test is valid)");
    check(real > 0.25 && real < 0.45, "the mod's counter keeps real time");
    check((rtb - rta) > 250 && (rtb - rta) < 450, "the mod's millisecond tick keeps real time");
    printf(fails ? "%d FAILED\n" : "all passed\n", fails);
    return fails;
}
