// Offline preview of the VR panel: the real option registration (src/menu.cpp) and the real panel layout
// (vrkit_menu_core.cpp BuildFrame), rasterised on the CPU from ImGui's draw data exactly as the D3D11 backend blends it
// (premultiplied result), then shown over a dark backdrop. Writes panel_<n>_<tab>.png. Runs under Wine (fonts:
// C:\windows\Fonts\segoeui.ttf / georgia.ttf, or stand-ins with those names).
#include <windows.h>
#include <cstdio>
#include <cmath>
#include <string>
#include <vector>
#include <algorithm>
#include "imgui.h"
#include "vrkit_menu_core.h"
#include "vrkit_options.h"
#include "settings.h"
#include "engine.h"
#include "game.h"

// ---- stubs for what the panel calls in the running mod
std::wstring g_gameDir = L".", g_cfgPath = L".\\awrvr_config.txt";
void CompositorRecenter() {}
void CompositorApplyPanels() {}
void FlatToggle() {}
void FirstPersonToggle() {}
void EngineSettingsChanged() {}
void GameApplySettings() {}
void GameFirstPerson(bool, float, float, float) {}
namespace xrb { void ClientSetFramePacing(uint32_t, uint32_t) {} }
int EngineEffectiveMode() { return 0; }
const char* GameStateName(GameState) { return "gameplay"; }
GameState GameStateNow() { return GS_GAMEPLAY; }
int D3DHooksUiCandidates() { return 2; }
void PanelMouseSetActive(bool) {}
void HeadAimSetAimHeld(bool) {} void HeadAimApplySettings() {}
const char* UpscalerStatus() { return ""; }
int PanelMouseTakeExtraButton() { return 0; }
long PanelMouseRightPresses() { return 0; }
void PanelMouseTake(float* a, float* b, float* c, bool* l, bool* r) { *a = *b = *c = 0; *l = *r = false; }
vrkit::menu::Settings MenuRegister();
void MenuNoteFps(float);
bool PngWrite(const std::wstring& path, const uint8_t* rgba, unsigned w, unsigned h, unsigned pitch);

struct Px { float r, g, b, a; };
static std::vector<Px> g_fb; static int W, H;
static const unsigned char* g_tex; static int TW, TH;

static void Tri(const ImDrawVert& v0, const ImDrawVert& v1, const ImDrawVert& v2, const ImVec4& clip) {
    float minx = std::max(clip.x, std::floor(std::min({ v0.pos.x, v1.pos.x, v2.pos.x }))), maxx = std::min(clip.z, std::ceil(std::max({ v0.pos.x, v1.pos.x, v2.pos.x })));
    float miny = std::max(clip.y, std::floor(std::min({ v0.pos.y, v1.pos.y, v2.pos.y }))), maxy = std::min(clip.w, std::ceil(std::max({ v0.pos.y, v1.pos.y, v2.pos.y })));
    float area = (v1.pos.x - v0.pos.x) * (v2.pos.y - v0.pos.y) - (v2.pos.x - v0.pos.x) * (v1.pos.y - v0.pos.y);
    if (fabsf(area) < 1e-8f) return;
    auto col = [](ImU32 c, int s) { return ((c >> s) & 255) / 255.f; };
    for (int y = (int)std::max(0.f, miny); y < (int)std::min((float)H, maxy); y++)
        for (int x = (int)std::max(0.f, minx); x < (int)std::min((float)W, maxx); x++) {
            float px = x + 0.5f, py = y + 0.5f;
            float w0 = ((v1.pos.x - px) * (v2.pos.y - py) - (v2.pos.x - px) * (v1.pos.y - py)) / area;
            float w1 = ((v2.pos.x - px) * (v0.pos.y - py) - (v0.pos.x - px) * (v2.pos.y - py)) / area;
            float w2 = 1.f - w0 - w1;
            if (w0 < -1e-5f || w1 < -1e-5f || w2 < -1e-5f) continue;
            float u = w0 * v0.uv.x + w1 * v1.uv.x + w2 * v2.uv.x, v = w0 * v0.uv.y + w1 * v1.uv.y + w2 * v2.uv.y;
            // bilinear font atlas sample
            float fx = u * TW - 0.5f, fy = v * TH - 0.5f; int ix = (int)std::floor(fx), iy = (int)std::floor(fy); float ax = fx - ix, ay = fy - iy;
            float t[4] = {};
            for (int k = 0; k < 4; k++) {
                int sx = std::min(TW - 1, std::max(0, ix + (k & 1))), sy = std::min(TH - 1, std::max(0, iy + (k >> 1)));
                const unsigned char* p = g_tex + (sy * TW + sx) * 4;
                float wk = ((k & 1) ? ax : 1 - ax) * ((k >> 1) ? ay : 1 - ay);
                for (int c = 0; c < 4; c++) t[c] += wk * p[c] / 255.f;
            }
            float sr = (w0 * col(v0.col, 0) + w1 * col(v1.col, 0) + w2 * col(v2.col, 0)) * t[0];
            float sg = (w0 * col(v0.col, 8) + w1 * col(v1.col, 8) + w2 * col(v2.col, 8)) * t[1];
            float sb = (w0 * col(v0.col, 16) + w1 * col(v1.col, 16) + w2 * col(v2.col, 16)) * t[2];
            float sa = (w0 * col(v0.col, 24) + w1 * col(v1.col, 24) + w2 * col(v2.col, 24)) * t[3];
            Px& d = g_fb[y * W + x];   // ImGui's D3D11 blend: rgb = src*a + dst*(1-a), a = a + dst_a*(1-a)
            d.r = sr * sa + d.r * (1 - sa); d.g = sg * sa + d.g * (1 - sa); d.b = sb * sa + d.b * (1 - sa); d.a = sa + d.a * (1 - sa);
        }
}

// a dark night-forest-ish backdrop: what the panel floats over in the headset
static Px Backdrop(int x, int y) {
    float u = (float)x / W, v = (float)y / H;
    float sky = 0.05f + 0.10f * (1 - v), fog = 0.06f * expf(-powf((v - 0.62f) * 5, 2));
    float trees = 0;
    for (int k = 0; k < 9; k++) { float cx = (k + 0.5f) / 9 + 0.03f * sinf(k * 7.1f), wdt = 0.025f + 0.01f * ((k * 37) % 5);
        if (fabsf(u - cx) < wdt * (0.4f + v)) trees = 1; }
    float beam = 0.22f * expf(-powf((u - 0.7f) * 3.2f, 2) - powf((v - 0.55f) * 2.2f, 2));
    float l = trees ? 0.015f + fog * 0.4f : sky + fog;
    return { l * 0.55f + beam * 0.9f, l * 0.68f + beam * 0.95f, l * 1.0f + beam, 1 };
}

int main() {
    vrkit::menu::Settings s = MenuRegister();
    MenuNoteFps(90);
    W = (int)s.texW; H = (int)s.texH;
    if (!vrkit::menu::core::InitImGui(s)) { printf("init failed\n"); return 1; }
    ImGuiIO& io = ImGui::GetIO();
    unsigned char* px; io.Fonts->GetTexDataAsRGBA32(&px, &TW, &TH); g_tex = px;
    auto pages = vrkit::Options::Get().Pages();
    int sels[] = { 1, 7, 2, 0, 3, 0, 2 };
    for (int p = 0; p < (int)pages.size(); p++) {
        vrkit::menu::core::SetPage(p); vrkit::menu::core::SetSelection(p < 7 ? sels[p] : 0);
        for (int pass = 0; pass < 2; pass++) vrkit::menu::core::BuildFrame();   // second frame: settled layout
        ImDrawData* dd = ImGui::GetDrawData();
        g_fb.assign((size_t)W * H, Px{ 0, 0, 0, 0 });
        for (int n = 0; n < dd->CmdListsCount; n++) {
            const ImDrawList* cl = dd->CmdLists[n];
            for (const ImDrawCmd& c : cl->CmdBuffer) {
                if (c.UserCallback) continue;
                for (unsigned i = 0; i < c.ElemCount; i += 3) {
                    const ImDrawIdx* id = cl->IdxBuffer.Data + c.IdxOffset + i;
                    Tri(cl->VtxBuffer[c.VtxOffset + id[0]], cl->VtxBuffer[c.VtxOffset + id[1]], cl->VtxBuffer[c.VtxOffset + id[2]], c.ClipRect);
                }
            }
        }
        std::vector<uint8_t> out((size_t)W * H * 4);
        for (int y = 0; y < H; y++) for (int x = 0; x < W; x++) {
            Px m = g_fb[y * W + x], b = Backdrop(x, y);   // premultiplied menu over the scene
            float r = m.r + b.r * (1 - m.a), g = m.g + b.g * (1 - m.a), bl = m.b + b.b * (1 - m.a);
            uint8_t* o = &out[((size_t)y * W + x) * 4];
            o[0] = (uint8_t)std::min(255.f, r * 255.f + 0.5f); o[1] = (uint8_t)std::min(255.f, g * 255.f + 0.5f); o[2] = (uint8_t)std::min(255.f, bl * 255.f + 0.5f); o[3] = 255;
        }
        wchar_t name[64]; swprintf(name, 64, L"panel_%d_%hs.png", p + 1, pages[p].c_str());
        PngWrite(name, out.data(), W, H, W * 4);
        printf("wrote panel_%d_%s.png (%d draw lists)\n", p + 1, pages[p].c_str(), dd->CmdListsCount);
    }
    return 0;
}
