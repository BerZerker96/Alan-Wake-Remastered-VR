// Fake game exe that imports dxgi.dll like Game_f_x64_EOS.exe: the mod, installed as dxgi.dll, must load, forward to
// the real dxgi.dll and hand out working factories (the hooks are installed on the first one).
#include <windows.h>
#include <dxgi1_4.h>
#include <cstdio>
int main() {
    IDXGIFactory1* f = nullptr;
    HRESULT hr = CreateDXGIFactory1(__uuidof(IDXGIFactory1), (void**)&f);
    printf("CreateDXGIFactory1 via proxy -> %08lx %p\n", hr, (void*)f);
    if (f) {
        IDXGIAdapter1* a = nullptr; UINT n = 0;
        while (SUCCEEDED(f->EnumAdapters1(n, &a))) { a->Release(); n++; }
        printf("adapters: %u\n", n);
        f->Release();
    }
    HMODULE self = GetModuleHandleW(L"dxgi.dll"); wchar_t p[MAX_PATH] = L""; GetModuleFileNameW(self, p, MAX_PATH);
    printf("dxgi.dll in this process: %ls\n", p);
    return SUCCEEDED(hr) ? 0 : 1;
}
