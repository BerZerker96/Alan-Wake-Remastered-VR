// g++ -std=c++17 -I../src test_math.cpp -o test_math && ./test_math
#include "vrmath.h"
#include <cstdio>
#include <cstdlib>
static int fails = 0;
static void Check(bool c, const char* what) { printf("%s %s\n", c ? "ok  " : "FAIL", what); if (!c) fails++; }
static bool Near(V3 a, V3 b, double e = 1e-6) { return Len(a - b) < e; }
int main() {
    Xf cam{}; cam.r[0] = {1, 0, 0}; cam.r[1] = {0, 1, 0}; cam.r[2] = {0, 0, 1}; cam.p = {100, 5, -20};
    float qi[4] = {0, 0, 0, 1};
    // identity head at origin -> unchanged camera
    { float p[3] = {0, 0, 0}; Xf o = Compose(EyeFromXr(qi, p, 1), cam); Check(Near(o.p, cam.p) && Near(o.r[2], cam.r[2]), "identity pose keeps the camera"); }
    // right eye 3.2 cm to the right (OpenXR +x) -> camera moves along its right row
    { float p[3] = {0.032f, 0, 0}; Xf o = Compose(EyeFromXr(qi, p, 1), cam); Check(Near(o.p, cam.p + V3{0.032, 0, 0}, 1e-6), "eye offset along camera right"); }
    // leaning forward (OpenXR -z) -> along the camera's forward row (+z in the engine)
    { float p[3] = {0, 0, -0.1f}; Xf o = Compose(EyeFromXr(qi, p, 1), cam); Check(Near(o.p, cam.p + V3{0, 0, 0.1}, 1e-6), "lean forward moves along forward"); }
    // world scale doubles the offset
    { float p[3] = {0.032f, 0, 0}; Xf o = Compose(EyeFromXr(qi, p, 2), cam); Check(Near(o.p, cam.p + V3{0.064, 0, 0}, 1e-6), "world scale scales eye offset"); }
    // head turned left 30 deg (OpenXR: +30 about +Y) -> engine forward gets a negative x (left), stays unit, det +1
    {
        double a = 30 * M_PI / 180; float q[4] = {0, (float)sin(a / 2), 0, (float)cos(a / 2)}, p[3] = {0, 0, 0};
        Xf o = Compose(EyeFromXr(q, p, 1), cam);
        Check(o.r[2].x < -0.49 && o.r[2].x > -0.51 && o.r[2].z > 0.86, "turn left: forward points left");
        Check(fabs(XfDet(o) - 1) < 1e-6, "rotation stays proper (det +1)");
        Check(Near(o.r[1], V3{0, 1, 0}), "yaw keeps up");
    }
    // head pitched up 20 deg (OpenXR: +20 about +X turns -Z toward +Y) -> engine forward gets +y
    {
        double a = 20 * M_PI / 180; float q[4] = {(float)sin(a / 2), 0, 0, (float)cos(a / 2)}, p[3] = {0, 0, 0};
        Xf o = Compose(EyeFromXr(q, p, 1), cam);
        Check(o.r[2].y > 0.34 && o.r[2].y < 0.35, "pitch up: forward points up");
    }
    // composed with a yawed camera: eye offset follows the camera's right axis
    {
        double a = 90 * M_PI / 180; Xf c = cam;   // camera turned so its right is world -z, forward world +x
        c.r[0] = {cos(a), 0, -sin(a)}; c.r[2] = {sin(a), 0, cos(a)};
        float p[3] = {0.032f, 0, 0}; Xf o = Compose(EyeFromXr(qi, p, 1), c);
        Check(Near(o.p, c.p + c.r[0] * 0.032, 1e-6), "offset follows a turned camera");
    }
    // level basis removes pitch, keeps yaw and handedness
    {
        Xf c = cam; double a = 25 * M_PI / 180;      // pitched down 25 deg
        c.r[1] = {0, cos(a), sin(a)}; c.r[2] = {0, -sin(a), cos(a)};
        Xf l = LevelBasis(c, V3{0, 1, 0});
        Check(Near(l.r[2], V3{0, 0, 1}) && Near(l.r[1], V3{0, 1, 0}) && Near(l.r[0], V3{1, 0, 0}), "level basis removes pitch");
        Xf m = c; m.r[0] = m.r[0] * -1.0;            // mirrored basis keeps its handedness
        Check(XfDet(LevelBasis(m, V3{0, 1, 0})) < 0, "level basis keeps a mirrored basis mirrored");
    }
    // the engine's projection from the lens fields reproduces the headset tangents
    {
        double tH = 1.3, tV = 1.1;                   // symmetric headset frustum
        double fov = 2 * atan(tH), aspect = tH / tV, zoom = 1;
        double t = tan(fov * 0.5), m00 = 1 / (t * zoom), m11 = aspect / (t * zoom);
        Check(fabs(m00 - 1 / tH) < 1e-12 && fabs(m11 - 1 / tV) < 1e-12, "lens fields -> projection matches the headset FOV");
    }
    printf(fails ? "%d FAILED\n" : "all passed\n", fails);
    return fails ? 1 : 0;
}
