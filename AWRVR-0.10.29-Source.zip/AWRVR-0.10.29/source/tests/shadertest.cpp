// Compiles every shader of the mod with D3DCompile (the same flags as the mod). Usage: shadertest.exe
#include <windows.h>
#include <d3dcompiler.h>
#include <cstdio>
#include "shaders.h"
int main() {
    struct { const char* src; const char* e; const char* t; } s[] = {
        { kShaderGfx, "VS", "vs_5_0" }, { kShaderGfx, "PSCrop", "ps_5_0" }, { kShaderGfx, "PSUiSplit", "ps_5_0" } };
    int bad = 0;
    for (auto& x : s) {
        ID3DBlob *b = nullptr, *e = nullptr;
        HRESULT hr = D3DCompile(x.src, strlen(x.src), x.e, nullptr, nullptr, x.e, x.t, D3DCOMPILE_OPTIMIZATION_LEVEL3, 0, &b, &e);
        printf("%-10s %s  %s %zu bytes\n", x.e, x.t, SUCCEEDED(hr) ? "ok  " : "FAIL", b ? b->GetBufferSize() : 0);
        if (e) { printf("%s\n", (const char*)e->GetBufferPointer()); e->Release(); }
        if (FAILED(hr)) bad++;
        if (b) b->Release();
    }
    printf(bad ? "%d failed\n" : "all compiled\n", bad);
    return bad;
}
