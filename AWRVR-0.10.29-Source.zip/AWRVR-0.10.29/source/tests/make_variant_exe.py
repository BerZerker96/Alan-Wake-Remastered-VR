#!/usr/bin/env python3
"""Makes a copy of Game_f_x64_EOS.exe (1.33) with the primary byte patterns of three hooks changed the way a rebuilt
game might differ (other registers), so tests/run_wine_tests.sh can show that the semantic fallbacks find the same
functions. Only used for testing; the copy is never run.  Usage: make_variant_exe.py <exe> <out>"""
import struct, sys
src, out = sys.argv[1], sys.argv[2]
b = bytearray(open(src, 'rb').read())
pe = struct.unpack_from('<I', b, 0x3c)[0]; ns = struct.unpack_from('<H', b, pe + 6)[0]; opt = struct.unpack_from('<H', b, pe + 20)[0]
secs = [struct.unpack_from('<IIII', b, pe + 24 + opt + i * 40 + 8) for i in range(ns)]
def r2o(r):
    for vs, va, rs, ra in secs:
        if va <= r < va + rs: return r - va + ra
def patch(rva, old, new):
    o = r2o(rva)
    if bytes(b[o:o + len(old)]) != old: sys.exit(f'not the 1.33 exe (exe+{rva:x})')
    b[o:o + len(new)] = new
patch(0x1df9c4, b'\x8B\x15', b'\x8B\x0D')          # frame timer: mov edx,[count] -> mov ecx,[count]
patch(0x2effd3, b'\x49\x8B\xCE', b'\x48\x8B\xCE')  # camera pivot height: mov rcx,r14 -> mov rcx,rsi
patch(0x19473f, b'\x48\x8B\xD7', b'\x48\x8B\xD6')  # action camera: mov rdx,rdi -> mov rdx,rsi
open(out, 'wb').write(b)
print('variant written:', out)
