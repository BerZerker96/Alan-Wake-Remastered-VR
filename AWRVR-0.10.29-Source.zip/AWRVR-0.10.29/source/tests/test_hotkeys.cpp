// Hotkey binding format: every key name, keyboard chords with modifiers, mouse buttons, XInput combos and DirectInput
// buttons / hats / axes survive text -> binding -> text, and no name collides with the separators.
// x86_64-w64-mingw32-g++ -O1 -std=c++17 -Isrc -Ithird_party/vrkit -static tests/test_hotkeys.cpp -ldinput8 -ldxguid -o test_hotkeys.exe
#include <windows.h>
#include <xinput.h>
#include <cstdio>
#include <string>
#include <functional>
#include "vrkit_options.h"
#include "vrkit_input.h"
#include "vrkit_menu_core.h"
#include "settings.h"
// ---- stubs for what hotkeys.cpp calls in the running mod
VrSettings g_set;
void SettingsApply() {} void SettingsSave() {} void SettingsCycleMode() {} void CompositorRecenter() {} void FlatToggle() {} void FirstPersonToggle() {}
int PanelMouseTakeExtraButton() { return 0; } long PanelMouseRightPresses() { return 0; }
void HeadAimSetAimHeld(bool) {}
std::string ConfigStr(const char*, const char* d) { return d; }
void LogWrite(const char*, const char*, ...) {}
WORD g_testPad = 0;
namespace vrkit {
Options& Options::Get() { static Options o; return o; }
Option& Options::AddHotkey(const char*, const char*, const char*, std::string*, std::function<void()>, std::function<std::string()>, const char*) { static Option o; return o; }
namespace input { bool ReadPad(unsigned u, void* st) { if (u) return false; XINPUT_STATE* x = (XINPUT_STATE*)st; ZeroMemory(x, sizeof *x); x->Gamepad.wButtons = g_testPad; return true; } void SetHiddenChords(const unsigned*, int) {} void SetExtraSource(uint32_t (*)()) {} }
namespace menu { namespace core { bool IsOpen() { return false; } void SetOpen(bool) {} void SetModal(std::function<bool()>) {} bool ModalActive() { return false; } } }
}
#include "../src/hotkeys.cpp"

static int fails = 0;
static void Check(bool c, const std::string& w) { if (!c) { printf("FAIL %s\n", w.c_str()); fails++; } }
int main() {
    int n = 0;
    for (auto& k : kKeys) {
        std::string name = k.n;
        Check(name.find(',') == std::string::npos && name.find('+') == std::string::npos, "separator in key name " + name);
        Bind b = Parse(name); Check(b.vk == k.vk, "parse " + name);
        Check(Compose(b) == name, "round trip " + name + " -> " + Compose(b));
        Bind c = Parse("CTRL+SHIFT+" + name); Check(c.vk == k.vk && c.ctrl && c.shift && !c.alt, "chord " + name);
        Check(Compose(c) == "CTRL+SHIFT+" + name, "chord round trip " + name);
        n++;
    }
    for (char ch : std::string("0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ")) { std::string s(1, ch); Check(Compose(Parse(s)) == s, "letter " + s); n++; }
    const char* cases[] = { "END, PAD LB+Y", "F9", "PAD LT+RT", "PAD BACK+START", "JOY B3", "JOY B1+B12", "JOY POV UP", "JOY POV2 LEFT",
                            "JOY ZUP", "JOY RZDOWN+B5", "ALT+MOUSE4", "MOUSE3", "CTRL+F12, JOY S0UP", "SHIFT+NUMPLUS", "COMMA, PAD L3+R3+A" };
    for (const char* c : cases) {
        Bind b = Parse(c); std::string back = Compose(b);
        Bind b2 = Parse(back);
        Check(b.vk == b2.vk && b.ctrl == b2.ctrl && b.shift == b2.shift && b.alt == b2.alt && b.pad == b2.pad && b.joy == b2.joy, std::string("stable ") + c + " -> " + back);
        Check(b.vk || b.pad || b.joy, std::string("parsed something: ") + c);
        n++;
    }
    Check(Parse("PAD LB+Y").pad == (XINPUT_GAMEPAD_LEFT_SHOULDER | XINPUT_GAMEPAD_Y), "LB+Y bits");
    Check(Parse("PAD LT").pad == kLT, "LT bit");
    Check(Parse("JOY ZUP").joy == 1ull << 40 && Parse("JOY ZDOWN").joy == 1ull << 41, "Z axis bits");
    Check(Parse("").vk == 0 && Parse("").pad == 0 && Parse("").joy == 0, "empty = none");
    Check(Bits(XINPUT_GAMEPAD_LEFT_SHOULDER | XINPUT_GAMEPAD_Y) == 2, "combo size");
    Define();
    bool fp = false; for (auto& a : g_acts) if (!strcmp(a.id, "first_person") && !strcmp(a.def, "END")) fp = true;
    Check(fp, "first person action with End as its default");
    // LB and LB+Y both bound: pressing LB then Y fires only LB+Y; LB alone fires (on release)
    {
        int lb = 0, lby = 0; bool shot = false;
        for (auto& a : g_acts) a.bind = "";
        g_acts[0].bind = "PAD LB"; g_acts[0].run = [&] { lb++; };
        g_acts[1].bind = "PAD LB+Y"; g_acts[1].run = [&] { lby++; };
        auto step = [&](WORD b) { g_testPad = b; HotkeysPoll(&shot); };
        step(0); step(XINPUT_GAMEPAD_LEFT_SHOULDER); step(XINPUT_GAMEPAD_LEFT_SHOULDER);
        step(XINPUT_GAMEPAD_LEFT_SHOULDER | XINPUT_GAMEPAD_Y); step(XINPUT_GAMEPAD_LEFT_SHOULDER); step(0);
        Check(lb == 0 && lby == 1, "LB then Y: only LB+Y fires (lb " + std::to_string(lb) + ", lb+y " + std::to_string(lby) + ")");
        step(XINPUT_GAMEPAD_LEFT_SHOULDER); step(0);
        Check(lb == 1 && lby == 1, "LB alone fires once on release");
        step(XINPUT_GAMEPAD_LEFT_SHOULDER | XINPUT_GAMEPAD_Y); step(0);
        Check(lb == 1 && lby == 2, "LB+Y together: only LB+Y");
        g_acts[1].bind = ""; step(XINPUT_GAMEPAD_LEFT_SHOULDER);
        Check(lb == 2, "LB with no larger binding fires at once on press"); step(0);
        n += 4;
    }
    printf("%d bindings checked, %zu actions\n", n, g_acts.size());
    printf(fails ? "%d FAILED\n" : "all passed\n", fails);
    return fails;
}
