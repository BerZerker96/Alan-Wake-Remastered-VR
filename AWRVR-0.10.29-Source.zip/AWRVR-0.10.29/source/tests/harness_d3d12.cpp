// Fake D3D12 game (Wine + vkd3d + lavapipe): window, device, queue, flip swap chain, N frames of clear + Present through
// the mod installed as dxgi.dll. Exercises the factory / swap chain / command list hooks, the compositor start-up and the
// in-process OpenXR host with no runtime. Usage: Game_f_x64_d3d12.exe [frames]
#include <windows.h>
#include <d3d12.h>
#include <dxgi1_4.h>
#include <cstdio>
#include <cstdlib>
static LRESULT CALLBACK Wnd(HWND h, UINT m, WPARAM w, LPARAM l) { return DefWindowProcW(h, m, w, l); }
#define CK(x) do { HRESULT hr_ = (x); if (FAILED(hr_)) { printf("FAILED %s -> %08lx\n", #x, hr_); return 1; } } while (0)
// the game's monitor-size clamp (exe+1ce7d8), so the mod's patch can be checked here: it must read d4 / d8 twice after load
__asm__(".text\n.globl clamp_sig\nclamp_sig:\n"
        ".byte 0x45,0x8b,0x86,0xd4,0,0,0, 0x41,0x8b,0x96,0xd8,0,0,0, 0x41,0x8b,0x8e,0xe8,0,0,0\n"
        ".byte 0x41,0x8b,0x86,0xec,0,0,0, 0x41,0x83,0xbe,0xdc,0,0,0,0x02, 0x74,0x0c\nret\n"
        ".globl mode_sig\nmode_sig:\n"
        ".byte 0x44,0x8b,0x47,0x20, 0x8b,0x44,0x24,0x54, 0x8b,0x54,0x24,0x50, 0x44,0x3b,0xc2, 0x72,0x21, 0x8b,0x4f,0x24, 0x3b,0xc8, 0x72,0x1a\n"
        ".byte 0x8b,0x44,0x24,0x44, 0x8b,0x54,0x24,0x40, 0x44,0x3b,0xc2, 0x77,0x04, 0x3b,0xc8, 0x76,0x20, 0x89,0x47,0x24, 0x8b,0x44,0x24,0x48, 0xeb,0x07\nret\n");
extern "C" unsigned char mode_sig[];
extern "C" unsigned char clamp_sig[];
// the game's LoadResolution (exe+1d0120): same prologue and "%sresolution.xml" reference; it "reads" 3840x2160
// Borderless into the settings object - the mod's hook must leave the headset's size and Windowed there
__asm__(".text\n.globl fake_loadres\nfake_loadres:\n"
        ".byte 0x48,0x89,0x5c,0x24,0x08, 0x48,0x89,0x74,0x24,0x10, 0x48,0x89,0x7c,0x24,0x18, 0x55, 0x41,0x56, 0x41,0x57\n"
        ".byte 0x48,0x8d,0xac,0x24,0x10,0xfd,0xff,0xff, 0x48,0x81,0xec,0xf0,0x03,0x00,0x00, 0x48,0x8b,0xf9\n"
        "call fake_stub\n"
        ".byte 0x4c,0x8b,0xc0\n"
        "lea fake_resname(%rip), %rdx\n"
        "movl $3840, 0xd4(%rdi)\nmovl $2160, 0xd8(%rdi)\nmovl $2, 0xdc(%rdi)\n"
        "add $0x3f0, %rsp\npop %r15\npop %r14\npop %rbp\nmov 8(%rsp), %rbx\nmov 0x10(%rsp), %rsi\nmov 0x18(%rsp), %rdi\nret\n"
        "fake_stub:\nxor %eax, %eax\nret\n"
        ".section .rdata\nfake_resname:\n.asciz \"%sresolution.xml\"\n.text\n");
extern "C" void fake_loadres(void* settings);
// the main thread's scratch pad set-up (exe+347777): mov ecx,1 / call / mov ecx,0x400000 / call ScratchPadInit
__asm__(".text\n.globl fake_padsetup\nfake_padsetup:\n"
        "sub $0x28, %rsp\n.byte 0xb9,1,0,0,0\ncall fake_stub2\n"
        ".globl fake_padsize\nfake_padsize:\n.byte 0xb9,0,0,0x40,0\ncall fake_padinit\nadd $0x28, %rsp\nret\n"
        "fake_padinit:\n.byte 0x48,0x89,0x5c,0x24,0x08, 0x57, 0x48,0x83,0xec,0x30, 0x48,0x63,0xf9, 0x33,0xc9\ncall fake_stub2\n"
        "add $0x30, %rsp\npop %rdi\nmov 8(%rsp), %rbx\nret\nfake_stub2:\nret\n");
extern "C" unsigned char fake_padsize[];
int main(int argc, char** argv) {
    printf("scratch pad size %u\n", *(unsigned*)(fake_padsize + 1));
    { static unsigned char st[0x100] = {}; fake_loadres(st); printf("LoadResolution hook: settings %ux%u window mode %d\n", *(unsigned*)(st + 0xd4), *(unsigned*)(st + 0xd8), *(int*)(st + 0xdc)); }
    printf("monitor clamp %s (%02x %02x)\n", clamp_sig[17] == 0xd4 && clamp_sig[24] == 0xd8 ? "lifted" : "kept", clamp_sig[17], clamp_sig[24]);
    printf("display mode clamp %s (%02x %02x %02x)\n", mode_sig[41] == 0x44 && mode_sig[42] == 0x89 && mode_sig[43] == 0xc2 ? "lifted" : "kept", mode_sig[41], mode_sig[42], mode_sig[43]);
    int frames = argc > 1 ? atoi(argv[1]) : 300;
    WNDCLASSW wc{}; wc.lpfnWndProc = Wnd; wc.hInstance = GetModuleHandleW(nullptr); wc.lpszClassName = L"awrvrtest";
    RegisterClassW(&wc);
    HWND hwnd = CreateWindowW(L"awrvrtest", L"AWRVR D3D12 test", WS_OVERLAPPEDWINDOW | WS_VISIBLE, 0, 0, 1280, 720, nullptr, nullptr, wc.hInstance, nullptr);
    IDXGIFactory4* fac = nullptr; CK(CreateDXGIFactory1(__uuidof(IDXGIFactory4), (void**)&fac));
    ID3D12Device* dev = nullptr; CK(D3D12CreateDevice(nullptr, D3D_FEATURE_LEVEL_11_0, __uuidof(ID3D12Device), (void**)&dev));
    D3D12_COMMAND_QUEUE_DESC qd{}; ID3D12CommandQueue* q = nullptr; CK(dev->CreateCommandQueue(&qd, __uuidof(ID3D12CommandQueue), (void**)&q));
    DXGI_SWAP_CHAIN_DESC1 sd{}; sd.Width = 1280; sd.Height = 720; sd.Format = DXGI_FORMAT_R10G10B10A2_UNORM; sd.SampleDesc.Count = 1;
    sd.BufferUsage = DXGI_USAGE_RENDER_TARGET_OUTPUT; sd.BufferCount = 3; sd.SwapEffect = DXGI_SWAP_EFFECT_FLIP_DISCARD;
    IDXGISwapChain1* sc1 = nullptr; CK(fac->CreateSwapChainForHwnd(q, hwnd, &sd, nullptr, nullptr, &sc1));
    IDXGISwapChain3* sc = nullptr; CK(sc1->QueryInterface(__uuidof(IDXGISwapChain3), (void**)&sc));
    fac->MakeWindowAssociation(hwnd, 0);
    sc->SetColorSpace1(DXGI_COLOR_SPACE_RGB_FULL_G22_NONE_P709);
    D3D12_DESCRIPTOR_HEAP_DESC hd{}; hd.Type = D3D12_DESCRIPTOR_HEAP_TYPE_RTV; hd.NumDescriptors = 3;
    ID3D12DescriptorHeap* heap = nullptr; CK(dev->CreateDescriptorHeap(&hd, __uuidof(ID3D12DescriptorHeap), (void**)&heap));
    UINT inc = dev->GetDescriptorHandleIncrementSize(D3D12_DESCRIPTOR_HEAP_TYPE_RTV);
    ID3D12Resource* bb[3] = {};
    for (UINT i = 0; i < 3; i++) {
        CK(sc->GetBuffer(i, __uuidof(ID3D12Resource), (void**)&bb[i]));
        D3D12_CPU_DESCRIPTOR_HANDLE h = heap->GetCPUDescriptorHandleForHeapStart(); h.ptr += i * inc;
        dev->CreateRenderTargetView(bb[i], nullptr, h);
    }
    ID3D12CommandAllocator* al = nullptr; CK(dev->CreateCommandAllocator(D3D12_COMMAND_LIST_TYPE_DIRECT, __uuidof(ID3D12CommandAllocator), (void**)&al));
    ID3D12GraphicsCommandList* cl = nullptr; CK(dev->CreateCommandList(0, D3D12_COMMAND_LIST_TYPE_DIRECT, al, nullptr, __uuidof(ID3D12GraphicsCommandList), (void**)&cl));
    cl->Close();
    ID3D12Fence* fence = nullptr; CK(dev->CreateFence(0, D3D12_FENCE_FLAG_NONE, __uuidof(ID3D12Fence), (void**)&fence));
    HANDLE ev = CreateEventW(nullptr, FALSE, FALSE, nullptr); UINT64 fv = 0;
    DWORD t0 = GetTickCount();
    for (int f = 0; f < frames; f++) {
        MSG m; while (PeekMessageW(&m, nullptr, 0, 0, PM_REMOVE)) { TranslateMessage(&m); DispatchMessageW(&m); }
        UINT i = sc->GetCurrentBackBufferIndex();
        al->Reset(); cl->Reset(al, nullptr);
        D3D12_RESOURCE_BARRIER b{}; b.Type = D3D12_RESOURCE_BARRIER_TYPE_TRANSITION; b.Transition.pResource = bb[i];
        b.Transition.Subresource = D3D12_RESOURCE_BARRIER_ALL_SUBRESOURCES; b.Transition.StateBefore = D3D12_RESOURCE_STATE_PRESENT; b.Transition.StateAfter = D3D12_RESOURCE_STATE_RENDER_TARGET;
        cl->ResourceBarrier(1, &b);
        D3D12_CPU_DESCRIPTOR_HANDLE h = heap->GetCPUDescriptorHandleForHeapStart(); h.ptr += i * inc;
        cl->OMSetRenderTargets(1, &h, FALSE, nullptr);
        D3D12_VIEWPORT vp{ 0, 0, 1280, 720, 0, 1 }; cl->RSSetViewports(1, &vp);
        float c[4] = { 0.1f, 0.2f * (f % 60) / 60.f, 0.4f, 1 }; cl->ClearRenderTargetView(h, c, 0, nullptr);
        b.Transition.StateBefore = D3D12_RESOURCE_STATE_RENDER_TARGET; b.Transition.StateAfter = D3D12_RESOURCE_STATE_PRESENT;
        cl->ResourceBarrier(1, &b);
        cl->Close();
        ID3D12CommandList* lists[] = { cl }; q->ExecuteCommandLists(1, lists);
        HRESULT hr = sc->Present(1, 0);
        if (FAILED(hr)) { printf("Present failed %08lx at frame %d\n", hr, f); return 1; }
        q->Signal(fence, ++fv); if (fence->GetCompletedValue() < fv) { fence->SetEventOnCompletion(fv, ev); WaitForSingleObject(ev, 2000); }
    }
    printf("%d frames presented in %lu ms\n", frames, GetTickCount() - t0);
    return 0;
}
