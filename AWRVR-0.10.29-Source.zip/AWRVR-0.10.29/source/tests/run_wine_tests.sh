#!/bin/bash
# Smoke tests under Wine (no GPU needed): 1) the proxy loads into a fake game exe and forwards exports,
# 2) the real discovery code finds every hook in the given game exe.  Usage: tests/run_wine_tests.sh <game exe>
set -e
cd "$(dirname "$0")/.."
GAME=${1:?game exe}
W=${WT:-/tmp/awrvr_wt}; rm -rf $W; mkdir -p $W
CXX=x86_64-w64-mingw32-g++; CC=x86_64-w64-mingw32-gcc
INC="-Ithird_party/openxr/include -Ithird_party/minhook/include -Ithird_party/xrbridge/include -Isrc"
FL="-O1 -D_CRT_SECURE_NO_WARNINGS -DWIN32_LEAN_AND_MEAN -DNOMINMAX -D_WIN32_WINNT=0x0A00 -w"
$CXX $FL -municode -static -o $W/scantest.exe -Wl,--image-base,0x10000000 tests/scantest.cpp tests/scanstubs.cpp src/scan.cpp src/engine.cpp src/game.cpp src/headaim.cpp src/upscaler.cpp src/log.cpp src/config.cpp \
  third_party/minhook/src/buffer.c third_party/minhook/src/hook.c third_party/minhook/src/trampoline.c third_party/minhook/src/hde/hde64.c $INC
cp build/dxgi.dll $W/dbghelp.dll
$CXX $FL -static -o $W/Game_f_x64_harness.exe tests/harness.cpp -ldbghelp
WD=$W/dxgi; mkdir -p $WD; cp build/dxgi.dll $WD/dxgi.dll
W12=$W/d3d12; mkdir -p $W12; cp build/dxgi.dll $W12/dxgi.dll
$CXX $FL -static -o $W12/Game_f_x64_d3d12.exe tests/harness_d3d12.cpp -ld3d12 -ldxgi -ldxguid
$CXX $FL -static -o $WD/Game_f_x64_dxgi.exe tests/harness_dxgi.cpp -ldxgi -ldxguid
cp "$GAME" $W/game.exe
export WINEDEBUG=-all WINEPREFIX=${WINEPREFIX:-/tmp/awrvr_wineprefix}
echo "== proxy load test (as dbghelp.dll)"; (cd $W && WINEDLLOVERRIDES="dbghelp=n,b" timeout 60 wine Game_f_x64_harness.exe) || true
echo "--- awrvr.log"; cat $W/AWRVR/awrvr.log 2>/dev/null || echo "(no log)"
echo "== proxy load test (as dxgi.dll)"; (cd $WD && WINEDLLOVERRIDES="dxgi=n,b" timeout 60 wine Game_f_x64_dxgi.exe) || true
echo "--- awrvr.log"; cat $WD/AWRVR/awrvr.log 2>/dev/null || echo "(no log)"
echo "== D3D12 render loop through the mod (needs xvfb-run + a Vulkan driver, e.g. mesa lavapipe)"
if command -v xvfb-run >/dev/null; then
  wineserver -k 2>/dev/null; sleep 1   # a server left from the display-less runs above would be reused without a display
  mkdir -p $W12/AWRVR; echo "3420 2668 72.00 Test HMD" > $W12/AWRVR/headset.txt
  DOC=$(ls -d $WINEPREFIX/drive_c/users/*/Documents 2>/dev/null | grep -v /Public/ | head -1); DOC=${DOC:-$WINEPREFIX/drive_c/users/root/Documents}; mkdir -p "$DOC/Remedy/AlanWakeRemastered"
  printf '<screen_resolution>\r\n  <width value="3840"/>\r\n  <height value="2160"/>\r\n  <window_mode value="2"/>\r\n</screen_resolution>\r\n' > "$DOC/Remedy/AlanWakeRemastered/resolution.xml"
  (cd $W12 && WINEDLLOVERRIDES="dxgi=n,b" timeout 180 xvfb-run -a wine Game_f_x64_d3d12.exe 300 2>&1 | grep -v "X connection") || true
  grep -E "scratch pad|LoadResolution|resolution:|d3d12:|dxgi: hooked|dxgi: swap chain|compositor: ready|xr: OpenXR|\[E\]" $W12/AWRVR/awrvr.log | grep -v "camera:\|getProjection" || true
else echo "(skipped: no xvfb-run)"; fi
echo "== discovery test"; (cd $W && timeout 120 wine scantest.exe game.exe scan.log) ; echo "exit $?"
cat $W/scan.log
echo "== discovery on a variant exe (primary patterns changed like another build might be): the fallbacks must find the same"
if python3 tests/make_variant_exe.py "$GAME" $W/variant.exe; then
  (cd $W && timeout 120 wine scantest.exe variant.exe variant.log); echo "exit $?"
  grep -E "fallback|FrameTimer|FrameDtRing|CameraPivot|ActionCamera|GameScan|not found|NOT" $W/variant.log
fi
echo "== speed hack test (the mod's clock under a patched QueryPerformanceCounter / GetTickCount)"
$CXX -O1 -Isrc -static -o $W/test_realclock.exe tests/test_realclock.cpp && (cd $W && timeout 60 wine test_realclock.exe); echo "exit $?"
echo "== head aim (fake game)"; $CXX -O1 -std=c++17 -Isrc -static -o $W/test_headaim.exe tests/test_headaim.cpp && (cd $W && timeout 60 wine test_headaim.exe | tail -1); echo "exit $?"
echo "== canted eye views (headsets)"; $CXX -O1 -std=c++17 -Isrc -Ithird_party/xrbridge/include -Ithird_party/openxr/include -static -DWIN32_LEAN_AND_MEAN -DNOMINMAX -o $W/test_cant.exe tests/test_cant.cpp && (cd $W && timeout 60 wine test_cant.exe | tail -1); echo "exit $?"
echo "== hotkey binding format test"
$CXX -O1 -std=c++17 -Isrc -Ithird_party/vrkit -Ithird_party/xrbridge/include -Ithird_party/openxr/include -static -o $W/test_hotkeys.exe tests/test_hotkeys.cpp -ldinput8 -ldxguid && (cd $W && timeout 60 wine test_hotkeys.exe); echo "exit $?"
