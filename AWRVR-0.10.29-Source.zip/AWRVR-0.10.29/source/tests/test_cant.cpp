// canted eye views: for several headsets' fields (and canted displays), the turned eye orientation and the compositor's
// eye -> picture mapping agree, the symmetric picture covers the whole field, and little of it is never shown
#include <cstdio>
#include <cmath>
#include <windows.h>
#include "../src/engine.h"
#include "../src/vrmath.h"
static int fails = 0;
#define CHECK(c, ...) do { if (!(c)) { printf("FAIL: " __VA_ARGS__); printf("\n"); fails++; } } while (0)
static void Rot(const float q[4], const double v[3], double o[3]) { M3 m = QuatToM3(q[0], q[1], q[2], q[3]); for (int i = 0; i < 3; i++) o[i] = m.m[i][0] * v[0] + m.m[i][1] * v[1] + m.m[i][2] * v[2]; }
static void RotT(const float q[4], const double v[3], double o[3]) { M3 m = QuatToM3(q[0], q[1], q[2], q[3]); for (int i = 0; i < 3; i++) o[i] = m.m[0][i] * v[0] + m.m[1][i] * v[1] + m.m[2][i] * v[2]; }
struct Hs { const char* name; float l, r, u, d, displayCant; };
int main() {
    const float D = 3.14159265f / 180.f;
    Hs hs[] = {
        { "Pimax Dream Air (log)", atanf(-1.61f), atanf(0.92f), atanf(0.98f), atanf(-0.98f), 0 },
        { "Quest 2-like", -49 * D, 43 * D, 42 * D, -51 * D, 0 },
        { "Quest 3-like", -52 * D, 47 * D, 48 * D, -50 * D, 0 },
        { "Index-like", -54 * D, 50 * D, 56 * D, -56 * D, 0 },
        { "Pimax canted displays (10 deg)", -66 * D, 40 * D, 45 * D, -45 * D, 10 * D },
        { "symmetric", -45 * D, 45 * D, 45 * D, -45 * D, 0 },
        { "Varjo-like vertical offset", -50 * D, 45 * D, 40 * D, -52 * D, 0 },
    };
    for (auto& h : hs) for (int eye = 0; eye < 2; eye++) {
        // right eye: mirrored field
        float L = eye ? -h.r : h.l, R = eye ? -h.l : h.r, U = h.u, Dn = h.d;
        float c[2] = { -(L + R) * 0.5f, (U + Dn) * 0.5f };
        // the eye pose: a head orientation, plus the display cant (outward)
        float head[4] = { 0.05f, 0.3f, -0.02f, 0.95f }; float n = sqrtf(head[0]*head[0]+head[1]*head[1]+head[2]*head[2]+head[3]*head[3]); for (auto& x : head) x /= n;
        float dc = (eye ? -1 : 1) * h.displayCant;     // left display turned left (+yaw)
        float dq[4] = { 0, sinf(dc * 0.5f), 0, cosf(dc * 0.5f) }, q[4]; QMul(head, dq, q);
        float qc[4] = { q[0], q[1], q[2], q[3] }; CantQuat(qc, c);
        float ch = 0, cv = 0, maxErr = 0;
        for (int i = 0; i <= 32; i++) for (int j = 0; j <= 32; j++) {
            float tx = tanf(L) + (tanf(R) - tanf(L)) * i / 32.f, ty = tanf(Dn) + (tanf(U) - tanf(Dn)) * j / 32.f;
            float px, py; CantToPic(c, tx, ty, &px, &py);
            ch = fmaxf(ch, fabsf(px)); cv = fmaxf(cv, fabsf(py));
            double de[3] = { tx, ty, -1 }, w[3], dcam[3]; Rot(q, de, w); RotT(qc, w, dcam);
            double ex = dcam[0] / -dcam[2], ey = dcam[1] / -dcam[2];
            maxErr = fmaxf(maxErr, (float)fmax(fabs(ex - px), fabs(ey - py)));
        }
        CHECK(maxErr < 1e-4f, "%s eye %d: the camera turn and the compositor's mapping disagree by %g", h.name, eye, maxErr);
        // the eye's axis: the middle of the field maps to the picture centre
        float mx, my; CantToPic(c, tanf((L + R) * 0.5f), tanf((U + Dn) * 0.5f), &mx, &my);
        CHECK(fabsf(mx) < 2e-3f && fabsf(my) < 2e-3f, "%s eye %d: field middle not at the centre (%g %g)", h.name, eye, mx, my);
        // pixels: density at the eye's lens axis (tangent 0) against an off-centre picture of the same pixel count
        float own = (tanf(R) - tanf(L)) * (tanf(U) - tanf(Dn)), sym = 4 * ch * cv;
        float matched = 4 * fmaxf(-tanf(L), tanf(R)) * fmaxf(tanf(U), -tanf(Dn));
        printf("%-32s eye %d: cant %5.1f / %5.1f deg, picture +-%.3f x +-%.3f | shown share: canted %3.0f %%, matched %3.0f %%\n", h.name, eye,
               c[0] / D, c[1] / D, ch, cv, 100 * own / sym, 100 * own / matched);
        CHECK(own / sym > 0.85f || h.displayCant > 0, "%s eye %d: canted picture wastes too much (%.0f %% shown)", h.name, eye, 100 * own / sym);
    }
    printf(fails ? "%d FAILED\n" : "canted views: all passed\n", fails);
    return fails ? 1 : 0;
}
