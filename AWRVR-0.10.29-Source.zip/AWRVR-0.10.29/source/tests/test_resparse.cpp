// g++ -std=c++17 -Isrc tests/test_resparse.cpp && ./a.out
#include "resparse.h"
#include <cstdio>
int fails = 0;
void T(const char* s, const char* w, const char* h) {
    std::string e = s; size_t a, b, c, d; bool ok = ResFindPair(e, &a, &b, &c, &d);
    std::string W = ok ? e.substr(a, b) : "-", H = ok ? e.substr(c, d) : "-";
    bool good = W == w && H == h; if (!good) fails++;
    printf("%s %-70s -> %s x %s\n", good ? "ok  " : "FAIL", s, W.c_str(), H.c_str());
}
int main() {
    T("screen_resolution width=\"3840\" height=\"2160\" />", "3840", "2160");
    T("screen_resolution>3840x2160</screen_resolution", "3840", "2160");
    T("screen_resolution w=\"2560\" h=\"1440\" refresh=\"144\"/>", "2560", "1440");
    T("screen_resolution refresh=\"360\" x=\"1920\" y=\"1080\"/>", "1920", "1080");
    T("screen_resolution refresh_rate=\"59.940\" monitor=\"1\" value=\"3840 2160\"/>", "3840", "2160");
    T("screen_resolution><x>1920</x><y>1200</y></screen_resolution", "1920", "1200");
    T("screen_resolution index=\"0\"/>", "-", "-");
    // Alan Wake Remastered's own layout (seen in a player's log): child elements with a value attribute
    {
        std::string x = "<resolution>\n<screen_resolution>\n  <width value=\"3840\"/>\n  <height value=\"2160\"/>\n  <refresh_rate value=\"60\"/>\n</screen_resolution>\n<window_mode value=\"borderless\"/>";
        size_t at = x.find("screen_resolution"), p, l;
        bool okw = FindValue(x, at, 400, "width", &p, &l) && x.substr(p, l) == "3840";
        if (okw) x.replace(p, l, "3420");
        bool okh = FindValue(x, at, 400, "height", &p, &l) && x.substr(p, l) == "2160";
        if (okh) x.replace(p, l, "2668");
        bool okm = FindValue(x, 0, x.size(), "window_mode", &p, &l) && x.substr(p, l) == "borderless";
        bool good = okw && okh && okm && x.find("<width value=\"3420\"/>") != std::string::npos && x.find("<height value=\"2668\"/>") != std::string::npos;
        printf("%s AW layout: <width value=..>/<height value=..> read and rewritten, window_mode read\n", good ? "ok  " : "FAIL"); if (!good) fails++;
        size_t q, m; bool nolong = !FindValue(std::string("<widthx value=\"5\"/>"), 0, 30, "width", &q, &m);
        printf("%s a longer name (widthx) is not width\n", nolong ? "ok  " : "FAIL"); if (!nolong) fails++;
    }
    printf(fails ? "%d FAILED\n" : "all passed\n", fails); return fails;
}
