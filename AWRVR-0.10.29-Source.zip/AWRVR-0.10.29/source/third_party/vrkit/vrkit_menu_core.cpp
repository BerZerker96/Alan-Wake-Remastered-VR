#include "vrkit_menu_core.h"
#include "vrkit_options.h"
#include <windows.h>
#include <vector>
#include <algorithm>
#include "imgui.h"
#include "realclock.h"
#include <cmath>
#include "fonts/vrkit_fonts.h"

namespace vrkit { namespace menu { namespace core {

namespace {
Settings g_s;
ImGuiContext* g_im = nullptr;
ImFont* g_body = nullptr; ImFont* g_titleFont = nullptr; ImFont* g_head = nullptr; ImFont* g_tab = nullptr; ImFont* g_type = nullptr; ImFont* g_bodyBold = nullptr;
bool g_open = false;
int g_page = 0, g_sel = 0;
LARGE_INTEGER g_qpf, g_last;
std::function<bool()> g_modal;
// mouse: cursor in panel pixels, last frame's buttons, and what is where on the panel (filled by BuildFrame)
float g_mx = 640, g_my = 480; bool g_ml = false, g_mr = false; float g_mdx = 0, g_mdy = 0, g_mwheel = 0; bool g_mlDown = false, g_mrDown = false;
DWORD g_mouseTick = 0;
struct HitRow { float y0, y1, valL, valR; int r; float xX0 = 0, xX1 = 0; };   // xX: a hotkey's unbind button
struct HitTab { float x0, y0, x1, y1; int page; };
std::vector<HitRow> g_hitRows; std::vector<HitTab> g_hitTabs;
// hotkeys: the controller's focus on the row's unbind button (Left moves onto it, A unbinds, Right / Up / Down leave it)
bool g_hkFocusX = false; int g_hkFocusSel = -1, g_hkFocusPage = -1;
bool HotkeyBound(const Option& o) { return o.s && !o.s->empty() && !o.noUnbind; }
float g_closeX0 = 0, g_closeY0 = 0, g_closeX1 = 0, g_closeY1 = 0, g_listX0 = 0, g_listX1 = 0, g_listY0 = 0, g_listY1 = 0;

std::vector<int> PageItems(int page) {
    auto& opts = Options::Get().All();
    auto pages = Options::Get().Pages();
    std::vector<int> r;
    if (pages.empty()) return r;
    page = (std::min)(page, (int)pages.size() - 1);
    for (int k = 0; k < (int)opts.size(); ++k)
        if (opts[k].page == pages[page] && (!opts[k].visible || opts[k].visible())) r.push_back(k);
    return r;
}

void Close() {
    g_open = false;
    g_modal = nullptr;
    input::SetBlocking(false);
    if (Options::Get().Dirty() && !g_s.configPath.empty()) {
        if (Options::Get().Save(g_s.configPath)) Log("vrkit: settings saved");
    }
}

void MouseInteract() {
    bool moved = g_mdx != 0 || g_mdy != 0;
    bool lClick = g_mlDown && !g_ml, rClick = g_mrDown && !g_mr;
    g_ml = g_mlDown; g_mr = g_mrDown;
    float wheel = g_mwheel; g_mdx = g_mdy = 0; g_mwheel = 0;
    if (!moved && !lClick && !rClick && wheel == 0) return;
    g_mouseTick = rc::TickMs();
    auto items = PageItems(g_page);
    const HitRow* row = nullptr;
    if (g_mx >= g_listX0 && g_mx <= g_listX1 && g_my >= g_listY0 && g_my <= g_listY1)
        for (const HitRow& h : g_hitRows) if (g_my >= h.y0 && g_my < h.y1) { row = &h; break; }
    if (row && row->r < (int)items.size() && (moved || lClick || rClick)) g_sel = row->r;
    if (lClick) {
        if (g_mx >= g_closeX0 && g_mx <= g_closeX1 && g_my >= g_closeY0 && g_my <= g_closeY1) { Close(); return; }
        for (const HitTab& t : g_hitTabs) if (g_mx >= t.x0 && g_mx <= t.x1 && g_my >= t.y0 && g_my <= t.y1) { if (g_page != t.page) { g_page = t.page; g_sel = 0; } return; }
    }
    if (!row || row->r >= (int)items.size()) return;
    Option& o = Options::Get().All()[items[row->r]];
    bool onValue = g_mx >= row->valL;
    if (o.type == OptType::Hotkey && row->xX1 > row->xX0 && g_mx >= row->xX0 && g_mx <= row->xX1) {   // the unbind button
        if (lClick && HotkeyBound(o)) Options::Get().Step(o, -1);   // clears keyboard and controller bindings
        if (lClick || rClick) return;
    }
    if (lClick) {
        if (o.type == OptType::Action || o.type == OptType::Hotkey || o.type == OptType::Bool) Options::Get().Activate(o);
        else if (onValue) Options::Get().Step(o, g_mx < (row->valL + row->valR) * 0.5f ? -1 : +1);   // left half of the value: down
    }
    if (rClick) Options::Get().Step(o, -1);   // back one value / clear a hotkey
    if (wheel != 0) {
        int n = (int)(wheel > 0 ? wheel + 0.5f : wheel - 0.5f); if (n == 0) n = wheel > 0 ? 1 : -1;
        if (onValue && (o.type == OptType::Int || o.type == OptType::Float || o.type == OptType::Choice))
            for (int k = 0; k < abs(n); ++k) Options::Get().Step(o, n > 0 ? +1 : -1);
        else if (!items.empty()) g_sel = (std::max)(0, (std::min)((int)items.size() - 1, g_sel - n));
    }
}

void Navigate(uint32_t b) {
    auto pages = Options::Get().Pages();
    if (pages.empty()) return;
    if (b & input::PagePrev) { g_page = (g_page + (int)pages.size() - 1) % (int)pages.size(); g_sel = 0; }
    if (b & input::PageNext) { g_page = (g_page + 1) % (int)pages.size(); g_sel = 0; }
    auto items = PageItems(g_page);
    if (items.empty()) return;
    int n = (int)items.size();
    if (b & input::Up) g_sel = (g_sel + n - 1) % n;
    if (b & input::Down) g_sel = (g_sel + 1) % n;
    g_sel = (std::min)(g_sel, n - 1);
    Option& o = Options::Get().All()[items[g_sel]];
    if (g_hkFocusSel != g_sel || g_hkFocusPage != g_page || (b & (input::Up | input::Down))) g_hkFocusX = false;
    g_hkFocusSel = g_sel; g_hkFocusPage = g_page;
    if (o.type == OptType::Hotkey) {   // Left: onto the unbind button, A there: unbind, Right: back (Right on the keys: set)
        if (b & input::Left) { if (HotkeyBound(o)) g_hkFocusX = true; }
        if (b & input::Right) { if (g_hkFocusX) g_hkFocusX = false; else Options::Get().Step(o, +1); }
        if (b & input::Accept) { if (g_hkFocusX) { Options::Get().Step(o, -1); g_hkFocusX = false; } else Options::Get().Activate(o); }
        if (b & input::Reset) { g_hkFocusX = false; Options::Get().Reset(o); }
        return;
    }
    if (b & input::Left) Options::Get().Step(o, -1);
    if (b & input::Right) Options::Get().Step(o, +1);
    if (b & input::Accept) Options::Get().Activate(o);
    if (b & input::Reset) Options::Get().Reset(o);
}
} // namespace

bool InitImGui(const Settings& s) {
    if (g_im) return true;
    g_s = s;
    input::Configure(s.input);
    input::InstallHooks();
    IMGUI_CHECKVERSION();
    g_im = ImGui::CreateContext();
    ImGui::SetCurrentContext(g_im);
    ImGuiIO& io = ImGui::GetIO();
    io.IniFilename = nullptr; io.LogFilename = nullptr;
    io.DisplaySize = ImVec2((float)s.texW, (float)s.texH);
    // fonts (embedded, so the panel looks the same on every PC), chosen after the game's own UI: its menus use a
    // condensed sans in capitals and its manuscript pages a typewriter face.
    //   titles, tabs, section heads: Oswald (condensed, capitals)   options and help: Barlow Semi Condensed
    //   status line: Special Elite (typewriter, the manuscript)     fallback: Segoe UI / ImGui's own font
    float os = s.fontOversample > 0 ? s.fontOversample : 1.f;
    auto mem = [&](const unsigned char* data, size_t n, float px) -> ImFont* {
        ImFontConfig fc; fc.FontDataOwnedByAtlas = false; fc.OversampleH = 3; fc.OversampleV = 2; fc.PixelSnapH = false;
        static const ImWchar ranges[] = { 0x0020, 0x00FF, 0x2013, 0x2026, 0x2190, 0x2193, 0 };
        return io.Fonts->AddFontFromMemoryTTF((void*)data, (int)n, px, &fc, ranges);
    };
    auto load = [&](std::initializer_list<const wchar_t*> names, float px) -> ImFont* {
        wchar_t win[MAX_PATH]; char path[MAX_PATH * 2];
        if (!GetWindowsDirectoryW(win, MAX_PATH)) return nullptr;
        for (const wchar_t* name : names) {
            std::wstring p = std::wstring(win) + L"\\Fonts\\" + name;
            WideCharToMultiByte(CP_UTF8, 0, p.c_str(), -1, path, sizeof(path), nullptr, nullptr);
            if (GetFileAttributesW(p.c_str()) == INVALID_FILE_ATTRIBUTES) continue;
            if (ImFont* f = io.Fonts->AddFontFromFileTTF(path, px)) return f;
        }
        return nullptr;
    };
    const float px = s.fontPx * os;
    g_body = mem(fonts::kBarlow, sizeof fonts::kBarlow, px * 1.04f);
    if (!g_body) g_body = load({ L"segoeui.ttf", L"arial.ttf" }, px);
    if (!g_body) { ImFontConfig fc; fc.SizePixels = px; g_body = io.Fonts->AddFontDefault(&fc); }
    g_bodyBold = mem(fonts::kBarlowSemiBold, sizeof fonts::kBarlowSemiBold, px * 1.04f); if (!g_bodyBold) g_bodyBold = g_body;
    g_titleFont = mem(fonts::kOswald, sizeof fonts::kOswald, px * 1.22f); if (!g_titleFont) g_titleFont = g_body;
    g_tab = mem(fonts::kOswald, sizeof fonts::kOswald, px * 0.92f); if (!g_tab) g_tab = g_body;
    g_head = mem(fonts::kOswald, sizeof fonts::kOswald, px * 0.74f); if (!g_head) g_head = g_body;
    g_type = mem(fonts::kTypewriter, sizeof fonts::kTypewriter, px * 0.78f); if (!g_type) g_type = g_body;
    io.FontDefault = g_body;
    io.FontGlobalScale = 1.f / os;
    ImGuiStyle& st = ImGui::GetStyle();
    st.WindowRounding = 0.f; st.WindowBorderSize = 0.f; st.WindowPadding = ImVec2(0, 0);
    st.Colors[ImGuiCol_WindowBg] = ImVec4(0, 0, 0, 0);   // the panel is drawn by BuildFrame (rounded, framed, see-through)
    rc::Qpf(&g_qpf); rc::Qpc(&g_last);
    return true;
}

void ShutdownImGui() {
    if (g_im) { ImGui::DestroyContext(g_im); g_im = nullptr; }
    g_open = false;
}

const Settings& Get() { return g_s; }

bool UpdateInput() {
    if (!g_im) return false;
    static int rehook = 0;
    if ((++rehook % 300) == 1) input::InstallHooks();   // the game may load XInput late
    uint32_t b = input::Poll();
    if (g_open && g_modal) {   // listening for a hotkey: nothing else reacts (not even close)
        g_mdx = g_mdy = 0; g_mwheel = 0; g_ml = g_mlDown; g_mr = g_mrDown;
        if (!g_modal()) g_modal = nullptr;
        ImGui::SetCurrentContext(g_im);
        return true;
    }
    if (b & input::Toggle) { if (g_open) Close(); else { g_open = true; input::SetBlocking(true); g_mx = g_s.texW * 0.5f; g_my = g_s.texH * 0.5f; } b &= ~input::Toggle; }
    else if (g_open && (b & input::Back)) { Close(); return false; }
    if (!g_open) return false;
    MouseInteract();
    if (!g_open) return false;
    Navigate(b);
    ImGui::SetCurrentContext(g_im);
    return true;
}

// ---------------------------------------------------------------- look: a see-through black panel, dark-grey framed cards,
// dark-blue tabs, light blue for what is selected or on; condensed capitals for titles, tabs and section heads (the
// game's own menus) and a typewriter status line (the manuscript pages).
namespace theme {
inline ImU32 A(int r, int g, int b, float a) { return IM_COL32(r, g, b, (int)(a * 255.f + 0.5f)); }
// text with extra letter spacing (capitals read better spaced out)
inline float TrackedWidth(ImFont* f, float size, const char* t, float track) {
    float w = 0; int n = 0;
    for (const char* c = t; *c; ++c, ++n) { char b[2] = { *c, 0 }; w += f->CalcTextSizeA(size, FLT_MAX, 0.f, b).x; }
    return n ? w + track * (n - 1) : 0.f;
}
inline void TrackedText(ImDrawList* dl, ImFont* f, float size, ImVec2 p, ImU32 col, const char* t, float track) {
    for (const char* c = t; *c; ++c) { char b[2] = { *c, 0 }; dl->AddText(f, size, p, col, b); p.x += f->CalcTextSizeA(size, FLT_MAX, 0.f, b).x + track; }
}
inline std::string Upper(std::string s) { for (auto& ch : s) ch = (char)toupper((unsigned char)ch); return s; }
// a soft horizontal light: bright at x0, gone at x1
inline void Beam(ImDrawList* dl, ImVec2 a, ImVec2 b, ImU32 c0, ImU32 c1) { dl->AddRectFilledMultiColor(a, b, c0, c1, c1, c0); }
}

void BuildFrame() {
    using namespace theme;
    ImGui::SetCurrentContext(g_im);
    ImGuiIO& io = ImGui::GetIO();
    LARGE_INTEGER now; rc::Qpc(&now);
    io.DeltaTime = (std::max)(0.001f, (float)(now.QuadPart - g_last.QuadPart) / (float)g_qpf.QuadPart); g_last = now;
    io.DisplaySize = ImVec2((float)g_s.texW, (float)g_s.texH);
    ImGui::NewFrame();
    const float W = (float)g_s.texW, H = (float)g_s.texH, fp = g_s.fontPx, pad = fp * 0.8f;
    const float al = (std::max)(0.25f, (std::min)(1.f, g_s.backgroundAlpha));
    // palette: black panel, dark-grey cards and frames, dark-blue tabs, light blue for what is selected or on
    const ImU32 cPanel = A(3, 4, 6, al), cPanelEdge = A(0, 0, 0, al),
                cLine = A(64, 68, 76, 1.f), cLineStrong = A(84, 88, 98, 1.f),
                cText = A(244, 245, 248, 1.f), cTextDim = A(160, 166, 178, 1.f), cHint = A(128, 134, 146, 1.f),
                cAmber = A(130, 178, 245, 1.f), cAmberSoft = A(150, 160, 176, 1.f), cAmber0 = A(130, 178, 245, 0.f),
                cWarm = A(255, 255, 255, 1.f), cGroup = A(22, 24, 28, 0.6f * al + 0.3f), cHead = A(200, 206, 218, 1.f),
                cSel0 = A(26, 54, 108, 0.95f), cSel1 = A(16, 32, 64, 0.85f), cHot = A(255, 255, 255, 0.05f),
                cWarn = A(240, 186, 96, 1.f), cKey = A(32, 35, 41, 1.f), cKeyEdge = A(78, 82, 92, 1.f),
                cTab = A(13, 25, 50, 0.95f), cTabOn = A(27, 56, 110, 1.f), cTabHot = A(19, 38, 76, 0.95f), cFrame = A(70, 74, 82, 1.f);
    (void)cAmber0;
    ImGui::SetNextWindowPos(ImVec2(0, 0)); ImGui::SetNextWindowSize(ImVec2(W, H));
    ImGui::Begin("##vrkit", nullptr, ImGuiWindowFlags_NoDecoration | ImGuiWindowFlags_NoMove | ImGuiWindowFlags_NoSavedSettings | ImGuiWindowFlags_NoNav |
                 ImGuiWindowFlags_NoScrollbar | ImGuiWindowFlags_NoBackground);
    ImDrawList* dl = ImGui::GetWindowDrawList();
    const float R = fp * 0.42f;
    // panel: see-through near-black, darker at the bottom; a flashlight's warm pool at the top left; hairline frame
    // with a brighter top edge
    dl->AddRectFilled(ImVec2(1, 1), ImVec2(W - 1, H - 1), cPanel, R);
    dl->AddRectFilledMultiColor(ImVec2(R, H * 0.55f), ImVec2(W - R, H - R), A(0, 0, 0, 0.f), A(0, 0, 0, 0.f), cPanelEdge, cPanelEdge);
    dl->AddRect(ImVec2(1.5f, 1.5f), ImVec2(W - 1.5f, H - 1.5f), cFrame, R, 0, 1.5f);

    // header: title in tracked condensed capitals, the status line under it in typewriter, close button at the right
    float y = pad * 0.75f;
    g_hitRows.clear(); g_hitTabs.clear();
    const float titleSz = g_titleFont->FontSize * io.FontGlobalScale, track = fp * 0.06f;
    std::string title = Upper(g_s.title);
    TrackedText(dl, g_titleFont, titleSz, ImVec2(pad, y), cText, title.c_str(), track);
    float titleW = TrackedWidth(g_titleFont, titleSz, title.c_str(), track);
    // a small amber "lamp" mark after the title
    dl->AddCircleFilled(ImVec2(pad + titleW + fp * 0.45f, y + titleSz * 0.55f), fp * 0.11f, cAmber, 16);
    for (int k = 0; k < 4; ++k) dl->AddCircleFilled(ImVec2(pad + titleW + fp * 0.45f, y + titleSz * 0.55f), fp * (0.2f + 0.12f * k), A(130, 178, 245, 0.07f), 20);
    const float cb = titleSz * 0.9f;
    {
        g_closeX0 = W - pad - cb; g_closeY0 = y + (titleSz - cb) * 0.5f + fp * 0.05f; g_closeX1 = g_closeX0 + cb; g_closeY1 = g_closeY0 + cb;
        bool hot = g_mx >= g_closeX0 && g_mx <= g_closeX1 && g_my >= g_closeY0 && g_my <= g_closeY1;
        ImVec2 c((g_closeX0 + g_closeX1) * 0.5f, (g_closeY0 + g_closeY1) * 0.5f);
        dl->AddCircleFilled(c, cb * 0.5f, hot ? A(130, 178, 245, 0.22f) : A(255, 255, 255, 0.05f), 32);
        dl->AddCircle(c, cb * 0.5f, hot ? cAmber : cLineStrong, 32, 1.4f);
        float m = cb * 0.2f;
        dl->AddLine(ImVec2(c.x - m, c.y - m), ImVec2(c.x + m, c.y + m), hot ? cWarm : cText, 2.f);
        dl->AddLine(ImVec2(c.x + m, c.y - m), ImVec2(c.x - m, c.y + m), hot ? cWarm : cText, 2.f);
    }
    // status (fps, method, game state, version) on the right of the title bar, before the close button, in typewriter;
    // smaller if it would reach the title
    if (g_s.statusLine) {
        std::string st = g_s.statusLine();
        float ts = g_type->FontSize * io.FontGlobalScale, right = g_closeX0 - fp * 0.55f, left = pad + titleW + fp * 1.0f;
        float tw = g_type->CalcTextSizeA(ts, FLT_MAX, 0.f, st.c_str()).x;
        if (tw > right - left && tw > 0) { ts *= (std::max)(0.6f, (right - left) / tw); tw = g_type->CalcTextSizeA(ts, FLT_MAX, 0.f, st.c_str()).x; }
        dl->AddText(g_type, ts, ImVec2(right - tw, y + (titleSz - ts) * 0.5f + fp * 0.04f), cAmberSoft, st.c_str());
    }
    y += titleSz + fp * 0.15f;
    y += fp * 0.4f;

    // tabs: tracked capitals on the dark, no boxes; the open tab in flashlight white with a glowing amber line under
    // it, the others in moonlight grey; a hairline under the whole row
    auto pages = Options::Get().Pages();
    const int np = (int)pages.size();
    const float tabH = fp * 1.5f, tabTrack = fp * 0.05f, gapT = fp * 0.18f;
    if (np > 0) {
        float tw = (W - 2 * pad) / np;
        for (int p = 0; p < np; ++p) {
            ImVec2 a(pad + p * tw, y), b(a.x + tw, y + tabH);
            bool on = p == g_page;
            g_hitTabs.push_back({ a.x, a.y, b.x, b.y, p });
            bool hot = !on && g_mx >= a.x && g_mx <= b.x && g_my >= a.y && g_my <= b.y;
            ImVec2 a2(a.x + (p ? gapT * 0.5f : 0.f), a.y), b2(b.x - (p + 1 < np ? gapT * 0.5f : 0.f), b.y);
            dl->AddRectFilled(a2, b2, on ? cTabOn : hot ? cTabHot : cTab, R * 0.6f, ImDrawFlags_RoundCornersTop);
            dl->AddRect(a2, b2, on ? cLineStrong : cLine, R * 0.6f, ImDrawFlags_RoundCornersTop, 1.f);
            std::string t = Upper(pages[p]);
            float w = TrackedWidth(g_tab, g_tab->FontSize * io.FontGlobalScale, t.c_str(), tabTrack);
            TrackedText(dl, g_tab, g_tab->FontSize * io.FontGlobalScale, ImVec2(a.x + (tw - w) * 0.5f, a.y + (tabH - g_tab->FontSize * io.FontGlobalScale) * 0.5f), on ? cText : hot ? A(210, 216, 228, 1.f) : cTextDim, t.c_str(), tabTrack);
            if (on) dl->AddRectFilled(ImVec2(a2.x + 2, b2.y - 3.f), ImVec2(b2.x - 2, b2.y), A(150, 190, 245, 1.f));
        }
    }
    y += tabH;
    dl->AddLine(ImVec2(pad, y), ImVec2(W - pad, y), cLine, 1.f);
    y += fp * 0.45f;

    // option list: lines = group headers + rows, laid out with real heights, scrolled to keep the selection centred
    auto items = PageItems(g_page);
    auto& opts = Options::Get().All();
    struct Line { int item; const std::string* header; float y, h; int groupEnd; };
    std::vector<Line> lines; int selLine = -1;
    const float rowH = fp * 1.36f, headH = fp * 1.12f, groupGap = fp * 0.5f;
    {
        const std::string* prev = nullptr; float cy = 0; int open = -1;
        static const std::string kNone;
        for (int r = 0; r < (int)items.size(); ++r) {
            const std::string& gname = opts[items[r]].group;
            if (!prev || *prev != gname) {
                if (open >= 0) { lines[open].groupEnd = (int)lines.size() - 1; cy += groupGap; }
                open = (int)lines.size();
                lines.push_back({ -1, gname.empty() ? &kNone : &gname, cy, gname.empty() ? fp * 0.25f : headH, -1 });
                cy += lines.back().h;
            }
            prev = &gname;
            if (r == g_sel) selLine = (int)lines.size();
            lines.push_back({ r, nullptr, cy, rowH, -1 });
            cy += rowH;
        }
        if (open >= 0) lines[open].groupEnd = (int)lines.size() - 1;
    }
    const float helpH = fp * 3.3f, keysH = fp * 1.45f;
    const float listTop = y, listBottom = H - pad * 0.6f - keysH - helpH - fp * 0.35f, viewH = listBottom - listTop;
    float total = lines.empty() ? 0 : lines.back().y + lines.back().h;
    float scroll = 0;
    if (selLine >= 0 && total > viewH) {
        float want = lines[selLine].y + rowH * 0.5f - viewH * 0.5f;
        for (int k = selLine; k >= 0; --k) if (lines[k].header) { if (lines[selLine].y + rowH - lines[k].y < viewH * 0.8f) want = (std::min)(want, lines[k].y - fp * 0.1f); break; }
        scroll = (std::max)(0.f, (std::min)(want, total - viewH));
        float snapped = 0;
        for (const Line& L : lines) { if (L.y <= scroll + 0.5f) snapped = L.y; else break; }
        if (lines[selLine].y + rowH > snapped + viewH) { for (const Line& L : lines) if (L.y > snapped) { snapped = L.y; if (lines[selLine].y + rowH <= snapped + viewH) break; } }
        scroll = snapped;
    }
    const float bx0 = pad, bx1 = W - pad;
    float clipBottom = listTop;
    for (const Line& L : lines) { float e = listTop + L.y + L.h - scroll; if (e <= listBottom + 0.5f) clipBottom = (std::max)(clipBottom, e); }
    if (lines.empty() || clipBottom <= listTop) clipBottom = listBottom;
    dl->PushClipRect(ImVec2(0, listTop), ImVec2(W, clipBottom + 1.f), true);
    g_listX0 = pad; g_listX1 = W - pad; g_listY0 = listTop; g_listY1 = clipBottom;
    // groups: a faint card; the head is tracked capitals in moonlight grey with an amber tick and a hairline after it
    for (int li = 0; li < (int)lines.size(); ++li) {
        const Line& L = lines[li];
        if (!L.header) continue;
        const Line& last = lines[(std::max)(li, L.groupEnd)];
        float gy0 = listTop + L.y - scroll, gy1 = listTop + last.y + last.h - scroll;
        if (gy1 < listTop || gy0 > listBottom) continue;
        dl->AddRectFilled(ImVec2(bx0, gy0), ImVec2(bx1, gy1), cGroup, R * 0.6f);
        dl->AddRect(ImVec2(bx0, gy0), ImVec2(bx1, gy1), cLine, R * 0.6f, 0, 1.f);
        if (!L.header->empty()) {
            std::string hdr = Upper(*L.header);
            float hs = g_head->FontSize * io.FontGlobalScale, ht = fp * 0.09f, hy = gy0 + (L.h - hs) * 0.5f;
            dl->AddRectFilled(ImVec2(bx0 + fp * 0.5f, hy + hs * 0.18f), ImVec2(bx0 + fp * 0.5f + 3.f, hy + hs * 0.86f), cAmber, 1.f);
            TrackedText(dl, g_head, hs, ImVec2(bx0 + fp * 0.8f, hy), cHead, hdr.c_str(), ht);
            float hw = TrackedWidth(g_head, hs, hdr.c_str(), ht);
            Beam(dl, ImVec2(bx0 + fp * 1.2f + hw, gy0 + L.h * 0.5f), ImVec2(bx1 - fp * 0.5f, gy0 + L.h * 0.5f + 1.f), cLineStrong, A(255, 255, 255, 0.f));
        }
    }
    for (int li = 0; li < (int)lines.size(); ++li) {
        const Line& L = lines[li];
        if (L.header) continue;
        float ry = listTop + L.y - scroll;
        if (ry + L.h < listTop || ry > listBottom) continue;
        int r = L.item;
        Option& o = opts[items[r]];
        bool sel = r == g_sel;
        bool hot = !sel && g_mx >= bx0 && g_mx <= bx1 && g_my >= ry && g_my < ry + L.h && g_my >= listTop && g_my <= clipBottom;
        if (li + 1 < (int)lines.size() && !lines[li + 1].header) dl->AddLine(ImVec2(bx0 + fp * 0.8f, ry + L.h), ImVec2(bx1 - fp * 0.8f, ry + L.h), A(255, 255, 255, 0.05f), 1.f);
        if (hot) dl->AddRectFilled(ImVec2(bx0 + 2, ry + 1), ImVec2(bx1 - 2, ry + L.h - 1), cHot, R * 0.4f);
        if (sel) {   // the flashlight on the selected row: warm light fading to the right, an amber edge that glows
            Beam(dl, ImVec2(bx0 + 2, ry + 1), ImVec2(bx1 - 2, ry + L.h - 1), cSel0, cSel1);
            for (int k = 3; k >= 1; --k) dl->AddRectFilled(ImVec2(bx0 + 2, ry + 3 - k), ImVec2(bx0 + 5 + k * 3.f, ry + L.h - 3 + k), A(130, 178, 245, 0.10f), 2.f);
            dl->AddRectFilled(ImVec2(bx0 + 2, ry + 4), ImVec2(bx0 + 6, ry + L.h - 4), cAmber, 2.f);
        }
        ImFont* lf = sel ? g_bodyBold : g_body;
        float fs = lf->FontSize * io.FontGlobalScale, ty = ry + (L.h - fs) * 0.5f;
        dl->AddText(lf, fs, ImVec2(bx0 + fp * 0.85f, ty), sel ? cWarm : cText, o.label.c_str());
        std::string v = Options::Get().DisplayText(o);
        bool adjustable = o.type != OptType::Action;
        if (o.type == OptType::Action) {   // a pill button
            const char* shown = "RUN";
            float w = TrackedWidth(g_tab, g_head->FontSize * io.FontGlobalScale, shown, fp * 0.08f);
            ImVec2 a(bx1 - fp * 0.7f - w - fp * 1.1f, ry + L.h * 0.2f), b(bx1 - fp * 0.7f, ry + L.h * 0.8f);
            dl->AddRectFilled(a, b, sel ? A(130, 178, 245, 0.25f) : cKey, (b.y - a.y) * 0.5f);
            dl->AddRect(a, b, sel ? cAmber : cKeyEdge, (b.y - a.y) * 0.5f, 0, 1.2f);
            TrackedText(dl, g_head, g_head->FontSize * io.FontGlobalScale, ImVec2(a.x + (b.x - a.x - w) * 0.5f, ry + (L.h - g_head->FontSize * io.FontGlobalScale) * 0.5f), sel ? cWarm : cText, shown, fp * 0.08f);
            g_hitRows.push_back({ (std::max)(ry, listTop), (std::min)(ry + L.h, clipBottom), a.x, bx1, r });
            continue;
        }
        if (o.type == OptType::Bool) {   // a toggle switch: amber and lit when on
            bool on = o.b && *o.b;
            float sh = L.h * 0.46f, sw = sh * 1.9f, sx1 = bx1 - fp * 1.0f, sx0 = sx1 - sw, sy0 = ry + (L.h - sh) * 0.5f, sy1 = sy0 + sh;
            if (on) for (int k = 3; k >= 1; --k) dl->AddRectFilled(ImVec2(sx0 - k * 2.f, sy0 - k * 2.f), ImVec2(sx1 + k * 2.f, sy1 + k * 2.f), A(130, 178, 245, 0.06f), sh);
            dl->AddRectFilled(ImVec2(sx0, sy0), ImVec2(sx1, sy1), on ? A(130, 178, 245, 0.9f) : A(255, 255, 255, 0.10f), sh * 0.5f);
            dl->AddRect(ImVec2(sx0, sy0), ImVec2(sx1, sy1), on ? cAmber : (sel ? A(150, 190, 245, 0.7f) : cKeyEdge), sh * 0.5f, 0, 1.2f);
            float kr = sh * 0.36f, kx = on ? sx1 - sh * 0.5f : sx0 + sh * 0.5f;
            dl->AddCircleFilled(ImVec2(kx, sy0 + sh * 0.5f), kr, on ? A(8, 16, 34, 1.f) : A(200, 206, 218, 1.f), 24);
            g_hitRows.push_back({ (std::max)(ry, listTop), (std::min)(ry + L.h, clipBottom), (std::min)(sx0 - fp * 0.9f, bx1 - fp * 5.f), bx1, r });
            if (o.needsRestart) { float rs = g_head->FontSize * io.FontGlobalScale; float w = TrackedWidth(g_head, rs, "RESTART", fp * 0.06f);
                TrackedText(dl, g_head, rs, ImVec2(sx0 - w - fp * 0.6f, ry + (L.h - rs) * 0.5f), cWarn, "RESTART", fp * 0.06f); }
            continue;
        }
        const std::string& shown = v;
        // hotkeys: each binding (keyboard / controller) drawn as a keycap, like the controls line, and in front of them a
        // round unbind button (x) - mouse: click it; controller: Left onto it, A. Dim when there is nothing to unbind.
        if (o.type == OptType::Hotkey && std::none_of(shown.begin(), shown.end(), [](char c) { return c >= 'a' && c <= 'z'; })) {
            std::vector<std::string> chips; size_t p0 = 0;
            if (!shown.empty() && shown != "-")
                for (;;) { size_t c = shown.find(", ", p0); chips.push_back(shown.substr(p0, c == std::string::npos ? std::string::npos : c - p0)); if (c == std::string::npos) break; p0 = c + 2; }
            float ks = g_head->FontSize * io.FontGlobalScale * 1.08f, kt = fp * 0.05f, padK = fp * 0.3f, kh = ks * 1.4f, gapC = fp * 0.3f, cy = ry + L.h * 0.5f;
            float x = bx1 - fp * 1.0f;
            for (int c = (int)chips.size() - 1; c >= 0; --c) {
                float kw = TrackedWidth(g_head, ks, chips[c].c_str(), kt) + 2 * padK; x -= kw;
                dl->AddRectFilled(ImVec2(x, cy - kh * 0.5f), ImVec2(x + kw, cy + kh * 0.5f), sel && !g_hkFocusX ? A(130, 178, 245, 0.22f) : cKey, fp * 0.16f);
                dl->AddRect(ImVec2(x, cy - kh * 0.5f), ImVec2(x + kw, cy + kh * 0.5f), sel && !g_hkFocusX ? cAmber : cKeyEdge, fp * 0.16f, 0, 1.f);
                TrackedText(dl, g_head, ks, ImVec2(x + padK, cy - ks * 0.5f), sel && !g_hkFocusX ? cWarm : cText, chips[c].c_str(), kt);
                x -= gapC;
            }
            if (chips.empty()) {   // unbound: a dim dash where the keys would be
                float dw = fp * 0.6f; x -= dw;
                dl->AddLine(ImVec2(x + dw * 0.2f, cy), ImVec2(x + dw * 0.8f, cy), cTextDim, 2.f);
                x -= gapC;
            }
            if (o.noUnbind) {   // a hotkey that can never be unbound (the panel's own): no x
                g_hitRows.push_back({ (std::max)(ry, listTop), (std::min)(ry + L.h, clipBottom), (std::min)(x - fp * 0.6f, bx1 - fp * 5.f), bx1, r });
                continue;
            }
            // the unbind button
            bool bound = !chips.empty();
            float xr = kh * 0.5f, xcx = x - fp * 0.15f - xr, xcy = cy;
            bool xHot = bound && g_mx >= xcx - xr - 3 && g_mx <= xcx + xr + 3 && g_my >= xcy - xr - 3 && g_my <= xcy + xr + 3 && g_my >= listTop && g_my <= clipBottom;
            bool xFocus = bound && sel && g_hkFocusX;
            ImU32 xFill = xFocus || xHot ? A(200, 70, 78, 0.85f) : cKey, xEdge = xFocus || xHot ? A(255, 150, 150, 1.f) : (bound ? cKeyEdge : A(60, 64, 72, 1.f));
            if (xFocus) for (int k = 3; k >= 1; --k) dl->AddCircleFilled(ImVec2(xcx, xcy), xr + k * 2.5f, A(220, 80, 90, 0.08f), 28);
            dl->AddCircleFilled(ImVec2(xcx, xcy), xr, xFill, 28);
            dl->AddCircle(ImVec2(xcx, xcy), xr, xEdge, 28, 1.2f);
            float m = xr * 0.38f; ImU32 xc = xFocus || xHot ? A(255, 255, 255, 1.f) : (bound ? cText : A(90, 94, 104, 1.f));
            dl->AddLine(ImVec2(xcx - m, xcy - m), ImVec2(xcx + m, xcy + m), xc, 2.f);
            dl->AddLine(ImVec2(xcx + m, xcy - m), ImVec2(xcx - m, xcy + m), xc, 2.f);
            HitRow hr{ (std::max)(ry, listTop), (std::min)(ry + L.h, clipBottom), (std::min)(xcx + xr + gapC, bx1 - fp * 5.f), bx1, r };
            hr.xX0 = xcx - xr - 3; hr.xX1 = xcx + xr + 3;
            g_hitRows.push_back(hr);
            continue;
        }
        ImVec2 vs = ImGui::CalcTextSize(shown.c_str());
        float vx = bx1 - fp * 1.05f - vs.x;
        g_hitRows.push_back({ (std::max)(ry, listTop), (std::min)(ry + L.h, clipBottom), (std::min)(vx - fp * 0.9f, bx1 - fp * 5.f), bx1, r });
        // numbers: a small slider left of the value showing where it sits in its range
        float leftEdge = vx;
        if ((o.type == OptType::Float || o.type == OptType::Int) && o.maxV > o.minV) {
            float cur = o.type == OptType::Float ? (o.f ? *o.f : 0.f) : (o.i ? (float)*o.i : 0.f);
            float t = (std::max)(0.f, (std::min)(1.f, (cur - o.minV) / (o.maxV - o.minV)));
            float tw = fp * 2.6f, tx1 = bx1 - fp * 1.05f - (std::max)(vs.x, fp * 2.2f) - fp * 0.85f, tx0 = tx1 - tw, tyl = ry + L.h * 0.5f;   // one column for every row
            dl->AddRectFilled(ImVec2(tx0, tyl - 1.5f), ImVec2(tx1, tyl + 1.5f), A(255, 255, 255, 0.12f), 1.5f);
            dl->AddRectFilled(ImVec2(tx0, tyl - 1.5f), ImVec2(tx0 + tw * t, tyl + 1.5f), sel ? cAmber : A(130, 178, 245, 0.6f), 1.5f);
            if (sel) dl->AddCircleFilled(ImVec2(tx0 + tw * t, tyl), fp * 0.2f, A(130, 178, 245, 0.18f), 20);
            dl->AddCircleFilled(ImVec2(tx0 + tw * t, tyl), fp * 0.11f, sel ? cWarm : A(214, 220, 232, 1.f), 16);
            leftEdge = tx0;
        }
        if (o.needsRestart) { float rs = g_head->FontSize * io.FontGlobalScale; float w = TrackedWidth(g_head, rs, "RESTART", fp * 0.06f);
            TrackedText(dl, g_head, rs, ImVec2(leftEdge - w - fp * 0.75f, ry + (L.h - rs) * 0.5f), cWarn, "RESTART", fp * 0.06f); }
        if (sel && adjustable) {   // < value > chevrons
            float cy = ry + L.h * 0.5f, s3 = fp * 0.16f, lx = vx - fp * 0.32f, rx = vx + vs.x + fp * 0.32f;
            dl->AddLine(ImVec2(lx, cy - s3), ImVec2(lx - s3, cy), cAmber, 2.f); dl->AddLine(ImVec2(lx - s3, cy), ImVec2(lx, cy + s3), cAmber, 2.f);
            dl->AddLine(ImVec2(rx, cy - s3), ImVec2(rx + s3, cy), cAmber, 2.f); dl->AddLine(ImVec2(rx + s3, cy), ImVec2(rx, cy + s3), cAmber, 2.f);
        }
        dl->AddText(ImVec2(vx, ty), sel ? cWarm : (o.type == OptType::Hotkey && (shown.empty() || shown == "-") ? cTextDim : A(214, 220, 232, 1.f)), shown.c_str());
    }
    if (items.empty()) dl->AddText(ImVec2(pad, listTop + fp * 0.3f), cTextDim, "(nothing on this page for the chosen stereo method)");
    dl->PopClipRect();
    // scroll hints: soft chevrons
    auto chev = [&](float cx, float cy, bool up) { float s = fp * 0.26f, d = up ? -1.f : 1.f;
        dl->AddLine(ImVec2(cx - s, cy - d * s * 0.5f), ImVec2(cx, cy + d * s * 0.5f), cTextDim, 2.f); dl->AddLine(ImVec2(cx, cy + d * s * 0.5f), ImVec2(cx + s, cy - d * s * 0.5f), cTextDim, 2.f); };
    if (scroll > 1) chev(W * 0.5f, listTop + fp * 0.2f, true);
    if (scroll + (clipBottom - listTop) < total - 1) chev(W * 0.5f, listBottom - fp * 0.12f, false);

    // help: the selected option explained, on a faint card with an amber edge
    float hy = listBottom + fp * 0.35f;
    dl->AddRectFilled(ImVec2(bx0, hy), ImVec2(bx1, hy + helpH), cGroup, R * 0.6f);
    dl->AddRect(ImVec2(bx0, hy), ImVec2(bx1, hy + helpH), cLine, R * 0.6f, 0, 1.f);
    dl->AddRectFilled(ImVec2(bx0, hy + fp * 0.25f), ImVec2(bx0 + 3.f, hy + helpH - fp * 0.25f), cAmberSoft, 1.f);
    if (!items.empty()) {
        const Option& o = opts[items[(std::min)(g_sel, (int)items.size() - 1)]];
        std::string h = o.help;
        if (!o.key.empty()) h += (h.empty() ? "" : "   ") + std::string("[") + o.key + "]";
        ImGui::SetWindowFontScale(0.9f);
        ImGui::SetCursorScreenPos(ImVec2(bx0 + fp * 0.6f, hy + fp * 0.3f));
        ImGui::PushTextWrapPos(bx1 - fp * 0.55f);
        ImGui::PushStyleColor(ImGuiCol_Text, A(186, 194, 210, 1.f));
        ImGui::PushClipRect(ImVec2(bx0, hy), ImVec2(bx1, hy + helpH - fp * 0.15f), true);
        ImGui::TextWrapped("%s", h.c_str());
        ImGui::PopClipRect();
        ImGui::PopStyleColor(); ImGui::PopTextWrapPos();
        ImGui::SetWindowFontScale(1.f);
    }
    // controls: each key drawn as a small keycap, then what it does
    {
        bool mouseRecent = g_mouseTick && rc::TickMs() - g_mouseTick < 15000;
        static const char* kMouse[][2] = { { "CLICK", "change / run" }, { "RIGHT CLICK", "back / clear" }, { "WHEEL", "scroll / adjust" }, { "X", "close" } };
        static const char* kPad[][2] = { { "D-PAD", "select / change" }, { "A", "toggle / run" }, { "Y", "default" }, { "LB / RB", "tabs" }, { "B", "close" } };
        static const char* kMouseHk[][2] = { { "CLICK", "set" }, { "CLICK X", "unbind" }, { "WHEEL", "scroll" }, { "X", "close" } };
        static const char* kPadHk[][2] = { { "A", "set" }, { "LEFT", "to the x" }, { "A ON X", "unbind" }, { "Y", "default" }, { "B", "close" } };
        bool hk = false;
        { auto it = PageItems(g_page); if (!it.empty() && g_sel < (int)it.size()) hk = Options::Get().All()[it[g_sel]].type == OptType::Hotkey; }
        const char* (*e)[2] = mouseRecent ? (hk ? kMouseHk : kMouse) : (hk ? kPadHk : kPad); int n = mouseRecent ? 4 : 5;
        float ks = g_head->FontSize * io.FontGlobalScale, as = g_body->FontSize * io.FontGlobalScale * 0.82f, kt = fp * 0.05f, gapK = fp * 0.3f, gapE = fp * 0.9f, padK = fp * 0.3f;
        float tot = 0;
        for (int i = 0; i < n; ++i) tot += TrackedWidth(g_head, ks, e[i][0], kt) + 2 * padK + gapK + g_body->CalcTextSizeA(as, FLT_MAX, 0.f, e[i][1]).x + (i + 1 < n ? gapE : 0);
        float x = (W - tot) * 0.5f, cy = H - pad * 0.5f - keysH * 0.5f;
        for (int i = 0; i < n; ++i) {
            float kw = TrackedWidth(g_head, ks, e[i][0], kt) + 2 * padK, kh = ks * 1.35f;
            dl->AddRectFilled(ImVec2(x, cy - kh * 0.5f), ImVec2(x + kw, cy + kh * 0.5f), cKey, fp * 0.16f);
            dl->AddRect(ImVec2(x, cy - kh * 0.5f), ImVec2(x + kw, cy + kh * 0.5f), cKeyEdge, fp * 0.16f, 0, 1.f);
            TrackedText(dl, g_head, ks, ImVec2(x + padK, cy - ks * 0.5f), cText, e[i][0], kt);
            x += kw + gapK;
            dl->AddText(g_body, as, ImVec2(x, cy - as * 0.52f), cHint, e[i][1]);
            x += g_body->CalcTextSizeA(as, FLT_MAX, 0.f, e[i][1]).x + gapE;
        }
    }
    // the mouse cursor: a slim modern dart in flashlight white fading to lamp amber, with a soft glow that hugs its
    // shape (brighter over anything clickable), a thin dark rim for contrast on the bright game behind the see-through
    // panel, and a ripple on each click
    {
        static DWORD s_clickAt = 0; static bool s_wasDown = false;
        DWORD now = rc::TickMs();
        if (g_mlDown && !s_wasDown) s_clickAt = now;
        s_wasDown = g_mlDown;
        bool hover = false;
        for (auto& t : g_hitTabs) if (g_mx >= t.x0 && g_mx < t.x1 && g_my >= t.y0 && g_my < t.y1) hover = true;
        if (g_mx >= g_closeX0 && g_mx < g_closeX1 && g_my >= g_closeY0 && g_my < g_closeY1) hover = true;
        if (g_mx >= g_listX0 && g_mx < g_listX1 && g_my >= g_listY0 && g_my < g_listY1)
            for (auto& r : g_hitRows) if (g_my >= r.y0 && g_my < r.y1) hover = true;

        float sc = fp / 34.f * 1.75f * (g_mlDown ? 0.92f : 1.f), x = g_mx, y0 = g_my;
        float breathe = 0.85f + 0.15f * sinf((float)(now % 100000u) * 0.0026f);
        auto P = [&](float px, float py) { return ImVec2(x + px * sc, y0 + py * sc); };
        // the dart: tip, left wing, notch, right wing
        const ImVec2 pts[4] = { P(0, 0), P(1.2f, 21.f), P(6.4f, 15.6f), P(15.2f, 15.0f) };

        // glow: the dart's own shape spread around it in rings (a cheap blur) - soft, round edges, no spikes at the tips
        const int gr = 255, gg = hover ? 206 : 180, gb = hover ? 120 : 96;
        {   // a faint round halo first, then the shape spread in fine rings over it
            ImVec2 cc = P(6.f, 11.f);
            for (int k = 0; k < 8; ++k) dl->AddCircleFilled(cc, (30.f - 3.f * k) * sc / 1.75f, A(gr, gg, gb, (hover ? 0.022f : 0.014f) * breathe), 40);
        }
        for (int ring = 6; ring >= 1; --ring) {
            float r = ring * 1.5f * sc / 1.75f, a = (hover ? 0.022f : 0.015f) * (7 - ring) * breathe / 2.f;
            for (int k = 0; k < 16; ++k) {
                float an = k * 0.3926991f + ring * 0.2f, ox = cosf(an) * r, oy = sinf(an) * r;
                ImVec2 q[4]; for (int m = 0; m < 4; ++m) q[m] = ImVec2(pts[m].x + ox, pts[m].y + oy);
                dl->AddConcavePolyFilled(q, 4, A(gr, gg, gb, a));
            }
        }
        // soft bloom at the tip: where the click lands
        for (int k = 0; k < 4; ++k) dl->AddCircleFilled(P(1.5f, 2.5f), (9.f - 2.f * k) * sc / 1.6f, A(255, 236, 200, (hover ? 0.10f : 0.06f) * (k + 1) * breathe * 0.5f), 24);

        // shadow
        ImVec2 sh[4]; for (int k = 0; k < 4; ++k) sh[k] = ImVec2(pts[k].x + 1.0f * sc, pts[k].y + 1.5f * sc);
        dl->AddConcavePolyFilled(sh, 4, A(0, 0, 0, 0.30f));
        // fill: white at the tip fading to warm amber at the wings (two convex triangles with per-vertex colours)
        {
            ImU32 cTip = A(255, 252, 244, 1.f), cMid = A(255, 232, 188, 1.f), cEnd = hover ? A(255, 196, 112, 1.f) : A(246, 188, 118, 1.f);
            ImVec2 uv = ImGui::GetFontTexUvWhitePixel();
            dl->PrimReserve(6, 6);
            dl->PrimWriteVtx(pts[0], uv, cTip); dl->PrimWriteVtx(pts[1], uv, cEnd); dl->PrimWriteVtx(pts[2], uv, cMid);
            dl->PrimWriteVtx(pts[0], uv, cTip); dl->PrimWriteVtx(pts[2], uv, cMid); dl->PrimWriteVtx(pts[3], uv, cEnd);
            ImDrawIdx b = (ImDrawIdx)(dl->_VtxCurrentIdx - 6);
            dl->PrimWriteIdx(b); dl->PrimWriteIdx(b + 1); dl->PrimWriteIdx(b + 2);
            dl->PrimWriteIdx(b + 3); dl->PrimWriteIdx(b + 4); dl->PrimWriteIdx(b + 5);
        }
        // crisp rim and a bright inner edge on the left wing (light from above)
        dl->AddPolyline(pts, 4, A(14, 16, 24, 0.95f), ImDrawFlags_Closed, 1.3f * sc / 1.6f + 0.5f);
        dl->AddLine(P(0.9f, 2.6f), P(1.7f, 17.5f), A(255, 255, 255, 0.85f), 1.2f);
        // accent: a short line in the panel's blue along the right wing
        dl->AddLine(P(2.4f, 3.0f), P(11.8f, 13.6f), A(150, 196, 255, hover ? 0.95f : 0.75f), 1.4f);

        // click ripple: an amber ring that grows and fades for 0.35 s
        DWORD age = now - s_clickAt;
        if (s_clickAt && age < 350) {
            float t = age / 350.f;
            dl->AddCircle(P(0, 0), (4.f + 18.f * t) * fp / 34.f, A(255, 214, 150, 0.85f * (1.f - t)), 32, 2.2f * (1.f - t) + 0.6f);
        }
    }
    ImGui::End();
    ImGui::Render();
}

void FeedMouse(const Mouse& m) {
    g_mdx += m.dx; g_mdy += m.dy; g_mwheel += m.wheel; g_mlDown = m.left; g_mrDown = m.right;
    g_mx = (std::max)(0.f, (std::min)((float)g_s.texW - 2.f, g_mx + m.dx));
    g_my = (std::max)(0.f, (std::min)((float)g_s.texH - 2.f, g_my + m.dy));
}
void SetModal(std::function<bool()> poll) { g_modal = poll; }
bool ModalActive() { return (bool)g_modal; }

void SetPage(int page) { g_page = page; g_sel = 0; }
void SetSelection(int sel) { g_sel = sel; }
void SetBackgroundAlpha(float a) { g_s.backgroundAlpha = a; }

bool IsOpen() { return g_open; }
void SetOpen(bool open) { if (open == g_open) return; if (open) { g_open = true; input::SetBlocking(true); g_mx = g_s.texW * 0.5f; g_my = g_s.texH * 0.5f; } else Close(); }

} } } // namespace vrkit::menu::core
