#!/usr/bin/env python3
"""Runs the mod's run-time discovery (src/engine.cpp, src/game.cpp, src/scan.cpp) offline against a game exe and prints what it
finds. Use it on a new game build before playing:  python3 verify_signatures.py <path to Game_f_x64_EOS.exe>
Needs: pip install pefile"""
import re, struct, sys
import pefile


def load(path):
    pe = pefile.PE(path, fast_load=True)
    img = pe.get_memory_mapped_image()
    secs = [(s.Name.rstrip(b'\0').decode(errors='replace'), s.VirtualAddress, s.Misc_VirtualSize, s.Characteristics) for s in pe.sections]
    text = next(s for s in secs if s[3] & 0x20000000)
    return pe, img, secs, text


def pattern(p):
    rx = b''
    for t in p.split():
        rx += b'.' if t.startswith('?') else re.escape(bytes([int(t, 16)]))
    return re.compile(rx, re.S)


def scan(img, text, p, maxhits=16):
    lo, hi = text[1], text[1] + text[2]
    return [m.start() + lo for m in pattern(p).finditer(img[lo:hi])][:maxhits]


def i32(img, a):
    return struct.unpack_from('<i', img, a)[0]


def rtti_vtable(img, secs, ib, name, coloff=0):
    data_secs = [s for s in secs if not s[3] & 0x20000000]
    for m in re.finditer(re.escape(name.encode() + b'\0'), img):
        td = m.start() - 16
        for cm in re.finditer(re.escape(struct.pack('<I', td)), img):
            col = cm.start() - 12
            if col < 0 or col % 4:
                continue
            sig, off, cd, tdr, cdr, selfr = struct.unpack_from('<IIIIII', img, col)
            if sig == 1 and off == coloff and tdr == td and selfr == col:
                for vm in re.finditer(re.escape(struct.pack('<Q', ib + col)), img):
                    if vm.start() % 8 == 0:
                        return vm.start() + 8
    return None


def main(path):
    pe, img, secs, text = load(path)
    ib = pe.OPTIONAL_HEADER.ImageBase
    ok = True
    print(f'exe: {path}\n  timestamp {pe.FILE_HEADER.TimeDateStamp:08x}, code exe+{text[1]:x} size {text[2]:x}')

    vt = rtti_vtable(img, secs, ib, '.?AVPerspectiveView@rend@@')
    gp = None
    if vt:
        gp = struct.unpack_from('<Q', img, vt + 16)[0] - ib
        print(f'  PerspectiveView vtable exe+{vt:x}, getProjection exe+{gp:x}')
    else:
        h = scan(img, text, '48 89 5C 24 08 57 48 83 EC ?? F3 0F 10 81 ?? ?? ?? ?? 48 8B DA 0F 5A C0')
        print(f'  PerspectiveView RTTI NOT found; getProjection pattern hits {len(h)}')
        gp = h[0] if len(h) == 1 else None
    if gp is None:
        print('  FAIL: no getProjection'); return False
    at = img.find(b'\xF3\x0F\x10\x81', gp, gp + 0x24)
    if at < 0:
        print('  FAIL: getProjection has no lens load'); return False
    fov = i32(img, at + 4)
    fn = img[gp:gp + 0x220]
    checks = [(b'\xF3\x0F\x10\xBF', 8, 'aspect'), (b'\xF3\x0F\x5C\x87', 0xC, 'near'), (b'\xF3\x0F\x10\x8F', 0x10, 'far'), (b'\xF3\x0F\x10\x87', 4, 'zoom')]
    passed = [n for op, d, n in checks if op + struct.pack('<i', fov + d) in fn]
    print(f'  lens fields at +{fov:x}; layout checks passed: {len(passed)}/4 {passed}')
    if len(passed) < 2:
        print('  WARN: FOV override would be disabled'); ok = False

    for name, field in (('setFov', fov), ('setAspect', fov + 8)):
        h = scan(img, text, 'F3 0F 11 89 ' + ' '.join(f'{b:02X}' for b in struct.pack('<i', field)) + ' 66 C7 81 ?? ?? ?? ?? 00 00 C3')
        print(f'  {name}: {len(h)} hit(s)' + (f' at exe+{h[0]:x}, dirty word +{i32(img, h[0] + 11):x}' if len(h) == 1 else ''))

    a = scan(img, text, '48 8B C4 48 81 EC ?? ?? ?? ?? F3 0F 10 81 ?? ?? ?? ?? 48 8D 50 ?? F3 0F 10 89 ?? ?? ?? ?? 0F 5A C0 0F 5A C9')
    found = []
    for p in a:
        x0, x1 = i32(img, p + 14), i32(img, p + 26)
        if x1 != x0 + 4:
            continue
        for q in range(p + 30, p + 0x200):
            if img[q] == 0xE8 and img[q + 5:q + 8] == b'\x48\x81\xC4':
                t = q + 5 + i32(img, q + 1)
                print(f'  applyTransform exe+{p:x} (camera transform +{x0:x}) -> setTransform exe+{t:x}')
                found.append(t)
                break
    b = scan(img, text, '48 89 5C 24 08 48 89 7C 24 10 55 48 8B EC 48 83 EC ?? 48 8B 02 48 8D 99 ?? ?? ?? ?? 48 89 81 ?? ?? ?? ?? 48 8B F9')
    print(f'  setTransform prologue pattern hits: {[hex(x) for x in b]}')
    if not found and not b:
        print('  FAIL: no setTransform'); ok = False

    # ---- game hooks (src/game.cpp)
    def has_str(t):
        return img.find(t.encode() + b'\0') >= 0
    tweaks = ['Camera:Near', 'Camera:FOV', 'TAA:Jitter Scale', 'TAA:Resolve', 'Cinematic Effect:Vignette', 'Vector Blur:Enable',
              'Vector Blur:Force Enable', 'Camera:High Pos', 'Camera:Mid Pos', 'Camera:Low Pos', 'Camera:Safe Pos']
    switches = ['TAA', 'Antialiasing', 'Render Vector Blur', 'Film grain', 'Enable Film Grain d3t', 'Use Umbra', 'Cinematic Mode', 'VSync Enabled']
    miss = [t for t in tweaks + switches if not has_str(t)]
    print(f'  tweakable / switch names present: {len(tweaks) + len(switches) - len(miss)}/{len(tweaks) + len(switches)}' + (f' missing {miss}' if miss else ''))
    ft = scan(img, text, '48 8D 0D ?? ?? ?? ?? E8 ?? ?? ?? ?? 8B 15 ?? ?? ?? ?? 0F 57 FF 4C 8B 05 ?? ?? ?? ?? 41 0F 28 F1 F2 0F 5A F8', 4)
    print(f'  frame timer (synchronized stereo): {len(ft)} hit(s)' + (f' at exe+{ft[0]:x}, Timer::lap exe+{ft[0] + 12 + i32(img, ft[0] + 8):x}' if len(ft) == 1 else ' - synced falls back to alternate eye'))
    lim = scan(img, text, 'F3 44 0F 10 05 ?? ?? ?? ?? 45 0F 57 C9 41 0F 2F C1 76 ?? F3 0F 10 0D', 4)
    print(f'  game frame limiter jump: {len(lim)} hit(s)' + (f' at exe+{lim[0] + 17:x}' if len(lim) == 1 else ''))
    for m in ('.?AVGameMode@@', '.?AVMenuMode@@', '.?AVLoadingMode@@', '.?AVVideoMode@@', '.?AVCreditsMode@@'):
        v = rtti_vtable(img, secs, ib, m)
        print(f'  {m:20s} ' + (f'update (slot 6) exe+{struct.unpack_from("<Q", img, v + 48)[0] - ib:x}' if v else 'NOT found'))
    ms = rtti_vtable(img, secs, ib, '.?AVModeSwitch@@', 8)
    fs = img.find(b'ModeSwitch: Focus Event - %s Focus\n\0')
    fok = False
    if ms and fs >= 0:
        fn = struct.unpack_from('<Q', img, ms + 15 * 8)[0] - ib
        fok = any(img[q] in (0x48, 0x4C) and img[q + 1] == 0x8D and q + 7 + i32(img, q + 3) == fs for q in range(fn, fn + 0x40))
        print(f'  focus handler ModeSwitch slot 15 exe+{fn:x}: ' + ('confirmed' if fok else 'NOT confirmed'))
    else:
        print('  focus handler: ModeSwitch vtable or string NOT found')
    print(f"  player anchor string: {'found' if has_str('Player    %.2fm/s') else 'NOT found'}")
    # first person: the camera tweakables it forces, and the camera-style switch it hooks (1.33+)
    for nm in ('Safe Area: Tweak enable', 'Safe Area: Tweak X', 'Safe Area: Tweak Y', 'Camera:Catch Amount', 'Camera:Angle', 'Camera:Modern Velocity Horizontal Offset Scale', 'Camera:Modern Central Offset Scale'):
        print(f"  first person tweakable {nm!r}: {'present' if has_str(nm) else 'absent'}")
    def tweak_value(name):   # lea rdx,[name]; lea rcx,[obj]; call -> obj + 0xB0
        so = img.find(name.encode() + b'\0')
        if so < 0: return None
        lo, hi = text[1], text[1] + text[2]
        for m in re.finditer(rb'\x48\x8D\x15(....)\x48\x8D\x0D(....)\xE8', img[lo:hi], re.S):
            a = lo + m.start()
            if a + 7 + i32(img, a + 3) == so: return a + 14 + i32(img, a + 10) + 0xB0
        return None
    def riprefs(target):
        lo, hi = text[1], text[1] + text[2]; out = []
        for i in range(lo + 1, hi - 8):
            if img[i - 1] & 0xC7 != 5: continue
            d_ = i32(img, i)
            if any(i + 4 + e + d_ == target for e in (0, 1, 4)): out.append(i - 1)
        return out
    mo = tweak_value('Camera:Modern Central Offset Scale')
    if mo:
        mid, ang = tweak_value('Camera:Mid Pos'), tweak_value('Camera:Angle')
        found = None
        for r in riprefs(mo):
            f = r
            while f > r - 0x2000 and not (f % 16 == 0 and img[f - 1] in (0xCC, 0xC3)): f -= 1
            if any(f < q < f + 0x600 for q in riprefs(mid)) and any(f < q < f + 0x600 for q in riprefs(ang)): found = f; break
        print(f"  camera-style switch (first person keeps its values): " + (f'exe+{found:x}' if found else 'NOT found'))
    else:
        print("  camera-style switch: no modern camera style in this build (pre-1.33)")

    # 0.4.0: render snapshots, frame-time averaging ring, camera pivot height, cinematic-moment camera
    pv = rtti_vtable(img, secs, ib, '.?AVPerspectiveView@rend@@')
    if pv:
        cl = struct.unpack_from('<Q', img, pv + 8)[0] - ib
        print(f"  view clone (slot 1) exe+{cl:x}: " + ('copies the lens fields' if img.find(b'\x8B\x87', cl, cl + 0xC0) >= 0 else 'NOT confirmed'))
    if len(ft) == 1:
        p0 = ft[0]; cnt = p0 + 18 + i32(img, p0 + 14); arr = p0 + 28 + i32(img, p0 + 24)
        idx = size = None
        for q in range(p0 + 28, p0 + 0x140):
            if idx is None and img[q:q + 3] == b'\x48\x63\x05': idx = q + 7 + i32(img, q + 3)
            if idx is not None and size is None and img[q:q + 2] == b'\x3B\x0D': size = q + 6 + i32(img, q + 2); break
        okr = idx is not None and cnt == idx + 4 and size == idx + 8 and arr == idx + 16
        print(f"  frame time averaging ring: " + (f'exe+{idx:x} (index, count, size, array)' if okr else 'NOT confirmed'))
    ph = scan(img, text, '49 8B CE E8 ?? ?? ?? ?? 48 8B C8 E8 ?? ?? ?? ?? F3 0F 10 4D ?? 4C 8D 4C 24 ?? F3 0F 58 C8', 4)
    if len(ph) == 1:
        a = ph[0] + 8 + i32(img, ph[0] + 4); b = ph[0] + 16 + i32(img, ph[0] + 12)
        print(f"  camera pivot height: exe+{ph[0]:x} -> character +{i32(img, a + 3):x} -> +{i32(img, b + 4):x}")
    else: print(f"  camera pivot height: {len(ph)} hits")
    mi = tweak_value('Cinematic Moment:Melee Camera In')
    found = None
    if mi:
        for r in riprefs(mi):
            k = img.find(b'\x0F\x28\xD6\x48\x8B\xD7\xE8', r, r + 0x60)
            if k >= 0: found = (k + 6, k + 11 + i32(img, k + 7)); break
    print("  cinematic-moment camera: " + (f'call exe+{found[0]:x} -> exe+{found[1]:x}' if found else 'NOT found'))

    # 0.7.0: camera shake controller Apply, renderer view render (native stereo research)
    sh = scan(img, text, '48 8B 8F ?? ?? ?? ?? 48 8D 54 24 ?? E8 ?? ?? ?? ?? 48 8D 54 24 ?? 48 8B CF E8', 8)
    st = scan(img, text, 'F3 0F 11 51 ?? F3 0F 11 49 ?? C7 41 ?? 00 00 00 00 C3', 8)
    applies = set()
    if st:
        tf = img[st[0] + 12]
        for q in sh:
            f = q + 17 + i32(img, q + 13)
            if any(img[z] == 0xF3 and img[z + 1] == 0x0F and img[z + 2] == 0x10 and img[z + 3] & 0xC7 == 0x41 and img[z + 4] == tf for z in range(f, f + 0x40)): applies.add(f)
    print("  camera shake Apply: " + (f'exe+{list(applies)[0]:x}' if len(applies) == 1 else f'NOT unique ({len(applies)})'))

    pe.parse_data_directories(directories=[pefile.DIRECTORY_ENTRY['IMAGE_DIRECTORY_ENTRY_IMPORT']])
    imps = {e.dll.decode().lower(): [i.name.decode() if i.name else i.ordinal for i in e.imports] for e in pe.DIRECTORY_ENTRY_IMPORT}
    bink = imps.get('bink2w64.dll', [])
    print(f"  Bink video imports: {[n for n in ('BinkOpen', 'BinkClose', 'BinkNextFrame') if n in bink]}")
    print(f"  imports dbghelp.dll: {'dbghelp.dll' in imps} {imps.get('dbghelp.dll')}; dxgi: {imps.get('dxgi.dll')}; d3d12: {'d3d12.dll' in imps}")
    if 'dbghelp.dll' not in imps:
        print('  NOTE: the exe does not import dbghelp.dll - install with an ASI loader (dxgi.dll / winmm.dll) as an .asi')
    # head aim (src/headaim.cpp)
    ha = {k: scan(img, text, v, 4) for k, v in {
        'update': '48 89 5C 24 10 55 56 57 41 54 41 55 41 56 41 57 48 8D AC 24 50 80 FF FF B8 B0 80 00 00 E8',
        'origin': '48 8D 56 0C 49 8B CF E8', 'angles': '48 8D 4D D0 E8 ?? ?? ?? ?? F2 0F 10 45 E8 F2 0F 11 46 18',
        'limits': 'F3 0F 10 0D ?? ?? ?? ?? F3 0F 10 1D ?? ?? ?? ?? F3 0F 59 CB 0F 2F C8 76 07 F3 0F 11 4E 28 EB 1C F3 0F 10 15',
        'set': 'F2 0F 10 02 4C 8B C9 48 83 C1 18 4D 8D 41 24 F2 0F 11 01 8B 42 08 49 8D 51 28 89 41 08 E9',
        'cam1': 'E8 ?? ?? ?? ?? 48 8B C8 48 8D 54 24 ?? E8 ?? ?? ?? ?? 48 8B C8 4C 8D 85 ?? ?? ?? ?? 48 8D 55 ?? E8',
        'cam2': 'E8 ?? ?? ?? ?? 48 8B C8 48 8D 54 24 ?? E8 ?? ?? ?? ?? F3 44 0F 10 B7'}.items()}
    dl = scan(img, text, '48 89 5C 24 08 48 89 6C 24 10 48 89 74 24 18 57 48 83 EC 40 49 8B D8 0F 29 74 24 30 4D 8B 01 48 8B F2 48 8B E9', 4)
    mc = scan(img, text, '45 8B 86 D4 00 00 00 41 8B 96 D8 00 00 00 41 8B 8E E8 00 00 00 41 8B 86 EC 00 00 00 41 83 BE DC 00 00 00 02 74')
    sp = scan(img, text, 'B9 01 00 00 00 E8 ?? ?? ?? ?? B9 00 00 40 00 E8')
    print('  main thread scratch pad 4 MB (raised to 16 MB for true stereo): ' + (f'exe+{sp[0]+10:x}' if len(sp) == 1 else f'{len(sp)} hits'))
    lr = scan(img, text, '48 89 5C 24 08 48 89 74 24 10 48 89 7C 24 18 55 41 56 41 57 48 8D AC 24 10 FD FF FF 48 81 EC F0 03 00 00 48 8B F9 E8')
    print('  LoadResolution (headset size into the game settings): ' + (f'exe+{lr[0]:x}' if len(lr) == 1 else f'{len(lr)} hits'))
    mm = scan(img, text, '44 8B 47 20 8B 44 24 54 8B 54 24 50 44 3B C2 72 21 8B 4F 24 3B C8 72 1A 8B 44 24 44 8B 54 24 40 44 3B C2 77 04 3B C8 76 20 89 47 24 8B 44 24 48 EB 07')
    print('  display largest-mode clamp (lifted with it): ' + (f'exe+{mm[0]:x}' if len(mm) == 1 else f'{len(mm)} hits'))
    print('  resolution.xml monitor-size clamp (lifted when the mod sets the size): ' + (f'exe+{mc[0]:x}' if len(mc) == 1 else f'{len(mc)} hits - a size above the monitor is cut'))
    print('  DLSS evaluate (upscaler): ' + (f'exe+{dl[0]:x}' if len(dl) == 1 else f'{len(dl)} hits (optional)'))
    hok = all(len(v) == 1 for v in ha.values())
    print('  head aim: ' + ', '.join(f'{k} ' + (f'exe+{v[0]:x}' if len(v) == 1 else f'{len(v)} hits') for k, v in ha.items()) + (' - OK' if hok else ' - PROBLEMS'))
    ok = ok and hok
    print('  RESULT:', 'OK' if ok else 'PROBLEMS (see above)')
    return ok


if __name__ == '__main__':
    if len(sys.argv) < 2:
        print(__doc__); sys.exit(2)
    sys.exit(0 if all(main(p) for p in sys.argv[1:]) else 1)
