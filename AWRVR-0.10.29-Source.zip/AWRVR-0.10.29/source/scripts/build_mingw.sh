#!/bin/bash
# Builds build/dxgi.dll (x64; the same file also works renamed to dbghelp.dll or as an .asi) with mingw-w64, e.g. on Linux:  apt install mingw-w64 && scripts/build_mingw.sh
set -e
cd "$(dirname "$0")/.."
CXX=${CXX:-x86_64-w64-mingw32-g++}; CC=${CC:-x86_64-w64-mingw32-gcc}; STRIP=${STRIP:-x86_64-w64-mingw32-strip}
mkdir -p build/obj
V=third_party/vrkit; I=$V/third_party/imgui
INC="-Ithird_party/openxr/include -Isrc/xrhost -Ithird_party/minhook/include -Ithird_party/xrbridge/include -I$V -I$I -Isrc"
FL="-O2 -D_CRT_SECURE_NO_WARNINGS -DWIN32_LEAN_AND_MEAN -DNOMINMAX -D_WIN32_WINNT=0x0A00 -Wall -Wno-unknown-pragmas -Wno-unused-function"
OBJS=()
for f in third_party/minhook/src/buffer.c third_party/minhook/src/hook.c third_party/minhook/src/trampoline.c third_party/minhook/src/hde/hde64.c; do
  o=build/obj/$(basename $f .c).o; $CC $FL -w $INC -c $f -o $o; OBJS+=($o)
done
for f in src/*.cpp src/xrhost/*.cpp; do
  o=build/obj/$(basename $f .cpp).o; $CXX -std=c++17 $FL $INC -c $f -o $o; OBJS+=($o)
done
for f in third_party/xrbridge/src/client/client.cpp $V/vrkit_input.cpp $V/vrkit_menu.cpp $V/vrkit_menu_core.cpp \
         $V/vrkit_options.cpp $I/imgui.cpp $I/imgui_draw.cpp $I/imgui_tables.cpp $I/imgui_widgets.cpp $I/imgui_impl_dx11.cpp; do
  o=build/obj/$(basename $f .cpp).o; $CXX -std=c++17 $FL -w $INC -c $f -o $o; OBJS+=($o)
done
$CXX -shared -static -static-libgcc -static-libstdc++ -o build/dxgi.dll src/exports.def "${OBJS[@]}" \
  -luser32 -ld3d11 -ldinput8 -ldxguid -ladvapi32 -lshell32 -ld3dcompiler_47 -lkernel32 -lole32 -luuid -lwinmm -ld3d12
$STRIP build/dxgi.dll
# a dxgi.dll proxy must not import dxgi.dll (the import would bind to itself)
if x86_64-w64-mingw32-objdump -p build/dxgi.dll | grep -qi "DLL Name: dxgi.dll"; then echo "ERROR: build/dxgi.dll imports dxgi.dll"; exit 1; fi
ls -la build/dxgi.dll
