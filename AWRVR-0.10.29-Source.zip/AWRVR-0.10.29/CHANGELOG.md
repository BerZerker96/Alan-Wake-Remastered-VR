# Changelog

## 0.10.29 - pixel perfect eyes; true stereo: effects in both eyes, no black flashes

**True stereo**
- Fixed: the right eye flashed black, some effects (lens flares, light glows) were missing from the right eye, and they showed on the HUD panel at a distance instead.
  - In true stereo the eyes are drawn inside the game's renderer view render, and the HUD after it returns. The HUD split took every blended 2D draw from the second eye's first one on as UI, so the game's own late effects were cut out of the right eye. The right eye's picture was also taken at that point, sometimes before the scene was in it, which showed as black.
  - Now nothing drawn inside either eye's render counts as UI. Only the 2D draws after both renders are the HUD.

**Pixel perfect**
- New Eye view setting (Advanced), "Pixel perfect" by default. Each eye is drawn symmetric around its lens axis, so the game's effects are right. The render grows by exactly drawn / shown per side, and the engine widens the frustum to the same exact scale. The part an eye shows is then the headset's own pixel grid, which the compositor copies 1:1 with no resampling.
  - Dream Air: 3420x2668 per eye shown out of a 4354x2668 picture.
  - The strip an eye never shows is drawn at a 16th of the cost by foveated rendering "Unseen".
- The eyes' fields are saved in AWRVR\headset_fov.txt the first time the headset reports them. The exact size applies from the next start.
- The other Eye view choices:
  - Canted: the 0.10.28 view at the headset's size, about 91 % of the headset's density.
  - Matched: the headset's size, about 79 % of the width.
  - Off-centre: the eye's own view, with the effects wrong.
- eye_view replaces the matched_view / canted_view keys, which follow it.

## 0.10.28 - canted eye views: lights, flashlight, flares and shadows right in both eyes (any headset)

**Canted eye views**
- Fixed: in true stereo (and with Matched view off in any method) the flashlight and light sources showed doubled at the sides, and lens flares, some effects and shadows showed in one eye only.
  - The cause: each eye was drawn with its own off-centre frustum (the Dream Air shows tangents -1.61..0.92). Part of the game's renderer works only from the view's symmetric fov and aspect, not from the off-centre projection: the light culling and volumetrics, flares, and screen-space shadows. The PerspectiveView getters at exe+4637a0 / exe+463aa0 / exe+463b00 / exe+463340 have 20+ callers.
- New default, canted_view: each eye gets a symmetric frustum turned (yaw, then pitch, in the eye's own frame) to the middle of that eye's field.
  - The game's own projection is symmetric again, so every effect is right in both eyes.
  - The compositor turns each eye's directions into the canted picture when it cuts the eye out. The HUD placement and the foveated-rendering zones follow the same turn.
- Works for any headset: asymmetric left / right and up / down fields, and canted displays (the turn is relative to the eye pose the runtime gives). tests/test_cant checks Dream Air, Quest 2 / 3, Index, Varjo-like and Pimax-canted fields. On each, the game camera's turn and the compositor's mapping agree to 1e-4.
- At the headset's own render size, the picture the eye shows is:

  | Headset | Canted | Matched view |
  |---|---|---|
  | Dream Air | 91 % | 79 % |
  | Quest 2 | 89 % | 78 % |
  | Index | 96 % | 93 % |
  | canted displays | 91 % | 69 % |

  An off-centre picture shows 100 % but draws the effects wrong.
- Matched view now applies only when canted views are off.

**Diagnostics**
- The setup check no longer reports nvngx_dlssg.dll, which ships with the game. Frame generation is detected by measurement instead.
- The config list no longer reports 1.00 against a default of 1.0 as a difference.

## 0.10.27 - true stereo by default; the framework's warnings and fixes; the window kept at the render size

**True stereo**
- True stereo is the default method for new installs and in the packaged config.
- Confirmed in game by the player: no crash, and the ground is drawn.
- Not fixed yet:
  - the flashlight and volumetric light are drawn offset;
  - a slight dark flicker in the right eye (under investigation).

**Render size**
- Fixed: the game rendered 3420x2135 after 7 s (0.10.26 log). Windows cut the window, which is taller than the 2160-line desktop, to the screen, and the game resized its swap chain to the cut client area.
- The game window now gets a larger size limit (WM_GETMINMAXINFO). Its client area is set back to the render size if anything cuts it (checked every second).

**Framework "Warnings and Fixes" (everything except stereo reconstruction)**
- **SETUP CHECK.** Logged with the 10 s report when the result changes, and every 5 minutes while there is anything. Problems are ERROR lines in ===== frames. The panel status line shows "SETUP: n problems (log)". It checks for:
  - motion smoothing / half rate (the runtime's period against the headset's full rate), with an ERROR the moment it starts;
  - other mod files next to the exe (proxy DLL names, *.asi in the folder, scripts\, plugins\);
  - other mods and tools loaded in the game (ReShade, OpenXR Toolkit, Special K, UEVR, vorpX, frame generation, OptiScaler...);
  - overlays that hook rendering (RTSS / Afterburner, Discord, OBS game capture, EA app);
  - AWRVR installed twice (the second copy writes its path into a named mapping and stays off);
  - AWRVR loaded through a loader under another name;
  - a cropped field of view (under 75 degrees);
  - upscaling, a low render scale, or a render size under the one set;
  - TAA or DLSS with an eye-alternating method;
  - changed stereo settings (swap_eyes, ipd_scale, world_scale).
- OpenXR API layers are listed once as not loaded: AWRVR's in-process host loads the runtime directly, so they never reach it.
- **Diagnostics:**
  - A run header. The previous run's logs are kept as awrvr.prev.log / xrhost.prev.log.
  - A system summary: OS, CPU, RAM, HAGS, Game Mode, monitor, store / exe, runtime / headset, GPU / driver / VRAM.
  - The settings that differ from the defaults, and every option change as "key: old -> new".
  - A crash report: exception, module + offset, registers, code addresses on the stack, mod state, flushed. Installed at start and again after 30 s.
  - VRAM OVER BUDGET, LOW FPS FOR THIS MODE, UNCAPPED FRAME RATE IN VR, and HEALTH every 60 s.
  - Panel View page: "Mark an issue in the log" (USER MARK #n) and "Make a report folder" (both logs, both previous logs, the config, the headset file).
- **Synchronized:** the first eye no longer waits forever for its twin. When the game clock stops while 3D is drawn, or 4 first eyes in a row get no twin, the eyes alternate frame by frame. The change is logged.
- **HUD layer:** a layer picked 24 frames in a row is kept at any draw count while it is drawn after the 3D scene. With only subtitles on screen it has 1 draw, and dropping it put the subtitles at the wrong depth.
- **Panel:** every frame-rate setting (uncapped, FPS limiter, headset refresh rate, foveated rendering, render scale) is now in one "Performance" group on the first tab (View).
- **README:** "Read this before playing or reporting" after Install. The ReShade-chaining tip is removed, because ReShade is a setup problem.

## 0.10.26 - true stereo: the ground (likely fix)

- True stereo turned the game's occlusion culling (Umbra) off, because Umbra reuses the last frame's visibility. Without it, the renderer takes its plain frustum-culling path: the RenderView core at exe+5095dd checks the Umbra switch and calls exe+4befa0, or exe+4bf850 when it is off. The ground (terrain) was missing in both eyes in true stereo, and the most likely cause is that path.
- New option "Occlusion culling in true stereo" (true_stereo_occlusion, Graphics page), on by default: true stereo now keeps the game's occlusion culling. If objects pop in and out between the eyes, turn it off. The ground would then likely be missing again.
- Not yet confirmed in game.

## 0.10.25 - true stereo: the scratch-pad leak; Matched view off by default

**True stereo**
- Fixed: the "Scratch pad is full" error, now with 16 MB, which the 0.10.24 log captured.
  - The log showed the main thread's pad growing by about 1.5 MB every 10 s (0.9 to 16.2 MB in 70 s) until it was full. Its use at the end of each frame was always 0.
  - The pad works as a stack. The caller of RendererRenderView frees what the one render it asked for left behind. True stereo renders twice, so the first render's leftovers sat under the second's and were never taken back.
  - After the first render, the pad is now put back to where it was before that render. This only happens when every block above that point belongs to the first render, which the mod checks by walking the block list.
  - The 10-second report counts the blocks taken back.
- Not fixed yet: the ground mesh missing in true stereo.

**Matched view**
- Matched view is now off by default and in the packaged config. Each eye is drawn for exactly what it shows, so at the headset's 3420x2668 the eye gets 100 % of the headset's pixel density, against about 79 % horizontally with Matched view.
- Culling still uses the wide view covering both eyes (wide_cull), so nothing is culled at the edges.
- An existing awrvr_config.txt keeps its own setting: switch it in the panel (Advanced > Matched view) or use the packaged config.

## 0.10.24 - diagnosis: true stereo stops the game; pixel density in the log

- True stereo still stops the game. The second true-stereo frame raises one of the game's fatal errors on the main thread and its error box ends the game, with the same stack as in 0.10.22. The 16 MB scratch pad didn't change that, so this is probably a different error, but the log had no text for it.
- The text of every game error box now goes to the log ("message box '...': ..."), together with every thread's scratch pad use.
- The scratch pads (exe+d25940: size, last frame, most used) are also listed in every 10-second report.
- New log line when it changes: the tangents each eye shows, the tangents of the drawn picture, and the share of the headset's pixel density the shown part gets. With Matched view, about 79 % horizontally and 100 % vertically on the Dream Air. With Matched view off, both are 100 %.

## 0.10.23 - fix: true stereo stopped the game ("Scratch pad is full")

- Fixed: true stereo could stop the game with the error box "Scratch pad is full (trying to allocate 524292 bytes, total size 4194304)".
- The game gives its main thread a 4 MB scratch pad, a frame allocator that is reset once per frame. It is made at exe+347781, through ScratchPadInit at exe+3c2fa0.
- True stereo renders the main view twice in one frame, so a busy frame needs about twice that.
- The size is raised to 16 MB at load, before the game makes the pad. That uses 12 MB more memory and changes nothing else. The log confirms it with "game: the main thread's scratch pad 4 MB -> 16 MB".

## 0.10.22 - fix: crash at start (0.10.21)

- Fixed: 0.10.21 crashed right after the resolution step. It started the whole VR host while the game's main thread was held. The host's D3D11 device creation stalled until the 3 s limit, then ran alongside the game's own start-up, and the game crashed. The VR host now starts at its usual place again.
- The first start (no AWRVR\headset.txt) still gets the headset's resolution. While the game's read of its settings is held (at most 14 s), a short OpenXR query of its own (instance, system, view size, then destroyed) asks for it, with no graphics and no session. That takes about 70 ms against a stand-in runtime.
- With a saved size nothing is asked at that point: zero wait. A different headset is noticed by the VR host and used from the next start.

## 0.10.21 - the headset's resolution on the very first start

- Like the other mods on this framework: the game's LoadResolution (exe+1d0120) is hooked, and the VR host starts there, on the game's main thread, before the game reads its settings. The read is held until the host reports the headset's recommended size. On a first start (no AWRVR\headset.txt) that is up to 14 s; with a saved size it is up to 3 s, so a different headset is used at once.
- The size is saved and resolution.xml is written. After the game's read, the size and Windowed are also set in its settings directly. That covers a first start where resolution.xml did not exist yet and the game made a default one at the monitor's size.
- The first start now renders at the headset's resolution, and VR comes up sooner on every start.
- README: the headset must be on, with its VR software running, before the game is launched.

## 0.10.20 - render size = the headset's, in one start

- The render size is exactly the headset's recommended per-eye size × render scale again (3420x2668 on the Dream Air). It applies at the start it is written, because the size is already known from AWRVR\headset.txt. The 0.10.19 growth (drawn / shown ratio, measured in VR, applied at a second start) and its density.txt are removed, along with the "Pixel density" option. A 4352-wide size left in resolution.xml by 0.10.19 is written back to the headset's size at the next start.
- Only the very first start with a new headset still needs a restart, because the size isn't known until the runtime reports it.

## 0.10.19 - full pixel density; foveated rendering you can't see

**Sharper picture**
- Matched view (the default) draws each eye's picture symmetric around its lens axis. On the Dream Air, an eye shows tangents -1.61 .. 0.92 of a picture drawn at -1.61 .. 1.61, so the picture is 1.27 x wider than what you see.
- Until now, the picture was rendered at only the headset's per-eye size. The part you see got 79 % of the headset's pixel density, and the compositor stretched it 1.27 x. That was the remaining softness.
- With render_density = headset (the default), the render size now grows by exactly drawn / shown on each side. The ratio is measured in VR for the current view settings and kept in AWRVR\density.txt. It applies at the next start: about 4350x2668 on the Dream Air.
- "fixed" keeps the old size. "sharp" is now the same as "headset".

**Foveated rendering**
- New "unseen only" level: each eye gets its own shading-rate image, coarse (4x4) only where that eye never looks. That is about a fifth of the picture with matched view, so nothing you see changes. It is the default for new installs and offsets part of the cost of the larger render.
- The other levels add their zones on top of that. There is no more dithering: 0.10.18's dithered border showed as a faint pattern over the picture.
- The full-detail zone now reaches about 40, 35 and 29 degrees from the lens axis in quality, balanced and performance, where the lenses are already soft.
- The log lists each eye's shown part of the picture.

## 0.10.18 - foveated rendering without the ring

- Foveated rendering no longer shows a ring at the zone borders. The shading rate used to jump in one hard step (1x1 to 2x2 to 4x4) along a circle. That circle was visible wherever you looked, in every mode except Off.
- The rate now falls in smaller steps: 1x1, 2x1, 2x2, then 4x2 and 4x4 in Balanced and Performance.
- Between two steps, each tile picks the finer or the coarser rate with a probability that follows its distance from the centre, using a fixed noise pattern. The game's TAA blends those mixed tiles, so there is no edge left to see.
- The zone sizes and the GPU savings stay about the same. The "show zones" debug option still draws hard edges.

## 0.10.17 - the full headset size, second clamp; always windowed

- Fixed: the game still rendered 3840x2160 in 0.10.16. It cuts the render size down to the monitor in a second place, the display setup at exe+1e0170, which runs after the settings clamp that 0.10.16 lifted. There, a size larger than the monitor's largest display mode on either side is replaced by that mode. That branch now keeps its refresh rate but leaves the size alone. Both clamps are lifted only when the mod sets the render size.
- The game now always runs windowed. A number in resolution.xml's window_mode (0 Fullscreen, 2 Borderless) is set to 1 (Windowed) at every start while "Always windowed" is on, which it is by default. Exclusive fullscreen and Alt+Enter were already refused.
- The flat window can be taller than the desktop. Windows may cut the window frame to the screen. That doesn't change the render size, because the game takes it from its settings, and the window's client area is only used to map the mouse.

## 0.10.16 - the headset's full render size reaches the game

- Fixed: the game rendered at the monitor's size, not the headset's. The game cuts the size in resolution.xml down to the monitor's size after reading it. In Borderless (window_mode 2) it replaces the size with the monitor's outright. Found at exe+1ce7d8. So 3420x2668 per eye on a 3840x2160 desktop came out as 3840x2160, and the eye images were stretched from 2160 lines to 2668. The mod now lifts that clamp at load, but only when it sets the render size itself (render_resolution = auto or WxH). With render_resolution = game, the game's own size is untouched.
- New log warning when the game's render size still differs from the size the mod wrote.
- Fixed: a false "frame generation is on" warning in the main menu. The menu ticks the game far less often than it presents, so frame generation is now measured during gameplay only.

## 0.10.15 - the panel key can never be unbound
- **Open / close this panel** has no x. It always shows its built-in keys, **INSERT** and **PAD L3+R3**, as
  keycaps, and they always work. Left and right click do not clear it.
- You can still add one more key or button (A / click). Y removes that extra one, never the built-in ones.

## 0.10.14 - an unbind button on every hotkey
- **Hotkeys tab:** every hotkey has a round **x** in front of its keys. It clears the action's keyboard and controller
  bindings together, and is styled like the panel's keycaps (dark grey, red when pointed at).
  - Mouse: click the x.
  - Controller: Left moves onto the x (it glows red), A unbinds, Right / Up / Down leave it. A on the keys still sets
    a new binding, and Y still restores the default.
  - The x is dimmed when there is nothing to unbind. The controls line at the bottom shows these keys on the Hotkeys
    tab.
- **Screenshot defaults to Delete.** It was already the built-in default; it is now also written into the config
  (`hotkey_screenshot = DELETE`), including the packaged `awrvr_config.txt`.

## 0.10.13 - a VR config in the package
- **`mod\awrvr_config.txt`** is now included, with **head aim: always** and **the VR panel at its lowest opacity
  (0.25)**. Everything else is the default. Copy it next to the game with `dxgi.dll`. New installs without that file
  get the same two defaults.
- **No second start needed for the resolution.** The mod writes `resolution.xml` while it loads, before any of the
  game's own code runs, so the first start already uses the headset's size. The install note no longer asks for a
  restart.

## 0.10.12 - fixes from the headset log
- **Head aim did nothing** (log: `aim turned 0` in every report, also with *Always*). Head aim only took the
  camera frame from a view whose type is `.?AVPlayerCamera@@`. In this game the view that is drawn is the render
  camera, `.?AVBaseCamera@@`; the PlayerCamera is a separate view the game never draws. So head aim never had a
  camera frame and never switched on. It now takes the frame from the drawn view.
  - New log line: aim updates per report, and how many of them had no VR camera or the aim button up.
- **The resolution was never written** (log: `screen_resolution entry not understood` and
  `game render size 3840x2160`). The game writes `<screen_resolution> <width value="3840"/> <height value="2160"/>`,
  and the reader cut the entry at the first `/>`, after the width. Values in a `value` attribute are now read, the
  entry ends at its closing tag, and a new test uses this exact layout.
  - After the next start the game renders at the headset's size (3420x2668 on the Dream Air) instead of 3840x2160 -
    sharper, and the right shape.
- **Frame generation false alarm** (log: `FRAME GENERATION is on (its module is loaded, 0.00 Presents per game
  frame)`). The NVIDIA driver / app can load `nvngx_dlssg.dll` for any game. Frame generation is now reported only
  when it is measured: more Presents than game frames. A loaded module is only listed.

## 0.10.11 - the game's resolution scale
Searched the exe for any render scaling apart from DLSS:
- **Resolution scale: yes.** It is a Graphics menu setting (saved as `resolutionscale`, debug name
  `g_fRenderScale`). The slider maps to slider / 10 + 0.5, so 50 - 150 % of the output. It is used only while DLSS is
  off: render size = output x scale, and the game's TAA path scales the 3D up (above 100 % it supersamples). The 3D
  targets are created at that size, as with DLSS.
- **Dynamic resolution: none.** The render size is only written by the DLSS manager, the resize and the scale above,
  never per frame by a heuristic. The "DLSS.Get.Dynamic..." names belong to the NGX SDK.
- **Other:** *Cinematic Render: Supersampling Mode* is a developer tweak for the game's offline cinematic rendering.
  *TripleHead resolution* is for multi-monitor setups. Neither affects VR play.
- **The mod copes with the resolution scale.** Scene depth and foveated rendering follow the render size from 33 % to
  200 % of the output. The log shows the scale with the 3D render size, and the panel status shows e.g. *scale 80%*.
- **Note:** the mod's own *Render scale* (the game's output size, which the game applies at its next start) and the
  game's resolution scale multiply. The log shows both sizes.

## 0.10.10 - DLSS traced through the exe
How the game runs DLSS (1.33 Epic addresses; all found by signature, details in NOTES.md):
- **Settings:** the Graphics menu's *DLSS Mode* (Off, Ultra Performance, Performance, Balanced, Quality, DLAA) is one
  global. The renderer's DLSS manager compares it, the output size and the render size every frame, and recreates the
  NGX feature when one changes.
- **Render targets:** the 3D targets are created at the render size, as separate textures (not a sub-rectangle of
  full-size ones). This is why the mod's render-size handling (scene depth, foveated rendering) works by texture size.
- **Jitter:** with DLSS on, the renderer takes its own jitter path, a Halton sequence whose length follows the scale.
  It does not use the TAA switch or *TAA: Jitter Scale*, and the game clears the TAA switch itself while DLSS runs.
  DLSS also does not depend on the TAA switch to get its motion vectors and history.
- **Evaluate parameters checked** against the parameter names the helper sets: +0x08 Output, +0x18 Depth, +0x20
  MotionVectors, +0x28 / +0x2C jitter, +0x30 / +0x34 render size, **+0x38 Reset**, +0x3C MV scale. The game always
  passes Reset = 0, so the mod's *fresh image each eye* is the only reset.

Changes:
- **The mod never forces TAA / jitter while DLSS is on.** That includes *Game anti-aliasing: On*, which would have
  fought the game clearing the switch every frame. The game's DLSS mode counts as "upscaler active" at once, without
  waiting for the first evaluation.
- **The log shows the game's DLSS setting,** the 3D render size and the output size every report. The panel status
  shows e.g. *DLSS Quality*.

## 0.10.9 - upscalers (DLSS / DLAA, FSR / XeSS through OptiScaler) and frame generation
The game has DLSS built in (NVIDIA NGX is linked into the exe). Tools like OptiScaler put FSR or XeSS behind it. An
upscaler draws the 3D smaller than the output, needs the game's jitter, and builds each picture from earlier ones.
Checked and fixed for each:
- **The game's DLSS evaluate is hooked** (found by signature and confirmed by the `Jitter.Offset.X` parameter it
  sets). The log shows the render size, the output size and the evaluations per report. OptiScaler and similar tools
  run behind the same call, so they are seen too. Loaded upscaler and frame-generation modules are listed in the log.
- **Scene depth at the upscaler's render size.** It was only recognised down to half the output size (DLSS
  Performance), now down to a third (Ultra Performance), with the same shape. The HUD-layer rule depends on it.
- **Foveated rendering under an upscaler.** It needed the 3D drawn at the back buffer's size, so it did nothing with
  DLSS. It now has its own shading-rate image for the upscaler's render size, centred correctly for that size.
- **TAA / jitter are no longer switched off while an upscaler is active.** True stereo and *Game anti-aliasing: Off*
  switch them off, but the upscaler needs them. The log says so once.
- **New option (Graphics): Upscaler: fresh image each eye.** With one eye per frame, the upscaler's earlier pictures
  belong to the other eye, which can ghost. On: every evaluation starts fresh (the upscaler's reset flag). Off by
  default.
- **Frame generation** (DLSS-G, FSR frame generation, DLSS-G-to-FSR mods) makes frames no camera drew, which breaks
  VR. It is detected by its modules and by Presents per game frame, logged as a warning and shown in the panel's
  status line: *FRAME GENERATION ON - turn it off*.
- **Unaffected:**
  - the UI is drawn at the output size after the upscaler, as before;
  - the eye pictures, the picture without the UI and the true-stereo first eye are all output size;
  - matched view uses the game's own projection, so the jitter is kept; the off-centre patch keeps it too;
  - the resolution file is the output size.

## 0.10.8 - head aim: the aim path traced through the exe
I traced every reader and writer of the player's aim in the exe (details in NOTES.md).

**Who uses the aim:**
- The aim object is reached only through its getter and small accessors; nothing else touches it directly.
- Readers of the direction:
  - the TailCamera update (the player camera), which reads it twice;
  - ThrowFlashbangAction and TakenThrowAction (throws);
  - DropFlareAction;
  - Character slots 78 / 79 (where Alan looks / turns);
  - PlayerInputReader slot 25.
- Readers of the aim point:
  - PlayerInputReader slot 16, the aim point getter. It hands over a locked target first when there is one.
  - The PlayerInputReader input handler.

**Fixed:**
- **The aim origin stayed at the eyes after the update.** The ray is still cast from the eyes. Afterwards the game's
  own origin (Alan's shoulder) goes back into the object, and the direction runs from the shoulder through the
  head-aimed point. Arms, throws, flares and where Alan looks now all point at what you look at, not parallel to it.
- **PlayerInputReader slot 25 turns the aim direction and sets it again**, which also sets the camera's angles. While
  the direction held the head's, the camera could have jumped to the head. That slot is now guarded: it turns the
  game's own direction.
- **The game setting the aim direction itself** (camera transitions, cutscene ends) is noticed. The camera's reads are
  no longer replaced with an older direction until the next aim update.

**Checks:**
- **Proof by data flow at start-up:** PlayerInputReader's vtable slot 5 must be `mov rcx,[rcx+0x50]; jmp <the hooked
  aim update>`. The log line `headaim: PlayerInputReader vtable ...` confirms it.
- **Log per report:** which code read the head-aimed direction and the aim point (exe addresses, busiest first),
  guarded turns and game sets. The next log shows exactly what uses the head aim while you shoot.
- **New unit test case:** origin back at the shoulder, direction through the aim point, and a close point keeps the
  head direction.

## 0.10.7 - head aim
- **Head aim** (Camera tab, at the top): the gun, the flashlight beam, Alan's arms and aim assist go where you look.
  The camera and the view never turn with it. It works in third and first person.
  - Modes: off / always / **while aiming** (default). "While aiming" means while L2 / LT on any XInput pad, L2 on
    DirectInput pads, or the right mouse button is held.
  - Options: *Head aim smoothing* (a time-based tremor filter; stick and mouse turns are never delayed) and *Aim from
    the eyes* (the aim ray starts where your eyes are drawn, not at Alan's shoulder, so it hits what you look at).
  - A hotkey to cycle the mode is on the Hotkeys tab (unbound).
- **How it works,** from the exe:
  - The game keeps the player's aim in one object (PlayerInputReader +0x50). It holds the aim point, the origin (a
    point on Alan's shoulder), the direction, yaw and pitch.
  - Once a frame the game turns yaw / pitch by the stick / mouse / assist, clamps the pitch (*Aim: Min / Max
    Vertical Angle*), builds the direction, casts a ray and stores the hit as the aim point. The player camera looks
    along the direction.
  - Around that update the mod gives the game the head's angles. The game builds the direction and the ray where the
    head looks, from the eyes.
  - Afterwards the angles go back to the game's own plus this frame's stick turn, and the player camera's two reads
    of the direction get the game's own direction, so the camera does not turn with the head.
  - The game's own functions do the angle maths, so its conventions are kept exactly.
- **Safety:**
  - Every part is found by signature and checked; if one is missing, head aim stays off and the log says why.
  - A run-time check compares the game camera with the head-aimed direction. If the camera turns with the head
    anyway, head aim falls back to the aim point only and logs it.
  - Log per report: aims turned, camera reads kept, origins at the eyes, the head vs game aim angle, and the camera
    check.
- New unit test `tests/test_headaim.cpp`. It runs a fake game with the real method and checks that:
  - the aim follows the head;
  - the camera's angles are unchanged;
  - stick turns reach the camera in the same frame;
  - the pitch limits hold;
  - the blend, the eye origin and the smoothing work.
  `tools/verify_signatures.py` checks the head aim signatures.

## 0.10.6 - new VR panel look
- **Fonts after the game's own UI:** the menus of Alan Wake Remastered use a condensed sans in capitals and its
  manuscript pages a typewriter face. The panel now uses:
  - Oswald (condensed capitals) for the title, tabs and section heads;
  - Barlow Semi Condensed for the options and help;
  - Special Elite (typewriter) for the status line.
  The fonts are built into the mod, so the panel looks the same on every PC. They are under the SIL Open Font
  License / Apache 2.0; the licences are in `source/third_party/vrkit/fonts`.
- **Same colours as before:** a black panel, dark-grey framed cards and dark-blue tabs. What is selected or switched
  on is light blue.
- **Top bar:** the title is on the left. The fps, stereo method, game state and version are on the right, before the
  round close button.
- **On / off options are toggle switches.** Numbers show a small slider of where they sit in their range, all in one
  column.
- **Hotkeys and controls:** hotkeys show as keycaps, and the controls line at the bottom draws each key as a keycap.
- **Actions are pill buttons.** *Restart* is marked in tracked capitals.

## 0.10.5 - audit: all features, true stereo stability
**True stereo.** The game's renderer draws the view once per eye. What its own code needs was checked again in the
exe:
- The view render takes exactly the four arguments the hook passes on; its fifth value is made inside.
- The resources it releases belong to the renderer and are only rebuilt when a setting changes, not on every call, so
  the second call frees nothing the first eye still uses.

Found and fixed:
- **Textures written by the game's own command lists were freed at once on a resize.** A list the game had
  already recorded could still copy into them, writing freed GPU memory (device removed = freeze / crash). They are
  now kept for 8 more frames before they are freed.
- **The game moving the camera while an eye was being drawn** would have put the centre view back halfway through
  that eye. The eye's own transform is now kept (counted in the log).
- **A broken camera record** (NaN or degenerate matrix) is never drawn from; that frame is drawn normally and counted.
- **GPU device lost:** detected and logged with the reason. If true stereo was running, it starts off at the next
  start (choose it again to retry).
- **No wait can hang on a lost GPU** (one GPU query wait had no time limit; now 0.5 s).
- **New log diagnostics** for the next headset test:
  - command lists submitted while each eye renders;
  - back-buffer work recorded on other threads;
  - camera moves during an eye;
  - broken records.

**Other features:**
- Render size changes are written once the settings have been still for 1.5 s, so dragging the *Render scale*
  slider no longer rewrites the file on every step.
- A null queue from the game is ignored safely.
- The log label "recon:" (a leftover from the removed reconstruction) now reads "capture:".
- Static analysis (clang-tidy bugprone + clang analyzer, clang -Wall -Wextra) finds no other issues in the mod's own
  code.

## 0.10.4 - new panel cursor
- **A modern cursor for the VR panel:**
  - Shape: a slim dart, flashlight white at the tip shading to lamp amber at the wings.
  - Glow: soft, follows the dart's shape and breathes slowly; it gets brighter and warmer over anything you can
    click (tabs, rows, the close button).
  - Contrast: a thin dark rim and a light shadow keep it readable over the bright game behind the see-through panel.
  - The panel's blue appears as a short accent line.
  - Clicks: the dart shrinks slightly while the button is held, and a fading amber ring ripples out from the tip.

## 0.10.3 - checked against the GOTGVR issue report
Every issue in the GOTGVR report (0.6.17 - 0.6.29) was looked for in this mod. Found and fixed:
- **Render size grew with matched view (GOTGVR Q.1 / Q.2).** Since the 0.10.2 resolution fix, matched view would
  really have rendered 1.3x wider - about 30 % fewer fps. Matched view now renders at the headset's own size (as you
  played it in 0.9 - 0.10.1). The growth is an option: *Pixel density -> Sharp* (1.25x). Head mode and *one symmetric
  view* still grow, as before. When a setting changes the size, it is written again at once **in both directions**,
  so switching an option off brings back the headset's size (the game applies it at its next start).
- **Synchronized: the held tick had a time step of ~0 (GOTGVR Q.3).** In GOTG this made characters lose momentum
  (speed = distance / time). The second eye's tick now steps 1/32 of its time (at most 4 ms, invisible between the
  eyes); the rest is paid back on the next tick, and the game's own limits count both, so the speed-hack test is still
  exact at x0.01 - x20.
- **Near plane written into the view (GOTGVR Q.5: depth and lighting disagreed).** The mod wrote a closer near into
  the camera's lens field. It no longer does; a closer near only goes through the game's own *Camera:Near* setting,
  which the game applies everywhere. A possible cause of missing shadows / AO.
- **HUD layer rules (GOTGVR Q.5: effect buffers taken as the HUD destroyed shadows).** A layer is only taken as the
  HUD if it has at least 2 draws and is bound after the last pass that uses the scene depth.
- **Flat screen / theater placed at the recentre point (GOTGVR Q.3: black loading screens).** It now opens in front
  of your head and follows lazily (only after you turn more than 40 deg or move more than 0.5 m).
- **Controllers after closing the panel (GOTGVR Q.6).** The game got a pad back as soon as *one* pad was released;
  now only when every controller is released.
- **LB and LB+Y both bound (GOTGVR Q.6).** LB fired first, then LB+Y. Now only LB+Y fires; LB alone fires when it is
  released. New test case.
- **Config folder not writable (GOTGVR Q.5).** Config, log, headset cache and screenshots fall back to
  `%LOCALAPPDATA%\AWRVR` (your config is copied there), and the log says why.
- **Code found by section flags (GOTGVR Q.5).** Every executable section of the exe is searched (this exe has two).
- **Frame limiter patch:** restoring it writes back the exe's own byte, not a fixed one.

Already correct here (checked): culling readers get the covering frustum, the picture stays exact; HUD on each eye's
optical axis; VRS only in depth passes; idle-sway lock; the fps cap follows a steady lower refresh after 20 s; no
launcher, OpenXR starts with the game; panel keys never fire hotkeys while it is open; mouse / key releases pass
through; DirectInput read without XInput; no slider drag in this panel. Not applicable: libScePad (this exe only
imports XInput).

## 0.10.2 - audit: 3D modes, tracking, performance
- **The render resolution was never applied.** All three `resolution.xml` files found in your log reported
  "was 0x0": their `screen_resolution` entry has no `width=` / `height=`, so nothing was written. The game kept
  rendering 3840x2160 (16:9) for 3420x2668 eyes - too few lines vertically, a softer picture. The entry is now read in
  any layout (`3840x2160`, `w=` / `h=`, `x=` / `y=`, child elements - the first two sizes standing together, never a
  refresh rate) and the log shows the entry's text. New test `tests/test_resparse.cpp`. It takes effect at the next
  start, as before. With matched view the render is about 1.3 x wider than an eye (what each eye's symmetric view
  needs); lower *Render scale* if the frame rate drops.
- **Tracking: the comfort filters stepped about 7 times per frame.** The game sets its camera that often per frame
  (your log: 6441 camera sets for 867 frames). The stabiliser, settle and head-bob filters and the turn-speed estimate
  (camera reprojection, "turn the older eye") treated those as samples 0.1 ms apart, which caused small jitter and a
  noisy turn speed. They now step once per game frame, with the frame's real time step and the last camera the game
  set.
- **Performance, from your log:**
  - Synchronized draws a pair every 2 game frames: about 43 pairs/s at 87 game fps, below the Pimax's 72 Hz, so the
    runtime dropped to 48 Hz.
  - Alternate eye (which you found good) sends a new eye every game frame.
  - True stereo aims at a pair every game frame.
  - The README now says which method to use for the frame rate.

## 0.10.1 - audit: hotkeys (keyboard, mouse, controllers) and true stereo
- **True stereo:**
  - The first-eye copy no longer happens when the back buffer is bound - the engine may bind it before its barrier,
    so the copy's state change could be invalid (device removed = freeze / crash). It now happens at the first draw,
    clear or barrier, where the state is known.
  - The first eye only counts as captured if its render really wrote the back buffer that frame; else the picture
    would be a stale one.
  - This game writes its final picture by **copy**: new CopyResource / CopyTextureRegion hooks take the first eye
    straight from the copy's source, checking size and format first (16 D3D12 hooks).
  - The log says how the back buffer was written in each eye (binds / copies) and how often the first eye was skipped.
- **Hotkeys, keyboard:**
  - Key names that contained the separators (`NUM+`, `,` ...) are now words (`NUMPLUS`, `COMMA` ...).
  - A key without modifiers also fires while Shift / Ctrl / Alt are held (sprinting), unless another binding uses
    exactly those.
  - A changed `recenter_key` / `fp_key` / `screenshot_key` now really is the default that Y restores.
- **Hotkeys, mouse:**
  - The middle and side buttons can be bound.
  - A right click cancels listening.
  - Button releases always reach the game, so a button held when the panel opens no longer sticks.
  - The cursor is centred when the panel opens, so no movement is lost at a screen edge.
- **Hotkeys, controllers:**
  - Combos win over their parts, and the game does not see a combo while all its buttons are held.
  - DirectInput controllers: axes (triggers, pedals, sticks past 60 %) and a second hat can be bound. Controllers are
    added and removed without touching the others (their resting positions are kept).
  - Non-XInput controllers can now navigate the VR panel (PlayStation layout).
- New test `tests/test_hotkeys.cpp`: 109 bindings round-tripped, the first-person action and its End default checked.

## 0.10.0 - true stereo back, hotkeys tab, mouse in the panel
- **True stereo is back** (`vr_mode = native`). Removing it in 0.9.0 was a mistake - only reconstruction should have
  gone. Changes against 0.8.1:
  - With matched view, each eye's lens fields are set before its render, so culling, shadows and every screen-space
    effect are computed for that eye (no patched matrix).
  - The game's occlusion culling (Umbra, which reuses the last frame's visibility) is off while it runs, together with
    TAA and motion blur.
  - The first-eye capture only uses whole-resource, non-split barriers.
  - **Protection:**
    - A marker file is written when the first eye pair is drawn and removed after 600 good pairs or at a clean exit.
      If it is still there at the next start, true stereo stays off (synchronized is used, logged and shown as
      "Synced - fallback") until you choose it again.
    - The first three eye pairs are logged step by step, written to disk at once.
    - A watchdog reports an eye render that has not returned after 2 s, with the render thread's instruction pointer
      and the exe addresses on its stack.
    - Crashes during an eye render are logged with their address.
  - 14 D3D12 hooks again (ClearRenderTargetView for the capture).
- **Hotkeys tab:** about 25 functions can be bound to any keyboard key (with Ctrl / Shift / Alt) and / or any controller
  button or combo, including **first person**.
  - Controllers: XInput pads on all four slots and other controllers through DirectInput (re-scanned every 5 s).
  - Bound with A / Enter / a click, then the key or button (Esc cancels). Right click / Left clears, Y restores the
    default.
  - Saved at once as `hotkey_<name>`. Only the six functions that had keys come with defaults (F9, End, F8, F7, F6,
    Delete). A key you had changed in `recenter_key` / `fp_key` / `screenshot_key` becomes that hotkey's default.
  - Hotkeys do not fire while the panel is open.
- **Mouse in the VR panel:** while the panel is open the mouse moves the panel's own cursor:
  - click changes or runs an option, picks a tab or closes the panel;
  - right click goes back a value or clears a hotkey;
  - the wheel scrolls, or adjusts the value under the cursor.
  - The mouse is kept from the game while the panel is open and the game is in front (no turning or shooting).
  - The cursor is a warm flashlight-white arrow with a soft lamp glow, a dark outline, a drop shadow and a line in the
    panel's blue. A close button sits at the top right, and the hint line switches to the mouse controls while you use
    the mouse.
- The panel's gamepad navigation reads every connected XInput pad, not only the first one.

## 0.9.0 - first headset test fixes
- **Removed true stereo and stereo reconstruction** - both froze and crashed the game. Configs that chose them are moved
  to synchronized once (logged); their settings are removed.
- **Matched view (new default, `matched_view = true`):** each eye is drawn with the symmetric frustum around its lens
  axis, and the game's own projection is used unchanged - the lens fields that culling, shadows and the screen-space
  effects read now describe exactly the picture. Fixes the flashlight glow and volumetric lights showing copies at the
  sides, and is aimed at the missing-looking shadows / ambient occlusion, the white rectangle during the focus zoom and
  the side-by-side flash in QTEs (all screen-space passes that read the fields). `matched_view = false` = the old
  off-centre view.
- **Foveated rendering:** only the solid, depth-writing geometry is coarsened - fog, particles, volumetric light and
  full-screen passes stay at full rate, so the zones no longer show as see-through rings. The zones are centred on the
  lens (with matched view the lens centre is the picture centre).
- **Cheat Engine speedhack, any speed:** the mod's own clock (head pose filters, frame pacing, the fps limiter, the
  headset host, timeouts, logs) reads ntdll's NtQueryPerformanceCounter, which speed hacks leave alone. Synchronized
  stereo lets the game step as far per tick as it would per frame without the mod, so the world moves exactly at the
  hacked speed (unit test from x0.01 to x20); its held step is paid back, so very slow speeds stay exact too. New test
  `tests/test_realclock.cpp` patches kernel32's QueryPerformanceCounter / GetTickCount the way Cheat Engine does.
- **First person:** defaults eye height 0.60 and Eye Z 0.60 (measured in the headset). Configs still on the old
  defaults (1.68 / 0.12) are moved once (logged); values you set yourself stay.
- **HUD = scale** falls back to the game's safe area when the HUD is baked into the picture (no separate HUD draws seen
  on this build), so it stays inside both eyes' views.
- **Log spam fixed:** the scene-depth pick flipped every frame between the scene depth and a 8192x4096 shadow map
  (2886 log lines in one session). Only back-buffer-shaped depth counts now, changes need 30 frames.
- README rewritten (short, with icons). Credits and notes no longer mention other VR mods.
- 13 D3D12 hooks again (the true-stereo ClearRenderTargetView hook is gone); the reconstruction compute shaders are
  gone, so every shader also compiles with Wine / Proton's built-in compiler.

## 0.8.1 - audit: true stereo, view modes, HUD, menu, theater
- **Swap eyes now works in every method.** Before, it only changed which eye synchronized / alternate eye drew first
  (each image still went to its own eye) and did nothing in reconstruction and head mode. Now every image goes to the
  other eye together with the pose and view it was made for.
- **True stereo:**
  - Repeated frames are no longer counted as "first eye not captured", so they cannot cause a false fallback.
  - The HUD panel is always used (HUD placement *Game layout* used to remove the HUD).
  - TAA / motion blur are only switched off while true stereo draws 3D, not during the theater or flat screen.
  - The safe-area HUD inset is not applied in true stereo (its panel shows the full layout).
- **When a method falls back** (true stereo → synchronized, synchronized → alternate eye), the game switches that
  belong to the method now in use are applied at once. Before, a fall back from true stereo to synchronized left the
  game's frame-time averaging untouched, so the eyes were not from the same moment.
- **HUD panel:**
  - Placed at *UI depth* in every case (true stereo put it at the menu's distance).
  - Sized by *UI scale*: the same size in your view as the scaled HUD (it used to take the menu's panel width).
  - *UI height* moves it by the same fraction of the view as the scaled HUD (it used to be read as metres).
  - With panels drawn into the picture, the same size and height.
- **This mod's menu:**
  - Always at *This menu's distance* / width while it is open, also with HUD placement = panel (it used to be pulled to
    UI depth).
  - On the flat screen and in the theater it keeps its size in your view. At theater size 100° it used to be ~19 m wide.
  - New *This menu's opacity* option (Screen tab), applied at once.
- **Reconstruction:** the comfort fade now covers it too, and *Picture width / height* apply as in the other methods.
- New shader `PSFade` (checked with DXC and Wine's compiler).

## 0.8.0 - true stereo
- **New 3D mode: True stereo** (`vr_mode = native`, experimental). The game's renderer draws the scene twice per frame,
  once from each eye: real depth, full world update rate, both eyes from the same frame.
  - The renderer's per-view render (RendererD3D12 slot 10, exe+508970) is hooked by a real detour (the 0.7 diagnostic
    thunk is gone). It is confirmed by its code: view kept in r14 and its own matrix update called on it.
  - Each eye gets its transform through the game's setTransform and its off-centre projection through getProjection
    (lazy matrices forced to rebuild); the view is put back to the centre afterwards.
  - The first eye's picture is copied on the GPU when the second eye first touches the back buffer (barrier, clear or
    bind - new ClearRenderTargetView hook, 14 D3D12 hooks now). The copy textures are made only when the mode is used.
  - UI detection ignores the first eye's passes and restarts for the second; the HUD goes on its panel.
  - TAA and motion blur are off while it runs (restored after; `game_aa = on` overrides).
  - Automatic fallback to synchronized, with the reason in the log and the panel status line.
- Panel: *True stereo (experimental)* in Stereo method (F8 cycles it too); the status line shows `True stereo` or
  `Synced - fallback`. Shorter help text so it fits the help box.
- Your existing settings are not changed: synchronized stays the default.
- The verifier checks the true stereo entry (view in r14 + matrix update).

## 0.7.0
- **Cutscene theater:**
  - In-game cutscenes (detected by the game's `CinematicCamera` class) and pre-rendered cinematics (Bink) play on a
    cinema screen.
  - New Screen-tab options: Theater size (40–170°), Theater distance and Fade in and out.
  - Cutscenes can stay 3D instead (`cutscene_mode = 3d`).
- **Camera shake fix:**
  - The game's `CameraShakeController::Apply` (exe+172db0) is hooked. It runs on a copy of the camera, and the mod keeps
    the `camera_shake` fraction (default 0 = no shake in VR).
  - Found by the camera manager's call shape and confirmed by the shake controller's own timer field.
- **Native stereo research:**
  - The renderer's per-view render (RendererD3D12 slot 10) is identified.
  - A register-preserving diagnostic records views per frame, view identity and thread (`stereo research:` log line),
    to decide whether a second-eye render is workable.
- The verifier checks the shake Apply and the renderer entry.

## 0.6.0 - store and version agnostic
- **Fallbacks for every byte-exact hook,** each finding the same code by what it does:
  - frame timer: a timer call followed by the load of its averaging ring (count, array = count + 12);
  - dt ring: derived from the count;
  - camera pivot height: the getter pair `mov rax,[rcx+d]; ret` / `movss xmm0,[rcx+d]; ret` near the player camera code;
  - action camera: the call whose float argument is set right before it;
  - focus handler: the method printing its focus log line, in any ModeSwitch vtable and slot;
  - tweakables and renderer switches: their registration shape, not fixed registers.
- **New test:** `tests/make_variant_exe.py` changes the primary patterns the way a rebuilt exe might differ. On that
  copy the fallbacks find the same functions, and the tolerant index resolves all 27 tweakables / switches identically.
- **Store:**
  - The game is recognised by name (`Game_f_x64*`) or, if renamed, by its contents (`AlanWakeRemastered\`).
  - `resolution.xml` is also searched in Saved Games, AppData and the game folder.
  - No store service is used. (The Remastered is sold on PC through the Epic Games Store.)
- Includes the 0.5.0 changes (tracking verified, HUD exact record, safer UI split, Game safe area HUD, world-up eye
  height).

## 0.5.0 - tracking, HUD and first person re-checked against the exe (built, not released separately)
- **Tracking verified.** `applyTransform` hands `Node::setTransform` the camera's world transform (right / up /
  forward rows, then position). setTransform stores it at +0x248 / +0x1E8 with no parent multiply and
  re-orthonormalises it (exe+15da10). That is the layout and handedness the head pose is composed into. setTransform's
  6 callers are all covered, since the function itself is hooked.
- **HUD - eye record:** UI scaling now uses the exact per-frame record of the snapshot the render thread rebuilt, so
  the HUD converges for the eye actually being drawn.
- **HUD - safer auto split:** only blended, depth-less 2D draws into the final image count as UI. The game's HUD is
  HUDMode atlas sprites and text; a second opaque post pass into the back buffer is no longer taken for HUD.
- **New HUD mode "Game safe area":**
  - It enables the game's own safe area ("Safe Area: Tweak enable / X / Y", read by getSafeArea exe+1e0710 for 59
    HUD, subtitle and menu layout callers) with VR insets.
  - The game lays out the HUD nearer the centre at full sharpness; the mod only moves it to each eye's centre.
  - The player's values are restored when another mode is chosen.
- **First-person eye height along world up:** the camera offsets tilt with the camera's pitch, so the eye-height
  difference is now added along world up on the PlayerCamera only (cutscene cameras untouched). The offset is the
  fallback.

## 0.4.0 - the 3D path re-checked against the exe
- **Fixed: alternate eye and synchronized could show both eyes with the same projection.**
  - The game rebuilds a view's projection only when its projection-dirty flag is cleared (exe+46c120 via exe+46c500 /
    46c890). With wide culling the lens fields never change, so the per-eye off-centre projection was not recomputed.
  - The flag is now cleared for every new eye.
  - The rebuilt projection uses the record of the transform it is paired with, not a thread / frame-count guess.
- **Fixed: synchronized did not freeze the world for the second eye.**
  - The game steps the world by the average of the last 4 frame times (exe+1df8d0), so holding the timer's lap still
    moved the world a full frame.
  - While synchronized, the average is now 1 frame long, and the mod writes it together with the lap.
  - Modelled from the disassembly and tested: 11.2 ms → 0.1 ms.
- **Render snapshots:**
  - The game clones the camera view for the renderer every frame (vtable slot 1, shared by all camera classes). The
    mod tags each clone with its eye and forces it to rebuild, so the renderer's projection is that eye's.
  - When that happens on the Present thread, the eye at Present is matched exactly, and the pipeline lag is measured
    (used for the frame-count fallback).
- **Fixed: main-camera selection.** It counted getProjection calls, which are lazy (only on a lens change), so a still
  camera could be dropped after 2 s. It now uses the per-frame clones. The still-camera refresh moved to the clone too.
- **First person: Eye height.** The camera pivot is Alan's feet plus a per-character height (character → +0x1C0 →
  +0xD0, read in the camera update). `fp_eye_height` (default 1.68 m) puts the eye there; Eye Y is now a fine-tune
  (default 0).
- **New option `action_cameras`** (default off in VR): skips the dodge / melee / throw cinematic-moment camera swing
  (exe+29bdb0 called from the moment code only). The slow motion stays.
- **Research:**
  - The getProjection matrix layout was confirmed element by element.
  - TAA jitter is a matrix multiplied after getProjection, so it survives the patch.
  - Culling builds its frustum from the lens getters (exe+475180).
  - OrthoView and CustomView share the field offsets but are other views.
- **Tests:**
  - `test_syncclock.cpp`.
  - The verifier checks the clone, the ring, the pivot height and the action camera.
  - The Wine discovery finds all of them.

## 0.3.0
- **Now a dxgi.dll.** The game's `CreateDXGIFactory` import binds to the mod's own export, so no import patching is
  needed.
  - The DLL exports the full DXGI set (forwarded to System32) plus the dbghelp set, so renaming it to `dbghelp.dll`
    still works.
  - `dxgi_chain.dll` next to the game chains another dxgi mod, such as ReShade.
  - The mod never imports dxgi.dll itself; the build checks this.
- **First person, redone from the game's camera code (1.33):**
  - It now also switches off the camera's trailing (`Camera:Catch Amount`), the shoulder toe-in (`Camera:Angle`, which
    yawed the view by about 7°) and the modern style's sideways shift.
  - The values are re-asserted every second.
  - The game's camera-style switch, which rewrites these tweakables, is hooked so it works on the player's values.
  - New `fp_near_clip` option (default: the game's own 0.2 m, which hides the inside of the head).
  - The log shows the eye height above Alan's node.
- **Comfort filters: no lag any more.**
  - The camera shake filter and the head-bob filter are now trend-following. Walking, running and turning used to lag
    10–20 cm and several degrees; steady motion is now followed exactly.
  - The bob filter acts on height only.
- **Forced game values follow the game.** If the game changes a value while the mod forces it (its options menu, the
  camera style), the new value is the one restored later.
- **HDR:**
  - `hdr_input = auto` (the new default) follows the game's swap-chain colour space via `SetColorSpace1`. 1.33 renders
    SDR in 10-bit too, so the back-buffer format alone doesn't show HDR.
  - The misleading 10-bit warning is gone.
- **VR panel restyle:**
  - Dark and see-through, with dark-blue tabs, white text and thin dark-grey frames.
  - Framed option groups with separators between rows, a serif title and a framed help box.
  - Scrolling by whole rows.
  - Readable names for every choice.
  - New offline preview renderer.
- **Fixed:**
  - In dxgi.dll mode the init thread deadlocked. Creating the throw-away D3D12 device made d3d12.dll call the mod's
    CreateDXGIFactory, whose hook re-entered the D3D12 hook lock. A per-thread re-entry guard fixes it; this was found
    by the new D3D12 Wine test.
  - The reconstruction statistics buffer is now a typed `RWBuffer` (portable).
- **Tests:**
  - New D3D12 render-loop test through the proxy (Wine + vkd3d + lavapipe) and a dxgi-mode load test.
  - The verifier checks the first-person tweakables and the camera-style switch.
  - Filter lag tests.

## 0.2.0
- **One DLL**: the XrBridge OpenXR host is now a thread inside the game (`host_mode = thread`), using a small OpenXR
  loader: the registry `ActiveRuntime` key, then manifest, then negotiation; API layers are logged. Logs go to
  `AWRVR\xrhost.log`. The separate exe is optional (`host_mode = exe`).
- **Five stereo methods**: synchronized (new default: the main-loop timer is held so both eyes come from one tick),
  stereo reconstruction (new: depth splat + gap fill compute shaders), alternate eye, head and screen. F8 cycles them.
- **Projection**: each eye uses its own off-centre frustum (patched into getProjection). Culling uses a wide symmetric
  view (`wide_cull`). Also new: `cull_margin`, `near_clip`, `view_width` / `view_height`, `symmetric_view`,
  `units_per_metre`, and eye alignment options.
- **Game hooks found by scanning**:
  - ~1,450 tweakables and ~124 renderer switches
  - the frame timer and the game's frame limiter
  - Game / Menu / Loading / Video / Credits modes
  - the focus handler and the player global
  - Bink video imports
- **D3D12 hooks** (13 entry points on a throw-away device): HUD split (auto / count / all, with a layer picker),
  HUD scale into each eye with convergence, HUD panel, hide HUD, depth capture for reconstruction, and fixed foveated
  rendering (VRS tier 2: quality / balanced / performance / custom).
- **Comfort**: camera shake filter, idle-sway lock, head-bob filter, decoupled pitch (now on by default).
- **First person** via the game's camera position tweakables, with eye offsets (End).
- **Flat screen** for pause menus / loading (from the game's mode), video cutscenes (Bink size) and F6.
- **Effects**: motion blur, film grain, vignette, TAA (game / off / on) and occlusion culling are switched while the
  mod runs and never saved. Optional: game frame cap off, no cutscene black bars (test).
- **Pacing**:
  - headset-rate limiter (`fps_limit`, `fps_unlocked`)
  - refresh detection with Pimax undivide, remembered per headset
  - full-rate / runtime / repeat smoothing
  - `max_frame_latency`, vsync off, tearing where allowed
- **Desktop and output**: left-eye mirror, edge fill, sharpening, HDR input (PQ / scRGB, paper white), screenshots
  (PNG, headset or full view).
- **Start-up**: windowed mode forced (exclusive fullscreen and Alt+Enter refused); render size from the headset, with
  pixel density for wide views.
- **VR panel**: six tabs with labelled sections, help texts on every option, rows filtered by method, a status line,
  and Frame rate at the top of Advanced.
- **Config**: `config_version`, with a logged migration of 0.1 configs.
- **Logs**: `camera:`, `xr:`, `perf:`, `ui:`, `recon:` and `game:` summaries every 10 s.
- **Tools**: `verify_signatures.py` checks every new signature; the Wine discovery test runs GameScan; new comfort and
  refresh unit tests; shader compile test.
- **Fixed**:
  - a race when two threads installed the D3D12 hooks
  - focus-string check (the string ends with a newline)
  - mirrored-frame roll in the comfort filters

## 0.1.0 (first build)
- dbghelp.dll proxy (the exe imports dbghelp.dll; forwards 85 dbghelp exports to System32), also usable as an .asi.
- Version-agnostic discovery: rend::PerspectiveView by RTTI, lens fields read from getProjection's code, FOV / aspect
  setters by run-time patterns, node setTransform via BaseCamera::applyTransform, DXGI through the exe's import table.
- Camera: game camera x headset eye pose in the node transform of the rendered view only; feedback guard; still-camera
  refresh; decoupled pitch with a measured world-up axis; camera offsets; world scale; rotation-only option.
- Lens: the rendered view gets the headset's symmetric field of view (covering both eyes, optional margin); the game's
  lens is restored in screen mode.
- Stereo by alternate-eye rendering with a frame ring (eye + pose per Present), auto / manual frame lag, swap eyes;
  head-tracked mono; flat screen for frames without the game camera (menus, loading, videos).
- D3D12 back buffer -> shared texture -> D3D11 (shared fences, CPU fallback) -> XrBridge keyed-mutex atlases.
- vrkit in-headset menu (View / Camera / Display / Screen), F8 mode, F9 recentre.
- Optional render size from the headset (resolution.xml, with backup).
- Tools: verify_signatures.py, Wine smoke tests, math unit tests.
